# -*- coding: utf-8 -*-
"""
Created on Thu Jun  8 07:33:33 2023

@author: psch9wyc
"""
import pandas as pd
import openpyxl
import json #TODO: can be delted if handover function is created check if needed for output

# global variables
rivet_lib_file_name = '../temp_Input_db/Rivet_Lib_Test.xlsx'

class Concession_Basics:
    
    def __init__(self, concession_id : str, msn : int):
        self.concession_id = concession_id
        self.MSN = msn
    
##################################################
###             EDGE KDF FORMULAS              ### 
##################################################      
    def get_e_to_d(self, e, d):
        return e/d
    
    def get_edge_KDF(self, mat, edge_distance, fasteners, analysis_type):
        assert mat.material_type == "Metal" or mat.material_type == "Composite", f'material type of {mat.name} is neither metal nor composite, but {mat.material_type}'
        if analysis_type == "Concession Case":
            fastener_1 = fasteners["nominal"]
            fastener_2 = fasteners["concession"]
        elif analysis_type == "Concession + R2 Case":
            fastener_1 = fasteners["adjacent"]
            fastener_2 = fasteners["adj_R2"]
        if mat.material_type == "Metal":
            return self.get_metal_edge_KDF(mat, edge_distance, fastener_2)
        elif mat.material_type == "Composite":
            return self.get_composite_edge_KDF(edge_distance, fastener_1, fastener_2)

            
    def get_metal_edge_KDF(self, mat, edge_distance, fastener):                          
        e_d = self.get_e_to_d(edge_distance, fastener.diameter)
        assert e_d >= 1.0 , f'e/d is lower than 1.0! No theory available!'
        Rbru_1_5 = mat.Rbru_1_5
        Rbru_2_0 = mat.Rbru_2_0
        if e_d >= 2.0:
            return 1.0
        elif e_d >= 1.5:
            return  (Rbru_1_5 + (Rbru_2_0 - Rbru_1_5) / 0.5 * (e_d - 1.5)) / Rbru_2_0
        elif e_d >= 1.0:
            return Rbru_1_5 * (e_d - 0.5) / Rbru_2_0
    
    def get_composite_edge_KDF(self, edge_distance, fastener_1, fastener_2):
        c_ed_nom = self.get_c_ed(edge_distance, fastener_1)
        c_ed_dev = self.get_c_ed(edge_distance, fastener_2)
        if c_ed_dev >= c_ed_nom:
            return 1.0
        else:
            return c_ed_dev/c_ed_nom
        
    def get_c_ed (self, edge_distance, fastener):
        #Theory from V020RP0818061_v10.0_EXP
        assert fastener.headtype == "CSK" or fastener.headtype == "PAN"
        e_d = self.get_e_to_d(edge_distance, fastener.diameter)
        assert e_d >= 1.5, f'Composite E/D = {edge_distance}/{fastener.diameter} = {edge_distance/fastener.diameter} is less than 1.5! No theory available'
        if fastener.headtype == "PAN":
            if e_d >= 3.0:
                return 1.0
            elif e_d >= 2.0:
                return (0.5 + e_d/6)
            elif e_d >= 1.5:
                return 5*e_d/12
        elif fastener.headtype == "CSK":
            if e_d >= 3.0:
                return 1.0
            elif e_d >= 1.5:
                return e_d/3
            
 ##################################################
 ###             PITCH KDF FORMULAS             ### 
 ##################################################        
    def get_p_to_d(self, p, d):
        return p/d
 
    def get_pitch_KDF(self, mat, pitch_distance, fasteners, analysis_type):
        if analysis_type == "Concession Case":
            average_nominal_diameter = (fasteners["nominal"].diameter + fasteners["adjacent"].diameter)/2
            average_deviation_diameter = (fasteners["concession"].diameter + fasteners["adjacent"].diameter)/2
        elif analysis_type == "Concession + R2 Case":
            average_nominal_diameter = (fasteners["nominal"].diameter + fasteners["adjacent"].diameter)/2
            average_deviation_diameter = (fasteners["concession"].diameter + fasteners["adj_R2"].diameter)/2 #TODO: check if R2 and maximum of R2 and Concession should be considered
        assert mat.material_type == "Metal" or mat.material_type == "Composite", f'material type of {mat.name} is neither metal nor composite, but {mat.material_type}'
        if mat.material_type == "Metal":
            return self.get_metal_pitch_KDF(pitch_distance, average_nominal_diameter, average_deviation_diameter)
        elif mat.material_type == "Composite":
            return self.get_composite_pitch_KDF(pitch_distance, average_nominal_diameter, average_deviation_diameter)
        
    def get_metal_pitch_KDF(self, pitch_distance, average_nominal_diameter, average_deviation_diameter):
        if self.get_p_to_d(pitch_distance, average_deviation_diameter) >= 4.0:
            return 1.0
        else:
            return (pitch_distance - average_deviation_diameter) / (pitch_distance - average_nominal_diameter)
     
    def get_composite_pitch_KDF(self, pitch_distance, average_nominal_diameter, average_deviation_diameter):
        c_wd_nom = self.get_c_wd(pitch_distance, average_nominal_diameter)
        c_wd_dev = self.get_c_wd(pitch_distance, average_deviation_diameter)
        return c_wd_nom/c_wd_dev
        
    def get_c_wd(self, pitch_distance, average_diameter):
        return (2+(1-average_diameter/pitch_distance)**3)/(3*(1-average_diameter/pitch_distance))
        
 ##################################################
 ###             HUTH FACTOR FORMULAS           ### 
 ##################################################  
    def get_huth_factor(self, fasteners, analysis_type):
        if analysis_type == "Concession Case":
            fastener_diameter_nom = fasteners["nominal"].diameter
            fastener_diameter_dev = fasteners["concession"].diameter
        elif analysis_type == "Concession + R2 Case":
            fastener_diameter_nom = fasteners["adjacent"].diameter
            fastener_diameter_dev = fasteners["adj_R2"].diameter
        return (fastener_diameter_dev/fastener_diameter_nom)**(2/3)
  
 ##################################################
 ###             SHIM FACTOR FORMULAS           ### 
 ################################################## 
    def get_shim_KDF(self, mat, shims):
        assert mat.material_type == "Metal" or mat.material_type == "Composite", f'material type of {mat.name} is neither metal nor composite, but {mat.material_type}'
        if mat.material_type == "Metal":
            return self.get_metal_shim_KDF(shims)
        elif mat.material_type == "Composite": 
            return self.get_composite_shim_KDF(shims)
        
    def get_metal_shim_KDF(self, shims):
        c_shim_nom = self.get_c_shim_metal(shims["nominal"])
        c_shim_dev =self.get_c_shim_metal(shims["deviation"])
        return c_shim_dev/c_shim_nom
        
    def get_c_shim_metal(self, shim):
        t_shim_equivalent = self.get_t_shim_equivalent(shim)
        return min(1,1.06 - min(0.7*t_shim_equivalent/shim.part_thickness,0.165)*t_shim_equivalent)      
    
    def get_t_shim_equivalent(self, shim):
        assert shim.nb_fast_load_direction >= 1, "Number of Fasteners in Loaddirection is less than 1"
        if shim.nb_fast_load_direction >= 2:
            return (0.7*shim.t_shim_liq + 0.5*shim.t_shim_sol)
        else:
            return (shim.t_shim_liq + shim.t_shim_sol)
    
    def get_composite_shim_KDF(self, shims):
        c_shim_nom = self.get_c_shim_composite(shims["nominal"])
        c_shim_dev =self.get_c_shim_composite(shims["deviation"])
        return c_shim_dev/c_shim_nom
    
    def get_c_shim_composite(self, shim):
        return (1 - min(0.16*((shim.t_shim_liq + shim.t_shim_sol)/shim.part_thickness),0.08)*(shim.t_shim_liq + shim.t_shim_sol))

 ##################################################
 ###              NON CONFORMITIES              ### 
 ##################################################  

class Non_Conformities:
    def __init__(self, nonconformities_inputs):
        self.deviations = {}
        self.final_output_dict = {}
        self.final_ratio = None
        self.deviation_RF = None
        #create object for each nonconformity
        if "Oversize Fastener" in nonconformities_inputs.keys(): 
            self.deviations["Oversize Fastener"] = Oversize_Fastener(nonconformities_inputs["Oversize Fastener"])
        if "Shim" in nonconformities_inputs.keys():
            self.deviations["Shim"] = Shim_Deviation(nonconformities_inputs["Shim"])
                
    def get_final_ratio(self):
        self.calculate_final_ratio()
        return self.final_ratio
    
    def calculate_final_ratio(self):
        current_ratio = 1.0
        for key in self.deviations.keys():
            self.deviations[key].calculate_KDFs()
            current_ratio = current_ratio * self.deviations[key].get_single_deviation_ratio()
        self.final_ratio = current_ratio
     
    def get_final_deviation_RF(self, nominal_RF):
        self.calculate_final_ratio()
        self.deviation_RF = nominal_RF * self.final_ratio
        return self.deviation_RF
    
    def get_final_output_dict(self, RF_nom = None):
        self.final_output_dict["Deviations"] = {}
        for key in self.deviations.keys():
            self.final_output_dict["Deviations"][key] = self.deviations[key].get_single_deviation_output_dict()
        self.final_output_dict["Final Ratio"] = self.get_final_ratio()
        if RF_nom is not None:
            self.final_output_dict["Nominal RF"] = RF_nom
            self.final_output_dict["Final Deviation RF"] = self.get_final_deviation_RF(RF_nom) 
        return self.final_output_dict
 ##################################################
 ###                 DEVIATIONS                 ### 
 ##################################################             
class Overall_Deviation:
    #def __init__(self):
    #   self.ratio = 1.0
    
    def calculate_single_deviation_ratio(self):
        self.calculate_KDFs()
        self.ratio = 1.0
        for KDF in self.KDFs.keys():
            if KDF == "Huth_Factor":
                self.ratio = self.ratio * 1/self.KDFs[KDF]
            else:
                self.ratio = self.ratio * self.KDFs[KDF]
                
    def get_single_deviation_ratio(self):
        self.calculate_single_deviation_ratio()
        return self.ratio
    
    def get_single_deviation_RF(self, nominal_RF):
        self.calculate_single_deviation_ratio()
        return nominal_RF * self.ratio
    
    def get_single_deviation_output_dict(self):
        self.output_dict["KDFs"] = self.KDFs
        self.output_dict["Deviation Ratio"] = self.get_single_deviation_ratio()
        return self.output_dict
        
class Oversize_Fastener(Overall_Deviation):
    #def __init__(self, con_basics, analysis_type, mat, edge_distance, pitch_distance, fasteners):
    def __init__(self, inputs):
        self.KDFs = {}
        self.output_dict = {}
        self.con_basics = inputs["con_basics"]
        self.analysis_type = inputs["analysis_type"]
        self.mat = inputs["mat"]
        self.edge_distance = inputs["edge_distance"]
        self.pitch_distance = inputs["pitch_distance"]
        self.fasteners = inputs["fasteners"]
        
    def calculate_KDFs(self):
        self.KDFs["E/D_KDF"] = self.con_basics.get_edge_KDF(self.mat, self.edge_distance, self.fasteners, self.analysis_type)
        self.KDFs["P/D_KDF"] = self.con_basics.get_pitch_KDF(self.mat, self.pitch_distance, self.fasteners, self.analysis_type)
        self.KDFs["Huth_Factor"] = self.con_basics.get_huth_factor(self.fasteners, self.analysis_type)
        
class Shim_Deviation(Overall_Deviation):
    #def __init__(self, con_basics, mat, shims):
    def __init__(self, inputs):
        self.KDFs = {}
        self.output_dict = {}
        self.mat = inputs["mat"]
        self.shims = inputs["shims"]
        self.con_basics = inputs["con_basics"]
        
    def calculate_KDFs(self):
        self.KDFs["Shim_KDF"] = self.con_basics.get_shim_KDF(self.mat, self.shims)
    
class Fastener:
    def __init__(self, fast_type, fastener_df):
        self.name = fast_type
        self.diameter = fastener_df.loc[fastener_df["Designation"] == fast_type,"Max Diameter"].iloc[0]
        self.material = fastener_df.loc[fastener_df["Designation"] == fast_type,"Material"].iloc[0]
        self.headtype = fastener_df.loc[fastener_df["Designation"] == fast_type,"Head"].iloc[0]
        
class Material:
    def __init__(self, sheet_material, material_df, material_allowables_df):
        self.name = sheet_material
        self.material_type = material_df.loc[material_df["Material"] == sheet_material, "Material Type"].iloc[0]
        if self.material_type == "Metal":
            self.ref = int(material_df.loc[material_df["Material"] == sheet_material, "UltimateList"].iloc[0])
            self.Rbru_1_5 = material_allowables_df.loc[material_allowables_df["Cluster"] == "REF " + str(self.ref), "Fbru 1_5D"].iloc[0]
            self.Rbru_2_0 = material_allowables_df.loc[material_allowables_df["Cluster"] == "REF " + str(self.ref), "Fbru 2D"].iloc[0]

class Shim:
    def __init__(self, part_thickness, t_shim_liq, t_shim_sol, nb_fast_load_direction):
        self.part_thickness = part_thickness
        self.t_shim_liq = t_shim_liq
        self.t_shim_sol = t_shim_sol
        self.nb_fast_load_direction = nb_fast_load_direction


def get_final_nc_outputs(input_dict_for_backend, concession_basics_input):
    final_nc_output = {}
    
    #set up basic objects
    support_data = {}
    support_data["con_basics"] = Concession_Basics(concession_id = concession_basics_input["fields"]["concession_reference"], msn = concession_basics_input["fields"]["msn"])
    
    support_data["fastener_df"] = pd.read_excel(rivet_lib_file_name, sheet_name = 'Rivet_Library')
    support_data["material_df"] = pd.read_excel(rivet_lib_file_name, sheet_name = 'Material_Library')
    support_data["material_allowables_df"] =pd.read_excel(rivet_lib_file_name, sheet_name = 'Material_Allowables') 
    for nc_input_dict in input_dict_for_backend:
        sub_final_nc_output = {}
        analysis_type = "Concession Case"
        sub_final_nc_output[analysis_type] = get_nc_output_dict(analysis_type, nc_input_dict, support_data)
        analysis_type = "Concession + R2 Case"
        sub_final_nc_output[analysis_type] = get_nc_output_dict(analysis_type, nc_input_dict, support_data)
        final_nc_output[nc_input_dict["pk"]] = sub_final_nc_output
    print(final_nc_output)
    return final_nc_output
    
def get_nc_output_dict(analysis_type, nc_input_dict, support_data):
    nonconformities_inputs = {}
    if nc_input_dict["fields"]["nc_oversize_fastener"]: #oversize_fastener is present
        #fastener_nominal = Fastener('EN6115B4', 6.34, 'Ti6Al4V', 'PAN')
        fasteners = {} # dictionary of fasteners containing Fastener objects
        fasteners["nominal"] = Fastener(nc_input_dict["fields"]["nc_oversize_fastener"]["fields"]["nom_fastener"], support_data["fastener_df"])
        fasteners["concession"] = Fastener(nc_input_dict["fields"]["nc_oversize_fastener"]["fields"]["con_fastener"], support_data["fastener_df"])
        fasteners["adjacent"] = Fastener(nc_input_dict["fields"]["nc_oversize_fastener"]["fields"]["adj_fastener"], support_data["fastener_df"])
        fasteners["adj_R2"] = Fastener(nc_input_dict["fields"]["nc_oversize_fastener"]["fields"]["adj_fastener_R2"], support_data["fastener_df"])
        mat = Material(nc_input_dict["fields"]["nc_affected_part"]["fields"]["part_material"], support_data["material_df"], support_data["material_allowables_df"])
        
        nonconformities_inputs["Oversize Fastener"] = {
                                      "con_basics": support_data["con_basics"],
                                      "analysis_type": analysis_type,
                                      "mat": mat,
                                      "edge_distance": float(nc_input_dict["fields"]["nc_oversize_fastener"]["fields"]["edge_distance"]), 
                                      "pitch_distance": float(nc_input_dict["fields"]["nc_oversize_fastener"]["fields"]["pitch_distance"]),
                                      "fasteners": fasteners
                                    }
    if nc_input_dict["fields"]["nc_shim_deviation"]: #shim_deviation is present
        shims = {} # dictionary of shims containing Shim objects
        shims["deviation"] = Shim(float(nc_input_dict["fields"]["nc_affected_part"]["fields"]["part_thickness"]),
                                  float(nc_input_dict["fields"]["nc_shim_deviation"]["fields"]["t_shim_liquid_deviation"]),
                                  float(nc_input_dict["fields"]["nc_shim_deviation"]["fields"]["t_shim_solid_deviation"]), 
                                  int(nc_input_dict["fields"]["nc_shim_deviation"]["fields"]["nb_fast_load_direction"]))
        shims["nominal"] = Shim(float(nc_input_dict["fields"]["nc_affected_part"]["fields"]["part_thickness"]), 
                                float(nc_input_dict["fields"]["nc_shim_deviation"]["fields"]["t_shim_liquid_nominal"]), 
                                float(nc_input_dict["fields"]["nc_shim_deviation"]["fields"]["t_shim_solid_nominal"]), 
                                int(nc_input_dict["fields"]["nc_shim_deviation"]["fields"]["nb_fast_load_direction"]))
        nonconformities_inputs["Shim"] = {
                                      "con_basics": support_data["con_basics"],
                                      "mat": mat,
                                      "shims": shims
                                    }              
    non_conf = Non_Conformities(nonconformities_inputs) 
    #print(non_conf.get_final_ratio())
    #print(non_conf.get_final_deviation_RF(1.85))
    #print(non_conf.get_final_output_dict(1.85))
    return(non_conf.get_final_output_dict())


def run_input_test_module(analysis_type, testing_input_dict):
    nonconformities_inputs = {}
    for key in nonconformities.keys():
        if key == "Oversize Fastener":
            #fastener_nominal = Fastener('EN6115B4', 6.34, 'Ti6Al4V', 'PAN')
            fasteners = {} # dictionary of fasteners containing Fastener objects
            fasteners["nominal"] = Fastener(testing_input_dict["fastener_nominal_type"], testing_input_dict["fastener_df"])
            fasteners["concession"] = Fastener(testing_input_dict["fastener_concession_type"], testing_input_dict["fastener_df"])
            fasteners["adjacent"] = Fastener(testing_input_dict["fastener_adjacent_type"], testing_input_dict["fastener_df"])
            fasteners["adj_R2"] = Fastener(testing_input_dict["fastener_adjacentR2_type"], testing_input_dict["fastener_df"])
            
            nonconformities_inputs[key] = {
                                         "con_basics": testing_input_dict["con_basics"],
                                         "analysis_type": analysis_type,
                                         "mat": testing_input_dict["mat"],
                                         "edge_distance": testing_input_dict["edge_distance"], 
                                         "pitch_distance": testing_input_dict["pitch_distance"],
                                         "fasteners": fasteners
                                        }
        elif key == "Shim":
            shims = {} # dictionary of shims containing Shim objects
            shims["deviation"] = Shim(testing_input_dict["part_thickness"], testing_input_dict["t_shim_liq"], testing_input_dict["t_shim_sol"], testing_input_dict["nb_fast_load_direction"])
            shims["nominal"] = Shim(testing_input_dict["part_thickness"], testing_input_dict["t_shim_liq_nom"], testing_input_dict["t_shim_sol_nom"], testing_input_dict["nb_fast_load_direction"])
            nonconformities_inputs[key] = {
                                         "con_basics": testing_input_dict["con_basics"],
                                         "mat": testing_input_dict["mat"],
                                         "shims": shims
                                        }
                    
    non_conf = Non_Conformities(nonconformities_inputs) 
    print(non_conf.get_final_ratio())
    print(non_conf.get_final_deviation_RF(1.85))
    print(non_conf.get_final_output_dict(1.85))
    return(non_conf.get_final_output_dict())
    
if __name__ == '__main__' :
    
##################################################
### This whole input section will be replaced  ###
### by the front end inputs once it is ready   ### 
################################################## 
    switch_input_sheet_or_json = "json"
    
    if switch_input_sheet_or_json == "json":
        input_dict_for_backend = [{'model': 'assessment.non_conformity', 'pk': 69, 'fields': {'nc_location': 74, 'nc_affected_part': {'model': 'assessment.affected_part', 'pk': 56, 'fields': {'part_number': 'V53476638', 'part_description': 'Web Slice', 'part_material': 'CFRP/194 - AIMS 05-27-002', 'part_thickness': '3.00'}}, 'nc_oversize_fastener': {'model': 'assessment.oversize_fastener', 'pk': 22, 'fields': {'nom_fastener': 'EN6115B4', 'con_fastener': 'EN6115B4X', 'adj_fastener': 'EN6115B4', 'adj_fastener_R2': 'EN6115B4Y', 'edge_distance': '13.0', 'pitch_distance': '22.0'}}, 'nc_shim_deviation': {'model': 'assessment.shim_deviation', 'pk': 6, 'fields': {'t_shim_liquid_deviation': '0.30', 't_shim_solid_deviation': '1.50', 't_shim_liquid_nominal': '0.10', 't_shim_solid_nominal': '1.00', 'nb_fast_load_direction': 2}}, 'sketch_image': '', 'overall_concession': 16}}, {'model': 'assessment.non_conformity', 'pk': 70, 'fields': {'nc_location': 75, 'nc_affected_part': {'model': 'assessment.affected_part', 'pk': 57, 'fields': {'part_number': 'V53476639', 'part_description': 'Web Slice', 'part_material': '2024_T42_Clad_Sheet_AIMS03-04-037', 'part_thickness': '2.00'}}, 'nc_oversize_fastener': {'model': 'assessment.oversize_fastener', 'pk': 23, 'fields': {'nom_fastener': 'EN6115B3X', 'con_fastener': 'EN6115B4X', 'adj_fastener': 'EN6115B4', 'adj_fastener_R2': 'EN6115B4Y', 'edge_distance': '11.0', 'pitch_distance': '21.0'}}, 'nc_shim_deviation': None, 'sketch_image': '', 'overall_concession': 16}}]
        concession_basics_input = {'model': 'assessment.general_concession_data', 'pk': 22, 'fields': {'msn': 23, 'concession_reference': 'TH-12345678', 'aircraft_type': 'A350-900', 'date': '2023-12-11T00:00:00Z', 'overall_concession': 16}}
        get_final_nc_outputs(input_dict_for_backend, concession_basics_input)
    elif switch_input_sheet_or_json == "input_sheet":
        input_sheet_name = '../Input_Example.xlsx'
        
        #get relevant input sheet data
        wb = openpyxl.load_workbook(input_sheet_name)
        sheet = wb.active
        msn = sheet['F8'].value
        concession_id = sheet['F10'].value
        
        testing_input_dict = {}
        
        #nonconformities input
        nonconformities = {}
        nonconformities["Oversize Fastener"] = sheet['G20'].value
        nonconformities["Scratch"] = sheet['G22'].value
        nonconformities["Flaking"] = sheet['G24'].value
        nonconformities["Burnt Hole"] = sheet['G26'].value
        nonconformities["Bush Inst."] = sheet['G28'].value
        nonconformities["Shim"] = sheet['G30'].value
        nonconformities["Unwanted Hole"] = sheet['G32'].value
        
        testing_input_dict["nonconformities"] = nonconformities
        
        #oversize fastener inputs
        testing_input_dict["fastener_nominal_type"] = sheet['G39'].value
        testing_input_dict["fastener_concession_type"] = sheet['G41'].value
        testing_input_dict["fastener_adjacent_type"] = sheet['G43'].value
        testing_input_dict["fastener_adjacentR2_type"] = sheet['G45'].value
        testing_input_dict["sheet_material"] = sheet['G47'].value
        testing_input_dict["edge_distance"] = sheet['M39'].value
        testing_input_dict["pitch_distance"] = sheet['M41'].value
        
        #shim deviation inputs
        testing_input_dict["part_thickness"] = sheet['G54'].value
        testing_input_dict["t_shim_liq"] = sheet['G56'].value
        testing_input_dict["t_shim_sol"] = sheet['G58'].value
        testing_input_dict["t_shim_liq_nom"] = sheet['G60'].value
        testing_input_dict["t_shim_sol_nom"] = sheet['G62'].value
        testing_input_dict["nb_fast_load_direction"] = sheet['M54'].value
                             
                             
        testing_input_dict["con_basics"] = Concession_Basics(concession_id = concession_id, msn = msn)
        
        testing_input_dict["fastener_df"] = pd.read_excel(rivet_lib_file_name, sheet_name = 'Rivet_Library')
        testing_input_dict["material_df"] = pd.read_excel(rivet_lib_file_name, sheet_name = 'Material_Library')
        testing_input_dict["material_allowables_df"] =pd.read_excel(rivet_lib_file_name, sheet_name = 'Material_Allowables') 
        
        testing_input_dict["mat"] = Material(testing_input_dict["sheet_material"], testing_input_dict["material_df"], testing_input_dict["material_allowables_df"])
        
        #create NC object for each analysis method and NC (each NC can have multiple deviations)
        final_nc_output_dict = {}
        analysis_type = "Concession Case"
        final_nc_output_dict[analysis_type] = run_input_test_module(analysis_type, testing_input_dict)
        analysis_type = "Concession + R2 Case"
        final_nc_output_dict[analysis_type] = run_input_test_module(analysis_type, testing_input_dict)
        print(final_nc_output_dict)
    
    

    
'''
    deviation_1 = Oversize_Fastener(concession, analysis_type, mat, edge_distance, pitch_distance, fasteners)
    deviation_1.get_KDFs()
    deviation_2 = Shim_Deviation(concession, mat, shims)
    deviation_2.get_KDFs()
    
    nominal_RF = 1.85
    deviation_ratio = round(deviation_1.get_deviation_ratio() * deviation_2.get_deviation_ratio() -0.005, 2)#-0.005 to round to lower 2 digit value
    print(f'The final ratio for this concession is: {deviation_ratio}')
    print(f'The nominal RF {nominal_RF:.2f} is affected by the KDF. \nThe concession RF is: {deviation_1.get_deviation_RF(1.85):.2f}')
'''