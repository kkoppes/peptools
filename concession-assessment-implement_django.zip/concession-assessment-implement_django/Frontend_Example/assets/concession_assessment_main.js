document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nc-spec').forEach(function(e) {
      console.log(e);
      e.style.display = "none";
    });
    document.querySelector('#Nonconformity_2').style.display = "none";
    document.querySelector('#nb_of_NC').onchange = function () {
      console.log(this.value);
      if( this.value == "2_nc") {
        document.querySelector('#Nonconformity_2').style.display = "flex";
      } else {
        document.querySelector('#Nonconformity_2').style.display = "none";
      };
    };
    document.querySelectorAll('.submit_deviations').forEach(function (submit_button) { //check if submit button is pushed
      submit_button.onclick = function() {
        const parentnode_id = this.parentNode.parentNode.parentNode.parentNode.id;
        console.log("here");
        console.log(parentnode_id);
        //get related Nonconformity Specification Section
        let nc_spec_section_name = parentnode_id + "_Specification";
        let nc_spec_section = document.getElementById(nc_spec_section_name);
        //check which deviation_checklist checkboxes are checked
        const deviation_checklist = document.querySelectorAll('.deviation_checklist').forEach(function(checklist) {
          // check if checklist belongs to parentnode_id
          if (checklist.parentNode.parentNode.parentNode.parentNode.id == parentnode_id) {
            let checked_boxes = [];
            let unchecked_boxes = [];
            for (const child of checklist.children) {
              if (child.tagName == "INPUT") {
                if (child.checked) {
                  checked_boxes.push(child);
                } else {
                  if (child.disabled == false) {
                    unchecked_boxes.push(child);
                  }
                }
              }
            }
            // if no check_box is checked, hide complete nonconformity specification section
            if (checked_boxes.length == 0){ 
            nc_spec_section.style.display = "none";

            } else {
            console.log(checked_boxes);
            nc_spec_section.style.display = "flex";
            }
            // only show relevant deviations
            console.log("checked");
            for (const item of checked_boxes) {
              console.log(item.name);
              nc_spec_section.getElementsByClassName(item.name)[0].style.display = "flex";
            }
            console.log("unchecked");
            for (const unchecked of unchecked_boxes) {
              console.log(unchecked.name);
              console.log(document.getElementById(parentnode_id).getElementsByClassName(unchecked.name));
              nc_spec_section.getElementsByClassName(unchecked.name)[0].style.display = "none"; // hide all relevant deviations
            }
          }
        });
      }
    });

    // define input form focus or checks
    document.querySelectorAll('.form-input').forEach(function(label) {
        label.addEventListener('focus', () => {
            label.previousElementSibling.classList.add('focused');
        });
    });
    document.querySelectorAll('.form-input').forEach(function(input) {
      input.addEventListener('blur', (event) => {
          if (input.value.length > 0) {
              input.classList.add('filled');
              console.log(input.className);
              if (input.classList.contains("integer")) {
                if (isNaN(input.value)) {
                  input.classList.add('wrong');
                  input.classList.remove('filled');
                }
                else {
                  input.classList.remove('wrong');
                }
              }
              
          /*     if (input === document.querySelector('#email')) {
                  if (validateEmail(input.value)) {
                      input.classList.remove('wrong');
                  } else {
                      input.classList.add('wrong');
                      input.classList.remove('filled');
                  }                                
              } */
          } else {
              input.classList.remove('filled');
              input.previousElementSibling.classList.remove('focused');
              input.classList.remove('wrong');
          }
      });
    });
});