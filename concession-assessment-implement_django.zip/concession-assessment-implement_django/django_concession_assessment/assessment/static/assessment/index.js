document.addEventListener('DOMContentLoaded', () => {
    // check if Run Analysis is pressed --> then show loading button
    document.querySelector('#Run_Analysis').addEventListener("click", () => {
      document.querySelectorAll('.loading_container').forEach(function(load_container) {
          load_container.style.display = "flex"
      });
  });
});