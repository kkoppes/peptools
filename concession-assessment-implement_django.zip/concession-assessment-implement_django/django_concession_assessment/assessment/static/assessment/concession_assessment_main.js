document.addEventListener('DOMContentLoaded', () => {
    // define input form focus or checks
    document.querySelectorAll('.form-input').forEach(function(input) {
        if (input.classList.contains("bootstrap-select")) {
                var button_title = input.children[1].title;
                var select_title = input.children[0].title;
                if (button_title != select_title) {
                    input.classList.add('filled');
                }
                else {
                    input.classList.remove('filled');
                }
        }
        else if (!input.classList.contains("selectpicker")){ //exclude selects --> only regular input fields left
            if (input.value.length > 0) {
                input.classList.add('filled');
                input.previousElementSibling.classList.add('focused');
            }
            input.addEventListener('focus', () => {
                input.previousElementSibling.classList.add('focused'); //add focused class to label
            });
        }
    });
    // hide loading_container
    document.querySelectorAll('.loading_container').forEach(function(load_container) {
        load_container.style.display = "none"
    });

    // hide modify_KDF tr
    document.querySelectorAll('.change_KDFs').forEach(function(change_KDF_row) {
        change_KDF_row.style.display = "none"
    });
    // hide modify_Final_Ratio_input
    document.querySelectorAll('.modify_Final_Ratio_input').forEach(function(modify_Final_Ratio_input) {
        modify_Final_Ratio_input.style.display = "none"
    });

    // output page calculate dev RF if nom RF is entered
    document.querySelectorAll('.output_nom_rf').forEach(function(nom_RF) {
        document.querySelectorAll('.output_dev_rf').forEach(function(dev_RF) {
            if (nom_RF.value.length > 0) {
                final_ratio = parseFloat(nom_RF.parentElement.previousElementSibling.innerHTML);
                //deviation_RF = nom_RF.parentElement.nextElementSibling.nextElementSibling;
                dev_RF.innerHTML = (parseFloat(nom_RF.value) * final_ratio).toFixed(3);
            }
            nom_RF.addEventListener('blur', () => {
                if (nom_RF.value.length > 0) {
                    final_ratio = parseFloat(nom_RF.parentElement.previousElementSibling.innerHTML);
                    //deviation_RF = nom_RF.parentElement.nextElementSibling.nextElementSibling;
                    dev_RF.innerHTML = (parseFloat(nom_RF.value) * final_ratio).toFixed(3);
                }
            });
        });
    });

    // highlight output cell KDFs less than 1
    document.querySelectorAll('.warning_below_one').forEach(function(td) {
        if (parseFloat(td.innerHTML) < 1) {
            td.classList.add('table-warning');
        }
    });

    // highlight output deviation RF less than 1 as danger (red)
    document.querySelectorAll('.danger_below_one').forEach(function(td) {
        if (parseFloat(td.innerHTML) < 1) {
            td.classList.add('table-danger');
        }
        else {
            td.classList.add('table-success');
        }
    });

    document.querySelectorAll('.modify_KDF_button').forEach(function(modify_KDF_button) {
        modify_KDF_button.addEventListener("click", () => {
            var tr_original_KDFs = modify_KDF_button.parentElement.parentElement;
            var tr_change_KDFs = modify_KDF_button.parentElement.parentElement.nextElementSibling;
            tr_change_KDFs.style.display = "table-row";
            tr_change_KDFs.querySelectorAll('.input_table').forEach(function(input) {
                input.classList.add("unchanged_KDF");
                input.addEventListener('blur', () => {
                    td = input.parentElement;
                    var input_index = 0; //get index of input made
                    while( (td = td.previousElementSibling) != null ) {
                        input_index++;
                    };  
                    if(tr_change_KDFs.children[input_index].children[0].value == tr_original_KDFs.children[input_index].innerHTML) {
                        input.classList.add("unchanged_KDF");
                        input.classList.remove("modified_KDF");
                    }
                    else {
                        input.classList.add("modified_KDF");
                        input.classList.remove("unchanged_KDF");
                    }
                });
            })
        });
    });

    document.querySelectorAll('.modify_Final_Ratio_button').forEach(function(modify_Final_Ratio_button) {
        modify_Final_Ratio_button.addEventListener("click", () => {
            var original_final_ratio = modify_Final_Ratio_button.parentElement.previousElementSibling;
            var changed_final_ratio = modify_Final_Ratio_button.nextElementSibling;
            console.log(original_final_ratio.innerHTML);
            console.log(changed_final_ratio.value)
            changed_final_ratio.style.display = "table-row";
            changed_final_ratio.classList.add("unchanged_KDF");
            changed_final_ratio.addEventListener('blur', () => {  
                if(changed_final_ratio.value == original_final_ratio.innerHTML) {
                    changed_final_ratio.classList.add("unchanged_KDF");
                    changed_final_ratio.classList.remove("modified_KDF");
                }
                else {
                    changed_final_ratio.classList.add("modified_KDF");
                    changed_final_ratio.classList.remove("unchanged_KDF");
                }
            });
        });
    });


    // make Report Ref and Nominal RF as required if final ratio is lower than 1
    document.querySelectorAll('.final_ratio').forEach(function(final_ratio) {
        if (final_ratio.previousElementSibling.innerHTML == "Concession Case") { //because of rowspan only apply this to the concession case
            if (parseFloat(final_ratio.innerHTML) < 1) {
                final_ratio.nextElementSibling.children[0].required = true;
                var report_input = document.getElementById("report_ref_img");
                //report_input.required = true; TODO: uncomment if finished with testing
                //final_ratio.nextElementSibling.nextElementSibling.children[0].required = true;
            }
            else {
                final_ratio.nextElementSibling.children[0].required = false;
                var report_input = document.getElementById("report_ref_img");
                report_input.required = false;
                //final_ratio.nextElementSibling.nextElementSibling.children[0].required = false;
            }
        }
    });

    document.querySelectorAll('.form-input').forEach(function(input) {
        //differentiate between regular input field and bootstrap select
        if (input.classList.contains("bootstrap-select")) {
            input.addEventListener('change', (event) => {
                var button_title = input.children[1].title;
                var select_title = input.children[0].title;
                if (button_title != select_title) {
                    input.classList.add('filled');
                }
                else {
                    input.classList.remove('filled');
                }
            });
        }
        else {
            input.addEventListener('blur', (event) => {
                if (input.value.length > 0) {
                      input.classList.add('filled');
                      if (input.classList.contains("integer")) {
                        console.log(input.value);
                        if (isNaN(input.value) && input.value != "N/A") {
                          input.classList.add('wrong');
                          input.classList.remove('filled');
                          input.nextElementSibling.style.display = "flex";
                        }
                        else {
                          input.classList.remove('wrong');
                          input.nextElementSibling.style.display = "none";
                        }
                      }
                      else if (input.classList.contains("concession_number")) {
                        console.log(input.value);
                        const regex = new RegExp('^[a-zA-Z]{2,3}-([0-9]{5,})(-[A-Z]{0,3})?$');
                        if (!regex.test(input.value)) {

                            input.classList.add('wrong');
                            input.classList.remove('filled');
                            input.nextElementSibling.style.display = "flex";
                          }
                          else {
                            input.classList.remove('wrong');
                            input.nextElementSibling.style.display = "none";
                          }
                      }
                      
                  /*     if (input === document.querySelector('#email')) {
                          if (validateEmail(input.value)) {
                              input.classList.remove('wrong');
                          } else {
                              input.classList.add('wrong');
                              input.classList.remove('filled');
                          }                                
                      } */
                } else {
                      input.classList.remove('filled');
                      input.previousElementSibling.classList.remove('focused');
                      input.classList.remove('wrong');
                      if (input.classList.contains("concession_number") || input.classList.contains("integer")) {
                        input.nextElementSibling.style.display = "none";
                      }
                }
            });
        }
    });
    document.querySelectorAll('.delete_button').forEach(function(input) {
        input.addEventListener("click", () => {
            confirm("Are you sure you want to delete the Non-Conformity Item?");
        });
    });
    //bootstrap popover JS
    // var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    // var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
    //     return new bootstrap.Popover(popoverTriggerEl, {html: true})
    // })
    $('.popover_test').popover();

    //popover for values which should be checked

    //remove attention_popover from select, to avoid double allocation
    document.querySelectorAll('.attention_popover').forEach(function(attention_popover) {
        if (attention_popover.nodeName == "SELECT") {
            attention_popover.classList.remove('attention_popover');
        }
    })
    document.querySelectorAll('.attention_popover').forEach(function(attention_popover) {
        var popover = new bootstrap.Popover(attention_popover, {
            content: 'Please check this copied value',
            html: true
        })
        popover.show();
        attention_popover.addEventListener("click", () => {
            console.log("here");
            attention_popover.classList.remove('attention_popover');
            popover.hide();
            popover.disable();
            });
        });


    //JS for Sketch Picture increase:
    document.querySelectorAll('.images').forEach(function(image) {
        image.addEventListener("click", () => {
            var modal_image = image.nextElementSibling.getElementsByClassName("modal-content-image")[0];
            var modal = image.nextElementSibling;
            console.log(image.nextElementSibling)
            modal.style.display = "block";
            modal_image.src = image.src;
            // Get the <span> element that closes the modal
            var span = modal.getElementsByClassName("close")[0];

            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                modal.style.display = "none";
            }
        });
    });

});