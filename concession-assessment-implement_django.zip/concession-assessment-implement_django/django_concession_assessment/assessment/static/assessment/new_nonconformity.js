document.addEventListener('DOMContentLoaded', () => {
    //document.querySelectorAll('.nc-spec').forEach(function(e) {
    //  e.style.display = "none";
    //});
    nc_spec_section = document.getElementById('Nonconformity_Specification');
    nc_spec_section.style.display = "none"
    document.querySelector('.Oversize_Fastener').style.display = "none";
    document.querySelector('.Shim').style.display = "none";

        //check which deviation_checklist checkboxes are checked and show or hide Specification sections
        let checked_boxes = 0;
        let deviation_checklist = document.querySelector('.deviation_checklist');
        console.log(deviation_checklist);
        deviation_checklist.querySelectorAll('input').forEach( function(checkbox) {
          //if already checked without user action e.g copy or modify nc
          console.log(checkbox.name);
          if (checkbox.checked) {
            checked_boxes += 1;
            console.log(document.getElementsByClassName(checkbox.name)[0]);
            document.getElementsByClassName(checkbox.name)[0].style.display = "flex";
          } else if (!checkbox.disabled) {
            document.getElementsByClassName(checkbox.name)[0].style.display = "none";
          }
          if (checked_boxes == 0) {
            nc_spec_section.style.display = "none";
          } else {
            nc_spec_section.style.display = "flex";
          }
          //if changed from user show or hide sections
          checkbox.addEventListener('change', function() {
                if (this.checked) {
                  checked_boxes += 1;
                  console.log(document.getElementsByClassName(this.name)[0]);
                  document.getElementsByClassName(this.name)[0].style.display = "flex";
                } else {
                  checked_boxes -= 1;
                  document.getElementsByClassName(this.name)[0].style.display = "none";
                }
                if (checked_boxes == 0) {
                  nc_spec_section.style.display = "none";
                } else {
                  nc_spec_section.style.display = "flex";
                }
          })
        })
});