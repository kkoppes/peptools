from django.urls import path

from . import views

urlpatterns = [
    path("<int:overall_nc_id>", views.index, name="index"),
    path("home", views.home, name="home"),
    path("login_signup", views.login_signup, name="login_signup"),
    path("output/<int:overall_nc_id>", views.output, name="output"),
    path("nonconformity/<str:type>/<int:nc_id>", views.nonconformity, name="nonconformity"),
    path("modify_output/<int:nc_id>/", views.modify_output, name="modify_output"),
    path("cos_storage", views.cos_storage, name="cos_storage"),
    path("general_concession_data/<int:id>", views.general_concession_data, name="general_concession_data"),

    #API routes
    path("delete_nc/<int:nc_id>/", views.delete_nc, name="delete_nc"),
    path("copy_overall_concession/<int:overall_nc_id>", views.copy_overall_concession, name="copy_overall_concession"),
]