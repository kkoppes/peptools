from django.db import models
from django.contrib.postgres.fields import ArrayField
#from django.forms import ModelForm

# Create your models here.

#Overall Concession
class Overall_Concession(models.Model):
    values_to_be_checked_when_copied = models.JSONField(blank=True, null=True)

class General_Concession_Data(models.Model):
    #msn = models.CharField(max_length=64)
    msn = models.IntegerField(null=True)
    concession_reference = models.CharField(max_length=64)
    concession_or_nc = models.CharField(max_length=64, blank=True) 
    aircraft_type = models.CharField(max_length=64, blank=True)
    date = models.DateTimeField(blank=True, null=True)
    overall_concession = models.ForeignKey(Overall_Concession, on_delete=models.CASCADE, null=True, blank=True, related_name='general_concession_data')

    
    def __str__(self):
        return f"{self.id}: Concession Reference {self.concession_reference} for MSN {self.msn}"
#if form should be included use this scheme    
#class General_Concession_Data_Form(ModelForm):
#   class Meta:
#       model = General_Concession_Data
#       fields = ["msn", "concession_reference", "aircraft_type", "date"]

class Oversize_Fastener(models.Model):
    nom_fastener = models.CharField(max_length=64)
    con_fastener = models.CharField(max_length=64)
    adj_fastener = models.CharField(max_length=64)
    adj_fastener_R2 = models.CharField(max_length=64) 
    edge_distance = models.DecimalField(max_digits=8, decimal_places=1, null=True)
    pitch_distance = models.DecimalField(max_digits=8, decimal_places=1, null=True)

    def __str__(self):
        return f"{self.id}: Oversize Fastener {self.con_fastener} instead of {self.nom_fastener}"

class Shim_Deviation(models.Model):
    t_shim_liquid_deviation = models.DecimalField(max_digits=8, decimal_places=2, null=True)
    t_shim_solid_deviation = models.DecimalField(max_digits=8, decimal_places=2, null=True)
    t_shim_liquid_nominal = models.DecimalField(max_digits=8, decimal_places=2, null=True)
    t_shim_solid_nominal = models.DecimalField(max_digits=8, decimal_places=2, null=True)
    nb_fast_load_direction = models.IntegerField(max_length=3) #TODO: max length will be ignored, find alternative

    def __str__(self):
        return f"{self.id}: Shim Deviation {self.t_shim_liquid_deviation + self.t_shim_solid_deviation} mm"

class Affected_Part(models.Model):
    part_number = models.CharField(max_length=64, blank=True)
    part_description = models.CharField(max_length=64, blank=True)
    part_material = models.CharField(max_length=64)
    part_thickness = models.DecimalField(max_digits=8, decimal_places=2, null=True)

    def __str__(self):
        return f"{self.id}: Part Material {self.part_material} with thickness of {self.part_thickness} mm"

class Location(models.Model):
    left_right = models.CharField(max_length=64, blank=True)
    frame_from = models.DecimalField(max_digits=8, decimal_places=1, null=True, blank=True)
    frame_to = models.DecimalField(max_digits=8, decimal_places=1, null=True, blank=True)
    stringer_from = models.IntegerField(null=True, blank=True)
    stringer_to = models.IntegerField(null=True, blank=True)
    #stringer_from = models.CharField(max_length=64, blank=True)
    #stringer_to = models.CharField(max_length=64, blank=True)

    def __str__(self):
        return f"{self.id}: Location {self.left_right} at frame {self.frame_from} and stringer {self.stringer_from}"

class Non_Conformity(models.Model):
    nc_location = models.ForeignKey(Location, on_delete=models.CASCADE, null=True, related_name='non_conformity')
    nc_affected_part = models.ForeignKey(Affected_Part, on_delete=models.CASCADE, null=True, related_name='non_conformity')
    nc_oversize_fastener = models.ForeignKey(Oversize_Fastener, on_delete=models.CASCADE, null=True, blank=True, related_name='non_conformity')
    nc_shim_deviation = models.ForeignKey(Shim_Deviation, on_delete=models.CASCADE, null=True, blank=True, related_name='non_conformity')
    sketch_image = models.ImageField(upload_to='images', blank=True, null=True)
    overall_concession = models.ForeignKey(Overall_Concession, on_delete=models.CASCADE, null=True, blank=True, related_name='non_conformity')

#Output models

class Oversize_Fastener_Output(models.Model):
    e_d_KDF = models.DecimalField(max_digits=8, decimal_places=3, null=True)
    p_d_KDF = models.DecimalField(max_digits=8, decimal_places=3, null=True)
    huth_factor = models.DecimalField(max_digits=8, decimal_places=3, null=True)
    deviation_ratio = models.DecimalField(max_digits=8, decimal_places=3, null=True)

class Shim_Deviation_Output(models.Model):
    shim_KDF = models.DecimalField(max_digits=8, decimal_places=3, null=True)
    deviation_ratio = models.DecimalField(max_digits=8, decimal_places=3, null=True)

class Non_Conformity_Output(models.Model):
    analysis_type = models.CharField(max_length=64, blank=True)
    final_ratio = models.DecimalField(max_digits=8, decimal_places=3, null=True)
    additional_statement = models.TextField(null=True, blank=True)
    nominal_RF = models.DecimalField(max_digits=8, decimal_places=3, blank=True, null=True)
    significant = models.CharField(max_length=64, blank=True)
    nc_decision_array_M20450_1 = models.JSONField(blank=True, null=True)
    manually_modified_fields = models.JSONField(blank=True, null=True)
    report_reference_image = models.ImageField(upload_to='images', blank=True, null=True) #maybe create a sub model for report
    report_reference = models.CharField(max_length=64, blank=True)
    report_issue = models.CharField(max_length=64, blank=True)
    report_name = models.CharField(max_length=264, blank=True)
    deviation_RF = models.DecimalField(max_digits=8, decimal_places=3, blank=True, null=True)
    oversize_fastener_output = models.ForeignKey(Oversize_Fastener_Output, on_delete=models.CASCADE, null=True, blank=True, related_name='non_conformity_output')
    shim_deviation_output = models.ForeignKey(Shim_Deviation_Output, on_delete=models.CASCADE, null=True, blank=True, related_name='non_conformity_output')
    non_conformity_input = models.ForeignKey(Non_Conformity, on_delete=models.CASCADE, null=True, blank=True, related_name='non_conformity_output')

class General_Concession_Output(models.Model):
    final_clarifications = models.TextField(null=True, blank=True)
    final_statement = models.TextField(null=True, blank=True)
    overall_concession = models.ForeignKey(Overall_Concession, on_delete=models.CASCADE, null=True, blank=True, related_name='general_concession_output')

#TODO: create user models from abstract users

