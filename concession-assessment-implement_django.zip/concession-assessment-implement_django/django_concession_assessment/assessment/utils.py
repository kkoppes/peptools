#utils class for defining translation functions

from .models import Overall_Concession, General_Concession_Data, Oversize_Fastener, Shim_Deviation, Affected_Part, Location, Non_Conformity, Non_Conformity_Output, Oversize_Fastener_Output, Shim_Deviation_Output, General_Concession_Output
from django.core import serializers
import datetime 
import json
from . import backend as Backend_Module

############################################################################
### Functions to create dicts for simplifying rendering html             ###
### Reduce process time and Smarty/Jinja2/Django Template Language usage ###
############################################################################

def change_naming_of_model_items(values_dict):
    conversion_dict = {
        "left_right": "Left/Right",
        "frame_from": "Frame from",
        "frame_to": "Frame to",
        "stringer_from": "Stringer from", 
        "stringer_to": "Stringer to",
        "part_number": "Part Number",
        "part_description": "Part Description",
        "part_material": "Part Material",
        "part_thickness": "Part Thickness",
        "nom_fastener": "Nominal Fastener",
        "con_fastener": "Concession Fastener",
        "adj_fastener": "Adjacent Fastener",
        "adj_fastener_R2": "Adjacent Fastener R2",
        "edge_distance": "Edge Distance",
        "pitch_distance": "Pitch Distance",
        "t_shim_liquid_deviation": "t shim liq deviation",
        "t_shim_solid_deviation": "t shim solid deviation",
        "t_shim_liquid_nominal": "t shim liq nominal",
        "t_shim_solid_nominal": "t shim solid nominal",
        "nb_fast_load_direction": "Nb of Fast. in Load Direction"
    }
    return_dict = {}
    for key,value in values_dict.items():
        if key in conversion_dict:
            return_dict[conversion_dict[key]] = value
        else:
            return_dict[key] = value
    return return_dict



def get_overall_concession(overall_concession_objects):
    overall_concession_dict = {}
    for overall_concession_obj in overall_concession_objects:
        sub_overall_concession_dict = {}
        general_concession_data_objects = General_Concession_Data.objects.filter(overall_concession = overall_concession_obj)
        sub_overall_concession_dict["general_concession_data"] = get_general_concession_data_dict(general_concession_data_objects)
        sub_overall_concession_dict["non_conformities"] = get_non_conformities_dict(overall_concession_obj, False)
        general_concession_output_obj = General_Concession_Output.objects.filter(overall_concession = overall_concession_obj)
        if len(general_concession_output_obj) > 0:
            sub_overall_concession_dict["general_concession_output"] = {"final_statement": general_concession_output_obj[0].final_statement, "final_clarifications": general_concession_output_obj[0].final_clarifications}
        overall_concession_dict[overall_concession_obj.id] = sub_overall_concession_dict
    return overall_concession_dict

def get_general_concession_data_dict(general_concession_data_objects):
    general_concession_data = {}
    if len(general_concession_data_objects) > 0:
        general_concession_data_obj = general_concession_data_objects[0]
        general_concession_data["id"] = general_concession_data_obj.id
        general_concession_data["msn"] = general_concession_data_obj.msn
        general_concession_data["concession_reference"] = general_concession_data_obj.concession_reference
        general_concession_data["aircraft_type"] = general_concession_data_obj.aircraft_type
        if general_concession_data_obj.date:
            general_concession_data["date"] = general_concession_data_obj.date.strftime('%Y-%m-%d')
        else:
            today_date = datetime.datetime.today().strftime('%Y-%m-%d')
            general_concession_data["date"] = today_date
    return general_concession_data

def get_non_conformities_dict(overall_concession_obj, change_naming_of_model_items_switch):
    non_conformities_dict = {}
    for non_conformity in Non_Conformity.objects.filter(overall_concession = overall_concession_obj):
        #non_conformities_dict[non_conformity] = non_conformity.nc_location.__dict__
        non_conformities_dict[non_conformity.id] = get_non_conformity_dict(non_conformity, change_naming_of_model_items_switch)
    return non_conformities_dict

def get_non_conformity_dict(non_conformity, change_naming_of_model_items_switch):
    sub_non_conformity_dict = {}
    if non_conformity.sketch_image:
        sub_non_conformity_dict["sketch_image"] = non_conformity.sketch_image


    location_obj = Location.objects.filter(non_conformity = non_conformity)
    if len(location_obj) > 0:
        location_values = location_obj.values()[0]
        del location_values["id"]
        if change_naming_of_model_items_switch:
            sub_non_conformity_dict["Location"] = change_naming_of_model_items(location_values)
            sub_non_conformity_dict["Location"]["Frame from"] = "C" + str(location_values["frame_from"]).replace(".0", "")
            sub_non_conformity_dict["Location"]["Frame to"] = "C" + str(location_values["frame_to"]).replace(".0", "")
            sub_non_conformity_dict["Location"]["Stringer from"] = "P" + str(location_values["stringer_from"])
            sub_non_conformity_dict["Location"]["Stringer to"] = "P" + str(location_values["stringer_to"])
        else:
            sub_non_conformity_dict["Location"] = location_values
            sub_non_conformity_dict["Location"]["frame_from"] = "C" + str(location_values["frame_from"]).replace(".0", "")
            sub_non_conformity_dict["Location"]["frame_to"] = "C" + str(location_values["frame_to"]).replace(".0", "")
            sub_non_conformity_dict["Location"]["stringer_from"] = "P" + str(location_values["stringer_from"])
            sub_non_conformity_dict["Location"]["stringer_to"] = "P" + str(location_values["stringer_to"])


    affected_part_obj = Affected_Part.objects.filter(non_conformity = non_conformity)
    if len(affected_part_obj) > 0:
        affected_part_values = affected_part_obj.values()[0]
        del affected_part_values["id"]
        if change_naming_of_model_items_switch:
            sub_non_conformity_dict["Affected Part"] = change_naming_of_model_items(affected_part_values)
        else:
            sub_non_conformity_dict["Affected_Part"] = affected_part_values

    oversize_fastener_obj = Oversize_Fastener.objects.filter(non_conformity = non_conformity)
    if len(oversize_fastener_obj) > 0:
        oversize_fast_values = oversize_fastener_obj.values()[0]
        del oversize_fast_values["id"]
        if change_naming_of_model_items_switch:
            sub_non_conformity_dict["Oversize Fastener"] = change_naming_of_model_items(oversize_fast_values)
        else:
            sub_non_conformity_dict["Oversize_Fastener"] = oversize_fast_values
        
    shim_deviation_obj = Shim_Deviation.objects.filter(non_conformity = non_conformity)
    if len(shim_deviation_obj) > 0:
        shim_values = shim_deviation_obj.values()[0]
        del shim_values["id"]
        if change_naming_of_model_items_switch:
            sub_non_conformity_dict["Shim Deviation"] = change_naming_of_model_items(shim_values)
        else:
            sub_non_conformity_dict["Shim_Deviation"] = shim_values
    
    nc_output_obj = Non_Conformity_Output.objects.filter(non_conformity_input = non_conformity)
    if len(nc_output_obj) > 0:
        sub_non_conformity_dict["Output"] = get_non_conformities_output_dict(nc_output_obj)
    
    return sub_non_conformity_dict

def get_non_conformities_output_dict(non_conformities_output):
    non_conformities_output_dict = {}
    for non_conformity_output in non_conformities_output:
        non_conformities_output_dict[non_conformity_output.analysis_type] = get_non_conformity_output_dict(non_conformity_output)
    return non_conformities_output_dict

def get_non_conformity_output_dict(nc_output):
    nc_output_dict = {}
    nc_output_dict["Final_Ratio"] = nc_output.final_ratio
    nc_output_dict["Additional_statement"] = nc_output.additional_statement
    nc_output_dict["Nom_RF"] = nc_output.nominal_RF
    nc_output_dict["Significant"] = nc_output.significant
    nc_output_dict["Nc_decision_array_M20450_1"] = nc_output.nc_decision_array_M20450_1
    nc_output_dict["Manually_Modified_Fields"] = nc_output.manually_modified_fields
    nc_output_dict["Report_reference_image"] = nc_output.report_reference_image
    nc_output_dict["Report_reference"] = nc_output.report_reference
    nc_output_dict["Report_issue"] = nc_output.report_issue
    nc_output_dict["Report_name"] = nc_output.report_name
    nc_output_dict["Dev_RF"] = nc_output.deviation_RF

    if nc_output.oversize_fastener_output:
        oversize_fastener_output = {}
        oversize_fastener_output["E_D_KDF"] = nc_output.oversize_fastener_output.e_d_KDF
        oversize_fastener_output["P_D_KDF"] = nc_output.oversize_fastener_output.p_d_KDF
        oversize_fastener_output["Huth_Factor"] = nc_output.oversize_fastener_output.huth_factor
        oversize_fastener_output["Deviation_Ratio"] = nc_output.oversize_fastener_output.deviation_ratio
        nc_output_dict["Oversize Fastener"] = oversize_fastener_output

    if nc_output.shim_deviation_output:
        shim_deviation_output = {}
        shim_deviation_output["Shim_KDF"] = nc_output.shim_deviation_output.shim_KDF
        shim_deviation_output["Deviation_Ratio"] = nc_output.shim_deviation_output.deviation_ratio
        nc_output_dict["Shim Deviation"] = shim_deviation_output

    return nc_output_dict

############################################################################
### util functions to create backend input and output                    ###
############################################################################

def create_input_dict_for_backend(overall_concession_obj):
    #get sub dictionaries of NCs
    nc_objects = Non_Conformity.objects.filter(overall_concession = overall_concession_obj)
    affected_part_obj_list = []
    oversize_fastener_obj_list = []
    shim_deviation_obj_list = []
    for nc_object in nc_objects:
        if nc_object.nc_affected_part:
            affected_part_obj_list.append(nc_object.nc_affected_part)
        if nc_object.nc_oversize_fastener:
            oversize_fastener_obj_list.append(nc_object.nc_oversize_fastener)
        if nc_object.nc_shim_deviation:
            shim_deviation_obj_list.append(nc_object.nc_shim_deviation)
    affected_part_json = serializers.serialize("json", affected_part_obj_list)
    oversize_fastener_json = serializers.serialize("json", oversize_fastener_obj_list)
    shim_deviation_json = serializers.serialize("json", shim_deviation_obj_list)
    nc_json = serializers.serialize("json", nc_objects)
    
    #convert to dict 
    nc_dict = json.loads(nc_json)
    affected_part_dict = json.loads(affected_part_json)
    oversize_fastener_dict = json.loads(oversize_fastener_json)
    shim_deviation_dict = json.loads(shim_deviation_json)
    
    #combine to one dict
    final_nc_dict = []
    for single_nc_dict in nc_dict:
        modified_nc_dict = single_nc_dict
        modified_nc_dict["Non_Conformity_Output_id"] = {}
        nc_output_objects = Non_Conformity_Output.objects.filter(non_conformity_input = Non_Conformity.objects.get(pk = single_nc_dict["pk"]))
        if len(nc_output_objects): #already Output present
            for nc_output_object in nc_output_objects:
                modified_nc_dict["Non_Conformity_Output_id"][nc_output_object.analysis_type] = nc_output_object.id
        else: #1st run. No Output present
            modified_nc_dict["Non_Conformity_Output_id"]["Concession Case"] = -9999
            modified_nc_dict["Non_Conformity_Output_id"]["Concession + R2 Case"] = -9999
        for key, value in single_nc_dict["fields"].items():
            if key == "nc_affected_part" and value:
                for affected_part in affected_part_dict:
                    if affected_part["pk"] == value:
                        modified_nc_dict["fields"][key] = affected_part
                        break
            if key == "nc_oversize_fastener" and value:
                for oversize_fastener in oversize_fastener_dict:
                    if oversize_fastener["pk"] == value:
                        modified_nc_dict["fields"][key] = oversize_fastener
                        break
            if key == "nc_shim_deviation" and value:
                for shim_deviation in shim_deviation_dict:
                    if shim_deviation["pk"] == value:
                        modified_nc_dict["fields"][key] = shim_deviation
                        break            
        final_nc_dict.append(modified_nc_dict)
    print(final_nc_dict)
    return final_nc_dict

def create_or_update_models_from_backend_output_dict(backend_output_dict):
    print(backend_output_dict)
    for nc_id, nc_output in backend_output_dict.items():
        non_conformity_object = Non_Conformity.objects.get(pk=nc_id) #TODO: think about if it is smarter to have nc_output allocated to nc or way around
        for analysis, deviations in nc_output.items():
            if len(Non_Conformity_Output.objects.filter(id = int(deviations['Non_Conformity_Output_id']))) > 0: #Non_Conformity_Output already exists --> do not create new model but overwrite old one; same for sub models oversize and shim
                non_conformity_output_object = Non_Conformity_Output.objects.get(pk=int(deviations['Non_Conformity_Output_id']))
                non_conformity_output_object.final_ratio = deviations['Final_Ratio']
                non_conformity_output_object.analysis_type = analysis
                if analysis == "Concession Case":
                    nc_decision_dict_M20450_1 = Backend_Module.get_M20450_1_nc_decision_dict(float(non_conformity_output_object.nominal_RF), float(non_conformity_output_object.nominal_RF) * non_conformity_output_object.final_ratio)
                    non_conformity_output_object.significant = nc_decision_dict_M20450_1["significant?"]
                    non_conformity_output_object.nc_decision_array_M20450_1 = nc_decision_dict_M20450_1["M20450_1_nc_decision_array"]
                non_conformity_output_object.manually_modified_fields = {}
                non_conformity_output_object.save()
                if 'Oversize Fastener' in deviations['Deviations'].keys():
                    if(non_conformity_output_object.oversize_fastener_output): #check if related Oversize Fastener Object is present
                        oversize_fastener_output_object = non_conformity_output_object.oversize_fastener_output
                        oversize_fastener_output_object.e_d_KDF = deviations['Deviations']['Oversize Fastener']['KDFs']['E_D_KDF']
                        oversize_fastener_output_object.p_d_KDF = deviations['Deviations']['Oversize Fastener']['KDFs']['P_D_KDF']
                        oversize_fastener_output_object.huth_factor = deviations['Deviations']['Oversize Fastener']['KDFs']['Huth_Factor']
                        oversize_fastener_output_object.deviation_ratio = deviations['Deviations']['Oversize Fastener']['Deviation_Ratio']
                        oversize_fastener_output_object.save()
                    else:
                        oversize_fastener_output_object = Oversize_Fastener_Output.objects.create(e_d_KDF = deviations['Deviations']['Oversize Fastener']['KDFs']['E_D_KDF'],
                                                                                                    p_d_KDF = deviations['Deviations']['Oversize Fastener']['KDFs']['P_D_KDF'],
                                                                                                huth_factor = deviations['Deviations']['Oversize Fastener']['KDFs']['Huth_Factor'],
                                                                                                deviation_ratio = deviations['Deviations']['Oversize Fastener']['Deviation_Ratio'])
                    
                    non_conformity_output_object.oversize_fastener_output = oversize_fastener_output_object
                    non_conformity_output_object.save()

                if 'Shim Deviation' in deviations['Deviations'].keys():
                    if(non_conformity_output_object.shim_deviation_output): #check if related Shim Deviation Object is present
                        shim_deviation_output_object = non_conformity_output_object.shim_deviation_output
                        shim_deviation_output_object.shim_KDF = deviations['Deviations']['Shim Deviation']['KDFs']['Shim_KDF']
                        shim_deviation_output_object.deviation_ratio = deviations['Deviations']['Shim Deviation']['Deviation_Ratio']
                        shim_deviation_output_object.save()
                    else:
                        shim_deviation_output_object = Shim_Deviation_Output.objects.create(shim_KDF = deviations['Deviations']['Shim Deviation']['KDFs']['Shim_KDF'],
                                                                                            deviation_ratio = deviations['Deviations']['Shim Deviation']['Deviation_Ratio'])
                    non_conformity_output_object.shim_deviation_output = shim_deviation_output_object
                    non_conformity_output_object.save()
            else:
                non_conformity_output_object = Non_Conformity_Output.objects.create(final_ratio = deviations['Final_Ratio'], 
                                                                                        analysis_type = analysis,
                                                                                        non_conformity_input = non_conformity_object)
                if 'Oversize Fastener' in deviations['Deviations'].keys():
                    oversize_fastener_output_object = Oversize_Fastener_Output.objects.create(e_d_KDF = deviations['Deviations']['Oversize Fastener']['KDFs']['E_D_KDF'],
                                                                                                p_d_KDF = deviations['Deviations']['Oversize Fastener']['KDFs']['P_D_KDF'],
                                                                                            huth_factor = deviations['Deviations']['Oversize Fastener']['KDFs']['Huth_Factor'],
                                                                                            deviation_ratio = deviations['Deviations']['Oversize Fastener']['Deviation_Ratio'])
                    non_conformity_output_object.oversize_fastener_output = oversize_fastener_output_object
                    non_conformity_output_object.save()
                if 'Shim Deviation' in deviations['Deviations'].keys():
                    shim_deviation_output_object = Shim_Deviation_Output.objects.create(shim_KDF = deviations['Deviations']['Shim Deviation']['KDFs']['Shim_KDF'],
                                                                                        deviation_ratio = deviations['Deviations']['Shim Deviation']['Deviation_Ratio'])
                    non_conformity_output_object.shim_deviation_output = shim_deviation_output_object
                    non_conformity_output_object.save()