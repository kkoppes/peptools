from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.template.defaulttags import register
from django.db.models import Q
from django.core import serializers
import json
from . import backend as Backend_Module
from . import utils as Utils
from isami_database import FastenerDatabase

import datetime 
import time
from .models import Overall_Concession, General_Concession_Data, Oversize_Fastener, Shim_Deviation, Affected_Part, Location, Non_Conformity, Non_Conformity_Output, Oversize_Fastener_Output, Shim_Deviation_Output, General_Concession_Output
from decimal import Decimal

FASTENER_TYPES = {}
FASTENER_TYPES['DAN'] = ['DAN5-5','DAN5-6']
FASTENER_TYPES['EN6115'] = ['EN6115B2', 'EN6115B3', 'EN6115B4', 'EN6115B3X', 'EN6115B4X', 'EN6115B4Y']

aircraft_types = ["A350-900", "A350-1000", "A350-1000F", "A321-200NY","A321-200NX","A321-NEO","A321","A320-NEO","A320","A319-NEO","A319"]

initial_values_to_be_checked_when_copied = ["MSN", "Concession", "Date", "Aircrafttype", "left_right"]

Frame_dict = {}
A320_SA_Frames = ["C35", "C36", "C37", "C38", "C39", "C40", "C41", "C42", "C43", "C44", "C45", "C46", "C47", "C48", "C49", "C50", "C51", "C52", "C53", "C54", "C55", "C56", "C57", "C58", "C59", "C60", "C61", "C62", "C63", "C64", "C65", "C66", "C67", "C68", "C69", "C70"]
A321_SA_Frames = ["C35.8", "C36", "C37", "C38", "C39", "C40", "C41", "C42", "C43", "C44", "C45", "C46", "C47", "C47.1", "C47.2", "C47.3", "C47.4", "C47.5", "C48", "C49", "C50", "C51", "C52", "C53", "C54", "C55", "C56", "C57", "C58", "C59", "C60", "C61", "C62", "C63", "C64", "C65", "C66", "C67", "C68", "C69", "C70"]
A350_Frames = ["C71", "C72", "C73", "C74", "C75", "C76", "C77", "C78", "C79", "C80", "C81", "C82", "C83", "C84", "C85", "C86", "C87", "C88", "C89", "C90", "C91", "C92", "C93"]
All_Frames = ["", "C35", "C35.8", "C36", "C37", "C38", "C39", "C40", "C41", "C42", "C43", "C44", "C45", "C46", "C47", "C47.1", "C47.2", "C47.3", "C47.4", "C47.5", "C48", "C49", "C50", "C51", "C52", "C53", "C54", "C55", "C56", "C57", "C58", "C59", "C60", "C61", "C62", "C63", "C64", "C65", "C66", "C67", "C68", "C69", "C70", "C71", "C72", "C73", "C74", "C75", "C76", "C77", "C78", "C79", "C80", "C81", "C82", "C83", "C84", "C85", "C86", "C87", "C88", "C89", "C90", "C91", "C92", "C93"]
Frame_dict["A320-NEO"] = A320_SA_Frames
Frame_dict["A320"] = A320_SA_Frames
Frame_dict["A319-NEO"] = A320_SA_Frames
Frame_dict["A319"] = A320_SA_Frames
Frame_dict["A321-200NY"] = A321_SA_Frames
Frame_dict["A321-200NX"] = A321_SA_Frames
Frame_dict["A321-NEO"] = A321_SA_Frames
Frame_dict["A321"] = A321_SA_Frames
Frame_dict["A350-900"] = A350_Frames
Frame_dict["A350-1000"] = A350_Frames
Frame_dict["A350-1000F"] = A350_Frames
Frame_dict["all"] = All_Frames

Stringer_dict = {}
Stringer_SA = ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10", "P11", "P12", "P13", "P14", "P15", "P16", "P17", "P18", "P19", "P20", "P21", "P22", "P23", "P24", "P25", "P26", "P27", "P28", "P29", "P30", "P31", "P32", "P33", "P34", "P35", "P36", "P37", "P38", "P39", "P40", "P41", "P42", "P43", "P44"]
Stringer_A350 = ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10", "P11", "P12", "P13", "P14", "P15", "P16", "P17", "P18", "P19", "P20", "P21", "P22", "P23", "P24", "P25", "P26", "P27", "P28", "P29", "P30", "P31", "P32", "P33", "P34", "P35", "P36", "P37", "P38", "P39", "P40", "P41", "P42", "P43", "P44", "P45", "P46", "P47"]
Stringer_All = ["", "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10", "P11", "P12", "P13", "P14", "P15", "P16", "P17", "P18", "P19", "P20", "P21", "P22", "P23", "P24", "P25", "P26", "P27", "P28", "P29", "P30", "P31", "P32", "P33", "P34", "P35", "P36", "P37", "P38", "P39", "P40", "P41", "P42", "P43", "P44", "P45", "P46", "P47"]
Stringer_dict["A320-NEO"] = Stringer_SA
Stringer_dict["A320"] = Stringer_SA
Stringer_dict["A319-NEO"] = Stringer_SA
Stringer_dict["A319"] = Stringer_SA
Stringer_dict["A321-200NY"] = Stringer_SA
Stringer_dict["A321-200NX"] = Stringer_SA
Stringer_dict["A321-NEO"] = Stringer_SA
Stringer_dict["A321"] = Stringer_SA
Stringer_dict["A350-900"] = Stringer_A350
Stringer_dict["A350-1000"] = Stringer_A350
Stringer_dict["A350-1000F"] = Stringer_A350
Stringer_dict["all"] = Stringer_All

#@register.filter
#def get_item(dictionary, key):
#    return dictionary.get(key)


def run_analysis(overall_concession_obj):
    testing_environment_switch = False
    
    if testing_environment_switch:
        nc_objects = Non_Conformity.objects.filter(overall_concession = overall_concession_obj)
        time.sleep(2) 
        temporary_return_dict_for_testing = {}
        for nc_object in nc_objects:
            temporary_return_dict_for_testing[nc_object.id] = {'Concession Case': {'Deviations': {}, 'Final_Ratio': 0.830, 'Nominal_RF': 1.85, 'Final_Deviation_RF': 1.536}, 'Concession + R2 Case':{'Deviations': {}, 'Final_Ratio': 0.730, 'Nominal_RF': 1.75, 'Final_Deviation_RF': 1.436}}
            if nc_object.nc_oversize_fastener:
                temporary_return_dict_for_testing[nc_object.id]['Concession Case']['Deviations']['Oversize Fastener'] = {'KDFs': {'E_D_KDF': 0.953, 'P_D_KDF': 0.992, 'Huth_Factor': 1.042}, 'Deviation_Ratio': 0.907}
                temporary_return_dict_for_testing[nc_object.id]['Concession + R2 Case']['Deviations']['Oversize Fastener'] = {'KDFs': {'E_D_KDF': 0.953, 'P_D_KDF': 0.992, 'Huth_Factor': 1.042}, 'Deviation_Ratio': 0.907}
            if nc_object.nc_shim_deviation:
                temporary_return_dict_for_testing[nc_object.id]['Concession Case']['Deviations']['Shim Deviation'] = {'KDFs': {'Shim_KDF': 0.915}, 'Deviation_Ratio': 0.915}
                temporary_return_dict_for_testing[nc_object.id]['Concession + R2 Case']['Deviations']['Shim Deviation'] = {'KDFs': {'Shim_KDF': 0.815}, 'Deviation_Ratio': 0.915}
            #temporary_return_dict_for_testing[nc_object.id] = {'Concession Case': {'Deviations': {'Oversize Fastener': {'KDFs': {'E_D_KDF': 0.953, 'P_D_KDF': 0.992, 'Huth_Factor': 1.042}, 'Deviation_Ratio': 0.907}, 'Shim Deviation': {'KDFs': {'Shim_KDF': 0.915}, 'Deviation_Ratio': 0.915}}, 'Final_Ratio': 0.830, 'Nominal_RF': 1.85, 'Final_Deviation_RF': 1.536}, 'Concession + R2 Case':{'Deviations': {'Oversize Fastener': {'KDFs': {'E_D_KDF': 0.953, 'P_D_KDF': 0.992, 'Huth_Factor': 1.042}, 'Deviation_Ratio': 0.907}, 'Shim Deviation': {'KDFs': {'Shim_KDF': 0.815}, 'Deviation_Ratio': 0.915}}, 'Final_Ratio': 0.730, 'Nominal_RF': 1.75, 'Final_Deviation_RF': 1.436}}
            temporary_return_dict_for_testing[nc_object.id]['Concession Case']['Non_Conformity_Output_id'] = -9999
            temporary_return_dict_for_testing[nc_object.id]['Concession + R2 Case']['Non_Conformity_Output_id'] = -9999
            for nc_output in nc_object.non_conformity_output.all(): ### <-- this all is needed to create an iterable queryset
                if nc_output.analysis_type == "Concession Case" :
                    temporary_return_dict_for_testing[nc_object.id]['Concession Case']['Non_Conformity_Output_id'] = nc_output.id
                elif nc_output.analysis_type == "Concession + R2 Case":
                    temporary_return_dict_for_testing[nc_object.id]['Concession + R2 Case']['Non_Conformity_Output_id'] = nc_output.id
    
    else:
        input_dict_for_backend = Utils.create_input_dict_for_backend(overall_concession_obj)
        concession_basic_input = json.loads(serializers.serialize("json", General_Concession_Data.objects.filter(overall_concession = overall_concession_obj)))[0]
        temporary_return_dict_for_testing = Backend_Module.get_final_nc_outputs(input_dict_for_backend, concession_basic_input)
    
    #update models
    Utils.create_or_update_models_from_backend_output_dict(temporary_return_dict_for_testing)
    

# Create your views here.
def index(request, overall_nc_id):
    overall_concession_obj = Overall_Concession.objects.get(pk = overall_nc_id)
    if request.method == "POST":
        if "add_general_concession_data" in request.POST:
            general_concession_obj = General_Concession_Data.objects.create()
            general_concession_obj.overall_concession = overall_concession_obj
            today_date = datetime.datetime.today().strftime('%Y-%m-%d')
            general_concession_obj.date = today_date
            general_concession_obj.save()
            general_concession_id = general_concession_obj.id
            return HttpResponseRedirect(reverse('general_concession_data', args=(general_concession_id,)))
        elif "add_nonconformity" in request.POST:
            new_nc_obj = Non_Conformity.objects.create()
            new_nc_obj.overall_concession = overall_concession_obj
            new_nc_obj.save()
            new_nc_id = new_nc_obj.id
            type = "new"
            return HttpResponseRedirect(reverse('nonconformity', args=(type, new_nc_id,)))
        elif "Run_Analysis" in request.POST:
            run_analysis(overall_concession_obj)
            return HttpResponseRedirect(reverse("output", args=(overall_nc_id,)))
    else:
        db = FastenerDatabase()
        standards = db.get_pin_standards()
        pins = db.get_pins()
        FASTENER_TYPES = {}
        #for standard in standards:
        #    FASTENER_TYPES[standard] = []


        FASTENER_TYPES['DAN'] = ['DAN5-5','DAN5-6']
        FASTENER_TYPES['EN6115'] = [*sorted(db.get_pins())]# ['EN6115B3', 'EN6115B3', 'EN6115B4', 'EN6115B3X', 'EN6115B4X', 'EN6115B4Y']
        general_concession_data_objects = General_Concession_Data.objects.filter(overall_concession = overall_concession_obj)
        return render(request, "index.html", context = {
            "title": "Concession Assessment",
            "overall_nc_id": overall_nc_id,
            "non_conformities_dict": Utils.get_non_conformities_dict(overall_concession_obj, True),
            "general_concession_data": Utils.get_general_concession_data_dict(general_concession_data_objects),
            "FASTENER_TYPES": FASTENER_TYPES, #just for testing, delete later
        })
def delete_nc(request, nc_id = None):
    nc_object = Non_Conformity.objects.get(pk = nc_id)
    overall_nc_id = nc_object.overall_concession.id
    nc_object.delete()
    return HttpResponseRedirect(reverse("index", args=(overall_nc_id,)))

def output(request, overall_nc_id):
    overall_concession_obj = Overall_Concession.objects.get(pk = overall_nc_id)
    if request.method == "POST":
        if "Save_and_Close" in request.POST:
            general_concession_output_objects = General_Concession_Output.objects.filter(overall_concession = overall_concession_obj)
            if len(general_concession_output_objects) > 0:
                general_concession_output_obj = general_concession_output_objects[0]
                general_concession_output_obj.final_clarifications = request.POST["final_clarifications"]
                general_concession_output_obj.final_statement = request.POST["final_statement"]
                general_concession_output_obj.save()
            else:
                General_Concession_Output.objects.create(final_clarifications = request.POST["final_clarifications"], final_statement = request.POST["final_statement"], overall_concession = overall_concession_obj)
            return HttpResponseRedirect(reverse("cos_storage"))
    else:
        general_concession_output_objects = General_Concession_Output.objects.filter(overall_concession = overall_concession_obj)
        if len(general_concession_output_objects) > 0:
            general_concession_output = general_concession_output_objects[0]
        else:
            general_concession_output = []
        concession_or_nc = General_Concession_Data.objects.get(overall_concession = overall_concession_obj).concession_or_nc

        return render(request, "output.html", context = {
            "title": "Output of Concession Assessment",
            "overall_nc_id": overall_nc_id,
            "concession_or_nc": concession_or_nc,
            "general_concession_output": general_concession_output,
            "non_conformities_dict": Utils.get_non_conformities_dict(overall_concession_obj, True),
        })
    
def modify_output(request, nc_id = None):
    if request.method == "POST":
        if "submit_output_changes" in request.POST:
            non_conformity_object = Non_Conformity.objects.get(pk=nc_id)
            non_conformity_output_objects = Non_Conformity_Output.objects.filter(non_conformity_input = non_conformity_object)
            for non_conformity_output_object in non_conformity_output_objects:
                if non_conformity_output_object.analysis_type == "Concession Case":
                    non_conformity_output_object.additional_statement = request.POST["additional_statement"] #only add final statement to first object
                    non_conformity_output_object.nominal_RF = request.POST["Nom_RF"]
                    nc_decision_dict_M20450_1 = Backend_Module.Concession_Basics.get_M20450_1_nc_decision_dict(float(non_conformity_output_object.nominal_RF), Decimal(request.POST["Nom_RF"]) *  Decimal(request.POST["Final_Ratio__Concession Case"]))
                    print(nc_decision_dict_M20450_1)
                    non_conformity_output_object.significant = nc_decision_dict_M20450_1["significant?"]
                    non_conformity_output_object.nc_decision_array_M20450_1 = nc_decision_dict_M20450_1["M20450_1_nc_decision_array"]
                    if "report_ref_img" in request.FILES:
                        non_conformity_output_object.report_reference_image = request.FILES["report_ref_img"]
                        non_conformity_output_object.report_reference = request.POST["report_reference"]
                        non_conformity_output_object.report_issue = request.POST["report_issue"]
                        non_conformity_output_object.report_name = request.POST["report_name"]
                

                #TODO: include if kdf inputs differ from model parameter --> update model and somehow keep track what changed (maybe JSONField with manually_modified_parameters and original_parameter_values)
                if non_conformity_output_object.manually_modified_fields:
                    manually_modified_fields = non_conformity_output_object.manually_modified_fields
                else:
                    manually_modified_fields = {} #will be a dict containing the modified field as a key and the original value as a value
                for key, value in request.POST.items():
                    key_splitted_name = key.split("__")
                    if len(key_splitted_name) > 1: #modifiable KDFs have naming e.g. E_D_KDF__Concession Case
                        if key_splitted_name[1] == non_conformity_output_object.analysis_type:
                            value_decimal = Decimal(value)
                            if key_splitted_name[0] == "E_D_KDF":
                                if non_conformity_output_object.oversize_fastener_output.e_d_KDF != value_decimal:
                                    if "E_D_KDF" not in manually_modified_fields:
                                        manually_modified_fields["E_D_KDF"] = float(non_conformity_output_object.oversize_fastener_output.e_d_KDF) #still the old original value
                                    elif manually_modified_fields["E_D_KDF"] == value_decimal: #if changed again to original value remove
                                        manually_modified_fields.pop("E_D_KDF")
                                    non_conformity_output_object.oversize_fastener_output.e_d_KDF = value_decimal
                                    non_conformity_output_object.oversize_fastener_output.save()
                            elif key_splitted_name[0] == "P_D_KDF":
                                if non_conformity_output_object.oversize_fastener_output.p_d_KDF != value_decimal:
                                    if "P_D_KDF" not in manually_modified_fields:
                                        manually_modified_fields["P_D_KDF"] = float(non_conformity_output_object.oversize_fastener_output.p_d_KDF) #still the old original value
                                    elif manually_modified_fields["P_D_KDF"] == value_decimal: #if changed again to original value remove
                                        manually_modified_fields.pop("P_D_KDF")
                                    non_conformity_output_object.oversize_fastener_output.p_d_KDF = value_decimal
                                    non_conformity_output_object.oversize_fastener_output.save()
                            elif key_splitted_name[0] == "Huth_Factor":
                                if non_conformity_output_object.oversize_fastener_output.huth_factor != value_decimal:
                                    if "Huth_Factor" not in manually_modified_fields:
                                        manually_modified_fields["Huth_Factor"] = float(non_conformity_output_object.oversize_fastener_output.huth_factor) #still the old original value
                                    elif manually_modified_fields["Huth_Factor"] == value_decimal: #if changed again to original value remove
                                        manually_modified_fields.pop("Huth_Factor")
                                    non_conformity_output_object.oversize_fastener_output.huth_factor = value_decimal
                                    non_conformity_output_object.oversize_fastener_output.save()
                            elif key_splitted_name[0] == "Deviation_Ratio":
                                if non_conformity_output_object.oversize_fastener_output.deviation_ratio != value_decimal:
                                    if "Deviation_Ratio" not in manually_modified_fields:
                                        manually_modified_fields["Deviation_Ratio"] = float(non_conformity_output_object.oversize_fastener_output.deviation_ratio) #still the old original value
                                    elif manually_modified_fields["Deviation_Ratio"] == value_decimal: #if changed again to original value remove
                                        manually_modified_fields.pop("Deviation_Ratio")
                                    non_conformity_output_object.oversize_fastener_output.deviation_ratio = value_decimal
                                    non_conformity_output_object.oversize_fastener_output.save()
                            elif key_splitted_name[0] == "Final_Ratio":
                                if non_conformity_output_object.final_ratio != value_decimal:
                                    if "Final_Ratio" not in manually_modified_fields:
                                        manually_modified_fields["Final_Ratio"] = float(non_conformity_output_object.final_ratio) #still the old original value
                                    elif manually_modified_fields["Final_Ratio"] == value_decimal: #if changed again to original value remove
                                        manually_modified_fields.pop("Final_Ratio")
                                    non_conformity_output_object.final_ratio = value_decimal
                                    non_conformity_output_object.save()  
                                non_conformity_output_object.deviation_RF = Decimal(request.POST["Nom_RF"]) *  value_decimal #TODO: use Backend function --> Calculation Logic only in Backend      

                non_conformity_output_object.manually_modified_fields = manually_modified_fields       
                non_conformity_output_object.save()
            overall_nc_id = non_conformity_object.overall_concession.id
        return HttpResponseRedirect(reverse("output", args=(overall_nc_id,)))
    else:
        return render(request, "modify_output.html", context = {
            "title": "Modify Output",
            "nc_id": nc_id,
            "nonconformity": Utils.get_non_conformity_dict(Non_Conformity.objects.get(pk = nc_id), True),
        })

def nonconformity(request, type= "", nc_id = None):
    if request.method == "POST":
        print(request.POST)
        if "submit_nonconformity" in request.POST:
            location_object = Location.objects.create(left_right= request.POST["left_right"], frame_from=request.POST["frame_from"][1:], frame_to=request.POST["frame_to"][1:],stringer_from=request.POST["stringer_from"][1:],stringer_to=request.POST["stringer_to"][1:])
            affected_part_object = Affected_Part.objects.create(part_number= request.POST["part_number"], part_description=request.POST["part_description"], part_material=request.POST["part_material"],part_thickness=request.POST["part_thickness"])
            non_conformity_object = Non_Conformity.objects.get(pk = nc_id)
            non_conformity_object.nc_location = location_object
            non_conformity_object.nc_affected_part = affected_part_object
            non_conformity_object.save()
            #non_conformity_object = Non_Conformity.objects.create(nc_location = location_object, nc_affected_part = affected_part_object)
            if "Oversize_Fastener" in request.POST:
                oversize_fastener_object = Oversize_Fastener.objects.create(nom_fastener= request.POST["nom_fastener"], con_fastener=request.POST["con_fastener"], adj_fastener=request.POST["adj_fastener"],adj_fastener_R2=request.POST["adj_fastener_R2"], edge_distance=request.POST["edge_distance"], pitch_distance=request.POST["pitch_distance"])
                non_conformity_object.nc_oversize_fastener = oversize_fastener_object
                non_conformity_object.save()
            if "Shim" in request.POST:
                shim_deviation_object = Shim_Deviation.objects.create(t_shim_liquid_deviation= request.POST["tshim_liq"], t_shim_solid_deviation=request.POST["tshim_sol"], t_shim_liquid_nominal=request.POST["tshim_liq_nom"], t_shim_solid_nominal=request.POST["tshim_sol_nom"], nb_fast_load_direction=request.POST["nb_fast_load_direction"])
                non_conformity_object.nc_shim_deviation = shim_deviation_object 
                non_conformity_object.save()
            print(request.FILES)
            print("sketch_image" in request.FILES)
            if "sketch_image" in request.FILES:
                non_conformity_object.sketch_image = request.FILES["sketch_image"]
                non_conformity_object.save()
        overall_nc_id = non_conformity_object.overall_concession.id
        return HttpResponseRedirect(reverse("index", args=(overall_nc_id,))) #instead of render no need to hand over attributes, just calling the http site
    
    #get_request
    if type == "copy":
        current_nc_obj = Non_Conformity.objects.create()
        current_nc_obj.overall_concession = Non_Conformity.objects.get(pk = nc_id).overall_concession
        current_nc_obj.save()
        current_nc_id = current_nc_obj.id
    else:
        current_nc_id = nc_id
    overall_concession_obj = Non_Conformity.objects.get(pk=current_nc_id).overall_concession
    aircraft_type = General_Concession_Data.objects.filter(overall_concession = overall_concession_obj)[0].aircraft_type
    return render(request, "nonconformity.html", context = {
        "title": "Nonconformity Definition and Specification",
        "nc_id": current_nc_id,
        "type": type,
        "stringer_dropdown_list": Stringer_dict[aircraft_type],
        "frame_dropdown_list": Frame_dict[aircraft_type],
        "nonconformity": Utils.get_non_conformity_dict(Non_Conformity.objects.get(pk = nc_id), False),
        "FASTENER_TYPES": FASTENER_TYPES,
        "values_to_be_checked_when_copied": overall_concession_obj.values_to_be_checked_when_copied,
    })

def general_concession_data(request, id):
    if request.method == "POST":
        general_concession_data_obj = General_Concession_Data.objects.get(pk = id)
        general_concession_data_obj.msn= request.POST["MSN"]
        general_concession_data_obj.concession_reference=request.POST["Concession"]
        if request.POST["Concession"][:2] == "NC":
            general_concession_data_obj.concession_or_nc = "Non_Conformity"
        else:
            general_concession_data_obj.concession_or_nc = "Concession"
        general_concession_data_obj.aircraft_type=request.POST["Aircrafttype"]
        general_concession_data_obj.date=request.POST["Date"]
        general_concession_data_obj.save()
        overall_nc_id = general_concession_data_obj.overall_concession.id
        return HttpResponseRedirect(reverse("index", args=(overall_nc_id,)))
    else:    
        general_concession_data_objects = General_Concession_Data.objects.filter(id = id)
        values_to_be_checked_when_copied = []
        if len(general_concession_data_objects) > 0:
            values_to_be_checked_when_copied = general_concession_data_objects[0].overall_concession.values_to_be_checked_when_copied
        return render(request, "general_concession_data.html", context = {
            "title": "Modify General Concession NC/Data",
            "id": id,
            "general_concession_data": Utils.get_general_concession_data_dict(general_concession_data_objects),
            "aircraft_types": aircraft_types,
            "values_to_be_checked_when_copied": values_to_be_checked_when_copied,
        })
    
def home(request):
    if request.method == "POST":
        overall_nc_concession_obj = Overall_Concession.objects.create()
        overall_nc_concession_id = overall_nc_concession_obj.id
        print(overall_nc_concession_id)
        return HttpResponseRedirect(reverse("index", args=(overall_nc_concession_id,)))
    else:
        return render(request, "home.html", context = {
            "title": "Home",
        })
def cos_storage(request):
    if request.method == "POST":
        if "filter_cos_storage" in request.POST: #set up filter_query
            filter_query = Q()
            if request.POST["filter_concession_nc_number"] != "":
                filter_query.add(Q(general_concession_data__concession_reference = request.POST["filter_concession_nc_number"]), Q.AND)
            if request.POST["filter_MSN"] != "":
                filter_query.add(Q(general_concession_data__msn = int(request.POST["filter_MSN"])), Q.AND)
                #filter_query.add(Q(general_concession_data__msn__lte = int(request.POST["filter_MSN"])), Q.AND) #lte means lower than equal
            if request.POST["filter_aircraft_type"] != "":
                filter_query.add(Q(general_concession_data__aircraft_type = request.POST["filter_aircraft_type"]), Q.AND)
            if request.POST["filter_frame_from"] != "":
                filter_query.add(Q(non_conformity__nc_location__frame_from__lte = Decimal.from_float(float(request.POST["filter_frame_from"][1:]))), Q.AND)
            if request.POST["filter_frame_to"] != "":
                filter_query.add(Q(non_conformity__nc_location__frame_to__gte = Decimal.from_float(float(request.POST["filter_frame_to"][1:]))), Q.AND)
            if request.POST["filter_stringer_from"] != "":
                filter_query.add(Q(non_conformity__nc_location__stringer_from__lte = Decimal.from_float(float(request.POST["filter_stringer_from"][1:]))), Q.AND)
            if request.POST["filter_stringer_to"] != "":
                filter_query.add(Q(non_conformity__nc_location__stringer_to__gte = Decimal.from_float(float(request.POST["filter_stringer_to"][1:]))), Q.AND)
            print(filter_query)
            overall_concession_objects = Overall_Concession.objects.filter(filter_query)
            print(overall_concession_objects)
        elif "show_all" in request.POST:
            overall_concession_objects = Overall_Concession.objects.all()
        return render(request, "cos_storage.html", context = {
            "title": "COS Storage",
            "stringer_dropdown_list": Stringer_dict["all"],
            "frame_dropdown_list": Frame_dict["all"],
            "aircraft_types": aircraft_types,
            "overall_concession" : Utils.get_overall_concession(overall_concession_objects)
        })  
    else:
        overall_concession_objects = Overall_Concession.objects.all()
        return render(request, "cos_storage.html", context = {
            "title": "COS Storage",
            "stringer_dropdown_list": Stringer_dict["all"],
            "frame_dropdown_list": Frame_dict["all"],
            "aircraft_types": aircraft_types,
            "overall_concession" : Utils.get_overall_concession(overall_concession_objects)
        })
    
def login_signup(request):
     return render(request, "login_signup.html", context = {
            "title": "Login / Signup",
        })

def copy_overall_concession(request, overall_nc_id = None):
    original_overall_concession_obj = Overall_Concession.objects.get(pk = overall_nc_id)
    overall_concession_obj = Overall_Concession.objects.get(pk = overall_nc_id)
    overall_concession_obj.pk = None #autogenerate new id
    overall_concession_obj.values_to_be_checked_when_copied = initial_values_to_be_checked_when_copied
    overall_concession_obj.save()
    #copy General_Concession_Output 
    general_concession_output_objects = General_Concession_Output.objects.filter(overall_concession = original_overall_concession_obj)
    if len(general_concession_output_objects) > 0:
        general_concession_output_obj = general_concession_output_objects[0]
        general_concession_output_obj.pk = None
        general_concession_output_obj.overall_concession = overall_concession_obj
        general_concession_output_obj.save()
    #copy Non_Conformity and Non_Conformity_Output
    non_conformity_objects = Non_Conformity.objects.filter(overall_concession = original_overall_concession_obj)
    for non_conformity_obj in non_conformity_objects:
        original_non_conformity_obj = Non_Conformity.objects.get(pk = non_conformity_obj.pk)
        non_conformity_obj.pk = None
        non_conformity_obj.overall_concession = overall_concession_obj
        non_conformity_obj.save()
        nc_output_objects = Non_Conformity_Output.objects.filter(non_conformity_input = original_non_conformity_obj)
        print(original_non_conformity_obj)
        print("here")
        print(nc_output_objects)
        print(non_conformity_obj)
        print("yes")
        for nc_output_obj in nc_output_objects:
            nc_output_obj.pk = None
            nc_output_obj.non_conformity_input = non_conformity_obj
            nc_output_obj.save()
    #copy general concession data object
    general_concession_data_obj = General_Concession_Data.objects.filter(overall_concession = original_overall_concession_obj)[0]
    general_concession_data_obj.pk = None
    general_concession_data_obj.overall_concession = overall_concession_obj
    general_concession_data_obj.save()
    #copy non conformity input and output objects
    return HttpResponseRedirect(reverse("index", args=(overall_concession_obj.pk,)))