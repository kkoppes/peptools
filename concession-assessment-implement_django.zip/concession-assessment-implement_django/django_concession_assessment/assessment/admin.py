from django.contrib import admin
from .models import Overall_Concession, General_Concession_Data, Oversize_Fastener, Shim_Deviation, Affected_Part, Location, Non_Conformity, Non_Conformity_Output, Oversize_Fastener_Output, Shim_Deviation_Output, General_Concession_Output
# Register your models here.
admin.site.register(Overall_Concession)
admin.site.register(General_Concession_Data)
admin.site.register(Oversize_Fastener)
admin.site.register(Shim_Deviation)
admin.site.register(Affected_Part)
admin.site.register(Location)
admin.site.register(Non_Conformity)
admin.site.register(Non_Conformity_Output)
admin.site.register(Oversize_Fastener_Output)
admin.site.register(Shim_Deviation_Output)
admin.site.register(General_Concession_Output)