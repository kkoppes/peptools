import pytest
from unittest.mock import MagicMock, patch
from todo import Todo


@patch('todo.TodoRepository')
def test_update(repository_mock: MagicMock):
    # GIVEN an update request
    # WHEN no item exist with requested value
    # THEN update the item

    repository = repository_mock.return_value
    repository.list_by_title.return_value = []

    Todo().update('id', dict(title='title'))
    assert repository.update.call_count == 1


@patch('todo.TodoRepository')
def test_update_with_error(repository_mock: MagicMock):
    # GIVEN an update request
    # WHEN item already exist with requested value
    # THEN raise the error

    repository = repository_mock.return_value
    repository.list_by_title.return_value = [dict(_id='wrong_id', title='sample')]

    with pytest.raises(Exception) as error:
        Todo().update('id', dict(title='sample'))
    assert str(error.value) == 'already existing todo with title sample'


@patch('todo.TodoRepository')
def test_add(repository_mock: MagicMock):
    # GIVEN an add request
    # WHEN no item exist with requested value
    # THEN add the item

    repository = repository_mock.return_value
    repository.list_by_title.return_value = []

    Todo().add(dict(title='title'))
    assert repository.add.call_count == 1


@patch('todo.TodoRepository')
def test_add_with_error(repository_mock: MagicMock):
    # GIVEN an add request
    # WHEN item already exist with requested value
    # THEN raise the error

    repository = repository_mock.return_value
    repository.list_by_title.return_value = [dict(_id='some_id', title='sample')]

    with pytest.raises(Exception) as error:
        Todo().add(dict(title='sample'))
    assert str(error.value) == 'already existing todo with title sample'
