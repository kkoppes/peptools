# from unittest.mock import MagicMock

sample_todos = [
    {
        "title": "Replace Wheel",
        "description": "Replace outboard left MLG wheel",
    },
    {
        "title": "Check Windscreen",
        "description": "Check center right windscreen for scratch.",
    },
]

sample_todo = {"title": "sample todo", "description": "Todo to test"}


def test_get_todos(client, mock_todo_repository):
    mock_todo_repository.return_value.list.return_value = sample_todos
    result = client.get("/api/todos")
    assert result.status_code == 200
    assert result.json == sample_todos


def test_get_todo(client, mock_todo_repository):
    mock_todo_repository.return_value.get.return_value = sample_todo
    result = client.get("/api/todos/1")
    assert result.status_code == 200
    assert result.json == sample_todo


def test_get_todo_with_error(client, mock_todo_repository):
    mock_todo_repository.return_value.get.return_value = None
    result = client.get("/api/todos/2")
    assert result.status_code == 404
    assert result.json.get("message") == "Todo not found"


def test_add_todo(client, mock_todo):
    mock_todo.return_value.add.return_value.inserted_id = 123
    result = client.post("/api/todos", json=sample_todo)
    assert result.status_code == 200
    assert result.json.get("id") == "123"


# def test_add_1_todo_api(client, mock_todo):
#     # Assume /api2/todos/ is expected to create a new todo item
#     mock_todo.return_value.add.return_value.inserted_id = 123

#     result = client.post("/api/todos/", json=sample_todo, follow_redirects=True)

#     assert result.status_code == 201
#     assert "Document added successfully" in result.json.get("message")

    # assert result.json.get("id") == "123"


# def test_add_todo_api2(client, mock_todo):

#     # Make the POST request to the adjusted endpoint
#     result = client.post('/api2/todos/', json=sample_todo, follow_redirects=True)

#     # Asserting the status code is 201 CREATED as expected
#     assert result.status_code == 201, "Expected a 201 CREATED response."

#     # Asserting the response message indicates success
#     assert result.json.get("message") == "Document added successfully", "Expected success message in response."

#     # Asserting the "id" in the response matches the mocked "123" inserted_id
#     assert result.json.get("id") == "123", f"Expected the 'id' in response to be '123', got '{result.json.get('id')}'"


def test_add_todo_with_error(client, mock_todo):
    mock_todo.return_value.add.side_effect = Exception("some exception")
    result = client.post("/api/todos", json=sample_todo)
    assert result.status_code == 500
    assert result.text == "Something went wrong"


def test_add_todo_with_missing_data(client, mock_todo):
    result = client.post("/api/todos", json={"title": "wrong todo"})
    assert result.status_code == 400
    assert result.json.get("message") == "Missing required fields"


def test_update_todo(client, mock_todo):
    mock_todo.return_value.update.return_value.modified_count = 1
    result = client.put("/api/todos/1", json=sample_todo)
    assert result.status_code == 200
    assert result.json.get("updated_count") == 1
    assert result.json.get("updated_data") == sample_todo


def test_update_todo_with_error(client, mock_todo):
    mock_todo.return_value.update.side_effect = Exception("some exception")
    result = client.put("/api/todos/1", json=sample_todo)
    assert result.status_code == 500
    assert result.text == "Something went wrong"


def test_delete_todo(client, mock_todo_repository):
    mock_todo_repository.return_value.delete.return_value.deleted_count = 1
    result = client.delete("/api/todos/2")
    assert result.status_code == 200
    assert result.json.get("deleted_count") == 1


def test_delete_todo_with_error(client, mock_todo_repository):
    mock_todo_repository.return_value.delete.side_effect = Exception("some exception")
    result = client.delete("/api/todos/2")
    assert result.status_code == 500
    assert result.text == "Something went wrong"
