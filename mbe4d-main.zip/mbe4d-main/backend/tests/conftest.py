import pytest
from unittest.mock import patch, MagicMock


@pytest.fixture(scope="module")
def mock_todo_repository():
    with patch("todo_repository.TodoRepository") as mock_todo_repository:
        yield mock_todo_repository


@pytest.fixture(scope="module")
def mock_todo():
    with patch("todo.Todo") as mock_todo:
        yield mock_todo


@pytest.fixture()
def client(mock_todo_repository, mock_todo):
    from api import app

    app.config.update(
        {
            "TESTING": True,
        }
    )
    app.static_folder = "../tests/build"
    return app.test_client()


@pytest.fixture(autouse=True)
def mock_db_client():
    with patch("db.DevXMongoClient") as mock_client:
        mock_db = MagicMock()
        mock_collection = MagicMock()
        # Adjusted to ensure inserted_id is a simple value
        insert_one_return_value = MagicMock(inserted_id="123")
        mock_collection.insert_one.return_value = insert_one_return_value

        mock_client.return_value = mock_db
        mock_db.__getitem__.return_value = mock_collection
        yield mock_client
