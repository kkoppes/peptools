def test_request_api_time(client):
    """
    GIVEN a running Flask app
    WHEN the /api/time endpoint is accessed
    THEN it should return a JSON response with status 200 OK.
    """
    response = client.get("/api/time")
    assert response.status == "200 OK"
    assert response.content_type == 'application/json'


# def test_request_bad_path(client):
#     """
#     GIVEN a running Flask app
#     WHEN a non-existent route is accessed (e.g., /api/nonexistent)
#     THEN it should return status 404 Not Found.
#     """
#     response = client.get('/api/nonexistent')

#     assert response.status == "404 NOT FOUND"
