from todo_repository import TodoRepository


class Todo:
    repository: TodoRepository

    def __init__(self):
        self.repository = TodoRepository()

    def update(self, todo_id: str, todo_dict: dict):
        title = todo_dict.get('title')
        todos = self.repository.list_by_title(title)
        if 1 < len(todos) or (len(todos) > 0 and todos[0].get('_id') != id):
            raise Exception(f'already existing todo with title {title}')

        return self.repository.update(todo_id, todo=todo_dict)

    def add(self, todo_dict: dict):
        title = todo_dict.get('title')
        todos = self.repository.list_by_title(title)
        if 0 < len(todos):
            raise Exception(f'already existing todo with title {title}')

        return self.repository.add(todo=todo_dict)
