import logging
import sys
import time
import json
from flask import Flask, Response, jsonify, redirect, request
from flask_cors import CORS
from bson.json_util import dumps
from todo import Todo
from todo_repository import TodoRepository
from repo import Repository
# from schema_factory import validate_data  # , load_schema

app = Flask(
    __name__,
    static_folder="../build",
    static_url_path="/",
)
app.config["APPLICATION_ROOT"] = "mbe4d"
logger = logging.getLogger(__name__)


@app.errorhandler(404)
def not_found(e):
    logger.error(e)
    return Response("Page not found", 404)


@app.route("/api/time")
def get_current_time():
    return {"epoch": time.time(), "verbose_time": time.asctime()}


@app.route("/api/todos", methods=["GET"])
def get_todos():
    """Get all todo items."""
    todos = TodoRepository().list()
    return jsonify(json.loads(dumps(todos))), 200


@app.route("/api/todos/<string:todo_id>", methods=["GET"])
def get_todo(todo_id):
    """Get a specific todo item by its ID."""
    todo = TodoRepository().get(todo_id)
    if not todo:
        return jsonify({"message": "Todo not found"}), 404

    return jsonify(json.loads(dumps(todo))), 200


@app.route("/api/todos", methods=["POST"])
def add_todo():
    """Create a new todo item."""
    data = request.get_json()
    if "title" not in data or "description" not in data:
        return jsonify({"message": "Missing required fields"}), 400

    try:
        result = Todo().add(
            {"title": data["title"], "description": data["description"]}
        )
        return jsonify({"id": str(result.inserted_id)}), 200

    except Exception as error:
        logger.error(error)
        return "Something went wrong", 500


@app.route("/api/todos/<string:todo_id>", methods=["PUT"])
def update_todo(todo_id):
    """Update a todo"""
    data = request.get_json()

    if "title" not in data or "description" not in data:
        return jsonify({"message": "Missing required fields"}), 400
    try:
        result = Todo().update(
            todo_id, {"title": data["title"], "description": data["description"]}
        )
        return (
            jsonify({"updated_count": result.modified_count, "updated_data": data}),
            200,
        )

    except Exception as error:
        logger.error(error)
        return "Something went wrong", 500


@app.route("/api/todos/<string:todo_id>", methods=["DELETE"])
def delete_todo(todo_id):
    """Delete a todo item by its ID."""
    try:
        result = TodoRepository().delete(todo_id)
        return jsonify({"deleted_count": result.deleted_count}), 200

    except Exception as error:
        logger.error(error)
        return "Something went wrong", 500


@app.route("/api/<collection>", methods=["POST"])
def create_document(collection):
    try:
        if request.content_type != 'application/json':
            return jsonify({"error": "Content-Type must be application/json"}), 400

        data = request.get_json()
        repo = Repository(collection)
        inserted_id = repo.add(data)
        return jsonify({"message": "Document added successfully", "id": str(inserted_id)}), 201
    except Exception as e:
        # Log the exception for debugging
        print(e)
        # Return a more generic error response to the client
        return jsonify({"error": "An error occurred processing your request"}), 500


@app.route("/api/<collection>", methods=["GET"])
def get_collection(collection):
    # data = request.json
    repo = Repository(collection)  # Initialize repository with dynamic collection name
    # Proceed with validation and other logic as before

    records = repo.list()
    return jsonify(json.loads(dumps(records))), 200


# The following section is for when running the app locally:
if __name__ == "__main__" and sys.platform in ["win32", "darwin"]:

    @app.route("/")
    def index():
        # You are running locally
        # Frontend should be running with NPM on localhost:5173!
        return redirect("http://localhost:5173/", code=302)

    CORS(app)
    app.debug = True
    app.run()

# The following section is for when running on DevX.
# Your frontend will have been built to an HTML file which is served.
else:

    @app.route("/")
    def index():
        return app.send_static_file("index.html")
