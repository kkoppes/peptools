import os
import json
from pathlib import Path
from pydantic import BaseModel, ValidationError, create_model
from typing import Any, Dict, Tuple, Type


def json_schema_to_pydantic_model(schema: Dict[str, Any]) -> Type[BaseModel]:
    """
    Converts a JSON Schema to a Pydantic model.

    Parameters:
    - schema: The JSON Schema to convert.

    Returns:
    - A Pydantic model class.
    """
    fields = {}

    for property_name, property_info in schema.get("properties", {}).items():
        field_type = property_info.get("type")

        # Simple type mapping, extend this as needed
        pydantic_type = {
            "string": str,
            "integer": int,
            "number": float,
            "boolean": bool,
            "array": list,
            "object": dict,
        }.get(field_type, Any)

        # Check if the field is required
        default = ...
        if "required" in schema and property_name not in schema["required"]:
            default = None

        fields[property_name] = (pydantic_type, default)

    # Create and return the dynamic Pydantic model
    return create_model(schema.get("title", "DynamicModel"), **fields)


def validate_dynamic(
    instance: Dict[str, Any], schema_definition: Dict[str, Tuple[Type, ...]]
) -> Tuple[bool, str]:
    """
    Dynamically validates 'instance' against a schema defined at runtime.

    Parameters:
    - instance: The data to validate.
    - schema_definition: A dictionary where keys are field names and values are tuples
      of (type, default value) or just (type,) if no default value.

    Returns:
    - A tuple (is_valid, error message or '').
    """
    DynamicModel = json_schema_to_pydantic_model(schema_definition)

    try:
        DynamicModel.parse_obj(instance)
        return True, ""
    except ValidationError as e:
        return False, e.json()


# JSON schema files are in a directory named 'schemas'
SCHEMA_DIR: Path = Path(__file__).parent / Path("schemas")
# SCHEMA_DIR = "schemas"


def load_schema(collection_name):
    schema_path = os.path.join(SCHEMA_DIR, f"{collection_name}_schema.json")
    print(schema_path)
    try:
        with open(schema_path, "r") as schema_file:
            schema = json.load(schema_file)
            return schema
    except FileNotFoundError:
        print("FileNotFoundError")
        return None


# Modify the validate_data function to use the schema factory
def validate_data(collection, data):
    print(f"{collection=}")
    print(f"{data=}")
    schema = load_schema(collection)
    if not schema:
        return False, "Schema not found for the provided collection."
    try:
        validate_dynamic(instance=data, schema_definition=schema)
    except ValidationError as e:
        return False, str(e)
    return True, ""
