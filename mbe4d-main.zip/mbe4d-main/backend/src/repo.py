from bson import ObjectId
from db import DevXMongoClient


class Repository:
    def __init__(self, collection_name):
        client = DevXMongoClient()  # Ensure this client is properly configured
        self.db = client["database"]  # Use your actual database name
        self.collection = self.db[collection_name]

    def list(self):
        return list(self.collection.find({}))

    def find_by(self, criteria: dict):
        return list(self.collection.find(criteria))

    def get(self, id: str):
        return self.collection.find_one(ObjectId(id))

    def add(self, document: dict):
        return self.collection.insert_one(document)

    def update(self, id: str, document: dict):
        return self.collection.update_one({"_id": ObjectId(id)}, {"$set": document})

    def delete(self, id: str):
        return self.collection.delete_one({"_id": ObjectId(id)})
