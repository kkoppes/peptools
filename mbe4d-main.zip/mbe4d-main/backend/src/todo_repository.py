from bson import ObjectId

from db import DevXMongoClient


class TodoRepository:
    def __init__(self):
        client = DevXMongoClient()
        self.mydb = client["database"]
        self.collection = self.mydb["todos"]

    def list(self):
        todos = list(self.collection.find({}))
        return todos

    def list_by_title(self, title: str):
        todos = list(self.collection.find({"title": title}))
        return todos

    def get(self, id: str):
        todo = self.collection.find_one(ObjectId(id))
        return todo

    def add(self, todo: dict):
        return self.collection.insert_one(todo)

    def update(self, id: str, todo: dict):
        return self.collection.update_one(ObjectId(id), {'$set': todo})

    def delete(self, id: str):
        return self.collection.delete_one({'_id': ObjectId(id)})
