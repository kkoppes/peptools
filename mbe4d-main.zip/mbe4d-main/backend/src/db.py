import sys
from devx.mongo_util import DevxMongoClientBuilder


def DevXMongoClient():
    """
        This function returns a MongoClient connection object with the
        correct connection parameters depending on the environment - local or AWS.
    """

    if sys.platform in ["win32", "darwin"]:
        # Running locally, try to connect to a local MongoDB client.
        db_client = DevxMongoClientBuilder.build_local_client()

    else:
        # Running on DevX, retrieve the connection information and credentials
        # from container environment variables
        db_client = DevxMongoClientBuilder.build_prod_client()

    return db_client
