# mbe4d

## Table of Contents

- [Description](#description)
- [Usage](#usage)
- [Support](#support)
- [Contributing](#contributing)
- [Contact](#contact)
- [Getting Started](#getting-started)
- [Local Development Guide](#local-usage)
- [Deployment](#deployment)
- [Where is my App](#where-is-my-app) 
- [Vite Config File](#config)
- [Testing](#testing)

## Description 

This DevX template is designed to develop websites with a React frontend and a Flask/Python backend. When you're ready, replace this text with a description of what your library does.

The frontend has been bootstrapped using [vite](https://vitejs.dev) and has been integrated with [Airbus Design System](https://github.airbus.corp/uxid/airbus-design-system)

## Usage

Use this space to show useful examples of how a project can be used. Additional screenshots, code examples and demos work well in this space. You may also link to more resources.

You might also add a link here to further documentation.

## Support

Mention where to get support - for instance via chat group.


## Contributing

Here you can add some information about how contributions would be appreciated! Here is some sample text:

Thank you for considering contributing to our project! We appreciate your time and effort. Please take a moment to review the following guidelines to ensure a smooth and effective collaboration. Ways to Contribute include:

- Spread the word
- Give feedback in our [chat room](#)
- Report bugs or missing features by creating issues
- Propose bug fixes or features by submitting a pull request

## Contact

Your Name - your.email@airbus.com

GitHub Owner Team: group:default/makerspace-mbe

## Getting Started

### Frontend

For Windows users, the easiest and fastest way to get Node/NPM installed is with Node Version Switcher, in the software catalogue. Make sure to allow follow the [guide on Confluence](https://goto/nvs) for mandatory configuration information.

There is further information on the Enterprise DevOps space, on the page [Use a npm repository](https://confluence.airbus.corp/x/ZIBQAQ).

Start application
* install dependencies<br>
`npm install` or `yarn install`
* start local server<br>
`npm dev` or `yarn dev`

> NOTE: <br>
> 
> Choose any of your preferred package manager 'npm' or 'yarn' and make sure to use that throughout the development. Combining yarn with npm or vice versa will result in conflicts.
> 
Yarn is generally faster. To install it globally, use `npm install -g yarn`. Do not mix package managers as it might cause conflicts.


### Backend

For Windows users, the easiest and fastest way to get Python installed is with Miniforge, an open source version of Anaconda, in the software catalogue. Make sure to allow follow the [guide on Confluence](https://goto/python) for mandatory configuration information. With Miniforge installed, you can create an environment with a Python version of your choice.

There is further information on the Enterprise DevOps space, on the section [Configure pip to install packages](https://confluence.airbus.corp/x/CwBS)

Activate or create your conda/venv environment and in the backend folder, run:

```
pip install -r requirements.txt
```

## Local Usage

### Frontend

In the frontend directory, you can run:

#### `yarn dev` 

Runs the app in the development mode.<br>
Open [Open Link](http://localhost:5173/mbe4d) to view it in the browser.
>To change the default port update the [server config option](https://vitejs.dev/config/server-options.html) in vite config file `vite.config.ts`

The page will reload if you make edits.<br>
You will also see any lint errors in the console.

#### `yarn test`

Launches the test runner in the interactive watch mode.<br>
See the doc [vitest](https://vitest.dev/) for more information.

#### `yarn test:coverage`

Launches the test runner with coverage enabled.

#### `yarn preview`

This will boot up a local static web server that serves the files from dist at [http://localhost:4173](http://localhost:4173)
It's an easy way to check if the production build looks OK in your local environment.
>You may configure the port of the server by passing the --port flag as an argument.
Learn more about this from [here](https://vitejs.dev/guide/static-deploy.html#testing-the-app-locally)
#### `yarn lint`

Launches the linter.

#### `yarn lint:fix`

It will run eslint --fix that fix every rule violation it is capable of fixing, actually overwrite the code, and print out any warnings or errors it was incapable of fixing
#### `yarn run build`

Builds the app for production to the `build` folder.<br>
It correctly bundles React in production mode and optimizes the build for the best performance.

Your app is ready to be deployed!

See the section about [deployment](https://vitejs.dev/guide/build.html) for more information.

### Backend

With your conda/venv environment activated, navigate to the backend folder, and run:

```
python api.py
```

### Database

#### Installing the database locally
MongoDB can be installed using conda/pip. In your conda/venv environment of choice, run:

```
conda install mongodb 
```
or
```
pip install mongodb
```
If you are using miniforge, the default location for mongodb is not usable. The solution is to create a dedicated folder. With the same conda/venv environment activated as before, run:

```
mongod --dbpath C:\Users\username\your_folder
```
## Deployment

This app is deployed using DevX. For more information how the DevX build and deployment works, please see the [dedicated template readme](https://github.airbus.corp/Airbus/software-templates/tree/master/flask-app).

## Where is my app

If the deployment succeeds, your app will be available from the following [REPLACE ME](https://airbus.com/)

## Config

You can modify the config for your vite app by modifying `vite.config.ts`.
Learn more about the available [config options](https://vitejs.dev/config/)

## Testing

### Frontend

This project has been configured with [vitest](https://vitest.dev/guide/) for testing pupose because it requires minimal configuration compared to Jest or any other available testing tools.
Also it is built on top of Jest and offers compatibility with most of the Jest API, making it easy to use.

### Backend

This boilerplate includes some sample test cases. To run these, navigate to the backend folder of the repo and run `pytest`.


