/// <reference types="vitest" />
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig(({mode}) => {
  let backendURL = '';

  if (mode === 'development') {
    backendURL = 'http://localhost:5000';
  } else {
    backendURL = '/mbe4d';
  }

  return{
  plugins: [react()],
  base: '/mbe4d',
  define: {
    'process.env': {
      NODE_ENV: mode,
      VITE_BACKEND_URL: backendURL,
    },
  },
  test: {
    globals : true,
    environment: 'jsdom',
    setupFiles: './src/test/setupTests.ts',
  },
  }
})