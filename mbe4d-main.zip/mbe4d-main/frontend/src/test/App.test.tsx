import {render, screen} from '@testing-library/react';
import {it, describe, expect} from 'vitest';
import App from '../App';

describe('App.tsx', () => {
    it('renders home page', () => {
        render(<App />);
        const homeElement = screen.getByText(/Home/i);
        expect(homeElement).toBeInTheDocument()
    })
})