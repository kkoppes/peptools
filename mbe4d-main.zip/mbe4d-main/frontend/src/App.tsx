import React, { useState, useEffect } from 'react';
import {
  Container,
  Header,
  Hidden,
  Divider,
  Banner,
  Button,
  Dialog,
  DialogHeader,
  DialogActions,
  DialogContent,
  IconButton,
  SideNav,
  SideNavItem,
  SideNavSection,
  Tab,
  Tabs,
    Tooltip,
    Avatar
} from '@airbus/components-react';
import { Search } from '@airbus/icons/react';
import { Todo } from './Todo';
import { PushRecordPage } from './PushRecordPage'; // Make sure to import your new component


interface userData {
  sub: string,
  identities: string
}

interface identities{
  userId: string
}

interface timeData {
  verbose_time: string,
  epoch: string
}

function App() {
  const [showDialog, setShowDialog] = useState(false);
  const [showSideNav, setShowSideNav] = useState(false);
  const [page, setPage] = useState('/home');
  const [user, setUser] = useState('');
  const [currentTime, setCurrentTime] = useState('');
  const backendServer = process.env.VITE_BACKEND_URL;

  const navigateTo = (page: React.SetStateAction<string>) => {
    setPage(page);
    setShowSideNav(false);
  };
  
  useEffect(() => {
    const getUser = async () => {
      try{
        const response = await fetch("/api/users/authenticated")
        const data : userData = await (response.json() as Promise<userData>)
        const userInfo : identities[] = JSON.parse(data.identities) as identities[]
        setUser(userInfo[0].userId)
      }
      catch(error){
        console.error('No valid response')
      }
    }
    getUser().catch((error) => {
      console.error(error)
    });
  }, [])

  useEffect(() => {
    const getTime = async () => {
      try {
        const response = await fetch(`${backendServer}/api/time`);
        const data: timeData = await (response.json() as Promise<timeData>);
        setCurrentTime(data.verbose_time);
      } catch (error) {
        console.error('No valid response');
        setCurrentTime('Unable to retrieve time from backend');
      }
    };
    getTime().catch((error) => {
      console.error(error);
    });
  }, [backendServer]);

  return (
    <div>
      <Hidden down="sm">
        <Header appName="App">
          <Tabs value={page} onChange={(_event, value) => setPage(value as React.SetStateAction<string>)}>
            <Tab value="/home">Home</Tab>
            <Tab value="/push">Push</Tab>
            <Tab value="/more">More</Tab>
            <Tab value="/about">About</Tab>
          </Tabs>
          <IconButton variant="ghost">
            <Search />
          </IconButton>
          <Button variant="primary" onClick={() => setShowDialog(true)}>
            Contact
          </Button>
          <Tooltip placement="bottom" label={user}>
            <Avatar size="small"/>
          </Tooltip>
        </Header>
      </Hidden>
      <Hidden up="sm">
        <Header appName="App" showMenuButton onMenuButtonClick={() => setShowSideNav(true)}>
          <IconButton variant="ghost">
            <Search />
          </IconButton>
        </Header>
        <SideNav open={showSideNav} onClose={() => setShowSideNav(false)}>
          <SideNavSection
            style={{
              paddingTop: 56,
              flex: 1,
            }}
          >
            <SideNavItem selected={page === '/home'} onSelected={() => navigateTo('/home')}>
              Home
            </SideNavItem>
            <SideNavItem selected={page === '/more'} onSelected={() => navigateTo('/more')}>
              More
            </SideNavItem>
            <SideNavItem selected={page === '/about'} onSelected={() => navigateTo('/about')}>
              About
            </SideNavItem>
            <SideNavItem selected={page === '/push'} onSelected={() => navigateTo('/push')}>
            pushRecord
            </SideNavItem>
          </SideNavSection>
          <Divider inset />
          <Button
            variant="primary"
            onClick={() => setShowDialog(true)}
            style={{
              margin: '0.5rem 1rem',
            }}
          >
            Contact
          </Button>
        </SideNav>
      </Hidden>
      <Container component="main">
        <h1>{page}</h1>
        <Banner>
          Showing you an example of an API call, this is a call to the backend to get the current time: {currentTime}
        </Banner>
        {page === '/home' && <Todo />}
        {page === '/push' && <PushRecordPage />}
        <Dialog open={showDialog} onClose={() => setShowDialog(false)}>
        <DialogHeader>Contact details for "Application Name"</DialogHeader>
          <DialogContent>
            {/* If available, add your application code from MyPortfolio */}
            <p><strong>Application Code:</strong> 11BC</p>
            {/* If relevant, add your Application Manager */}
            {/* By IM governance, if an Application Manager is not declared it is the person who created the application. */}
            <p><strong>Application Manager(s):</strong> Phillip Lederbogen</p>
            {/* Please add a support contact/instructions - ServiceNow, email or link to a Google Group */}
            <p><strong>For support, please contact:</strong>kristiaan.koppes@airbus.com</p>
          </DialogContent>
          <DialogActions>
            <Button variant="primary" onClick={() => setShowDialog(false)}>
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </div>
  );
}

export default App;
