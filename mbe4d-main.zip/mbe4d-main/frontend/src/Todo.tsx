import React, { useState, useEffect, useCallback } from 'react';
import {
  Button,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Dialog,
  DialogActions,
  DialogContent,
  DialogHeader,
  Divider,
  Inline,
  Input,
} from '@airbus/components-react';

import { AirplanemodeActive } from '@airbus/icons/react';

console.log(process.env.VITE_BACKEND_URL)

export type TodoItem = {
  _id: {
    $oid: string;
  };
  title: string;
  description: string;
};

export const TodoCard = ({ todo, onDelete }: { todo: TodoItem; onDelete: (todoId: string) => Promise<void> }) => {
  const handleDelete = () => {
    onDelete(todo._id.$oid);
  };

  return (
    <div>
      <Card>
        <CardHeader icon={<AirplanemodeActive />} title={todo.title} />
        <CardContent>
          <p>{todo.description}</p>
        </CardContent>
        <CardActions>
          <Button variant="warning" onClick={handleDelete}>
            Delete
          </Button>
        </CardActions>
      </Card>
    </div>
  );
};

export const TodoCards = ({ todos, onDelete }: { todos: TodoItem[]; onDelete: (todoId: string) => Promise<void> }) => {
  return (
    <div className="bg-coolgrey-10 p-4">
      <Inline spacing="4-x" wrap>
        {todos.map((todo) => {
          return <TodoCard key={todo._id.$oid} todo={todo} onDelete={onDelete} />;
        })}
      </Inline>
    </div>
  );
};
export const Todo = () => {
  const backendServer = process.env.VITE_BACKEND_URL;
  const [open, setOpen] = useState(false);
  const [todos, setTodos] = useState<TodoItem[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const fetchTodos = useCallback(async () => {
    try {
      const res = await fetch(`${backendServer}/api/todos`);
      const data = await res.json();
      setTodos(data);
    } catch (e) {
      console.error('Error fetching the todos', e);
    }
  }, [backendServer])

  useEffect(() => {
    fetchTodos()
  }, [fetchTodos]);

  const addTodo = async () => {
    try {
      await fetch(`${backendServer}/api/todos`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ title: title, description: description }),
      });

      setTitle('');
      setDescription('');
      fetchTodos();
    } catch (e) {
      console.error('Error adding todo:', e);
    }
  };

  const deleteTodo = async (todoId: string) => {
    try {
      await fetch(`${backendServer}/api/todos/${todoId}`, {
        method: 'DELETE',
      });
      fetchTodos();
    } catch (e) {
      console.error('Error deleting todo:', e);
    }
  };

  return (
    <React.Fragment>
      <div
        style={{
          paddingTop: '20px',
          display: 'flex',
          marginLeft: '10px',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <TodoCards todos={todos} onDelete={deleteTodo} />
        <Divider />
      </div>

      <div
        style={{
          paddingTop: '20px',
          display: 'flex',
          marginLeft: '10px',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <Button variant="primary" onClick={() => setOpen(true)} aria-haspopup="dialog">
          ➕ ADD
        </Button>
      </div>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogHeader>Add Todo Item</DialogHeader>
        <DialogContent>
          <Input
            type={'text'}
            value={title}
            placeholder={'title'}
            onChange={(e) => {
              setTitle(e.target.value);
            }}
          />
          <br />
          <Divider />
          <Input
            type={'text'}
            value={description}
            placeholder={'description'}
            onChange={(e) => {
              setDescription(e.target.value);
            }}
          />
        </DialogContent>
        <DialogActions>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={() => {
              addTodo();
              setOpen(false);
            }}
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );
};
