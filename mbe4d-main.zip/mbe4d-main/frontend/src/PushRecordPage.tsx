import React, { useState } from 'react';
import {
  Button,
  Input,
  Dialog,
  DialogHeader,
  DialogContent,
  DialogActions,
  Divider,
} from '@airbus/components-react';

console.log(process.env.VITE_BACKEND_URL)

export const PushRecordPage = () => {
  const [collectionName, setCollectionName] = useState('');
  const [recordData, setRecordData] = useState('');
  const [open, setOpen] = useState(false);
  const backendServer = process.env.VITE_BACKEND_URL; // Make sure this is correctly configured in your .env file

  const pushRecord = async () => {
    let parsedData;
    try {
      // Parse the recordData from the input string to JSON
      parsedData = JSON.parse(recordData);
    } catch (error) {
      alert('Failed to parse record data as JSON. Please correct the format and try again.');
      console.error('Error parsing record data:', error);
      return; // Prevent sending a request if parsing fails
    }

    try {
      const response = await fetch(`${backendServer}/api/${collectionName}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsedData), // Send the parsed object
      });

      if (response.ok) {
        alert('Record pushed successfully');
      } else {
        // Attempt to read the error message from the response, if any
        const errorMsg = await response.text();
        alert(`Failed to push the record: ${errorMsg}`);
      }
    } catch (error) {
      console.error('Error pushing the record:', error);
    }
  };

  return (
    <React.Fragment>
      <Button variant="primary" onClick={() => setOpen(true)}>
        Push Record to Collection
      </Button>

      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogHeader>Push Record</DialogHeader>
        <DialogContent>
          <Input
            type="text"
            value={collectionName}
            onChange={(e) => setCollectionName(e.target.value)}
            placeholder="Collection Name"
          />
          <Divider />
          <Input
            type="text"
            value={recordData}
            onChange={(e) => setRecordData(e.target.value)}
            placeholder="Record Data (JSON format)"
          />
        </DialogContent>
        <DialogActions>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={() => {
            pushRecord();
            setOpen(false);
          }}>
            Push
          </Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );
};
