package Nastran;

use strict;
use warnings;

1;
__END__

=head1 NAME

Nastran - Perl extension for manipulation of Nastran models

=head1 SYNOPSIS

  use Nastran;
  my $bdf = Nastran::BDF->new($filename);
  my $card = $bdf->readcard;
  print $card;

  my $f06 = Nastran::f06->new($filename);
  my $block = $f06->next_block;
  while (defined $block) {
   my @data = $block->read_result;
   while (@data) {
    @data = $block->read_result;
   }
   $block = $f06->next_block;
  }

=head1 DESCRIPTION

The Nastran::BDF module will open a Nastran finite element bulk data file and read and write
its contents, one card at at time.

The module understands free, long and short field format.
It is assumed however, that any continuation cards follow in their
correct order; no attempt is made to sort the deck.

Card replication is not supported.

The Nastran::f06 module will open a Nastran .f06 results file and read its
contents.

=head1 SUBROUTINES/METHODS

=over

=item my $bdf = Nastran::BDF->new($filename);

Opens an (ASCII) bulk data file $filename and passes back a Nastran::BDF object
for use with subsequent readcard calls.

=item my $card = $bdf->readcard;

Reads the next card in the $bdf and passes it back as an array blessed into
a Nastran::Card object. The array is held as $card->{data}, and therefore the
first field is $card->{data}[0]. The last field has index $#{$card->{data}}.

=item my $card = Nastran::Card->new_from_array(@array);

=item $card->to_set

Blesses a SET card into a Set::IntSpan set.

Takes an array of field and blesses it into a Nastran::Card object.

=item String operations

String operations with $card are overloaded so that the following are possible:

print $card;

print <FH> $card;

etc..

Short field format as default. If the first field contains an asterix (*),
then long field format is used.

=item my $f06 = Nastran::f06->new($filename);

Opens a .f06 results file $filename and passes back a Nastran::f06 object for
use with subsequent first_block calls.

=item my $block = $f06->first_block;

Reads the first block in the $f06 and passes back a Nastran::f06::Block object.
The block name is stored in $block->{name}.

=item $block = $block->next_block;

Reads subsequent blocks as above. undef is returned if there are no more blocks.

=item $name = $block->name;

Returns the name of the block.

=item my @data = $block->read_result;

Returns results data for $block as an array. undef is returned if there are no
more results for $block.

=back

=head1 TO DO

Probably lots. :-)

=head1 SEE ALSO

FeResPost L<http://www.ferespost.be/> is a ruby extension allowing the rapid development of small programs to be used to automate the post-processing of structural analysis finite element results.

=head1 AUTHOR

Jeffrey Ratcliffe, L<Jeffrey.Ratcliffe@gmail.com>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2007--2011 by Jeffrey Ratcliffe

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.5 or,
at your option, any later version of Perl 5 you may have available.

=cut
