package Nastran::Octree;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::Octree::Box;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub new {
 my ( $class, $box ) = @_;
 my $self = {};
 $self->{box} = $box;
 bless $self, $class;
 return $self;
}

# insert given entity into proper tile of provided tree.
sub insert {
 my ( $self, $eid, $box ) = @_;
 if ( not defined $box or not $box->isa('Nastran::Octree::Box') ) {
  croak 'Nastran::Octree::Box required';
 }

 # If tree has no tiles, create them
 if ( not $self->{tiles} ) {
  my @mid;
  for ( 0 .. 2 ) {
   $mid[$_] = ( $self->{box}[0][$_] + $self->{box}[1][$_] ) / 2;
  }
  for my $i ( 0, 1 ) {    # x
   for my $j ( 0, 1 ) {    # y
    for my $k ( 0, 1 ) {    # z
     my $tile = Nastran::Octree::Box->new();
     for my $l ( 0, 1 ) {    # max or min
      $tile->[$l][0] = $i == $l ? $self->{box}[$l][0] : $mid[0];
      $tile->[$l][1] = $j == $l ? $self->{box}[$l][1] : $mid[1];
      $tile->[$l][2] = $k == $l ? $self->{box}[$l][2] : $mid[2];
     }
     $self->{tiles}[$i][$j][$k] = Nastran::Octree->new($tile);
    }
   }
  }
 }

 # Find a tile for the entity
 for my $i ( 0, 1 ) {        # x
  for my $j ( 0, 1 ) {       # y
   for my $k ( 0, 1 ) {      # z
    if ( $self->{tiles}[$i][$j][$k]{box}->box_in_box($box) ) {
     $self->{tiles}[$i][$j][$k]->insert( $eid, $box );
     return;
    }
   }
  }
 }

 # Entity doesn't fit in tiles, so put it here
 push @{ $self->{entities} }, $eid;
 return;
}

# traverses the tree, returning a list of entities in the boxes enclosing the given entity

sub find_entities {
 my ( $self, $entity ) = @_;
 if (
  not defined $entity
  or not( $entity->isa('Math::Vector::Real')
   or $entity->isa('Nastran::Octree::Box') )
   )
 {
  croak 'Math::Vector::Real or Nastran::Octree::Box required';
 }
 if ( $entity->isa('Nastran::Octree::Box') ) {
  for ( 0 .. 2 ) {
   if ( not defined $entity->[0][$_] or not defined $entity->[1][$_] ) {
    croak 'Box must be defined';
   }
  }
 }
 my @entities;
 if ( defined $self->{tiles} ) {
  for my $i ( 0, 1 ) {    # x
   for my $j ( 0, 1 ) {    # y
    for my $k ( 0, 1 ) {    # z
     if (
      (
           $entity->isa('Math::Vector::Real')
       and $self->{tiles}[$i][$j][$k]{box}->vector_in_box($entity)
      )
      or ( $entity->isa('Nastran::Octree::Box')
       and $self->{tiles}[$i][$j][$k]{box}->box_in_box($entity) )
       )
     {
      @entities = @{ $self->{tiles}[$i][$j][$k]->find_entities($entity) };
      last;
     }
    }
    last if (@entities);
   }
   last if (@entities);
  }
 }
 if ( defined $self->{entities} and @{ $self->{entities} } ) {
  push @entities, @{ $self->{entities} };
 }
 return \@entities;
}

1;

__END__

=head1 NAME

Nastran::Octree - an octree optimised for FE entities

=head1 SYNOPSIS

Implements a k-D tree to optimise searching for spacial data.

=head1 DESCRIPTION

=head1 VERSION

Nastran::Octree is part of the Perl module Nastran, and shares its version number.

=head1 SUBROUTINES/METHODS

=over

=item Nastran::Octree->new()
creates a new Nastran::Octree instance.

=item $tree->insert($eid, $box)
inserts the entity id $eid with bounding box $box (a Nastran::Octree::Box
object) in the smallest tile of $tree in which $box will fit, creating new tiles
where necessary.

=item $tree->find_entities($entity)
returns an array of the entities in the boxes enclosing $entity, which can be
either a Nastran::Octree::Box or Math::Vector::Real object.

=back

=head1 DIAGNOSTICS

=head1 CONFIGURATION AND ENVIRONMENT

Nastran::Octree is pure Perl, and should therefore work on every platform where
Perl is available.

=head1 DEPENDENCIES

Nastran::Octree requires Nastran::Octree::Box, and can use vectors supplied by
Math::Vector::Real.

=head1 INCOMPATIBILITIES

None known.

=head1 BUGS AND LIMITATIONS

None known.

=head1 SEE ALSO

L<http://en.wikipedia.org/wiki/Octree>

=head1 AUTHOR

Jeffrey Ratcliffe, L<Jeffrey.Ratcliffe@premium-aerotec.com|mailto:Jeffrey.Ratcliffe@premium-aerotec.com>

=head1 LICENSE AND COPYRIGHT

Copyright (C) 2010--2015 by Jeffrey Ratcliffe

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.5 or,
at your option, any later version of Perl 5 you may have available.

=cut
