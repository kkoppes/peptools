package Nastran::f06;    ## no critic (Capitalization)

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::f06::Block;
use Nastran::f06::Block::BulkDataEcho;
use English qw(-no_match_vars);

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 $VERSION = '0.56';

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub new {
 my $class = shift;
 my $self  = {};
 $self->{filename} = shift;
 open my $fh, '<', $self->{filename}    ## no critic (RequireBriefOpen)
   or croak "can't open $self->{filename}: $OS_ERROR";
 $self->{FH} = $fh;
 bless $self, $class;
 return $self;
}

sub DESTROY {
 my $self = shift;
 close $self->{FH} or croak "can't close $self->{filename}: $OS_ERROR";
 return;
}

sub first_block {
 my $self = shift;
 if ( not $self->isa('Nastran::f06') ) {
  croak "$self must be a Nastran::f06 object";
 }
 seek $self->{FH}, 0, 0;
 return $self->next_block;
}

sub next_block {
 my $self = shift;
 if ( not $self->isa('Nastran::f06') ) {
  croak "$self must be a Nastran::f06 object";
 }
 my $fh = $self->{FH};

 my ( $pos, $name, $subcase );
 while (<$fh>) {

  # note start of page
  if (/^1/xsm) { $pos = tell $fh }
  my $block = Nastran::f06::Block->new;

  # give the block access to the subcase table
  $block->{parent}   = $self;
  $block->{FH}       = $fh;
  $block->{filename} = $self->{filename};
  ( $name, $subcase ) = $block->read_block_header;
  if ( not defined $name ) { return }

  # rebless if necessary
  # note this is only ok because Nastran::f06::Block::BulkDataEcho
  # inherits Nastran::f06::Block
  if ( $name eq 'S O R T E D   B U L K   D A T A   E C H O' ) {
   bless $block, 'Nastran::f06::Block::BulkDataEcho';
   $block->{BDF} = {};

   # Need a Nastran::BDF object to register cards
   bless $block->{BDF}, 'Nastran::BDF';
  }

  # is a new a header line if not from news, the previous one was the first or
  # not the same as the previous one.
  if (not defined $block->{name}
   or $name ne $block->{name}
   or not defined $block->{position}
   or not defined $pos
   or ( $pos != $block->{position} ) )
  {
   $block->{name}     = $name;
   $block->{position} = $pos;
   $block->{subcase}  = $subcase;

   # skip down, ready to read data
   $block->read_result_header;

   return $block;
  }
 }
 return;
}

sub bytes_read {
 my $self = shift;
 return tell $self->{FH};
}

sub filename {
 my $self = shift;
 return $self->{filename};
}

1;
