package Nastran::BDF;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::BDF::CaseControl;
use Nastran::BDF::CaseControl::Card::Set;
use Nastran::Card;
use Nastran::Card::Cord2r;
use Nastran::Card::Force;
use Nastran::Card::Grid;
use Nastran::Card::Load;
use Nastran::Card::Seset;
use feature 'switch';
no if $] >= 5.018, warnings => 'experimental::smartmatch';
use English qw(-no_match_vars);
use Readonly;
Readonly my $FIELDS_PER_LINE => 9;
Readonly my $CHARS_PER_FIELD => 8;

my $EMPTY = q{};
my $SPACE = q{ };

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 # set the version for version checking
 # If necessary bump with something like
 #     xargs sed -i "s/\(\$VERSION *= \)'0\.55'/\1'0.56'/" < MANIFEST
 $VERSION = '0.56';

 use base qw(Exporter);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub new {
 my ( $class, $filename, @options ) = @_;
 my $self = {};
 $self->{filename} = $filename;
 if ( not defined $self->{filename} ) { croak "Can't open undefined filename" }
 open my $fh, '<', $self->{filename}    ## no critic (RequireBriefOpen)
   or croak "can't open $self->{filename}: $OS_ERROR";
 $self->{FH} = $fh;
 bless $self, $class;

 for (@options) {
  $self->{options}{ uc() } = 1;    ## no critic (ProhibitParensWithBuiltins)
 }
 return $self;
}

sub DESTROY {
 my $self = shift;
 if ( defined $self->{FH} ) {
  close $self->{FH} or croak "can't close $self->{filename}: $OS_ERROR";
 }
 return;
}

# Return the next card from the deck

sub readcard {
 my $self = shift;
 croak "$self must be a Nastran::BDF object" if ( !$self->isa('Nastran::BDF') );
 my $fh = $self->{FH};

 my ( $format, @fields, @line );
 my $original = $EMPTY;
 while (1) {

  # If there is a line in the buffer, use it.
  # Otherwise read the next line from the deck.
  if ( defined $self->{buffer} ) {
   $_ = $self->{buffer};
   undef $self->{buffer};
  }
  else {
   $_ = <$fh>;
  }

  if (defined) {
   chomp;
  }
  else {
   return $self->_extract_fields( \@fields, $original, $format );
  }

  # if we've already got a line and this isn't a continuation card or a comment,
  # or an empty line then put the line in the buffer and return.
  if ( @fields and not /^(?:[ +*\t]|\s*\$|\s*$)/xsm ) {
   my $card = $self->_extract_fields( \@fields, $original, $format );
   if ( defined $card ) {
    $self->{buffer} = $_;
    return $card;
   }
  }
  else {
   if ( $original ne $EMPTY ) { $original .= "\n" }
   $original .= $_;
  }

  # if we haven't got a comment, unpack
  if ( not /^\s*\$/xsm ) {

   ( $format, @line ) = $self->_parse_line($_);

   if ( defined( $self->{section} ) and $self->{section} eq 'CC' ) {
    ( $original, @fields ) = $self->_parse_case_control_card($original);
    my $card = $self->_extract_fields( \@fields, $original, $format );
    if ( defined $card ) { return $card }
   }
   else {

    # If we have a continuation card, skip the first field
    my $cc = /^[ +*]/xsm ? 1 : 0;

    for my $i ( $cc .. $#line ) {
     push @fields, add_exponent( $line[$i] );
    }
   }
  }
 }
 return;
}

sub _extract_fields {
 my ( $self, $fields, $original, $format ) = @_;
 @{$fields} = chop_array( @{$fields} );
 if ( @{$fields} ) {
  my $card = $self->create_card( @{$fields} );
  $card->set_original("$original\n");
  $card->set_format($format);
  return $card;
 }
 return;
}

sub _parse_case_control_card {
 my ( $self, $original ) = @_;
 my $fh    = $self->{FH};
 my $field = $_;
 while ( $field =~ /^\s*SET/xsmi and /,\s*$/xsm and $_ = <$fh> ) {
  chomp;
  $field    .= "\n$_";
  $original .= "\n$_";
 }
 if ( $field =~ /^\s*SET.*,\s*$/xsm and not defined ) {
  carp "Ignoring trailing comma in SET definition in $self->{filename}\n";
 }
 if ( defined and /^BEGIN[ ]BULK/xsmi ) { $self->{section} = 'BULK' }
 return $original, $field;
}

sub _parse_line {
 my ( $self, $line ) = @_;
 my @line;
 my $format = 'small';
 if ( $line =~ /,/xsm ) {
  @line = split /,/xsm, $line;
  $format = 'free';

  # if the card is continued on the next line, pad our array here
  while ( @line < $FIELDS_PER_LINE ) { push @line, $EMPTY }
 }
 else {
  if (/\t/xsm) { $_ = tab2spc($_) }
  if (/[ ]{0,7}[*]/xsm) {
   @line   = unpack 'A8A16A16A16A16';
   $format = 'large';
  }
  else {
   @line = unpack 'A8A8A8A8A8A8A8A8A8';
  }
 }
 if ( not defined $self->{section}
  and /^\s*(?:BEGIN[ ]BULK|ID|NASTRAN|SET|SOL|SUBCASE)/xsmi )
 {
  $self->{section} = 'CC';
 }
 return $format, @line;
}

sub tab2spc {
 my ($s) = @_;

 while ( $s =~ /\t/xsm ) {
  my $i = index( $s, "\t" ) + 1;
  my $j = $CHARS_PER_FIELD - ( $i % $CHARS_PER_FIELD );
  if ( $j >= $CHARS_PER_FIELD ) { $j -= $CHARS_PER_FIELD }
  my $t = $EMPTY;
  while ( $j-- >= 0 ) { $t .= $SPACE }
  $s =~ s/\t/$t/xsm;
 }
 return $s;
}

sub add_exponent {
 my ($n) = @_;

 # The if here is not strictly necessary,
 # but profiling seems to suggest it is worthwhile
 if ( $n =~ /[ ]/xsm ) { $n =~ s/[ ]+//xsmg }

 # The if here is not strictly necessary,
 # but profiling seems to suggest it is worthwhile
 if ( $n =~ /[.]/xsm ) {

  # Perl does not understand exponents without "e" or with "d".
  if ( $n =~ /([+-]?\d*[.]\d*)D?([+-]\d+)/xsmi ) { return $1 . 'e' . $2 }

 }

 return $n;
}

# delete blank trailing fields from an array of fields

sub chop_array {
 my @array = @_;
 while ( @array and $array[-1] eq $EMPTY ) { delete $array[-1] }
 return @array;
}

# Convenience method to read case control

sub read_case_control {
 my $self = shift;
 croak "$self must be a Nastran::BDF object"
   if ( not $self->isa('Nastran::BDF') );
 if ( not defined $self->{case_control} ) {
  $self->{case_control} = Nastran::BDF::CaseControl->new;
 }

 my $card = $self->readcard;

 # Hack to avoid warning messages reading executive control deck/file
 # management deck
 if ( defined $card
  and $card->{data}[0] =~ /^(ASSIGN|CEND|ID|NASTRAN|SOL)/xsmi )
 {

  # We are above case control so skip
  while ( defined $card and $card->{data}[0] !~ /^CEND/xsmi ) {
   $card = $self->readcard;
  }
  $card = $self->readcard;
 }

 while ( defined $card and $card->{data}[0] !~ /^BEGIN[ ]BULK/xsmi ) {
  if ( $card->{data}[0] =~ /^\s*SET$/xsmi ) {
   $self->{case_control}->append_card($card);
  }
  elsif ( $card->{data}[0] !~ /^\s*$/xsm ) {
   $self->{case_control}
     ->append_card( Nastran::BDF::CaseControl::Card->new( $card->{data}[0] ) );
  }
  $card = $self->readcard;
 }
 return $self->{case_control};
}

# Return case control in array of hashes

sub case_control {
 my $self = shift;
 croak "$self must be a Nastran::BDF object"
   if ( not $self->isa('Nastran::BDF') );
 return $self->{case_control};
}

# Convenience method to read selected cards from the complete deck

sub read_model {
 my $self = shift;
 croak "$self must be a Nastran::BDF object"
   if ( not $self->isa('Nastran::BDF') );

 my $card = $self->readcard;
 while ( defined $card ) {
  $card = $self->readcard;
 }
 return;
}

# Helper sub to store those cards requested in new() call

sub register_card {
 my ( $self, $card ) = @_;
 if ( not $self->isa('Nastran::BDF') ) {
  croak "$self must be a Nastran::BDF object";
 }
 my $f1 = uc( $card->{data}[0] );
 $f1 =~ s/[*]//xsm;
 if ( defined $self->{options}{$f1} ) {
  if ( $f1 =~ /^(FORCE|MPC|MOMENT|PLOAD2|PLOAD4|SESET)$/xsm ) {
   if ( defined $self->{bulk_data}{$f1}{ $card->{data}[1] + 0 } ) {
    push @{ $self->{bulk_data}{$f1}{ $card->{data}[1] + 0 } }, $card;
   }
   else {
    $self->{bulk_data}{$f1}{ $card->{data}[1] + 0 } = [$card];
   }
  }
  else {
   # all MAT cards use a single numbering space
   if ( $f1 =~ /^MAT/xsm ) {
    $f1 = 'MAT';
   }
   elsif ( $f1 eq 'PBARL' ) {
    $f1 = 'PBAR';
   }
   elsif ( $f1 eq 'PBEAML' ) {
    $f1 = 'PBEAM';
   }
   $self->{bulk_data}{$f1}{ $card->{data}[1] + 0 } = $card;
  }
 }
 return $card;
}

# Helper sub to call the new() in the right class

sub create_card {
 my ( $self, @fields ) = @_;
 croak "$self must be a Nastran::BDF object"
   if ( not $self->isa('Nastran::BDF') );
 $fields[0] =~ s/[*]//xsm;
 my $card = uc $fields[0];
 given ($card) {
  when ('CORD2R') {
   return $self->register_card(
    Nastran::Card::Cord2r->new_from_array(@fields) );
  }
  when ('FORCE') {
   return $self->register_card( Nastran::Card::Force->new_from_array(@fields) )
     ->validate;
  }
  when ('GRID') {
   return $self->register_card( Nastran::Card::Grid->new_from_array(@fields) );
  }
  when ('LOAD') {
   return $self->register_card( Nastran::Card::Load->new_from_array(@fields) );
  }
  when ('SESET') {
   return $self->register_card( Nastran::Card::Seset->new_from_array(@fields) );
  }
 }
 if ( "$card" =~ /^SET/xsm ) {
  return Nastran::BDF::CaseControl::Card::Set->new(@fields);
 }
 return $self->register_card( Nastran::Card->new_from_array(@fields) );
}

# Return model in hash of hashes

sub bulk_data {
 my $self = shift;
 croak "$self must be a Nastran::BDF object"
   if ( not $self->isa('Nastran::BDF') );
 return $self->{bulk_data};
}

sub bytes_read {
 my $self = shift;
 return tell $self->{FH};
}

sub filename {
 my $self = shift;
 return $self->{filename};
}

1;
