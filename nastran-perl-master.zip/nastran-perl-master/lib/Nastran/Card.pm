package Nastran::Card;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::Card::Force;
use feature 'switch';
no if $] >= 5.018, warnings => 'experimental::smartmatch';
use Try::Tiny;
use overload
  '""'  => 'to_string',
  'cmp' => 'threeway_compare',
  'eq'  => 'to_string',
  'ne'  => 'to_string';

use Readonly;
Readonly my $NUM_FIELDS_LFF              => 4;
Readonly my $NUM_FIELDS_SFF              => 8;
Readonly my $FIELD_WIDTH_SFF             => 8;
Readonly my $FIELD_WIDTH_LFF             => 16;
Readonly my $SIG_FIGS_LFF                => 9;
Readonly my $SIG_FIGS_LOST_DEFAULT_FLOAT => 3;
Readonly my $SIG_FIGS_LOST_MAXIMISE_SCI  => 5;
Readonly my $SIG_FIGS_LOST_DEFAULT_SCI   => 7;
Readonly my $BASE10                      => 10;
Readonly my $GRID1                       => 3;
Readonly my $GRID2                       => 4;
Readonly my $GRID3                       => 5;
Readonly my $GRID4                       => 6;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

our ( $_EXPONENT, $_PATRAN_INT, $_REMOVE_ZEROS, $_MAXIMISE_WIDTH,
 $_REMOVE_TRAILING_ZEROS );

my $EMPTY    = q{};
my $ASTERISK = q{*};
my $PLUS     = q{+};
my $MINUS    = q{-};
my $PERCENT  = q{%};
my $COMMA    = q{,};
my $DOT      = q{.};
my $QUOTE    = q{'};
my $SPACE    = q{ };

my %format = (
 CBAR   => 'AIIII(I  |FFF)AIIFFFFFF',
 CBUSH  => 'AIIII(I  |FFF)IFIFFF',
 CORD2R => 'AIIFFFFFFFFF',
 FORCE  => 'AIIIFFFF',
 GRID   => 'AIIFFFIII',
 LOAD   => 'AIF(FI)+',
 MOMENT => 'AIIIFFFF',
 PBEAML => 'AIIAA    FFF+(AFFFF+)+',
 SPCD   => 'AIIIFIIF',
 TEMP   => 'AIIFIFIF',
);

my %gids = (
 CQUAD4 => [ $GRID1, $GRID2, $GRID3, $GRID4 ],
 CSHEAR => [ $GRID1, $GRID2, $GRID3, $GRID4 ],
 CTRIA3 => [ $GRID1, $GRID2, $GRID3 ],
 CBAR   => [ $GRID1, $GRID2, $GRID3 ],
 CBEAM  => [ $GRID1, $GRID2, $GRID3 ],
 CBUSH  => [ $GRID1, $GRID2 ],
 CROD   => [ $GRID1, $GRID2 ],
 CONROD => [ 2,      $GRID1 ],
 CELAS1 => [ $GRID1, $GRID3 ],
 CELAS2 => [ $GRID1, $GRID3 ],
 FORCE  => [2],
 GRID   => [1],
 MOMENT => [2],
 TEMP => [ 2, $GRID2, $GRID4 ],
);

sub new {
 my $class = shift;
 my $self  = {};
 bless $self, $class;
 return $self;
}

sub new_from_array {
 my ( $class, @data ) = @_;
 if (@data) {
  my $self = $class->new;
  $self->{data} = [@data];
  return $self;
 }
 croak 'Undefined array';
}

sub clone {
 my $self = shift;
 if ( not $self->isa('Nastran::Card') ) {
  croak "$self must be a Nastran::Card object";
 }
 my $card = Nastran::Card->new_from_array( @{ $self->{data} } );
 if ( defined $self->{format} ) { $card->{format} = $self->{format} }
 return $card;
}

sub set_original {
 my $self = shift;
 if ( not $self->isa('Nastran::Card') ) {
  croak "$self must be a Nastran::Card object";
 }
 $self->{original} = shift;
 return $self;
}

sub get_original {
 my $self = shift;
 if ( not $self->isa('Nastran::Card') ) {
  croak "$self must be a Nastran::Card object";
 }
 return $self->{original};
}

sub set_format {
 my $self = shift;
 if ( not $self->isa('Nastran::Card') ) {
  croak "$self must be a Nastran::Card object";
 }
 $self->{format} = shift;
 return $self;
}

sub get_format {
 my $self = shift;
 if ( not $self->isa('Nastran::Card') ) {
  croak "$self must be a Nastran::Card object";
 }
 return $self->{format};
}

sub to_string {
 my $self = shift;
 if ( not $self->isa('Nastran::Card') ) {
  croak "$self must be a Nastran::Card object";
 }
 my @field = @{ $self->{data} };

 # Remove trailing undef and blank fields
 while ( not defined $field[-1] or $field[-1] =~ /^\s*$/xsm ) {
  delete $field[-1];
 }
 if ( not @field ) { return }

 my ( $w, $nf, $cc, $string );
 my $lf = $EMPTY;
 if ( $self->is_lff ) {
  $w  = $FIELD_WIDTH_LFF;
  $nf = $NUM_FIELDS_LFF;
  $cc = $ASTERISK;
  $lf = $cc;
  $field[0] =~ s/[*]//xsm;
 }
 else {
  $w  = $FIELD_WIDTH_SFF;
  $nf = $NUM_FIELDS_SFF;
  $cc = $PLUS;
 }

 $string = @field > 1 ? sprintf '%-8s', "$field[0]$lf" : $field[0];

 my $f    = 0;
 my $type = uc $field[0];
 if ( defined $format{$type} ) {

  # Lose the first field, as we have already printed it
  my $f_in = 1;
  $string .= parse_template(
   template        => substr( $format{$type}, 1, length( $format{$type} ) - 1 ),
   field_width     => $w,
   out_field_index => \$f,
   num_fields      => $nf,
   continuation_card => $cc,
   in_field_index    => \$f_in,
   fields            => \@field,
  );
 }
 else {
  for my $i ( 1 .. $#field ) {
   if ( defined $field[$i] ) { $field[$i] =~ s/\s*//gxsm }
   if ( ++$f > $nf ) {
    $string .= sprintf "\n%-8s", $cc;
    $f = 1;
   }
   given ( $field[$i] ) {
    when ( not defined or /^\s*$/xsm ) {
     $string .= sprintf "$PERCENT$w" . 's', $SPACE;
    }
    when (/'/xsm) {
     $string .= sprintf "$PERCENT$w" . 's', $field[$i];
    }
    when (/[.]/xsm) {
     $string .= sprintfloat( $field[$i], $w );
    }
    when (/^\s*[-+]?[[:digit:]]+\s*$/xsm) {

     # Patran has left-justified integer fields
     if ( $_PATRAN_INT and length $field[$i] < $w ) {
      $string .= sprintf ' %-' . ( $w - 1 ) . 'i', $field[$i];
     }
     else {
      $string .= sprintf "$PERCENT$w" . 'i', $field[$i];
     }
    }
    default {
     $string .= sprintf "$PERCENT$w" . 's', $field[$i];
    }
   }
  }
 }

 # Large field format always requires an even number of lines.
 # Add a blank line if necessary
 if ( $self->is_lff
  and $#field % $NUM_FIELDS_SFF > 0
  and $#field % $NUM_FIELDS_SFF < $NUM_FIELDS_LFF + 1 )
 {
  $string .= "\n$ASTERISK";
 }

 return "$string\n";
}

sub is_lff {
 my ($self) = @_;
 my $format = $self->get_format;
 if ( defined $format ) {
  if ( $format eq 'large' ) { return 1 }
  return 0;
 }
 if ( $self->{data}[0] =~ /[*]/xsm ) { return 1 }
 return 0;
}

# Parse the template

sub parse_template {
 my %options  = @_;
 my $template = $options{template};
 my $w        = $options{field_width};
 my $f_out    = $options{out_field_index};
 my $nf       = $options{num_fields};
 my $cc       = $options{continuation_card};
 my $f_in     = $options{in_field_index};
 my $fields   = $options{fields};
 my $string   = $EMPTY;
 while ( ${$f_in} < @{$fields} and defined $template and $template ne $EMPTY ) {
  my ( $code, $repeat, $rest );

  # alternatives. pick first one that matches
  if ( $template =~ /^([AFI\s\d]+)([|].+)+/xsm ) {
   ( my $substr, $rest ) = parse_alternation(
    template          => $template,
    code              => $1,
    rest              => $2,
    field_width       => $w,
    out_field_index   => $f_out,
    num_fields        => $nf,
    continuation_card => $cc,
    in_field_index    => $f_in,
    fields            => $fields,
   );
   $string .= $substr;
  }

  # simple code with optional repeat
  elsif ( $template =~ /^([AFI\s])([\d**+]?)(.*)/xsm ) {
   ( my $substr, $rest ) = parse_simple(
    template          => $template,
    code              => $1,
    repeat            => ( defined $2 and $2 ne $EMPTY ) ? $2 : 1,
    rest              => $3,
    field_width       => $w,
    out_field_index   => $f_out,
    num_fields        => $nf,
    continuation_card => $cc,
    in_field_index    => $f_in,
    fields            => $fields,
   );
   $string .= $substr;
  }

  # code group with optional repeat
  elsif ( $template =~ /^[(](.*)[)]([\d**+]?)(.*)/xsm ) {
   $code   = $1;
   $repeat = ( defined $2 and $2 ne $EMPTY ) ? $2 : 1;
   $rest   = $3;
   while ( ( $repeat =~ /[*+]/xsm or $repeat > 0 )
    and ( ${$f_in} < @{$fields} ) )
   {
    $string .= parse_template(
     template          => $code,
     field_width       => $w,
     out_field_index   => $f_out,
     num_fields        => $nf,
     continuation_card => $cc,
     in_field_index    => $f_in,
     fields            => $fields,
    );
    if ( $repeat =~ /\d/xsm ) { $repeat-- }
   }
  }
  else {
   croak "Error: unknown template '$template'";
  }
  $template = $rest;
 }
 return $string;
}

sub parse_alternation {
 my %options  = @_;
 my $template = $options{template};
 my $code     = $options{code};
 my $rest     = $options{rest};
 my $w        = $options{field_width};
 my $f_out    = $options{out_field_index};
 my $nf       = $options{num_fields};
 my $cc       = $options{continuation_card};
 my $f_in     = $options{in_field_index};
 my $fields   = $options{fields};
 my $string   = $EMPTY;
 my $alt;

 while ( not defined $alt and defined $code ) {

  # work with a copy in case the alternative doesn't match
  my ( $f_in_copy, $f_out_copy ) = ( ${$f_in}, ${$f_out} );

  try {
   $alt = parse_template(
    template          => $code,
    field_width       => $w,
    out_field_index   => \$f_out_copy,
    num_fields        => $nf,
    continuation_card => $cc,
    in_field_index    => \$f_in_copy,
    fields            => $fields,
   );
  };
  if ( defined $alt ) {
   ( ${$f_in}, ${$f_out} ) = ( $f_in_copy, $f_out_copy );

   # don't need the remaining alternatives
   undef $rest;
  }
  else {

   # lose the |
   $template = substr $rest, 1, length($rest) - 1;
   if ( $template =~ /^(.+)([|].+)*/xsm ) {
    $code = $1;
    $rest = $2;
   }
   else {
    undef $code;
   }
  }
 }
 if ( defined $alt ) {
  $string .= $alt;
 }
 else {
  croak "Error: none of the alternatives in '$template' matches '"
    . join( $COMMA, @{$fields} )
    . $QUOTE;
 }
 return $string, $rest;
}

sub parse_simple {
 my %options  = @_;
 my $template = $options{template};
 my $code     = $options{code};
 my $repeat   = $options{repeat};
 my $rest     = $options{rest};
 my $w        = $options{field_width};
 my $f_out    = $options{out_field_index};
 my $nf       = $options{num_fields};
 my $cc       = $options{continuation_card};
 my $f_in     = $options{in_field_index};
 my $fields   = $options{fields};
 my $string   = $EMPTY;

 while ( ( $repeat =~ /[*+]/xsm or $repeat > 0 )
  and ( ${$f_in} < @{$fields} ) )
 {
  my $substr = packfield(
   code              => $code,
   field_width       => $w,
   out_field_index   => $f_out,
   num_fields        => $nf,
   continuation_card => $cc,
   in_field_index    => $f_in,
   fields            => $fields,
  );
  if ( defined $substr and $substr ne $EMPTY ) {
   $string .= $substr;
   if ( $repeat =~ /\d/xsm ) { $repeat-- }
  }
  elsif ( $repeat !~ /[*+]/xsm and $repeat > 0 ) {
   croak "Error: '$template' does not match '"
     . join( $COMMA, @{$fields} )
     . $QUOTE;
  }
  else {
   if ( defined $rest and $rest ne $EMPTY ) {
    $string .= parse_template(
     template          => $rest,
     field_width       => $w,
     out_field_index   => $f_out,
     num_fields        => $nf,
     continuation_card => $cc,
     in_field_index    => $f_in,
     fields            => $fields,
    );
   }
   else {
    return $string, $rest;
   }
  }
 }
 return $string, $rest;
}

# Return the card (or part of it) according to the supplied template
# (or subtemplate)

sub packfield {
 my %options = @_;
 my $code    = $options{code};
 my $w       = $options{field_width};
 my $f_out   = $options{out_field_index};
 my $nf      = $options{num_fields};
 my $cc      = $options{continuation_card};
 my $f_in    = $options{in_field_index};
 my $fields  = $options{fields};
 my $string  = $EMPTY;

 my $field = $fields->[ ${$f_in} ];
 if ( defined $field ) { $field =~ s/\s*//gxsm }
 if ( ++${$f_out} > $nf ) {
  $string .= sprintf "\n%-8s", $cc;
  ${$f_out} = 1;
 }
 given ($code) {
  when ($SPACE) {

   # an empty field cannot have any content
   if ( $field !~ /^\s*$/xsm ) {
    croak "Template '$code' does not match '$field'";
   }

   $string .= sprintf "$PERCENT$w" . 's', $SPACE;
  }
  when ( not defined $field or $field =~ /^\s*$/xsm ) {
   $string .= sprintf "$PERCENT$w" . 's', $SPACE;
  }
  when ('A') {
   $string .= sprintf "$PERCENT$w" . 's', $field;
  }
  when ('F') {
   my $substr;
   try {
    $substr = sprintfloat( $field, $w );
   };
   if ( defined $substr ) {
    $string .= $substr;
   }
   else {

    ## undo initial increment
    --${$f_out};
    return $string;
   }
  }
  when ('I') {

   # an integer field cannot have a decimal point
   croak "Template '$code' does not match '$field'"
     if ( ( $field + 0 ) =~ /[.]/xsm );

   # Patran has left-justified integer fields
   if ( $_PATRAN_INT and length $field < $w ) {
    $string .= sprintf ' %-' . ( $w - 1 ) . 'i', $field;
   }
   else {
    $string .= sprintf "$PERCENT$w" . 'i', $field;
   }
  }
  default {
   croak "Error: unknown template code '$code'";
  }
 }
 ${$f_in}++;
 return $string;
}

sub printfloat {
 my ( $n, $f ) = @_;
 printf '%s', sprintfloat( $n, $f );
 return;
}

sub fprintfloat {
 my ( $fh, $n, $f ) = @_;
 printf {$fh} '%s', sprintfloat( $n, $f );
 return;
}

sub sprintfloat {
 my ( $n, $f ) = @_;
 for ( $n, $f ) {
  croak "Argument $_ not numeric in sub sprintfloat"
    if ( not /^[-+\d.e]*$/ixsm );
 }
 my $result;
 if ( defined $_EXPONENT and $_EXPONENT eq 'D' ) {
  $result = sprintf "% $f$DOT$SIG_FIGS_LFF" . 'e', $n;
  $result =~ s/e/D/xsm;
 }
 elsif ( $n == 0 ) {
  if ( defined $_REMOVE_ZEROS and $_REMOVE_ZEROS ) {
   return sprintf "$PERCENT$f" . 's', $EMPTY;
  }
  else {
   return sprintf ' 0.%' . ( $f - $SIG_FIGS_LOST_DEFAULT_FLOAT ) . 's', $EMPTY;
  }
 }
 elsif ($_MAXIMISE_WIDTH) {
  $result = sprintfloat_maximised_width( $n, $f );
 }
 else {
  $result = sprintfloat_default_width( $n, $f );
 }
 if ( defined $_REMOVE_TRAILING_ZEROS and $_REMOVE_TRAILING_ZEROS ) {

  # remove the zeros before the exponent
  if ( $result =~ /\d*[.]\d*E?[-+]\d+/ixsm ) {
   while ( $result =~ s/([\d.])0(E?[-+]\d+)/$1$2 /ixsm ) { }
  }

  # remove the trailing zeros
  else {
   while ( $result =~ s/0(\s*)$/ $1/xsm ) { }
  }
 }
 return $result;
}

sub sprintfloat_maximised_width {
 my ( $n, $f ) = @_;
 my $sign = $n < 0 ? $MINUS : $EMPTY;
 my $result;
 if (( $n > $BASE10**( $f - 1 ) - 1 )
  or ( $n < -$BASE10**( $f - 2 ) + 1 )
  or ( abs($n) < $BASE10**( $SIG_FIGS_LOST_MAXIMISE_SCI - $f ) ) )
 {
  my ( $s, $e ) = e($n);
  $result = f_format( $n, $s, $e, $f );

  # Required here to cover floating point bug
  if ( length($result) > $f or $result =~ /^\s?-?0[.]/xsm ) {
   my $signe = sign($e);
   $s /= $BASE10**$signe;
   $e += $signe;
   $result = f_format( $n, $s, $e, $f );
  }
  elsif ( length($result) < $f ) {
   my $signe = sign($e);
   $s *= $BASE10**$signe;
   $e -= $signe;
   $result = f_format( $n, $s, $e, $f );
  }
 }
 else {
  my $i = abs $n < 1 ? $EMPTY : abs int $n;
  my $width = $f - length($i) - 1;

  if ( $n < 0 ) {
   $f     -= 1;
   $width -= 1;
  }
  $result = sprintf "$PERCENT$f.$width" . 'f', $n;
  $result =~ s/^(-?)0/$1/xsm;
  $result =~ s/^\s//xsm;
  if ( $result !~ /[.]/xsm ) { $result .= $DOT }
 }
 return $result;
}

sub sprintfloat_default_width {
 my ( $n, $f ) = @_;
 my $format;
 if (
  ( abs($n) > $BASE10**( $f - 2 ) - 1 )
  or (
   abs($n) <
   $BASE10**( $SIG_FIGS_LOST_DEFAULT_SCI - $f - $SIG_FIGS_LOST_DEFAULT_FLOAT ) )
   )
 {
  $format = "% $f$DOT" . ( $f - $SIG_FIGS_LOST_DEFAULT_SCI ) . 'e';
 }
 elsif ( abs($n) > $BASE10**( $f - $SIG_FIGS_LOST_DEFAULT_FLOAT ) - 1 ) {
  $format = '% ' . ( $f - 1 ) . '.0f.';
 }
 elsif ( abs($n) < 1 ) {
  $format = "% $f$DOT" . ( $f - $SIG_FIGS_LOST_DEFAULT_FLOAT ) . 'f';
 }
 else {
  my ( $s, $e ) = e($n);
  $format = "% $f$DOT" . ( $f - $SIG_FIGS_LOST_DEFAULT_FLOAT - $e ) . 'f';
  my $result = sprintf $format, $n;

  # Required here to cover floating point bug
  if ( length($result) > $f ) {
   my $sign = sign($e);
   $s /= $BASE10**$sign;
   $e += $sign;
   $format = "% $f$DOT" . ( $f - $SIG_FIGS_LOST_DEFAULT_FLOAT - $e ) . 'f';
  }
  elsif ( length($result) < $f ) {
   my $sign = sign($e);
   $s *= $BASE10**$sign;
   $e -= $sign;
   $format = "% $f$DOT" . ( $f - $SIG_FIGS_LOST_DEFAULT_FLOAT - $e ) . 'f';
  }
 }
 return sprintf $format, $n;
}

# get or set a particular field of the card
sub field {
 my ( $self, $i, $value ) = @_;
 if ( not $self->isa('Nastran::Card') ) {
  croak "$self must be a Nastran::Card object";
 }
 if ( defined $value ) {
  $self->{data}[$i] = $value;
  return;
 }
 return $self->{data}[$i];
}

sub sign {
 my ($n) = @_;
 return $n < 0 ? -1 : 1;    ## no critic (ProhibitMagicNumbers)
}

# return exponent

sub e {
 my ($n)         = @_;
 my $e           = int( log( abs $n ) / log $BASE10 );
 my $significand = $n * $BASE10**( -$e );
 return $significand, $e;
}

sub f_format {
 my ( $n, $s, $e, $f ) = @_;
 if ( $e > 0 ) { $e = "$PLUS$e" }
 my $width = $f - length($e) - 2;
 if ( $n < 0 ) { $width -= 1 }
 return sprintf $PERCENT . ( $width + 2 ) . "$DOT$width" . 'f%s', $s, $e;
}

sub threeway_compare {
 my ( $s1, $s2 ) = @_;
 return ( "$s1" cmp "$s2" );
}

sub options {
 my ( $class, %options ) = @_;
 for ( keys %options ) {
  if (/^_?MAXIMISE_WIDTH$/xsm) { $_MAXIMISE_WIDTH = $options{$_} }
 }
 return;
}

# get gids associated with card
sub gids {
 my ($self) = @_;
 my $type = uc $self->{data}[0];
 my @gids;
 if ( defined $gids{$type} ) {
  for ( @{ $gids{$type} } ) {
   if ( defined $self->{data}[$_] and $self->{data}[$_] =~ /^\s*\d+\s*$/xsm ) {
    push @gids, $self->{data}[$_];
   }
  }
 }
 return \@gids;
}

1;

__END__
