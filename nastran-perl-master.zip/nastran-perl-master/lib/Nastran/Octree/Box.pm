package Nastran::Octree::Box;

use 5.008005;
use strict;
use warnings;
use Carp;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub new {
 my ( $class, $box ) = @_;
 my $self = [];
 if ($box) {
  for ( 0 .. @{ $box->[0] } ) {
   $self->[0][$_] = $box->[0][$_];
   $self->[1][$_] = $box->[1][$_];
  }
 }
 bless $self, $class;
 return $self;
}

# update box with point, including an optional tolerance

sub update {
 my ( $self, $point, $tolerance ) = @_;
 if ( not defined $tolerance ) { $tolerance = 0 }
 for ( 0 .. 2 ) {
  if ( not defined( $self->[0][$_] )
   or $point->[$_] - $tolerance < $self->[0][$_] )
  {
   $self->[0][$_] = $point->[$_] - $tolerance;
  }
  if ( not defined( $self->[1][$_] )
   or $point->[$_] + $tolerance > $self->[1][$_] )
  {
   $self->[1][$_] = $point->[$_] + $tolerance;
  }
 }
 return $self;
}

# returns 1 if the box is inside the box, otherwise undef

sub box_in_box {
 my ( $self, $box ) = @_;
 if ( not defined $box or not $box->isa('Nastran::Octree::Box') ) {
  croak 'Nastran::Octree::Box required';
 }
 for ( 0 .. 2 ) {
  if ( not defined $box->[0][$_] or not defined $box->[1][$_] ) {
   croak 'Box must be defined';
  }
  if ($box->[0][$_] < $self->[0][$_]
   or $box->[1][$_] > $self->[1][$_] )
  {
   return;
  }
 }
 return 1;
}

# returns 1 if the vector is inside the box, otherwise undef

sub vector_in_box {
 my ( $self, $vector ) = @_;
 if (not defined $vector
  or not $vector->isa('Math::Vector::Real') )
 {
  croak 'Math::Vector::Real required';
 }
 for ( 0 .. 2 ) {
  return
    if ( $vector->[$_] < $self->[0][$_]
   or $vector->[$_] > $self->[1][$_] );
 }
 return 1;
}

1;

__END__
