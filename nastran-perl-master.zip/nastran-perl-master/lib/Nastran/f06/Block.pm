package Nastran::f06::Block;    ## no critic (Capitalization)

use 5.008005;
use strict;
use English qw(-no_match_vars);
use warnings;
use Carp;
use Readonly;
Readonly my $BULK_MAX_LINE => 72;

my $EMPTY     = q{};
my $ASTERIXES = qr/[*][*][*]/xsm;
my $MESSAGE   = qr/(INFORMATION|WARNING)[ ]MESSAGE/xsm;

my %block_table = (
 'N A S T R A N    E X E C U T I V E    C O N T R O L    E C H O' => {
  'header-lines' => 3,
  format         => ['x5A88'],
  columns        => 1,
 },
 'C A S E    C O N T R O L    E C H O' => {
  'header-lines' => 2,
  format         => ['x25A72'],
  columns        => 1,
 },
 'D I S P L A C E M E N T   V E C T O R' => {
  'header-lines' => 2,
  format         => ['xA13A7x5A13A*'],
  remaining      => '(x2A13)5',
  columns        => 3,
 },
 'E I G E N V E C T O R     M A X / M I N   V A L U E   S U M M A R Y' => {
  'header-lines' => 2,
  format         => ['A9A6A8x3(x4A13)6'],
  columns        => 9,
 },
 'F O R C E S   O F   S I N G L E - P O I N T   C O N S T R A I N T' => {
  'header-lines' => 2,
  format         => ['xA13A7x5A13A*'],
  remaining      => '(x2A13)5',
  columns        => 3,
 },
 'F O R C E S   I N   B A R   E L E M E N T S         ( C B A R )' => {
  'header-lines' => 2,
  format         => ['xA14(x2A13xA13)3(x2A13)2'],
  columns        => 9,
 },
 'F O R C E S   O F   M U L T I P O I N T   C O N S T R A I N T' => {
  'header-lines' => 2,
  format         => ['xA13A7x5A13A*'],
  remaining      => '(x2A13)5',
  columns        => 3,
 },
 'G R I D   P O I N T   F O R C E   B A L A N C E' => {
  'header-lines' => 2,
  format         => ['xA10A14A12x4(x2A13)6'],
  columns        => 9,
 },
 'G R I D   P O I N T   S I N G U L A R I T Y   T A B L E' => {
  'header-lines' => 2,
  format         => ['xA32A9A7A17A11A9A11A9'],
  columns        => 8,
 },
 'MAXIMUM  DISPLACEMENTS' => {
  'header-lines' => 2,
  format         => ['x2A8x(xA14)6'],
  columns        => 7,
 },
 'M O D E L   S U M M A R Y' => {
  'header-lines' => 1,
  format         => ['x45A8x11A9'],
  columns        => 2,
 },
 'M O D E L   S U M M A R Y (2013)' => {
  'header-lines' => 2,
  format         => ['x37A8x8A17'],
  columns        => 2,
 },
 'MPCFORCE RESULTANT' => {
  'header-lines' => 2,
  format         => ['x2A8xA8(xA13)6'],
  columns        => 8,
 },
 'OLOAD    RESULTANT' => {
  'header-lines' => 2,
  format         => ['x2A8xA8(xA13)6'],
  columns        => 8,
 },
 'R E A L   E I G E N V A L U E S' => {
  'header-lines' => 2,
  format         => ['A9A10(x7A13)5'],
  columns        => 7,
 },
 'SPCFORCE RESULTANT' => {
  'header-lines' => 2,
  format         => ['x2A8xA8(xA13)6'],
  columns        => 8,
 },
 'S O R T E D   B U L K   D A T A   E C H O' => {
  'header-lines' => 2,
  format         => ['x30A80'],
  columns        => 1,
 },
 'S T R E S S E S   I N   B A R   E L E M E N T S          ( C B A R )' => {
  'header-lines' => 2,
  format         => [ 'xA10(xA14)8', 'x11(xA14)4x15(xA14)3' ],
  columns        => 16,
 },
'S T R E S S E S   I N   Q U A D R I L A T E R A L   E L E M E N T S   ( Q U A D 4 )'
   => {
  'header-lines' => 2,
  format =>
    [ 'xA10xA16(x2A13)3x3A8(x3A13)2x2A13', 'x12A16(x2A13)3x3A8(x3A13)2x2A13' ],
  columns => 17,
   },
 'S T R E S S E S   I N   R O D   E L E M E N T S      ( C R O D )' => {
  'header-lines' => 2,
  format         => ['xA15xA13xA11xA13xA*'],
  remaining      => 'xA12xA13xA11xA13xA*',
  columns        => 5,
 },
 'S T R E S S E S   I N   T R I A N G U L A R   E L E M E N T S   ( T R I A 3 )'
   => {
  'header-lines' => 2,
  format =>
    [ 'xA10xA16(x2A13)3x3A8(x3A13)2x2A13', 'x12A16(x2A13)3x3A8(x3A13)2x2A13' ],
  columns => 17,
   },
 '*** USER INFORMATION MESSAGE 5293 (SSG3A)' => {
  'header-lines' => 2,
  format         => ['A17(A23)2'],
  columns        => 3,
 },
);

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub new {
 my $class = shift;
 my $self  = {};
 bless $self, $class;
 return $self;
}

sub name {
 my $self = shift;
 croak "$self must be a Nastran::f06::Block object"
   if ( !$self->isa('Nastran::f06::Block') );
 return $self->{name};
}

{
 # Note header info between calls
 my ( $title, $subtitle, $label, $subcase );

 sub note_title {
  my ($fh) = @_;
  if ( /^1/xsm and length > $BULK_MAX_LINE ) {
   ($title) = unpack 'x4A67';
   $_ = <$fh>;
   ($subtitle) = unpack 'x5A67';
   undef $label;
   undef $subcase;
  }
  return;
 }

 sub read_block_header {
  my $self = shift;
  croak "$self must be a Nastran::f06::Block object"
    if ( !$self->isa('Nastran::f06::Block') );
  my $fh = $self->{FH};

  note_title($fh);
  while (<$fh>) {
   note_title($fh);
   if (/^0[ ]{4}(.{104})SUBCASE[ ]+(?:=[ ])?(\d*)/xsm) {
    ( $label, $subcase ) = ( $1, $2 );

    # strip trailing blanks
    $label =~ s/[ ]*$//xsm;

    next;
   }
   if (( /[ ]\w[ ]\w[ ]\w[ ]/xsm and not /[ ]M[ ]S[ ]C[ ]/xsm )
    or /(?:OLOAD|MPCFORCE|SPCFORCE)\s+RESULTANT/xsm
    or /USER[ ]INFORMATION[ ]MESSAGE[ ]5293/xsm
    or /MAXIMUM[ ][ ]DISPLACEMENTS/xsm )
   {

    # strip a leading 0 and blanks, and trailing blanks
    chomp;
    s/^0?[ ]*(.*?)[ ]*$/$1/xsm;

    # extract direction and mode number if we have eigenvector summary
    my $dof           = qr/$ASTERIXES[ ]([TR][1-3])[ ]$ASTERIXES/xsm;
    my $model_summary = qr/M[ ]O[ ]D[ ]E[ ]L[ ]{3}S[ ]U[ ]M[ ]M[ ]A[ ]R[ ]Y/xsm;
    if (/^$dof[ ]+(.+?)[ ]+RESULTS[ ]FOR[ ][ ][ ]MODE[ ]+(\d+)/xsm) {
     ( $self->{direction}, my $header, $self->{mode} ) = ( $1, $2, $3 );
     $_ = <$fh>;
     if (/^\s+CYCLES[ ]=[ ][ ]?(\S+)\s+EIGENVALUE[ ]=[ ][ ]?(\S+)/xsm) {
      ( $self->{cycles}, $self->{eigenvalue} ) = ( $1, $2 );
     }
     $_ = $header;
    }

    # remove BULK = for model summary
    elsif (/^$model_summary[ ]{10}BULK[ ]=[ ](\d+)?/xsm) {
     $_       = 'M O D E L   S U M M A R Y (2013)';
     $subcase = $1;
    }

    $self->create_subcase_table;

    return $_, $subcase;
   }
  }
  return;
 }

 sub create_subcase_table {
  my $self = shift;

  # Create the subcase table
  my $case_control = $self->{parent}{case_control};
  if (not defined $case_control
   or ref($case_control) eq 'HASH'
   or not $case_control->isa('Nastran::BDF::CaseControl') )
  {
   $case_control = Nastran::BDF::CaseControl->new;
   $self->{parent}{case_control} = $case_control;
  }

  # Create the subcase
  my $sid = defined($subcase) ? $subcase : 0;
  my $sc = $case_control->subcase($sid);
  if ( not defined $sc ) {
   $case_control->add($sid);
   $sc = $case_control->subcase($sid);
  }

  # Create the subcase cards
  if ( defined $title
   and $title !~ /^\s*$/xsm
   and not defined $sc->get('TITLE') )
  {
   $case_control->append_card(
    Nastran::BDF::CaseControl::Card->new("TITLE=$title") );
  }
  if ( defined $subtitle
   and $subtitle !~ /^\s*$/xsm
   and not defined $sc->get('SUBTITLE') )
  {
   $case_control->append_card(
    Nastran::BDF::CaseControl::Card->new("SUBTITLE=$subtitle") );
  }
  if ( defined $label
   and $label !~ /^\s*$/xsm
   and not defined $sc->get('LABEL') )
  {
   $case_control->append_card(
    Nastran::BDF::CaseControl::Card->new("LABEL=$label") );
  }
  return;
 }
}

sub read_result {
 my $self = shift;
 croak "$self must be a Nastran::f06::Block object"
   if ( !$self->isa('Nastran::f06::Block') );

 # Already reached the end of the block
 return if $self->{EOB};

 my $fh = $self->{FH};

 if ( defined $self->{buffer} ) {
  my @data = @{ $self->{buffer} };
  if ( @data > $block_table{ $self->{name} }{columns} ) {
   my @buffer = splice @data, $block_table{ $self->{name} }{columns};
   $self->{buffer} = [@buffer];
  }
  else {
   delete $self->{buffer};
  }
  return $self->{subcase}, @data;
 }

 # Deal with blank lines in M O D E L   S U M M A R Y
 while (<$fh>) {
  if ( length > 2 ) { last }
 }
 return if ( not defined );

 # Deal with messages at end of block
 if (/^[ ](?:$ASTERIXES|\^\^\^)/xsm) {
  if (/USER[ ]WARNING[ ]MESSAGE[ ]602/xsm) {
   $_ = <$fh>;
   $_ = <$fh>;
   $_ = <$fh>;
  }
  else {
   $self->{EOB} = 1;
   return;
  }
 }

 # Found a new header
 if (/^1/xsm) {
  my $pos = tell $fh;
  ( my $name, $self->{subcase} ) = $self->read_block_header;

  # Different header, so return
  if ( not defined $name or $name ne $self->{name} ) {
   seek $fh, $pos, 0;
   $self->{EOB} = 1;
   return;
  }

  # Same header, so skip to data
  $self->read_result_header;
  $_ = <$fh>;
 }

 if ( defined $block_table{ $self->{name} }{format} ) {
  return $self->read_data;
 }
 else {
  croak "Unknown result type $self->{name}";
 }
}

sub read_data {
 my ($self) = @_;
 my $fh = $self->{FH};
 my @data;
 for my $format ( @{ $block_table{ $self->{name} }{format} } ) {
  if (@data) { $_ = <$fh> }
  eval {
   push @data, unpack $format, $_;
   1;
  } or croak "Error reading line $INPUT_LINE_NUMBER of $self->{filename}";
 }

 # Lose trailing empty field
 if ( $data[-1] eq $EMPTY ) { delete $data[-1] }

 if ( $self->{name} eq 'C A S E    C O N T R O L    E C H O' ) {
  @data = $self->_read_case_control_echo(@data);
 }

 # if we have more data than expected
 if ( @data > $block_table{ $self->{name} }{columns} ) {
  my @buffer = splice @data, $block_table{ $self->{name} }{columns};

  # if we have additional results, e.g. DISP for grid rather than scalar point,
  # process them
  if ( defined $block_table{ $self->{name} }{remaining} ) {
   eval {
    push @data, unpack $block_table{ $self->{name} }{remaining}, shift @buffer;
    1;
   } or croak "Error reading line $INPUT_LINE_NUMBER of $self->{filename}";
  }

  # if we have results for more than one element per line, then buffer the rest
  else {
   $self->{buffer} = [@buffer];
  }
 }

 # Remove leading spaces
 for (@data) {
  if (defined) { s/^[ ]*//xsm }
 }

 return @data
   if ( $self->{name} eq 'MAXIMUM  DISPLACEMENTS'
  or $self->{name} =~ /^[ ]$ASTERIXES[ ]USER[ ]$MESSAGE/xsm );

 # Here we know we've reached the end of the block
 if ( $self->end_of_block(@data) ) { $self->{EOB} = 1 }

 if ( $self->{name} =~ /^(OLOAD[ ][ ][ ]|SPCFORCE|MPCFORCE)[ ]RESULTANT$/xsm ) {
  if ( $data[1] eq 'FX' ) { $self->{subcase} = $data[0] }
  shift @data;
 }

 if ( $self->{name} eq
  'E I G E N V E C T O R     M A X / M I N   V A L U E   S U M M A R Y' )
 {
  return $self->{mode}, $self->{direction}, $self->{cycles},
    $self->{eigenvalue}, @data;
 }
 else {
  return $self->{subcase}, @data;
 }
}

sub end_of_block {
 my ( $self, @data ) = @_;
 return (
  @data and ( $self->{name} eq 'C A S E    C O N T R O L    E C H O'
   and $data[-1] eq 'BEGIN BULK' )
    or ( $self->{name} eq 'S O R T E D   B U L K   D A T A   E C H O'
   and $data[-1] eq 'ENDDATA' )
 );
}

sub read_result_header {
 my $self = shift;
 croak "$self must be a Nastran::f06::Block object"
   if ( !$self->isa('Nastran::f06::Block') );
 my $fh = $self->{FH};

 # skip down, ready to read data
 my $i = 0;
 if ( defined $block_table{ $self->{name} }{'header-lines'} ) {
  $i = $block_table{ $self->{name} }{'header-lines'};
 }
 while ( $i-- > 0 ) { $_ = <$fh> }
 return;
}

sub _read_case_control_echo {
 my ( $self, @data ) = @_;
 while ( @data and $data[0] =~ /^\s*SET/ixsm and $data[0] =~ /,\s*$/xsm ) {
  my @new = $self->read_result;
  if ( @new > 1 ) {
   $data[0] .= $new[1];
  }
  else {
   carp "Ignoring trailing comma in SET definition in $self->{filename}\n";
   last;
  }
 }
 return @data;
}

# Convenience method to read case control echo

sub read_case_control {
 my $self = shift;
 if ( not $self->isa('Nastran::f06::Block') ) {
  croak "$self must be a Nastran::f06::Block object";
 }
 if ( not $self->{name} eq 'C A S E    C O N T R O L    E C H O' ) {
  croak "$self must be a Case Control Echo block";
 }
 use Nastran::BDF::CaseControl;
 my $case_control = $self->{parent}{case_control};
 if ( not defined $case_control ) {
  $case_control = Nastran::BDF::CaseControl->new;
  $self->{parent}{case_control} = $case_control;
 }

 my @data = $self->read_result;
 while (@data) {
  if ( @data != 1 and $data[1] !~ /^\s*(?:$|\$|BEGIN[ ]BULK)/ixsm ) {
   $case_control->append_card(
    Nastran::BDF::CaseControl::Card->new( $data[1] ) );
  }
  @data = $self->read_result;
 }
 return $case_control;
}

# Return case control in array of hashes

sub case_control {
 my $self = shift;
 if ( not $self->isa('Nastran::f06::Block') ) {
  croak "$self must be a Nastran::f06::Block object";
 }
 return $self->{case_control};
}

1;
