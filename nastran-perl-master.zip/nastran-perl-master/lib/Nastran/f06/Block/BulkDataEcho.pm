package Nastran::f06::Block::BulkDataEcho;    ## no critic (Capitalization)

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::BDF;
use Readonly;
Readonly my $BDF_FIELD_WIDTH => 8;
Readonly my $BDF_LINE_WIDTH  => 72;

my $EMPTY = q{};
my $PLUS  = q{+};

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::f06::Block);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

# Return the next card from the deck

sub readcard {
 my $self = shift;
 croak "$self must be a Nastran::f06::Block::BulkDataEcho object"
   if ( not $self->isa('Nastran::f06::Block::BulkDataEcho') );

 my ( @fields, @line );
 my $format = 'small';
 while (1) {

  # if there is a line in the buffer, use it. Otherwise read the next line from
  # the deck
  if ( defined $self->{buffer} ) {
   $_ = $self->{buffer};
   undef $self->{buffer};
  }
  else {
   ( my $subcase, $_ ) = $self->read_result;
  }

  if ( not defined ) {
   @fields = Nastran::BDF::chop_array(@fields);
   if (@fields) {
    my $card = $self->{BDF}->create_card(@fields);
    $card->set_format($format);
    return $card;
   }
   return;
  }

  # if we've already got a line and this isn't a continuation card
  # or an empty line then put the line in the buffer and return.
  if ( @fields and not /^(?:[ +*]|\s*$)/xsm ) {

   # deal with a blank line at the beginning of the deck
   @fields = Nastran::BDF::chop_array(@fields);
   if (@fields) {

    $self->{buffer} = $_;
    my $card = $self->{BDF}->create_card(@fields);
    $card->set_format($format);
    return $card;
   }
  }
  if ( not @fields and ( not defined or $_ eq $EMPTY ) ) { return }

  # The model summary block does not start with ^1,
  # but the bulk data echo finishes with ENDDATA, so use it.
  if ( $_ eq 'ENDDATA' ) {

   # Skip the TOTAL COUNT line
   ( my $subcase, $_ ) = $self->read_result;
   return;
  }

  if ( substr( $_, 0, $BDF_FIELD_WIDTH ) =~ /[*]/xsm ) {
   @line   = unpack 'A8A16A16A16A16';
   $format = 'large';
  }
  else {
   @line = unpack 'A8A8A8A8A8A8A8A8A8';
  }

  # If we have a continuation card, we need to skip the first field
  my $cc = /^[+*]/xsm ? 1 : 0;

  for my $i ( $cc .. $#line ) {
   push @fields, Nastran::BDF::add_exponent( $line[$i] );
  }

  # If the line does not finish with a continuation card, then we can return
  if ( length() < $BDF_LINE_WIDTH + 1
   or substr( $_, $BDF_LINE_WIDTH + 1, 1 ) ne $PLUS )
  {
   my $card = $self->{BDF}->create_card(@fields);
   $card->set_format($format);
   return $card;
  }
 }
 return;
}

1;

__END__
