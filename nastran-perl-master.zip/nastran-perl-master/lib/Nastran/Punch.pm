package Nastran::Punch;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::Punch::Block;
use Nastran::Punch::BulkData;
use English qw(-no_match_vars);

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub new {
 my $class = shift;
 my $self  = {};
 $self->{filename} = shift;
 open my $fh, q{<}, $self->{filename}    ## no critic (RequireBriefOpen)
   or croak "can't open $self->{filename}: $OS_ERROR";
 $self->{FH} = $fh;
 my ( $buffer, $next );
 $self->{buffer} = \$buffer;
 $self->{next}   = \$next;
 bless $self, $class;
 return $self;
}

sub DESTROY {
 my $self = shift;
 close $self->{FH} or croak "can't close $self->{filename}: $OS_ERROR";
 return;
}

sub first_block {
 my $self = shift;
 if ( not $self->isa('Nastran::Punch') ) {
  croak "$self must be a Nastran::Punch object";
 }
 seek $self->{FH}, 0, 0;
 return $self->next_block;
}

sub next_block {
 my $self = shift;
 if ( not $self->isa('Nastran::Punch') ) {
  croak "$self must be a Nastran::Punch object";
 }
 my $fh = $self->{FH};

 my ( $name, $subcase );
 while (1) {
  if ( defined ${ $self->{next} } ) {
   my $block = ${ $self->{next} };
   undef ${ $self->{next} };
   return $block;
  }
  if ( defined ${ $self->{buffer} } ) {
   $_ = ${ $self->{buffer} };
  }
  else {
   $_ = <$fh>;
  }
  if ( not defined ) { last }
  my $block = Nastran::Punch::Block->new;
  $block->{FH}     = $fh;
  $block->{buffer} = $self->{buffer};
  $block->{next}   = $self->{next};

  if ( defined $self->{section} or /[$]TITLE[ ]{3}=.*1$/xsm ) {

   # if still in middle of bulk data, skip to end
   if ( defined( $self->{section} ) and $self->{section} eq 'BULK DATA' ) {
    while ( defined and not /[$]TITLE[ ]{3}=.*1$/xsm ) {
     $_ = <$fh>;
    }
    if ( not defined ) { return }
   }

   # give the block access to the subcase table
   $block->{parent} = $self;
   ( $name, $subcase ) = $block->read_block_header;
   if ( not defined $name ) { return }
  }
  else {

   # Assume we've got bulk data
   $block->{name}   = 'BULK DATA';
   $self->{section} = 'BULK DATA';
   ${ $self->{buffer} } = $_;

   # rebless if necessary
   # note this is only ok because
   # Nastran::Punch::BulkData inherits Nastran::Punch::Block
   bless $block, 'Nastran::Punch::BulkData';
   $block->{BDF} = {};

   # Need a Nastran::BDF object to register cards
   bless $block->{BDF}, 'Nastran::BDF';
  }

  return $block;
 }
 return;
}

sub bytes_read {
 my $self = shift;
 return tell $self->{FH};
}

sub filename {
 my $self = shift;
 return $self->{filename};
}

1;
