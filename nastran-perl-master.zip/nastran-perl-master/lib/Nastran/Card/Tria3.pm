package Nastran::Card::Tria3;

use 5.008005;
use strict;
use warnings;
use Carp;
use Math::Trig;
use Math::Vector::Real 0.10;    # for ->versor

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::Card);
 %EXPORT_TAGS = ();             # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

# From Executive control card Geomcheck:
# Smallest angle at any of the three vertices

sub skew {
 my ( $v1, $v2, $v3 ) = @_;
 my @angles = interior_angles( $v1, $v2, $v3 );
 return $angles[0];
}

# From Executive control card Geomcheck:
# The angles formed by the edges that meet at the corner node of an element

sub interior_angles {
 my ( $v1, $v2, $v3 ) = @_;
 my $e1     = ( $v2 - $v1 )->versor;
 my $e2     = ( $v3 - $v2 )->versor;
 my $e3     = ( $v1 - $v3 )->versor;
 my @angles = ( $e1 * -$e3, $e2 * -$e1, $e3 * -$e2 );
 @angles = map  { acos($_) * 180 / pi } @angles;
 @angles = sort { $a <=> $b } @angles;
 return @angles;
}

1;

__END__
