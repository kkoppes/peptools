package Nastran::Card::Force;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::Card;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::Card);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub validate {
 my $self = shift;
 my $vector;
 for ( 5 .. 7 ) {
  if ( defined( $self->{data}[$_] )
   and $self->{data}[$_] ne ''
   and $self->{data}[$_] != 0 )
  {
   $vector = 1;
   last;
  }
 }
 croak "Error: zero-length vector in FORCE card:\n$self"
   unless $vector;
 return $self;
}

1;

__END__
