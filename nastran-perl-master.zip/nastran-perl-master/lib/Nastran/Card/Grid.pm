package Nastran::Card::Grid;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::Card;
use Math::Vector::Real;
use Readonly;
Readonly my $T1 => 3;
Readonly my $T3 => 5;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::Card);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub to_vector {
 my $self = shift;
 my $vector = Math::Vector::Real->new( ( @{ $self->{data} } )[ $T1 .. $T3 ] );
 for ( 0 .. 2 ) {
  if ( not defined $vector->[$_] or $vector->[$_] eq q{} ) { $vector->[$_] = 0 }
 }
 return $vector;
}

1;

__END__
