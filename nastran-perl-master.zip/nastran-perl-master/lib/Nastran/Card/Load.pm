package Nastran::Card::Load;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::Card;
use overload '+' => 'sum';

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::Card);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub sum {
 my $self = shift;
 croak "$self must be a Nastran::Card::Load object"
   unless ( $self->isa('Nastran::Card::Load') );
 my $add = shift;
 croak "$add must be a Nastran::Card::Load object"
   unless ( $self->isa('Nastran::Card::Load') );
 my $card = Nastran::Card::Load->new_from_array( @{ $self->{data} } )
   ;    # Make copy of $self
 my $scale = $add->field(2) / $self->field(2);
 for ( my $i = 3 ; $i < @{ $add->{data} } ; $i += 2 ) {
  push @{ $card->{data} }, $add->field($i) * $scale;
  push @{ $card->{data} }, $add->field( $i + 1 );
 }
 $card->field( 1, $add->field(1) + $self->field(1) );
 return $card;
}

1;

__END__
