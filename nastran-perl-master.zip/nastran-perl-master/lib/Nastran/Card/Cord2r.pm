package Nastran::Card::Cord2r;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::Card;
use Math::MatrixReal;
use Try::Tiny;
use Readonly;
Readonly my $I_VLENGTH => 3;
Readonly my $GRID_CD   => 6;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::Card);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

my $EMPTY = q{};

# transform grid to reference system of coordinate system
sub transform_to_reference {
 my ( $self, $grid ) = @_;
 if ( not defined $self or not $self->isa('Nastran::Card::Cord2r') ) {
  croak "$self must be a Nastran::Card::Cord2r object";
 }
 if ( not defined $grid or not $grid->isa('Nastran::Card::Grid') ) {
  croak "$grid must be a Nastran::Card::Grid object";
 }
 my $cr  = $grid->field(2);
 my $cid = $self->field(1);
 if ( not defined $cr  or $cr eq $EMPTY )  { $cr  = 0 }
 if ( not defined $cid or $cid eq $EMPTY ) { $cid = 0 }
 if ( $cr != $cid ) {
  croak "Reference CID for GRID is $cr, but CORD2R supplied is $cid";
 }
 my $matrix = $self->transformation_matrix;
 return _transform_grid( $grid, $matrix, $self->field(2) );
}

# transform grid from reference system of coordinate system
sub transform_from_reference {
 my ( $self, $grid ) = @_;
 if ( not defined $self or not $self->isa('Nastran::Card::Cord2r') ) {
  croak "$self must be a Nastran::Card::Cord2r object";
 }
 if ( not defined $grid or not $grid->isa('Nastran::Card::Grid') ) {
  croak "$grid must be a Nastran::Card::Grid object";
 }
 my $cr  = $grid->field(2);
 my $cid = $self->field(2);
 if ( not defined $cr  or $cr eq $EMPTY )  { $cr  = 0 }
 if ( not defined $cid or $cid eq $EMPTY ) { $cid = 0 }
 if ( $cr != $cid ) {
  croak "Reference CID for GRID is $cr, but CORD2R supplied is $cid";
 }
 my $matrix = $self->transformation_matrix->inverse;
 return _transform_grid( $grid, $matrix, $self->field(1) );
}

# Creates a 4x4 transformation matrix from the 9 values in a CORD2R card.
sub transformation_matrix {
 my $self = shift;
 if ( not defined $self or not $self->isa('Nastran::Card::Cord2r') ) {
  croak "$self must be a Nastran::Card::Cord2r object";
 }
 my $i = 2;
 my @A = ( $self->field( ++$i ), $self->field( ++$i ), $self->field( ++$i ) );
 my @B = ( $self->field( ++$i ), $self->field( ++$i ), $self->field( ++$i ) );
 my @C = ( $self->field( ++$i ), $self->field( ++$i ), $self->field( ++$i ) );
 my ( @AB, @AC );
 for ( 0 .. 2 ) {
  if ( not defined $A[$_] or $A[$_] eq $EMPTY ) { $A[$_] = 0 }
  if ( not defined $B[$_] or $B[$_] eq $EMPTY ) { $B[$_] = 0 }
  if ( not defined $C[$_] or $C[$_] eq $EMPTY ) { $C[$_] = 0 }
  $AB[$_] = $B[$_] - $A[$_];
  $AC[$_] = $C[$_] - $A[$_];
 }
 $AB[$I_VLENGTH] = vector_length( $AB[0], $AB[1], $AB[2] );
 $AC[$I_VLENGTH] = vector_length( $AC[0], $AC[1], $AC[2] );
 my @tempmat;
 $tempmat[0][1] = $AB[1] * $AC[2] - $AB[2] * $AC[1];
 $tempmat[1][1] = $AB[2] * $AC[0] - $AB[0] * $AC[2];
 $tempmat[2][1] = $AB[0] * $AC[1] - $AB[1] * $AC[0];
 for ( 0 .. 2 ) {
  $tempmat[$_][2] = $AB[$_] / $AB[$I_VLENGTH];
 }
 $tempmat[0][0] =
   $tempmat[1][1] * $tempmat[2][2] - $tempmat[2][1] * $tempmat[1][2];
 $tempmat[1][0] =
   $tempmat[2][1] * $tempmat[0][2] - $tempmat[0][1] * $tempmat[2][2];
 $tempmat[2][0] =
   $tempmat[0][1] * $tempmat[1][2] - $tempmat[1][1] * $tempmat[0][2];
 for ( 0 .. 2 ) {
  $tempmat[$I_VLENGTH][$_] =
    vector_length( $tempmat[0][$_], $tempmat[1][$_], $tempmat[2][$_] );
 }
 my $out = Math::MatrixReal->new( $I_VLENGTH + 1, $I_VLENGTH + 1 );
 for my $i ( 0 .. 2 ) {
  my $j = 0;
  $out->assign( $i + 1, ++$j, $tempmat[$i][0] / $tempmat[$I_VLENGTH][0] );
  $out->assign( $i + 1, ++$j, $tempmat[$i][1] / $tempmat[$I_VLENGTH][1] );
  $out->assign( $i + 1, ++$j, $tempmat[$i][2] );
  $out->assign( $i + 1, ++$j, $A[$i] );
  $out->assign( $I_VLENGTH + 1, $i + 1, 0 );
 }
 $out->assign( $I_VLENGTH + 1, $I_VLENGTH + 1, 1 );
 return $out;
}

sub vector_length {
 my ( $x, $y, $z ) = @_;
 return sqrt( $x * $x + $y * $y + $z * $z );
}

sub _matrix_from_grid {
 my ($grid) = @_;
 my $i = 2;
 my @A =
   ( $grid->field( ++$i ), $grid->field( ++$i ), $grid->field( ++$i ), 1 );
 for (@A) {
  if ( not defined or $_ eq $EMPTY ) { $_ = 0 }

  # bug in Math::MatrixReal doesn't like numbers starting with decimal
  s/^[.]/0./xsm;
  s/^-[.]/-0./xsm;
 }
 my $A;
 try {
  $A = Math::MatrixReal->new_from_cols( [ \@A ] );
 }
 catch {
  $i = 2;
  my $msg =
    sprintf 'Error: unable to parse coordinates of grid: %d (%s, %s, %s)',
    $grid->field(1), $grid->field( ++$i ), $grid->field( ++$i ),
    $grid->field( ++$i );
  warn "$msg\n";
 };
 return $A;
}

sub _transform_grid {
 my ( $grid, $matrix, $cid ) = @_;
 my $A = _matrix_from_grid($grid);
 my $card;
 try {
  my $out = $matrix * $A;
  my $i   = 0;
  $card = Nastran::Card::Grid->new_from_array(
   $grid->field(0), $grid->field(1), $cid,
   $out->element( ++$i, 1 ),
   $out->element( ++$i, 1 ),
   $out->element( ++$i, 1 ),
   $grid->field($GRID_CD)
  );
  $card->set_format( $grid->get_format );
 }
 catch {
  warn 'Error transforming grid ', $grid->field(1), "\n";
 };
 return $card;
}

1;

__END__
