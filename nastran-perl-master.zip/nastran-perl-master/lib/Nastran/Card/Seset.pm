package Nastran::Card::Seset;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::Card;
use Set::IntSpan;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::Card);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub to_Set_IntSpan {
 my $self = shift;
 if ( not $self->isa('Nastran::Card::Seset') ) {
  croak "$self must be a Nastran::Card::Seset object";
 }

 my $s;
 my $i = 3;    ## no critic (ProhibitMagicNumbers)
 if ( defined( $self->{data}[$i] ) and $self->{data}[$i] =~ /THRU/ixsm ) {
  $s = Set::IntSpan->new("$self->{data}[2]-$self->{data}[4]");
 }
 else {
  my $line = $self->{data}[2];
  while ( $i <= $#{ $self->{data} } and defined( $self->{data}[$i] ) ) {
   $line .= ",$self->{data}[$i++]";
  }
  $s = Set::IntSpan->new($line);
 }
 return $s;
}

sub from_Set_IntSpan {
 my ( $self, $sid, $s ) = @_;
 if ( not $s->isa('Set::IntSpan') ) {
  croak "$s must be a Set::IntSpan object";
 }

 my @cards;
 for ( $s->spans ) {
  my @data;
  if ( $_->[0] == $_->[1] ) {
   @data = ( 'SESET', $sid, $_->[0] );
  }
  else {
   @data = ( 'SESET', $sid, $_->[0], 'THRU', $_->[1] );
  }
  push @cards, Nastran::Card::Seset->new_from_array(@data);
 }

 return @cards;
}

1;

__END__
