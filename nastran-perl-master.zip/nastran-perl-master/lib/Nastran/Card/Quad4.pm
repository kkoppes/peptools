package Nastran::Card::Quad4;

use 5.008005;
use strict;
use warnings;
use Carp;
use Math::Trig;
use Math::Vector::Real 0.10;    # for ->versor

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::Card);
 %EXPORT_TAGS = ();             # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

# From Executive control card Geomcheck:
# Angle between the lines that join midpoints of the opposite sides of the
# quadrilateral

sub skew {
 my ( $v1, $v2, $v3, $v4 ) = @_;
 my $m1   = ( $v2 + $v1 ) / 2;
 my $m2   = ( $v3 + $v2 ) / 2;
 my $m3   = ( $v4 + $v3 ) / 2;
 my $m4   = ( $v1 + $v4 ) / 2;
 my $l1   = $m3 - $m1;
 my $l2   = $m4 - $m2;
 my $skew = acos( $l1->versor * $l2->versor ) * 180 / pi;
 $skew = 180 - $skew if ( $skew > 90 );
 return $skew;
}

# From Executive control card Geomcheck:
# The angles formed by the edges that meet at the corner node of an element

sub interior_angles {
 my ( $v1, $v2, $v3, $v4 ) = @_;
 my $e1     = ( $v2 - $v1 )->versor;
 my $e2     = ( $v3 - $v2 )->versor;
 my $e3     = ( $v4 - $v3 )->versor;
 my $e4     = ( $v1 - $v4 )->versor;
 my @angles = ( $e1 * -$e4, $e2 * -$e1, $e3 * -$e2, $e4 * -$e3 );
 @angles = map  { acos($_) * 180 / pi } @angles;
 @angles = sort { $a <=> $b } @angles;
 return @angles;
}

# From Executive control card Geomcheck:
# The largest of the four absolute values of:
#  [the ratio of the area of the triangle formed at each corner grid
#   point to one half the area of the quadrilateral - 1.0]

sub taper {
 my ( $v1, $v2, $v3, $v4 ) = @_;
 my $a1 = area_of_triangle( $v1, $v2, $v3 );
 my $a2 = area_of_triangle( $v2, $v3, $v4 );
 my $a3 = area_of_triangle( $v3, $v4, $v1 );
 my $a4 = area_of_triangle( $v4, $v1, $v2 );
 my $A  = ( $a1 + $a3 ) / 2;
 my @angles = ( $a1 / $A, $a2 / $A, $a3 / $A, $a4 / $A );
 @angles = map  { abs( $_ - 1 ) } @angles;
 @angles = sort { $a <=> $b } @angles;
 return $angles[3];
}

# The distance of the corner points of the element to the mean plane of the
# grid points divided by the average of the element diagonal lengths.

sub warp {
 my @v = @_;

 # The average element normal is computed as
 # the vector (cross) product of the 2 diagonals
 my $n = ( $v[2] - $v[0] )->versor x ( $v[3] - $v[1] )->versor;

 # Point on mean plane is the centroid of the corners
 my $p = ( $v[0] + $v[1] + $v[2] + $v[3] ) / 4;

 # Average diagonal length
 my $l = ( abs( $v[2] - $v[0] ) + abs( $v[3] - $v[1] ) ) / 2;

 # As we have a mean plane, each corner is the same distance from it
 # Therefore only need to calculate the first one
 return abs( $n * ( $v[0] - $p ) ) / $l;    # dot product
}

# Helper function to calculate the area of triangle defined by the
# position of its corners

sub area_of_triangle {
 my ( $a, $b, $c ) = @_;
 return abs( ( $b - $a ) x ( $c - $a ) ) / 2;
}

1;

__END__
