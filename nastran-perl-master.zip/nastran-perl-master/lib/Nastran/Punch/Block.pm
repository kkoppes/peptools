package Nastran::Punch::Block;

use 5.008005;
use strict;
use warnings;
use Carp;
use Readonly;
Readonly my $BAR => 34;

my %block_table = (
 'DISPLACEMENTS' => {
  format  => [ 'A10A8(x5A13)3', 'x18(x5A13)3' ],
  columns => 8,
 },
 'GRID POINT FORCE BALANCE' => {
  format  => [ 'A10A18x8A8', 'x18(x5A13)3', 'x18(x5A13)3' ],
  columns => 9,
 },
 'SPCF' => {
  format  => [ 'A10A8(x5A13)3', 'x18(x5A13)3' ],
  columns => 8,
 },
 'ELEMENT STRESSES' => {
  $BAR => {
   format => [
    'A10x8(x5A13)3', 'x18(x5A13)3', 'x18(x5A13)3', 'x18(x5A13)3',
    'x18(x5A13)3'
   ],
   columns => 16,
  },
 },
);

my %header_table = (
 'TITLE'        => 'x10A62',
 'SUBTITLE'     => 'x10A62',
 'LABEL'        => 'x10A62',
 'SUBCASE ID'   => 'x13A12',
 'ELEMENT TYPE' => 'x15A12A8',
);

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub new {
 my $class = shift;
 my $self  = {};
 bless $self, $class;
 return $self;
}

sub name {
 my $self = shift;
 if ( not $self->isa('Nastran::Punch::Block') ) {
  croak "$self must be a Nastran::Punch::Block object";
 }
 return $self->{name};
}

sub read_block_header {
 my $self = shift;
 if ( not $self->isa('Nastran::Punch::Block') ) {
  croak "$self must be a Nastran::Punch::Block object";
 }

 my $fh = $self->{FH};

 while (/^\$/xsm) {
  if (/^\$(.{1,24})=/xsm) {
   my $key = $1;

   # strip trailing spaces
   $key =~ s/\s*$//xsm;

   if ( not defined $header_table{$key} ) { croak "Unknown header key $key" }
   my @values = unpack $header_table{$key};

   # strip leading and trailing spaces
   for (@values) {
    s/\s*$//xsm;
    s/^\s*//xsm;
   }

   if ( @values > 1 ) {
    $self->{$key} = \@values;
   }
   else {
    $self->{$key} = $values[0];
   }
  }
  else {
   my ($key) = unpack 'xA24';

   # strip trailing spaces
   $key =~ s/\s*$//xsm;
   if ( $key =~ /REAL/xsm ) {
    $self->{type} = $key;
   }
   elsif ( defined $block_table{$key} ) {
    $self->{name} = $key;
   }
   else {
    croak "Unknown header key $key";
   }
  }
  $_ = <$fh>;
 }
 ${ $self->{buffer} } = $_;
 if ( not defined $self->{name} ) { return }

 $self->_create_subcase_table;

 return $self->{name};
}

sub _create_subcase_table {
 my ($self) = @_;

 my $case_control = $self->{parent}{case_control};
 if (not defined $case_control
  or not $case_control->isa('Nastran::BDF::CaseControl') )
 {
  $case_control = Nastran::BDF::CaseControl->new;
  $self->{parent}{case_control} = $case_control;
 }

 # Create the subcase
 my $sid = defined( $self->{'SUBCASE ID'} ) ? $self->{'SUBCASE ID'} : 0;
 my $sc = $case_control->subcase($sid);
 if ( not defined $sc ) {
  $case_control->add($sid);
  $sc = $case_control->subcase($sid);
 }

 # Create the subcase cards
 if ( defined( $self->{TITLE} )
  and $self->{TITLE} !~ /^\s*$/xsm
  and not defined( $sc->get('TITLE') ) )
 {
  $case_control->append_card(
   Nastran::BDF::CaseControl::Card->new("TITLE=$self->{TITLE}") );
 }
 if ( defined( $self->{SUBTITLE} )
  and $self->{SUBTITLE} !~ /^\s*$/xsm
  and not defined( $sc->get('SUBTITLE') ) )
 {
  $case_control->append_card(
   Nastran::BDF::CaseControl::Card->new("SUBTITLE=$self->{SUBTITLE}") );
 }
 if ( defined( $self->{LABEL} )
  and $self->{LABEL} !~ /^\s*$/xsm
  and not defined( $sc->get('LABEL') ) )
 {
  $case_control->append_card(
   Nastran::BDF::CaseControl::Card->new("LABEL=$self->{LABEL}") );
 }
 return;
}

sub read_result {
 my $self = shift;
 if ( not $self->isa('Nastran::Punch::Block') ) {
  croak "$self must be a Nastran::Punch::Block object";
 }
 my $fh = $self->{FH};

 if ( defined ${ $self->{buffer} } ) {
  $_ = ${ $self->{buffer} };
  undef ${ $self->{buffer} };
 }
 else {
  $_ = <$fh>;
 }
 if ( not defined ) { return }

 # Found a new header
 if (/^\$/xsm) {
  my $block = Nastran::Punch::Block->new;
  $block->{FH}     = $fh;
  $block->{buffer} = $self->{buffer};
  $block->{next}   = $self->{next};
  $block->{parent} = $self->{parent};
  my $name = $block->read_block_header;

  # Different header, so return
  if ( not defined $name or $name ne $self->{name} ) {
   ${ $self->{next} } = $block;
   return;
  }

  # Copy new header data to block
  else {
   while ( my ( $k, $v ) = each %{$block} ) {
    $self->{$k} = $v;
   }
   $_ = ${ $self->{buffer} };
   undef ${ $self->{buffer} };
  }
 }

 # Retrieve the data format
 if ( not defined $block_table{ $self->{name} } ) {
  croak "Unknown result type $self->{name}";
 }
 my $fhash = $block_table{ $self->{name} };
 if ( $self->{name} =~ /(STRESSES|FORCES)/xsm ) {
  if ( not defined $block_table{ $self->{name} }{ $self->{'ELEMENT TYPE'}[0] } )
  {
   croak
"Unknown element type $self->{'ELEMENT TYPE'}[0] $self->{'ELEMENT TYPE'}[1] ($self->{name})";
  }
  $fhash = $block_table{ $self->{name} }{ $self->{'ELEMENT TYPE'}[0] };
 }

 # Read the data
 my @data;
 for my $format ( @{ $fhash->{format} } ) {
  if (@data) { $_ = <$fh> }
  push @data, unpack $format;
 }

 # Remove leading spaces
 for (@data) {
  if (defined) { s/^\s*//xsm }
 }

 return $self->{'SUBCASE ID'}, @data;
}

1;
