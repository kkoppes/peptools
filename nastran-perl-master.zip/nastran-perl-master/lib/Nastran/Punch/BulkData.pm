package Nastran::Punch::BulkData;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::BDF;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::Punch::Block);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

# Return the next card from the deck

sub readcard {
 my $self = shift;
 croak "$self must be a Nastran::Punch::BulkData object"
   unless ( $self->isa('Nastran::Punch::BulkData') );
 my $fh = $self->{FH};

 my ( @fields, @line );
 my $format = 'small';
 while (1) {

  # if there is a line in the buffer, use it. Otherwise read the next line from
  # the deck
  if ( defined ${ $self->{buffer} } ) {
   $_ = ${ $self->{buffer} };
   undef ${ $self->{buffer} };
  }
  else {
   $_ = <$fh>;
  }

  unless ( defined $_ ) {
   @fields = Nastran::BDF::chop_array(@fields);
   if (@fields) {
    my $card = $self->{BDF}->create_card(@fields);
    $card->set_format($format);
    return $card;
   }
   return;
  }

  # if we've already got a line and this isn't a continuation card
  # or an empty line then put the line in the buffer and return.
  if ( @fields and not /^(?:[\ \+\*]|\s*$)/xsm ) {

   # deal with a blank line at the beginning of the deck
   @fields = Nastran::BDF::chop_array(@fields);
   if (@fields) {

    ${ $self->{buffer} } = $_;
    my $card = $self->{BDF}->create_card(@fields);
    $card->set_format($format);
    return $card;
   }
  }
  if ( not @fields and ( not defined $_ or $_ eq '' ) ) { return }

  # We've reached results data
  if (/\$TITLE\ {3}=.*1$/xsm) {
   ${ $self->{buffer} } = $_;
   return;
  }

  # if we haven't got a comment, unpack
  if ( not /^\$/xsm ) {
   if ( substr( $_, 0, 8 ) =~ /\*/xsm ) {
    @line   = unpack 'A8A16A16A16A16';
    $format = 'large';
   }
   else {
    @line = unpack 'A8A8A8A8A8A8A8A8A8';
   }

   # If we have a continuation card, we need to skip the first field
   my $cc = /^[\+\*]/xsm ? 1 : 0;

   for ( my $i = $cc ; $i < @line ; $i++ ) {
    push @fields, Nastran::BDF::add_exponent( $line[$i] );
   }

   # If the line does not finish with a continuation card, then we can return
   if ( _finishes_with_cc($_) ) {
    my $card = $self->{BDF}->create_card(@fields);
    $card->set_format($format);
    return $card;
   }
  }
 }
 return;
}

sub _finishes_with_cc {
 my ($line) = @_;
 return ( length $line < 73 or substr( $line, 73, 1 ) ne '+' );
}

1;

__END__
