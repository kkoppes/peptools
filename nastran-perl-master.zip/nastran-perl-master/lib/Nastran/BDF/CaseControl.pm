package Nastran::BDF::CaseControl;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::BDF;
use Nastran::BDF::CaseControl::Card;
use Nastran::BDF::CaseControl::Subcase;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::BDF);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub new {
 my $class = shift;
 my $self  = {};
 $self->{current_subcase} = 0;
 bless $self, $class;
 return $self;
}

sub subcases {
 my $self = shift;
 if ( not $self->isa('Nastran::BDF::CaseControl') ) {
  croak "$self must be a Nastran::BDF::CaseControl object";
 }
 return $self->{subcases};
}

sub subcase_ids {
 my $self = shift;
 if ( not $self->isa('Nastran::BDF::CaseControl') ) {
  croak "$self must be a Nastran::BDF::CaseControl object";
 }
 if ( not defined $self->{subcase_list} ) {
  @{ $self->{subcase_list} } =
    sort { $a <=> $b } keys %{ $self->{subcase_hash} };
 }
 return $self->{subcase_list};
}

sub subcase {
 my ( $self, $id ) = @_;
 if ( not $self->isa('Nastran::BDF::CaseControl') ) {
  croak "$self must be a Nastran::BDF::CaseControl object";
 }
 if ( not defined $id ) { croak 'id must be an integer' }
 return $self->{subcases}[ $self->{subcase_hash}{$id} ]
   if ( defined $self->{subcase_hash}{$id} );
 return;
}

sub add {
 my ( $self, $id ) = @_;
 if ( not $self->isa('Nastran::BDF::CaseControl') ) {
  croak "$self must be a Nastran::BDF::CaseControl object";
 }
 my $subcase = Nastran::BDF::CaseControl::Subcase->new($id);
 if ( defined $self->{subcases} ) {
  push @{ $self->{subcases} }, $subcase;
 }
 else {
  $self->{subcases} = [$subcase];
 }
 $self->{subcase_hash}{$id} = $#{ $self->{subcases} }
   ;    # a look-up table to avoid scanning the array of subcases
 delete $self->{subcase_list};
 $self->{current_subcase} = $id;
 return;
}

sub remove {
 my ( $self, $id ) = @_;
 if ( not $self->isa('Nastran::BDF::CaseControl') ) {
  croak "$self must be a Nastran::BDF::CaseControl object";
 }
 if ( not defined $self->subcase($id) ) { croak "subcase $id not defined" }
 splice @{ $self->{subcases} }, $self->{subcase_hash}{$id}, 1;
 delete $self->{subcase_hash}{$id};
 delete $self->{subcase_list};
 if ( $self->{current_subcase} == $id ) { undef $self->{current_subcase} }
 return;
}

sub append_card {
 my ( $self, $card ) = @_;
 if ( not $self->isa('Nastran::BDF::CaseControl') ) {
  croak "$self must be a Nastran::BDF::CaseControl object";
 }
 if ( not $card->isa('Nastran::BDF::CaseControl::Card') ) {
  croak "$card must be a Nastran::BDF::CaseControl::Card object";
 }
 if ( not defined $self->{current_subcase} ) { croak 'No current subcase' }
 if ( $card->key eq 'subcase' ) {
  $self->add( $card->value );
 }
 elsif ( $self->{current_subcase} == 0
  and not defined( $self->subcase(0) ) )
 {
  $self->add(0);
 }
 $self->subcase( $self->{current_subcase} )->add($card);
 return;
}

1;
