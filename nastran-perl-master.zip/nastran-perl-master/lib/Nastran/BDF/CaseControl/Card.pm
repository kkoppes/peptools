package Nastran::BDF::CaseControl::Card;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::BDF;
use Nastran::Card;
use overload
  '""' => 'to_string',
  'eq' => 'to_string',
  'ne' => 'to_string';

my %key_tree;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::Card);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

add_keys(
 \%key_tree, qw[
   OUTPUT SUBCASE SUBCOM SYM SYMCOM REPCASE SUBSEQ SYMSEQ MODES
   MASTER LOAD DEFORM CLOAD DLOAD LOADSET NONLINEAR SPC MPC
   SUPORT1 AXISYMMETRIC DSYM BC STATSUB TEMPERATURE TSTRU
   SMETHOD DYNRED METHOD CMETHOD SDAMPING FREQUENCY RANDOM
   IC SMETHOD TSTEP B2GG B2PP K2GG K2PP M2GG M2PP TFL P2G
   MFLUID NLPARM SMETHOD TSTEP TSTEPNL ECHO
   AECONFIG AESYMXY AESYMXZ AEUXREF CSSCHD GUST TRIM FMETHOD
   DIVERG ANALYSIS AUXCASE AUXMODEL DESGLB DESOBJ DESSUB DSAPRT
   MODTRAK SENSITY ADACT ADAPT DATAREC OUTRCV OUTRCV SET
   VUGRID TITLE SUBTITLE LABEL LINES MAXLINES ECHOOFF ECHOON
   PAGE PLOTID SKIPON SKIPOFF SET2 MAXMIN OFREQUENCY OMODES
   OTIME PARTN SURFACE VOLUME SVECTOR VELOCITY ACCELERATION
   FORCE ELFORCES STRESS ELSTRESS GPSTRESS ELSDCON GPSDCON
   STRFIELD STRAIN GPFORCES ESE FLUX DISPLACEMENT VECTOR PRESSURE
   ENTHALPY HDOT MPCFORCES SPCFORCES OLOAD THERMAL NOUTPUT BOUTPUT
   EDE EKE GPKE GPSTRAIN MEFFMASS NLSTRESS HARMONICS HOUTPUT
   SDISPLACEMENT SVELOCITY SACCELERATION NLLOAD MPRES AEROF
   APRESSURE ELSUM GROUNDCHECK WEIGHTCHECK SUPER SEMGENERATE
   SELGENERATE SEALL SEKREDUCE SEMREDUCE SELREDUCE SEFINAL
   SEEXCLUDE SEDR SEDV SERESP INCLUDE MSGSTRESS PARAM EQUILIBRIUM
   ]
);

sub new {
 my ( $class, $card ) = @_;
 my $self = {};
 if ( $card =~ /^\s*([a-z1-9]+)(?:\(([,=\+\.a-z0-9]+)\))?\s*[= ]([\s\S]*)/ixsm )
 {
  $self->{data}[0] = lc($1);
  $self->{key}     = \$self->{data}[0];
  $self->{data}[1] = $2;
  $self->{data}[2] = $3;
  if ( defined $self->{data}[2] ) {
   if ( $self->{data}[2] =~ /^(\d+)\s*=\s*([\s\S]+)$/xsm ) {
    $self->{data}[1] = $1;
    $self->{data}[2] = $2;
   }
   elsif ( $self->{data}[2] =~ /^\s*\d+\s*$/xsm ) {
    $self->{data}[2] += 0;
   }
   $self->{value} = \$self->{data}[2];
  }
  $self->{option} = \$self->{data}[1] if ( defined $self->{data}[1] );
 }
 else {
  croak "Error: unrecognised case control card $card\n";
 }
 bless( $self, $class );
 return $self;
}

sub key {
 my $self = shift;
 croak "$self must be a Nastran::BDF::CaseControl::Card object"
   unless ( $self->isa('Nastran::BDF::CaseControl::Card') );
 return ${ $self->{key} };
}

sub option {
 my $self = shift;
 croak "$self must be a Nastran::BDF::CaseControl::Card object"
   unless ( $self->isa('Nastran::BDF::CaseControl::Card') );
 return ${ $self->{option} };
}

sub value {
 my ( $self, $value ) = @_;
 croak "$self must be a Nastran::BDF::CaseControl::Card object"
   unless ( $self->isa('Nastran::BDF::CaseControl::Card') );
 if ( defined $value ) {
  ${ $self->{value} } = $value;
 }
 return ${ $self->{value} };
}

sub to_string {
 my $self = shift;
 croak "$self must be a Nastran::BDF::CaseControl::Card object"
   unless ( $self->isa('Nastran::BDF::CaseControl::Card') );

 return "${$self->{key}}(${$self->{option}}) = ${$self->{value}}\n"
   if ( defined $self->{option} );
 return sprintf "%s=%s\n", $self->prefix, ${ $self->{value} }
   if ( ${ $self->{key} } =~ /^(titl|subt|labe)/xsm );
 return "${$self->{key}} = ${$self->{value}}\n";
}

# Store case control cards in a tree to be able to look up by prefix

sub add_keys {
 my ( $key_tree, @keys ) = @_;
 for my $key (@keys) {
  add_key( $key_tree, 1, $key );
 }
 return;
}

# Recursive helper sub to walk the tree and add the new key

sub add_key {
 my ( $key_tree, $length, $key ) = @_;
 my $prefix = substr( $key, 0, $length );
 if ( defined $key_tree->{$prefix} ) {
  if ( ref( $key_tree->{$prefix} ) ne 'HASH' ) {
   my $other = $key_tree->{$prefix};
   return if ( $other eq $key );    # already in tree
   delete $key_tree->{$prefix};
   $key_tree->{$prefix}{ substr( $other, 0, $length + 1 ) } = $other;
  }
  add_key( $key_tree->{$prefix}, $length + 1, $key );
 }
 else {
  $key_tree->{$prefix} = $key;
 }
 return;
}

# Look up by prefix

sub lookup {
 my ($key) = @_;
 return lookup_helper( \%key_tree, 1, uc($key), 0 );
}

# Recursive helper sub to walk the tree and look up the key

sub lookup_helper {
 my ( $key_tree, $length, $key, $shortest ) = @_;
 my $prefix = substr( $key, 0, $length );
 if ( defined $key_tree->{$prefix} ) {
  if ( ref( $key_tree->{$prefix} ) eq 'HASH' ) {
   return lookup_helper( $key_tree->{$prefix}, $length + 1, $key, $shortest );
  }
  elsif ( substr( $key_tree->{$prefix}, 0, length($key) ) eq $key ) {
   if ($shortest) {
    return substr( $key, 0, 4 ) if ( length($prefix) < 4 );
    return $prefix;
   }
   return $key_tree->{$prefix};
  }
 }
 return;    # doesn't exist
}

# Find the shortest prefix for the key

sub prefix {
 my ($self) = @_;
 croak "$self must be a Nastran::BDF::CaseControl::Card object"
   unless ( $self->isa('Nastran::BDF::CaseControl::Card') );
 return lookup_helper( \%key_tree, 1, uc( ${ $self->{key} } ), 1 );
}

1;
