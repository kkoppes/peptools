package Nastran::BDF::CaseControl::Card::Set;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::BDF::CaseControl::Card;
use Set::IntSpan;

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter Nastran::BDF::CaseControl::Card);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

# Todo: add overloaded operators for +-, etc.

sub to_Set_IntSpan {
 my $self = shift;
 croak "$self must be a Nastran::BDF::CaseControl::Card::Set object"
   unless ( $self->isa('Nastran::BDF::CaseControl::Card::Set') );

 my $line = $self->{data}[2];
 $line =~ s/[,\s*]thru[,\s*]/-/gi;
 $line =~ s/[\n ]//gi;

 # Minimise the number of += Set::IntSpan->new() calls, as they are very slow
 my @a = split( ',', $line );
 my $set = Set::IntSpan->new;
 while (@a) {
  my $last = 0;
  my $run;
  while (@a) {

# unfortunately, we can't compare a number to a range, so we have to remove everything but the start
   my $next = $a[0];
   $next =~ s/-.*$//i;
   last unless ( $next > $last );
   $last = $next;
   if ( defined $run ) {
    $run .= ',' . shift @a;
   }
   else {
    $run = shift @a;
   }
  }
  $set += Set::IntSpan->new($run);
 }
 return $set;
}

sub from_Set_IntSpan {
 my ( $sid, $set ) = @_;
 croak "from_Set_IntSpan requires two arguments, Int and Set::IntSpan object"
   unless ( defined $set );
 croak "$set must be a Set::IntSpan object"
   unless ( $set->isa('Set::IntSpan') );

 my ( $s, $l );
 if ( $set->empty ) {
  $s = "SET $sid = 0";
 }
 else {
  for ( $set->spans ) {
   if ( defined $s ) {
    $s .= ',';
    $l++;
   }
   else {
    $s = "SET $sid = ";
    $l = length($s);
   }
   my $span;
   if ( $_->[0] == $_->[1] ) {
    $span = $_->[0];
   }
   elsif ( $_->[0] == $_->[1] - 1 ) {
    $span = "$_->[0],$_->[1]";    # fix this to allow line break between the two
   }
   else {
    $span = "$_->[0],THRU,$_->[1]";
   }
   if ( $l + 1 + length($span) > 72 ) {
    $s .= "\n ";
    $l = 1;
   }
   $s .= $span;
   $l += length($span);
  }
 }
 return Nastran::BDF::CaseControl::Card::Set->new($s);
}

sub to_string {
 my $self = shift;
 croak "$self must be a Nastran::BDF::CaseControl::Card::Set object"
   unless ( $self->isa('Nastran::BDF::CaseControl::Card::Set') );
 return "${$self->{key}} ${$self->{option}}=${$self->{value}}\n";
}

1;

__END__
