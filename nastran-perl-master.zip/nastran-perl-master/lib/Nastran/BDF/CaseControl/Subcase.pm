package Nastran::BDF::CaseControl::Subcase;

use 5.008005;
use strict;
use warnings;
use Carp;
use Nastran::BDF;
use Nastran::Card;
use overload
  '""' => 'to_string',
  'eq' => 'to_string',
  'ne' => 'to_string';

BEGIN {
 use Exporter ();
 our ( $VERSION, @EXPORT_OK, %EXPORT_TAGS );

 use base qw(Exporter);
 %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

 # your exported package globals go here,
 # as well as any optionally exported functions
 @EXPORT_OK = qw();
}
our @EXPORT_OK;

sub new {
 my ( $class, $id ) = @_;
 my $self = {};
 $self->{id} = $id;
 bless( $self, $class );
 return $self;
}

sub id {
 my ($self) = @_;
 croak "$self must be a Nastran::BDF::CaseControl::Subcase object"
   unless ( $self->isa('Nastran::BDF::CaseControl::Subcase') );
 return $self->{id};
}

sub add {
 my ( $self, $card ) = @_;
 croak "$self must be a Nastran::BDF::CaseControl::Subcase object"
   unless ( $self->isa('Nastran::BDF::CaseControl::Subcase') );
 croak "$card must be a Nastran::BDF::CaseControl::Card object"
   unless ( $card->isa('Nastran::BDF::CaseControl::Card') );

 my $key = $card->key;
 $key = Nastran::BDF::CaseControl::Card::lookup($key);
 die "Error: unknown card `$card'\n" unless ( defined $key );
 $self->{$key} = $card;
 return;
}

sub get {
 my ( $self, $key ) = @_;
 croak "$self must be a Nastran::BDF::CaseControl::Subcase object"
   if ( not $self->isa('Nastran::BDF::CaseControl::Subcase') );

 my $card = Nastran::BDF::CaseControl::Card::lookup($key);
 die "Error: unknown card `$key'\n" unless ( defined $card );
 return $self->{$card};
}

sub to_string {
 my $self = shift;
 croak "$self must be a Nastran::BDF::CaseControl::Subcase object"
   unless ( $self->isa('Nastran::BDF::CaseControl::Subcase') );

 my $string = '';
 $string .= $self->{SUBCASE} if ( defined $self->{SUBCASE} );
 for ( sort { $a cmp $b } keys %{$self} ) {
  $string .= $self->{$_} unless (/^(SUBCASE|id)$/);
 }
 return $string;
}

1;
