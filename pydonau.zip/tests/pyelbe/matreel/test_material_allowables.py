# -*- coding: utf-8 -*-

from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicAllowables,
    CompositeAllowables,
)
from pydantic import ValidationError
import pytest


def test_composite_init() -> None:
    """test class initialization no errors shall occour"""
    # name = "IMA_M21E_194_0.184"
    # spec = "IPS05-27-002-01"
    allowables = {
        "f1_t": 2610.0,
        "f1_c": -1450.0,
        "f2_t": 55.0,
        "f2_c": -285.0,
        "f3_t": 64.5,
        "f3_c": -250.0,
        "f12_s": 105.0,
        "f13_s": 68.0,
        "f23_s": 68.0,
        "f_pt": 120.0,
    }
    cfrp = CompositeAllowables(**allowables)
    assert cfrp.f1_t == allowables["f1_t"]
    assert cfrp.f1_c == allowables["f1_c"]
    assert cfrp.f2_t == allowables["f2_t"]
    assert cfrp.f2_c == allowables["f2_c"]
    assert cfrp.f3_t == allowables["f3_t"]
    assert cfrp.f3_c == allowables["f3_c"]
    assert cfrp.f12_s == allowables["f12_s"]
    assert cfrp.f13_s == allowables["f13_s"]
    assert cfrp.f23_s == allowables["f23_s"]
    assert cfrp.f_pt == allowables["f_pt"]


def test_metallic_init() -> None:
    """test class initialization no errors shall occour"""
    # name = "Ti-6Al-4V_ab_Annealed_Plate"
    # spec = "AIMS03-18-006"
    allowables = {
        "Fcy": 855.0,
        "Fty": 830.0,
        "Ftu": 900.0,
        "Fsu": 490.0,
        "b10": 1245.0,
        "e": 0.06,
        "n": 28.0,
        "nc": 28.0,
    }
    basis = "A"
    orientation = "Fcy:L,Fty:L,Ftu:L,Fsu:ST,b10:L,e:ST,n:ST,nc:ST"
    met = MetallicAllowables(**allowables, basis=basis, orientation=orientation)
    assert met.Fcy == allowables["Fcy"]
    assert met.Fty == allowables["Fty"]
    assert met.Ftu == allowables["Ftu"]
    assert met.Fsu == allowables["Fsu"]
    assert met.b10 == allowables["b10"]
    assert met.e == allowables["e"]
    assert met.n == allowables["n"]
    assert met.nc == allowables["nc"]
    assert met.basis == basis
    assert met.orientation == orientation


def test_composite_validation_error() -> None:
    """test class initialization with strings instead of numbers,
    ValidationError exceptions shall occour"""
    allowables = {
        "f1_t": 2610.0,
        "f1_c": -1450.0,
        "f2_t": 55.0,
        "f2_c": -285.0,
        "f3_t": 64.5,
        "f3_c": -250.0,
        "f12_s": 105.0,
        "f13_s": 68.0,
        "f23_s": 68.0,
        "f_pt": 120.0,
    }
    for allowable in allowables:
        # allowables shall be float
        wrong_arguments = dict(allowables)
        wrong_arguments[allowable] = "test"
        with pytest.raises(ValidationError) as exc_info:
            CompositeAllowables(**wrong_arguments)
        print(str(exc_info.value))
        assert exc_info.value


def test_metallic_validation_error() -> None:
    """test class initialization with strings instead of numbers,
    ValidationError exceptions shall occour"""
    # name = "Ti-6Al-4V_ab_Annealed_Plate"
    # spec = "AIMS03-18-006"
    allowables = {
        "Fcy": 855.0,
        "Fty": 830.0,
        "Ftu": 900.0,
        "Fsu": 490.0,
        "b10": 1245.0,
        "e": 0.06,
        "n": 28.0,
        "nc": 28.0,
    }
    basis = "A"
    orientation = "Fcy:L,Fty:L,Ftu:L,Fsu:ST,b10:L,e:ST,n:ST,nc:ST"
    for allowable in allowables:
        # allowables shall be float
        wrong_arguments = dict(allowables)
        wrong_arguments[allowable] = "test"
        with pytest.raises(ValidationError) as exc_info:
            MetallicAllowables(**wrong_arguments, basis=basis, orientation=orientation)
        print(str(exc_info.value))
        assert exc_info.value
    with pytest.raises(ValidationError) as exc_info:
        MetallicAllowables(**allowables, basis=None, orientation=orientation)
        print(str(exc_info.value))
        assert exc_info.value
    with pytest.raises(ValidationError) as exc_info:
        MetallicAllowables(**allowables, basis=basis, orientation=None)
        print(str(exc_info.value))
        assert exc_info.value


# if __name__ == "__main__":
#     test_composite_init()
#     test_metallic_init()
#     test_composite_validation_error()
#     test_metallic_validation_error()
