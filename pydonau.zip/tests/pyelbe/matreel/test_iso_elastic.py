# -*- coding: utf-8 -*-

from makerspace_mbe_pylantir.pyelbe.matreel import IsoElastic
from pydantic import ValidationError
import pytest


def calc_shear_modulus(E: float, nu: float) -> float:
    return E / 2.0 / (1.0 + nu)


def calc_poisson_ratio(E: float, G: float) -> float:
    return E / 2.0 / G - 1.0


def test_iso_elastic_init() -> None:
    """test class initialization no errors shall occour"""
    # name = "Ti-6Al-4V_ab_Annealed_Plate"
    # spec = "AIMS03-18-006"
    E = 110.3e3
    G = 42.75e3
    nu = 310e-3

    iso = IsoElastic(
        E=E,
        G=G,
        nu=nu,
    )
    assert iso.E == E
    assert iso.G == G
    assert iso.nu == nu

    iso = IsoElastic(
        E=E,
        nu=nu,
    )
    thd = 1e-6  # theshold
    assert (iso.G - calc_shear_modulus(E, nu)) < thd
    iso = IsoElastic(
        E=E,
        G=G,
    )
    thd = 1e-6  # theshold
    assert (iso.nu - calc_poisson_ratio(E, G)) < thd


def test_iso_elastic_ValidationError() -> None:
    """test class initialization with strings instead of numbers,
    ValidationError exceptions shall occour"""
    # name = "Ti-6Al-4V_ab_Annealed_Plate"
    # spec = "AIMS03-18-006"
    E = 110.3e3
    G = 42.75e3
    nu = 310e-3
    # properties shall be float
    with pytest.raises(ValidationError) as exc_info:
        IsoElastic(
            E="test",
            G=G,
            nu=nu,
        )
    print(str(exc_info.value))
    assert str(exc_info.value)
    with pytest.raises(ValidationError) as exc_info:
        IsoElastic(
            E=E,
            G="test",
            nu=nu,
        )
    print(str(exc_info.value))
    assert str(exc_info.value)
    with pytest.raises(ValidationError) as exc_info:
        IsoElastic(
            E=E,
            G=G,
            nu="test",
        )
    print(str(exc_info.value))
    assert str(exc_info.value)
    with pytest.raises(ValidationError) as exc_info:
        IsoElastic()
    print(str(exc_info.value))
    assert str(exc_info.value)
    with pytest.raises(ValidationError) as exc_info:
        IsoElastic(E=E)
    print(str(exc_info.value))
    assert str(exc_info.value)
    with pytest.raises(ValidationError) as exc_info:
        IsoElastic(G=G)
    print(str(exc_info.value))
    assert str(exc_info.value)
    with pytest.raises(ValidationError) as exc_info:
        IsoElastic(nu=nu)
    print(str(exc_info.value))
    assert str(exc_info.value)
    with pytest.raises(ValidationError) as exc_info:
        IsoElastic(G=G, nu=nu)
    print(str(exc_info.value))
    assert str(exc_info.value)


# if __name__ == "__main__":
#     test_iso_elastic_init()
#     test_iso_elastic_ValidationError()
