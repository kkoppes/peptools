#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 22 10:17:15 2022

@author: gi11883
"""

from makerspace_mbe_pylantir.pyelbe.matreel import OrthoElastic
from pydantic import ValidationError
import pytest


def test_ortho_elastic_init() -> None:
    """test class initialization no errors shall occour"""
    # name = "IMA_M21E_194_0.184"
    # spec = "IPS05-27-002-01"
    E1 = 154e3
    E2 = 8.5e3
    E3 = 8.5e3
    G12 = 4.2e3
    G13 = 4.2e3
    G23 = 3.36e3
    nu12 = 0.35
    nu13 = 0.35
    nu23 = 0.26488095
    ortho = OrthoElastic(
        E1=E1,
        E2=E2,
        E3=E3,
        G12=G12,
        G13=G13,
        G23=G23,
        nu12=nu12,
        nu13=nu13,
        nu23=nu23,
    )
    assert ortho.E1 == E1
    assert ortho.E2 == E2
    assert ortho.E3 == E3
    assert ortho.G12 == G12
    assert ortho.G13 == G13
    assert ortho.G23 == G23
    assert ortho.nu12 == nu12
    assert ortho.nu13 == nu13
    assert ortho.nu23 == nu23

    # provide arguments
    ortho = OrthoElastic(
        E1=E1,
        E2=E2,
        G12=G12,
        nu12=nu12,
    )
    assert ortho.E1 == E1
    assert ortho.E2 == E2
    assert ortho.G12 == G12
    assert ortho.nu12 == nu12


def test_ortho_elastic_ValidationError() -> None:
    """test class initialization with strings instead of numbers,
    ValidationError exceptions shall occour"""
    # name = "Ti-6Al-4V_ab_Annealed_Plate"
    # spec = "AIMS03-18-006"

    arguments = {
        "E1": 154e3,
        "E2": 8.5e3,
        "E3": 8.5e3,
        "G12": 4.2e3,
        "G13": 4.2e3,
        "G23": 3.36e3,
        "nu12": 0.35,
        "nu13": 0.35,
        "nu23": 0.26488095,
    }

    for argument in arguments:
        # properties shall be float
        wrong_arguments = dict(arguments)
        wrong_arguments[argument] = "test"
        with pytest.raises(ValidationError) as exc_info:
            OrthoElastic(**wrong_arguments)
        print(str(exc_info.value))
        assert str(exc_info.value)

    required_args = ["E1", "E2", "G12", "nu12"]

    for argument in required_args:
        wrong_arguments = dict(arguments)
        del wrong_arguments[argument]
        with pytest.raises(ValidationError) as exc_info:
            OrthoElastic(**wrong_arguments)
        print(str(exc_info.value))
        assert str(exc_info.value)


# if __name__ == "__main__":
#     test_ortho_elastic_init()
#     test_ortho_elastic_ValidationError()
