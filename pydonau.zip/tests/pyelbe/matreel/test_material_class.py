#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 18 09:13:26 2022

@author: gi11883
"""
import os
from pathlib import Path
from dataclasses import dataclass
import shelve
from makerspace_mbe_pylantir.pyelbe.matreel import (
    IsoElastic,
    Material,
    MetallicAllowables,
    MetallicMaterial,
    Billet,
)
from pydantic import ValidationError
import pytest

test_folder = os.getcwd()
test_shelve = Path("test_mat.shelve")


@pytest.fixture(autouse=True)
def cleanup_files():
    """Remove the test files."""
    if test_shelve.exists():
        os.remove(test_shelve)


@dataclass
class DataExchange:
    basis: str
    orientation: str
    allowables: dict
    properties: dict
    billets: dict
    material: Material


def test_material_class() -> None:
    properties = {"E": 110.3e3, "G": 42.75e3, "nu": 310e-3}
    iso = IsoElastic(
        E=properties["E"],
        G=properties["G"],
        nu=properties["nu"],
    )

    allowables = {
        "Fcy": 855.0,
        "Fty": 830.0,
        "Ftu": 900.0,
        "Fsu": 490.0,
        "b10": 1245.0,
        "e": 0.06,
        "n": 28.0,
        "nc": 28.0,
    }

    billets = {
        "billet": Billet(nominal=20, minimum=12, maximum=40),
        "low_billet": Billet(nominal=15, minimum=12, maximum=40),
        "high_billet": Billet(nominal=25, minimum=12, maximum=40),
        "min_billet": Billet(nominal=5, minimum=1, maximum=6),
        "max_billet": Billet(nominal=45, minimum=40, maximum=60),
    }

    basis = "A"
    orientation = "Fcy:L,Fty:L,Ftu:L,Fsu:ST,b10:L,e:ST,n:ST,nc:ST"
    allow = MetallicAllowables(**allowables, basis=basis, orientation=orientation)
    name = "Ti-6Al-4V_ab_Annealed_Plate"
    spec = "AIMS03-18-006"
    mat = MetallicMaterial(name=name, specification=spec, properties=iso, allowables=allow, billet=billets["billet"])

    data_exchange = DataExchange(
        allowables=allowables,
        properties=properties,
        billets=billets,
        material=mat,
        orientation=orientation,
        basis=basis,
    )

    assertions(data_exchange)
    # test seve and load to shelve
    shelve_filename = str(test_shelve.absolute())
    with shelve.open(shelve_filename) as db_save:
        db_save[spec] = mat

    with shelve.open(shelve_filename) as db_load:
        data_exchange.material = db_load[spec]
        assertions(data_exchange)

    # the file is removed with the cleanup_files fixture


def assertions(arg: DataExchange):
    mat = arg.material
    basis = arg.basis
    billets = arg.billets
    orientation = arg.orientation
    properties = arg.properties
    allowables = arg.allowables
    # test properties values
    assert mat.properties.E == properties["E"]
    assert mat.properties.G == properties["G"]
    assert mat.properties.nu == properties["nu"]
    # test allowables
    assert mat.allowables.Fcy == allowables["Fcy"]
    assert mat.allowables.Fty == allowables["Fty"]
    assert mat.allowables.Ftu == allowables["Ftu"]
    assert mat.allowables.Fsu == allowables["Fsu"]
    assert mat.allowables.b10 == allowables["b10"]
    assert mat.allowables.e == allowables["e"]
    assert mat.allowables.n == allowables["n"]
    assert mat.allowables.nc == allowables["nc"]
    assert mat.allowables.basis == basis
    assert mat.allowables.orientation == orientation
    # test billet
    assert mat.billet == billets["billet"]
    assert mat.billet != billets["min_billet"]
    assert mat.billet != billets["max_billet"]
    assert mat.billet > billets["min_billet"]
    assert mat.billet < billets["max_billet"]
    assert mat.billet > billets["low_billet"]
    assert mat.billet < billets["high_billet"]
    assert mat.billet >= billets["min_billet"]
    assert mat.billet <= billets["max_billet"]
    assert mat.billet >= billets["low_billet"]
    assert mat.billet <= billets["high_billet"]
    assert str(mat.billet) == "12-40"


def test_material_class_from_dict() -> None:
    allowables = {
        "Fcy": 855.0,
        "Fty": 830.0,
        "Ftu": 900.0,
        "Fsu": 490.0,
        "b10": 1245.0,
        "e": 0.06,
        "n": 28.0,
        "nc": 28.0,
    }
    properties = {
        "E": 110.3e3,
        "Ec": 110.3e3,
        "G": 42.75e3,
        "nu": 310e-3,
    }
    input_dict = {
        "name": "Ti-6Al-4V_ab_Annealed_Plate",
        "specification": "AIMS03-18-006",
        "properties": {
            "E": 110.3e3,
            "Ec": 110.3e3,
            "G": 42.75e3,
            "nu": 310e-3,
        },
        "allowables": {
            "Fcy": 855.0,
            "Fty": 830.0,
            "Ftu": 900.0,
            "Fsu": 490.0,
            "b10": 1245.0,
            "e": 0.06,
            "n": 28.0,
            "nc": 28.0,
        },
        "billet": {"nominal": 20},
    }

    billet = Billet(nominal=20)
    mat = MetallicMaterial.from_dict(input_dict)
    # test properties values
    assert mat.properties.E == properties["E"]
    assert mat.properties.G == properties["G"]
    assert mat.properties.nu == properties["nu"]
    # test allowables
    assert mat.allowables.Fcy == allowables["Fcy"]
    assert mat.allowables.Fty == allowables["Fty"]
    assert mat.allowables.Ftu == allowables["Ftu"]
    assert mat.allowables.Fsu == allowables["Fsu"]
    assert mat.allowables.b10 == allowables["b10"]
    assert mat.allowables.e == allowables["e"]
    assert mat.allowables.n == allowables["n"]
    assert mat.allowables.nc == allowables["nc"]
    assert mat.billet == billet


def test_material_errors():
    # check for ValidatorError

    E = 110.3e3
    G = 42.75e3
    nu = 310e-3

    iso = IsoElastic(
        E=E,
        G=G,
        nu=nu,
    )
    allowables = {
        "Fcy": 855.0,
        "Fty": 830.0,
        "Ftu": 900.0,
        "Fsu": 490.0,
        "b10": 1245.0,
        "e": 0.06,
        "n": 28.0,
        "nc": 28.0,
    }
    billet = Billet(nominal=20, minimum=12, maximum=40)
    basis = "A"
    orientation = "Fcy:L,Fty:L,Ftu:L,Fsu:ST,b10:L,e:ST,n:ST,nc:ST"
    allow = MetallicAllowables(**allowables, basis=basis, orientation=orientation)
    name = "Ti-6Al-4V_ab_Annealed_Plate"
    spec = "AIMS03-18-006"

    with pytest.raises(ValidationError) as exc_info:
        MetallicMaterial(
            name=name,
            specification=spec,
            properties=[],
            allowables=allow,
            billet=billet,
        )
    print(str(exc_info.value))
    assert exc_info.value

    with pytest.raises(ValidationError) as exc_info:
        MetallicMaterial(name=name, specification=spec, properties=iso, allowables=[], billet=billet)
    print(str(exc_info.value))
    assert str(exc_info.value)

    with pytest.raises(ValidationError) as exc_info:
        MetallicMaterial(name=name, specification=spec, properties=iso, allowables=allow, billet=[])
    print(str(exc_info.value))
    assert str(exc_info.value)


# if __name__ == "__main__":
#     test_material_class()
#     test_material_errors()
