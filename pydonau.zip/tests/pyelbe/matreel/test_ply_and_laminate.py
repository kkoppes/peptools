#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 22 10:39:33 2022

@author: gi11883
"""

from makerspace_mbe_pylantir.pyelbe.matreel import Laminate, Ply, OrthoElastic

name = "IMA_M21E_194_0.184"
spec = "IPS05-27-002-01"
E1 = 154e3
E2 = 8.5e3
G12 = 4.2e3
nu12 = 0.35
thickness = 0.184

mat_1 = OrthoElastic(E1=E1, E2=E2, G12=G12, nu12=nu12)


def create_stacking(angles) -> list[Ply]:
    """Return a list of Ply objects given angles."""
    stacking = []
    for angle in angles:
        stacking += [
            Ply(
                name=name,
                specification=spec,
                elastic=mat_1,
                thickness=thickness,
                angle=angle,
            )
        ]
    return stacking


def test_ply() -> None:
    """test Ply class initialization, no errors shall occour"""
    angle = 45  # deg
    ply = Ply(
        name=name,
        specification=spec,
        elastic=mat_1,
        thickness=thickness,
        angle=angle,
    )
    assert ply.name == name
    assert ply.specification == spec
    assert ply.angle == float(angle)
    assert ply.thickness == thickness


def test_laminate() -> None:
    """test Laminate class initialization, no errors shall occour"""
    # build the stacking
    angles = [0, 0, 90, 45, 45, 90, 0, 45, 45, 90, 0, 0]  # deg
    stacking = create_stacking(angles)
    laminate = Laminate(stacking=stacking)
    # pre-calculated laminate equivalent elastic properties
    Eeq1 = 72.300054e3
    Eeq2 = 48.026429e3
    Geq12 = 12.301211e3
    nueq12 = 0.110981
    # threshold 1e-6
    thd = 1e-6
    assert abs(laminate.thickness - len(angles) * thickness) < thd
    assert abs(laminate.nu12 - nueq12) < thd
    # threshold 1e-3
    thd = 1e-3
    assert abs(laminate.E1 - Eeq1) < thd
    assert abs(laminate.E2 - Eeq2) < thd
    assert abs(laminate.G12 - Geq12) < thd
    # check the stacking sequence
    stacking_sequence = (
        "[" + "/".join([f"{angle:.1f}" for angle in angles]) + "]"
    )
    assert str(laminate) == stacking_sequence
    assert len(laminate) == len(angles)
    # remove plies (the first and the last one)
    laminate.remove_ply(1)
    laminate.remove_ply(-1)
    angles.pop(0)
    angles.pop(-1)
    stacking = create_stacking(angles)
    stacking_sequence = (
        "[" + "/".join([f"{angle:.1f}" for angle in angles]) + "]"
    )
    Eeq1 = 55.396938e3
    Eeq2 = 55.357906e3
    Geq12 = 13.214024e3
    nueq12 = 0.095426
    thd = 1e-6
    assert abs(laminate.thickness - len(angles) * thickness) < thd
    assert abs(laminate.nu12 - nueq12) < thd
    thd = 1e-3
    assert abs(laminate.E1 - Eeq1) < thd
    assert abs(laminate.E2 - Eeq2) < thd
    assert abs(laminate.G12 - Geq12) < thd
    assert str(laminate) == stacking_sequence
    # assign a new stacking
    angles = [0, 90, 45, 45, 0, 90, -45, -45, 90, 0]  # deg
    stacking = create_stacking(angles)
    laminate.set_stacking(stacking)
    stacking_sequence = (
        "[" + "/".join([f"{angle:.1f}" for angle in angles]) + "]"
    )
    Eeq1 = 57.577071e3
    Eeq2 = 57.537781e3
    Geq12 = 15.756441e3
    nueq12 = 0.138596
    thd = 1e-6
    assert abs(laminate.thickness - len(angles) * thickness) < thd
    assert abs(laminate.nu12 - nueq12) < thd
    thd = 1e-3
    assert abs(laminate.E1 - Eeq1) < thd
    assert abs(laminate.E2 - Eeq2) < thd
    assert abs(laminate.G12 - Geq12) < thd
    assert str(laminate) == stacking_sequence


# if __name__ == "__main__":
#     test_ply()
#     test_laminate()
