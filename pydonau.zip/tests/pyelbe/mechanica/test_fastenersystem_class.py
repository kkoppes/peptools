#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 18 09:13:26 2022

@author: gi11883
"""
from makerspace_mbe_pylantir.pyelbe.mechanica import (
    Pin,
    Nut,
    Collar,
    PinAllowables,
    NutAllowables,
    MaterialAllowables,
    FastenerSystem,
)
from makerspace_mbe_pylantir.pyelbe.matreel import IsoElastic, Material

from pydantic import ValidationError
import pytest


def test_pin_allowables() -> None:
    pin_allowables = {"Fsu": 6725.0, "Ftu": 6550.0}
    pin_allow = PinAllowables(**pin_allowables)
    # test get_attributes()
    assert pin_allow.get_attributes() == pin_allowables
    # test copy allowables
    copy_pin_allow = pin_allow.copy()
    assert copy_pin_allow == pin_allow
    # test errors
    # wrong values
    with pytest.raises(ValidationError) as exc_info:
        PinAllowables(Fsu="test", Ftu=6550.0)
    print(str(exc_info.value))
    assert str(exc_info.value)
    with pytest.raises(ValidationError) as exc_info:
        PinAllowables(Fsu=6725.0, Ftu="test")
    print(str(exc_info.value))
    assert str(exc_info.value)


def test_nut_allowables() -> None:
    nut_allowables = {"Ftu": 6550.0}
    nut_allow = NutAllowables(**nut_allowables)
    # test get_attributes()
    assert nut_allow.get_attributes() == nut_allowables
    # test copy allowables
    copy_nut_allow = nut_allow.copy()
    assert copy_nut_allow == nut_allow
    # test errors
    # wrong value
    with pytest.raises(ValidationError) as exc_info:
        NutAllowables(Ftu="test")
    print(str(exc_info.value))
    assert str(exc_info.value)


def test_material_allowables() -> None:
    mat_allowables = {"Fsu": 6550.0}
    mat_allow = MaterialAllowables(**mat_allowables)
    # test get_attributes()
    assert mat_allow.get_attributes() == mat_allowables
    # test copy allowables
    copy_mat_allow = mat_allow.copy()
    assert copy_mat_allow == mat_allow
    # test errors
    # wrong value
    with pytest.raises(ValidationError) as exc_info:
        MaterialAllowables(Fsu="test")
    print(str(exc_info.value))
    assert str(exc_info.value)


def test_pin_class() -> None:
    """Test the Pin class"""
    iso = IsoElastic(E=110.0e3, nu=330e-3)

    allow = MaterialAllowables(Fsu=655.0)
    mat = Material(
        name="Ti-6Al-4V_ab_Annealead_Bar",
        specification="AIMS03-18-010",
        properties=iso,
        allowables=allow,
    )

    pin_allowables = {"Fsu": 6725.0, "Ftu": 6550.0}
    pin_allow = PinAllowables(**pin_allowables)

    pin = Pin(
        standard="prEN6115B",
        diameter=4.78,
        dash="3",
        material=mat,
        allowables=pin_allow,
        family="Bolt",
        head="Protruding",
    )

    # test pin data
    assert pin.standard == "prEN6115B"
    assert pin.diameter == 4.78
    assert pin.dash == "3"
    assert pin.family == "Bolt"
    assert pin.head == "Protruding"
    assert pin.oversized is False

    # test material and allowables
    assert mat == pin.material
    assert mat.allowables == pin.material.allowables
    assert mat.properties == pin.material.properties
    assert pin_allow == pin.allowables
    # test errors
    # missing material
    with pytest.raises(ValidationError) as exc_info:
        Pin(
            standard="prEN6115B",
            diameter=4.78,
            dash="3",
            allowables=pin_allow,
            family="Bolt",
            head="Protruding",
        )
    print(str(exc_info.value))
    assert str(exc_info.value)
    # wrong material type
    with pytest.raises(ValidationError) as exc_info:
        Pin(
            standard="prEN6115B",
            diameter=4.78,
            dash="3",
            material="test",
            allowables=pin_allow,
            family="Bolt",
            head="Protruding",
        )
    print(str(exc_info.value))
    assert str(exc_info.value)
    # wrong allowables typew
    with pytest.raises(ValidationError) as exc_info:
        Pin(
            standard="prEN6115B",
            diameter=4.78,
            dash="3",
            material=mat,
            allowables=NutAllowables(Ftu=7120.0),
            family="Bolt",
            head="Protruding",
        )
    print(str(exc_info.value))
    assert str(exc_info.value)


def test_nut_class() -> None:
    """Test the Nut class"""
    iso = IsoElastic(
        E=70.0e3,
        nu=330e-3,
    )

    allow = MaterialAllowables(Fsu=280.0)
    name = "7075-Clad_T6_Sheet"
    spec = "WL3.4374T6"
    mat = Material(name=name, specification=spec, properties=iso, allowables=allow)

    nut_allowables = {"Ftu": 7120.0}
    nut_allow = NutAllowables(**nut_allowables)

    nut = Nut(
        standard="ASNA2528",
        diameter=4.78,
        dash="3",
        material=mat,
        allowables=nut_allow,
    )
    # test nut data
    assert nut.standard == "ASNA2528"
    assert nut.diameter == 4.78
    assert nut.dash == "3"

    # test material and allowables
    assert mat == nut.material
    assert mat.allowables == nut.material.allowables
    assert mat.properties == nut.material.properties
    assert nut_allow == nut.allowables
    # test errors
    with pytest.raises(ValidationError) as exc_info:
        Nut(
            standard="ASNA2528",
            diameter=4.78,
            dash="3",
            material=mat,
        )
    print(str(exc_info.value))
    assert str(exc_info.value)
    with pytest.raises(ValidationError) as exc_info:
        Nut(
            standard="ASNA2528",
            diameter=4.78,
            dash="3",
            material="test",
            allowables=nut_allow,
        )
    print(str(exc_info.value))
    assert str(exc_info.value)
    pin_allow = PinAllowables(Fsu=6725.0, Ftu=6550.0)
    # test a pin allowable into a nutcollar
    with pytest.raises(ValidationError) as exc_info:
        Nut(
            standard="ASNA2528",
            diameter=4.78,
            dash="3",
            material=mat,
            allowables=pin_allow,
        )
    print(str(exc_info.value))
    assert str(exc_info.value)


def test_collar_class() -> None:
    """Test the Collar class"""
    iso = IsoElastic(
        E=70.0e3,
        nu=330e-3,
    )

    allow = MaterialAllowables(Fsu=235.0)
    name = "2024_T351_Plate"
    spec = "AIMS03-02-004"
    mat = Material(name=name, specification=spec, properties=iso, allowables=allow)

    col = Collar(
        standard="EN6054",
        diameter=5.56,
        dash="060",
        material=mat,
    )
    # test nut data
    assert col.standard == "EN6054"
    assert col.diameter == 5.56
    assert col.dash == "060"

    # test material and allowables
    assert mat == col.material
    assert mat.allowables == col.material.allowables
    assert mat.properties == col.material.properties

    pin_allow = PinAllowables(Fsu=6725.0, Ftu=6550.0)
    # test errors
    with pytest.raises(ValidationError) as exc_info:
        Collar(
            diameter=5.56,
            dash="060",
            material=mat,
        )
    print(str(exc_info.value))
    assert str(exc_info.value)
    # test a pin allowable into a material
    with pytest.raises(ValidationError) as exc_info:
        Collar(
            standard="EN6054",
            diameter=5.56,
            dash="060",
            material=pin_allow,
        )
    print(str(exc_info.value))
    assert str(exc_info.value)


def test_fastener_system():
    pin_mat = Material(
        name="Ti-6Al-4V_ab_Annealead_Bar",
        specification="AIMS03-18-010",
        properties=IsoElastic(E=110.0e3, nu=330e-3),
        allowables=MaterialAllowables(Fsu=655.0),
    )

    nut_mat = Material(
        name="7075-Clad_T6_Sheet",
        specification="WL3.4374T6",
        properties=IsoElastic(E=70.0e3, nu=330e-3),
        allowables=MaterialAllowables(Fsu=280.0),
    )

    pin = Pin(
        standard="prEN6115B",
        diameter=4.78,
        dash="3",
        material=pin_mat,
        allowables=PinAllowables(Fsu=6725.0, Ftu=6550.0),
        family="Bolt",
        head="Protruding",
    )

    nut = Nut(
        standard="ASNA2528",
        diameter=4.78,
        dash="3",
        material=nut_mat,
        allowables=NutAllowables(Ftu=7120.0),
    )
    fast_sys = FastenerSystem(pin=pin, nut_collar=nut)
    assert fast_sys.pin == pin
    assert fast_sys.nut_collar == nut
    # test errors
    with pytest.raises(ValidationError) as exc_info:
        FastenerSystem(nut_collar=nut)
    print(str(exc_info.value))
    assert str(exc_info.value)
    # test a pin allowable into a material
    with pytest.raises(ValidationError) as exc_info:
        FastenerSystem(pin=nut, nut_collar=pin)
    print(str(exc_info.value))
    assert str(exc_info.value)


if __name__ == "__main__":
    test_pin_class()
    test_nut_class()
    test_collar_class()
    test_pin_allowables()
    test_nut_allowables()
    test_material_allowables()
    test_fastener_system()
