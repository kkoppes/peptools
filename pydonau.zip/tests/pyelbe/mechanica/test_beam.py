import pytest
from makerspace_mbe_pylantir.pyelbe.mechanica.beam import Beam


@pytest.fixture
def my_test_beam():
    """
    here you make the beam
    """

    beam = Beam(elf=1.0, cl=560, moi=16760, ca=143.7)

    return beam


def test_beam(my_test_beam):
    """to beam or not to beam"""

    assert my_test_beam.effective_length_factor == 1.0
    assert my_test_beam.column_length == 560
    assert my_test_beam.effective_column_length == my_test_beam.effective_length_factor * my_test_beam.column_length
    assert my_test_beam.moment_of_inertia == 16760
    assert my_test_beam.column_area == 143.7


#    assert (beam.xxx is True)
