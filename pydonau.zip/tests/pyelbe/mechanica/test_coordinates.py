# test_coordinates.py
import pytest
import numpy as np
from makerspace_mbe_pylantir.pyelbe.mechanica.coordinates import (
    Coordinate2D,
    Coordinate3D,
)


def test_coordinates2D_distance():
    coord1 = Coordinate2D("coord1", 1.0, 2.0)
    coord2 = Coordinate2D("coord2", 4.0, 6.0)
    assert np.isclose(coord1.distance(coord2), 5.0)

    with pytest.raises(TypeError):
        coord1.distance(Coordinate3D("coord3", 1.0, 2.0, 3.0))


def test_coordinates3D_distance():
    coord1 = Coordinate3D("coord1", 1.0, 2.0, 3.0)
    coord2 = Coordinate3D("coord2", 4.0, 5.0, 6.0)
    assert np.isclose(coord1.distance(coord2), np.sqrt(27))

    with pytest.raises(TypeError):
        coord1.distance(Coordinate2D("coord3", 1.0, 2.0))
