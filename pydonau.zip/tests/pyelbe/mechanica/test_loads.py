import pytest
from makerspace_mbe_pylantir.pyelbe.mechanica.loads import Forces, Moments


def test_forces():
    forces = Forces("forces", 1.0, 2.0)
    assert forces.force_x == 1.0
    assert forces.force_y == 2.0
    assert getattr(forces, "force_z", None) is None

    forces = Forces("forces", 1.0, 2.0, 3.0)
    assert forces.force_x == 1.0
    assert forces.force_y == 2.0
    assert forces.force_z == 3.0


def test_moments():
    moments = Moments("moments", 1.0, 2.0)
    assert moments.moment_x == 1.0
    assert moments.moment_y == 2.0
    assert getattr(moments, "moment_z", None) is None

    moments = Moments("moments", 1.0, 2.0, 3.0)
    assert moments.moment_x == 1.0
    assert moments.moment_y == 2.0
    assert moments.moment_z == 3.0


def test_forces_from_list():
    name = "TestForces"
    forces_list = [1.0, 2.0, 3.0]
    forces = Forces.from_list(name, forces_list)

    assert forces.name == name
    assert forces.force_x == forces_list[0]
    assert forces.force_y == forces_list[1]
    assert forces.force_z == forces_list[2]


def test_forces_from_dict():
    name = "TestForces"
    forces_dict = {"force_x": 1.0, "force_y": 2.0, "force_z": 3.0}
    forces = Forces.from_dict(name, forces_dict)

    assert forces.name == name
    assert forces.force_x == forces_dict["force_x"]
    assert forces.force_y == forces_dict["force_y"]
    assert forces.force_z == forces_dict["force_z"]


def test_moments_from_list():
    name = "TestMoments"
    moments_list = [1.0, 2.0, 3.0]
    moments = Moments.from_list(name, moments_list)

    assert moments.name == name
    assert moments.moment_x == moments_list[0]
    assert moments.moment_y == moments_list[1]
    assert moments.moment_z == moments_list[2]


def test_moments_from_dict():
    name = "TestMoments"
    moments_dict = {"moment_x": 1.0, "moment_y": 2.0, "moment_z": 3.0}
    moments = Moments.from_dict(name, moments_dict)

    assert moments.name == name
    assert moments.moment_x == moments_dict["moment_x"]
    assert moments.moment_y == moments_dict["moment_y"]
    assert moments.moment_z == moments_dict["moment_z"]


def test_forces_post_init():
    name = "TestForces"
    forces = Forces(name, 1.0, 2.0, 3.0)

    assert forces.forces.force_x == 1.0
    assert forces.forces.force_y == 2.0
    assert forces.forces.force_z == 3.0

    forces = Forces(name, 1.0, 2.0)

    assert forces.forces.force_x == 1.0
    assert forces.forces.force_y == 2.0
    with pytest.raises(AttributeError):
        forces.forces.force_z is None


def test_moments_post_init():
    name = "TestMoments"
    moments = Moments(name, 1.0, 2.0, 3.0)

    assert moments.moment_tuple.moment_x == 1.0
    assert moments.moment_tuple.moment_y == 2.0
    assert moments.moment_tuple.moment_z == 3.0

    moments = Moments(name, 1.0, 2.0)

    assert moments.moment_tuple.moment_x == 1.0
    assert moments.moment_tuple.moment_y == 2.0

    with pytest.raises(AttributeError):
        moments.moment_tuple.moment_z is None
