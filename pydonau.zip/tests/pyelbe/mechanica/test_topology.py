#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 16 14:27:10 2023

@author: gi11883
"""
# TODO: complete with other tests

import pytest
from makerspace_mbe_pylantir.pyelbe.matreel import (
    Material,
    IsoElastic,
    MetallicMaterial,
    MetallicAllowables,
    Billet,
)
from makerspace_mbe_pylantir.pyelbe.mechanica import (
    Topology,
    Level,
    Plate,
    FastenerSystem,
    Pin,
    PinAllowables,
    Nut,
    NutAllowables,
    MaterialAllowables,
    Forces,
    Coordinate3D,
)

from makerspace_mbe_pylantir.pyelbe.mechanica.topology import (
    WrongType,
    WrongSize,
    MaximumSizeReached,
    LevelLocked,
    Link,
)


def create_fastener_system() -> FastenerSystem:
    pin_mat = Material(
        name="Ti-6Al-4V_ab_Annealead_Bar",
        specification="AIMS03-18-010",
        properties=IsoElastic(E=110.0e3, nu=330e-3),
        allowables=MaterialAllowables(Fsu=655.0),
    )

    nut_mat = Material(
        name="7075-Clad_T6_Sheet",
        specification="WL3.4374T6",
        properties=IsoElastic(E=70.0e3, nu=330e-3),
        allowables=MaterialAllowables(Fsu=280.0),
    )

    pin = Pin(
        standard="prEN6115B",
        diameter=4.78,
        dash="3",
        material=pin_mat,
        allowables=PinAllowables(Fsu=6725.0, Ftu=6550.0),
        family="Bolt",
        head="Protruding",
    )

    nut = Nut(
        standard="ASNA2528",
        diameter=4.78,
        dash="3",
        material=nut_mat,
        allowables=NutAllowables(Ftu=7120.0),
    )
    return FastenerSystem(pin=pin, nut_collar=nut)


def create_material_class() -> MetallicMaterial:
    E = 110.3e3
    G = 42.75e3
    nu = 310e-3

    iso = IsoElastic(
        E=E,
        G=G,
        nu=nu,
    )
    allowables = {
        "Fcy": 855.0,
        "Fty": 830.0,
        "Ftu": 900.0,
        "Fsu": 490.0,
        "b10": 1245.0,
        "e": 0.06,
        "n": 28.0,
        "nc": 28.0,
    }
    billet = Billet(nominal=20, minimum=12, maximum=40)
    basis = "A"
    orientation = "Fcy:L,Fty:L,Ftu:L,Fsu:ST,b10:L,e:ST,n:ST,nc:ST"
    allow = MetallicAllowables(**allowables, basis=basis, orientation=orientation)
    name = "Ti-6Al-4V_ab_Annealed_Plate"
    spec = "AIMS03-18-006"
    return MetallicMaterial(
        name=name, specification=spec, properties=iso, allowables=allow, billet=billet
    )


def test_topology():
    fast = create_fastener_system()
    plate = Plate.rectangular_plate(
        width=200, length=160, thickness=2.0, material=create_material_class()
    )
    topo = Topology(name="joint")
    topo.add_level(Level(name="fasteners", size=1))
    topo.add_level(Level(name="plates", size=5))
    assert topo[1].size == 1
    assert topo[2].size == 5

    topo[1].add_type(FastenerSystem)
    assert topo[1].types == set([FastenerSystem])
    topo[1].static()
    topo[1].append(fast)

    topo[2].add_type(Plate)
    assert topo[2].types == set([Plate])
    topo[2].static()
    topo[2].append(plate)


def test_topology_errors():
    fastener = create_fastener_system()
    plate = Plate.rectangular_plate(
        width=200, length=160, thickness=2.0, material=create_material_class()
    )
    topo = Topology(name="joint")

    with pytest.raises(WrongSize):
        topo.add_level(Level(name="fasteners", size=0))
    with pytest.raises(WrongSize):
        topo.add_level(Level(name="fasteners", size=-1))

    topo.add_level(Level(name="fasteners", size=1))
    topo.add_level(Level(name="plates", size=5))
    # check for null index
    with pytest.raises(IndexError):
        topo[0].add_type(FastenerSystem)
    # add a fastener type
    topo[1].add_type(FastenerSystem)
    # make the level static only the added types are allowed (in this case only FastenerSystem)
    topo[1].static()
    # check for wrong type
    with pytest.raises(WrongType):
        topo[1].append(plate)
    # add a fastener
    topo[1].append(fastener)
    # because the size of the first level is 1, only one FastenterSystem is allowed
    with pytest.raises(MaximumSizeReached):
        topo[1].append(fastener)

    topo[2].add_type(Plate)
    topo[2].static()
    with pytest.raises(WrongType):
        topo[2].append(fastener)
    topo[2].append(plate)
    topo[2].lock()
    with pytest.raises(LevelLocked):
        topo[2].append(plate)


def test_link_creation():
    link = Link(element1=("Level1", 1), element2=("Level2", 2))
    assert isinstance(link, Link)
    assert link.element1 == ("Level1", 1)
    assert link.element2 == ("Level2", 2)


def test_link_validation():
    with pytest.raises(TypeError):
        Link.validate("Not a link")

    link = Link(element1=("Level1", 1), element2=("Level2", 2))
    assert Link.validate(link) == link


def test_link_level2():
    link = Link(element1=("level1", "element1"), element2=("level2", "element2"))
    assert isinstance(link, Link)
    assert link.element1 == ("level1", "element1")
    assert link.element2 == ("level2", "element2")


def test_add_link():
    topology = Topology(name="TestTopology")
    level1 = Level(name="Level1", size=2)
    level1.append("element1")
    level1.append("element2")
    topology.add_level(level1)
    level2 = Level(name="Level2", size=2)
    level2.append("element3")
    level2.append("element4")
    topology.add_level(level2)

    topology.add_link("Level1", "element1", "Level2", "element3")

    assert len(topology.get_links()) == 1
    assert topology.get_links()[0].element1 == ("Level1", "element1")
    assert topology.get_links()[0].element2 == ("Level2", "element3")


def test_get_level_and_element_by_link():
    topology = Topology(name="TestTopology")
    level1 = Level(name="Level1", size=2)
    level1.append("element1")
    level1.append("element2")
    topology.add_level(level1)
    level2 = Level(name="Level2", size=2)
    level2.append("element3")
    level2.append("element4")
    topology.add_level(level2)

    link = Link(element1=("Level1", "element1"), element2=("Level2", "element3"))
    topology.add_link("Level1", "element1", "Level2", "element3")

    (
        level_1_from_link,
        element1,
        level_2_from_link,
        element2,
    ) = topology.get_level_and_element_by_link(link)
    assert level_1_from_link == level1
    assert element1 == "element1"
    assert level_2_from_link == level2
    assert element2 == "element3"


def test_multiple_links():
    topology = Topology(name="TestTopology")

    level1 = Level(name="Level1", size=3)
    level1.append("element1")
    level1.append("element2")
    level1.append("element5")
    topology.add_level(level1)

    level2 = Level(name="Level2", size=3)
    level2.append("element3")
    level2.append("element4")
    level2.append("element6")
    topology.add_level(level2)

    link1 = Link(element1=("Level1", "element1"), element2=("Level2", "element3"))
    link2 = Link(element1=("Level1", "element2"), element2=("Level2", "element4"))
    link3 = Link(element1=("Level1", "element5"), element2=("Level2", "element6"))

    topology.add_link("Level1", "element1", "Level2", "element3")
    topology.add_link("Level1", "element2", "Level2", "element4")
    topology.add_link("Level1", "element5", "Level2", "element6")

    # Check first link
    (
        level_1_from_link,
        element1,
        level_2_from_link,
        element2,
    ) = topology.get_level_and_element_by_link(link1)
    assert level_1_from_link == level1
    assert element1 == "element1"
    assert level_2_from_link == level2
    assert element2 == "element3"

    # Check second link
    (
        level_1_from_link,
        element1,
        level_2_from_link,
        element2,
    ) = topology.get_level_and_element_by_link(link2)
    assert level_1_from_link == level1
    assert element1 == "element2"
    assert level_2_from_link == level2
    assert element2 == "element4"

    # Check third link
    (
        level_1_from_link,
        element1,
        level_2_from_link,
        element2,
    ) = topology.get_level_and_element_by_link(link3)
    assert level_1_from_link == level1
    assert element1 == "element5"
    assert level_2_from_link == level2
    assert element2 == "element6"
