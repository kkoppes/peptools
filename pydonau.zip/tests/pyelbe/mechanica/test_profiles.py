import pytest

# from pydantic import ValidationError

# from makerspace_mbe_pylantir.pyelbe.mechanica.profiles.profiles import SubEl
from makerspace_mbe_pylantir.pyelbe.matreel import IsoElastic, Material
from makerspace_mbe_pylantir.pyelbe.mechanica.profiles.elm_factory import (
    create_subelm_plugin as new_subel,
)
from makerspace_mbe_pylantir.pyelbe.mechanica import Profile


# test class Profile
def test_profile_init():
    """test class initialization no errors shall occour"""
    name = "test"
    E = 110.0e3
    nu = 330e-3

    iso = IsoElastic(
        E=E,
        nu=nu,
    )

    # allowables = {
    #     "Fsu": float(662),
    #     "Ftu": float(580),
    # }

    name = "Ti-6Al-4V_ab_annealead"
    spec = "AIMS03-18-006"
    mat = Material(name=name, specification=spec, properties=iso)

    rect1_props = {
        "width": 9,
        "height": 1,
        "name": "rect1",
        "sub_type": "rect",
        "position": (1, 99),
        "material": mat,
    }

    rect2_props = {
        "width": 1,
        "height": 100,
        "name": "rect2",
        "sub_type": "rect",
        "position": (0, 0),
        "material": mat,
    }

    rect3_props = {
        "width": 9,
        "height": 1,
        "name": "rect3",
        "sub_type": "rect",
        "position": (-9, 0),
        "material": mat,
    }

    rect_1 = new_subel("rect", rect1_props)
    rect_2 = new_subel("rect", rect2_props)
    rect_3 = new_subel("rect", rect3_props)

    profile = Profile([rect_1, rect_2, rect_3])  # , name=name)
    # assert profile.name == name
    assert profile.subel_list == [rect_1, rect_2, rect_3]

    # assert calculated properties, checked with ISAMI IA1140_A350
    assert profile.area == 118
    assert profile.x_cg == 0.5
    assert profile.y_cg == 50

    assert round(profile.Ix, 0) == 127439
    assert round(profile.Iy) == 579
