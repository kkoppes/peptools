import pytest
from pydantic import ValidationError

# from makerspace_mbe_pylantir.pyelbe.mechanica.profiles.profiles import SubEl
from makerspace_mbe_pylantir.pyelbe.matreel import (
    IsoElastic,
    Material,
    MetallicAllowables,
)

import math
from math import pi
import numpy as np

from makerspace_mbe_pylantir.pyelbe.mechanica.profiles.utils import PointsCrossSection
from makerspace_mbe_pylantir.pyelbe.mechanica.plugins.subelms.subel import SubEl
from makerspace_mbe_pylantir.pyelbe.mechanica.plugins.subelms.arc import Arc
from makerspace_mbe_pylantir.pyelbe.mechanica.plugins.subelms.rect import Rectangle
from makerspace_mbe_pylantir.pyelbe.mechanica.plugins.subelms.qarc import QArc
from makerspace_mbe_pylantir.pyelbe.mechanica.plugins.subelms.fillet import Fillet
from makerspace_mbe_pylantir.pyelbe.mechanica.plugins.subelms.edge_points import (
    EdgePointElm,
)


# Arrange
@pytest.fixture
def dummy_material():
    E = 110.3e3
    G = 42.75e3
    nu = 310e-3

    iso = IsoElastic(
        E=E,
        G=G,
        nu=nu,
    )
    allowables = {
        "Fcy": 855.0,
        "Fty": 830.0,
        "Ftu": 900.0,
        "Fsu": 490.0,
        "b10": 1245.0,
        "e": 0.06,
        "n": 28.0,
        "nc": 28.0,
    }
    info = {
        "Fcy": "L",
        "Fty": "L",
        "Ftu": "L",
        "Fsu": "ST",
        "b10": "L",
        "e": "ST",
        "n": "ST",
        "nc": "ST",
    }
    allow = MetallicAllowables(**allowables, info=info)
    name = "Ti-6Al-4V_ab_Annealed_Plate"
    spec = "AIMS03-18-006"
    mat = Material(name=name, specification=spec, properties=iso, allowables=allow)

    return mat


def test_subelm_init(dummy_material):
    """Test the Profile __init__ method"""
    name = "test"
    sub_type = "implemented?"
    coords = (0, 0)
    with pytest.raises(ValueError) as exc_info:
        elm = SubEl(name=name, sub_type=sub_type, material=dummy_material)
    assert str(exc_info.value) == "Either position or pos_x and pos_y must be defined"

    elm = SubEl(name=name, sub_type=sub_type, position=coords, material=dummy_material)
    assert isinstance(elm, SubEl)
    assert elm.name == name
    assert elm.material == dummy_material


# Arc tests
def test_arc_creation(dummy_material):
    name = "test"
    sub_type = "arc"
    coords = (0, 0)
    with pytest.raises(ValueError) as exc_info:
        arc = Arc(outer_radius=1.0, inner_radius=0.5, angle=math.pi / 2)
    assert str(exc_info.value) == "Either position or pos_x and pos_y must be defined"

    arc = Arc(
        outer_radius=1.0,
        inner_radius=0.5,
        angle=math.pi / 2,
        name=name,
        sub_type=sub_type,
        position=coords,
        material=dummy_material,
    )
    assert isinstance(arc, Arc)
    # test arc points
    assert (
        len(arc.points) == 201
    )  # 100 points on outer and inner edges 1 to close the loop
    assert arc.points[0] == (1, 0)
    assert math.isclose(arc.points[99][0], 0, abs_tol=0.01)  # (0,1)
    assert math.isclose(arc.points[99][1], 1.0)
    assert math.isclose(arc.points[100][0], 0, abs_tol=0.01)  # (0,0.5)
    assert math.isclose(arc.points[100][1], 0.5)
    assert arc.points[199] == (0.5, 0.0)


@pytest.fixture
def dummy_arc_full_circle(dummy_material):
    name = "dummy_arc"
    sub_type = "arc"
    coords = (0, 0)

    arc = Arc(
        outer_radius=1.0,
        inner_radius=0,
        angle=math.pi * 2,
        name=name,
        sub_type=sub_type,
        position=coords,
        material=dummy_material,
    )
    return arc


@pytest.fixture
def dummy_arc(dummy_material):
    name = "dummy_arc"
    sub_type = "arc"
    coords = (0, 0)

    arc = Arc(
        outer_radius=1.0,
        inner_radius=0.5,
        angle=math.pi / 2,
        name=name,
        sub_type=sub_type,
        position=coords,
        material=dummy_material,
    )
    return arc


def test_arc_properties(dummy_arc):
    arc = dummy_arc

    assert isinstance(arc.get_properties(), dict)
    assert "area" in arc.get_properties().keys()
    assert "centroid" in arc.get_properties().keys()
    assert "inertia" in arc.get_properties().keys()
    assert isinstance(arc.area, float)
    assert isinstance(arc.centroid, tuple)
    assert isinstance(arc.inertia, tuple)


def test_arc_properties_values_circle(dummy_arc_full_circle):
    arc = dummy_arc_full_circle

    assert math.isclose(arc.area, 3.14, abs_tol=0.01)
    assert math.isclose(arc.centroid[0], 0.0, abs_tol=0.01)
    assert math.isclose(arc.centroid[1], 0.0, abs_tol=0.01)
    assert math.isclose(arc.inertia[0], math.pi / 4, abs_tol=0.01)
    assert math.isclose(arc.inertia[1], math.pi / 4, abs_tol=0.01)
    assert math.isclose(arc.inertia[2], 0, abs_tol=0.01)


def test_arc_properties_values(dummy_arc):
    arc = dummy_arc

    assert math.isclose(arc.area, 0.5875, abs_tol=0.05)
    assert math.isclose(arc.centroid[0], 0.5, abs_tol=0.05)
    assert math.isclose(arc.centroid[1], 0.5, abs_tol=0.05)
    assert math.isclose(arc.inertia[0], 0.04, abs_tol=0.05)
    assert math.isclose(arc.inertia[1], 0.04, abs_tol=0.05)
    assert math.isclose(arc.inertia[2], -0.03, abs_tol=0.05)


# Rectangle tests
def test_rectangle_creation(dummy_material):
    with pytest.raises(ValueError) as exc_info:
        rect = Rectangle(width=1.0, height=0.5)
    assert str(exc_info.value) == "Either position or pos_x and pos_y must be defined"

    name = "test"
    sub_type = "rect"
    coords = (0, 0)
    rect = Rectangle(
        width=1.0,
        height=0.5,
        name=name,
        sub_type=sub_type,
        position=coords,
        material=dummy_material,
    )

    assert isinstance(rect, Rectangle)


@pytest.fixture
def dummy_rect(dummy_material):
    name = "test"
    sub_type = "rect"
    coords = (0, 0)
    rect = Rectangle(
        width=1.0,
        height=0.5,
        name=name,
        sub_type=sub_type,
        position=coords,
        material=dummy_material,
    )
    return rect


def test_rectangle_points(dummy_rect):
    rect = dummy_rect
    assert len(rect.points) == 5  # 4 corners and 1 to close the loop
    assert rect.points == [
        (0, 0),
        (1, 0),
        (1, 0.5),
        (0, 0.5),
        (0, 0),
    ]


def test_rectangle_properties(dummy_rect):
    rect = dummy_rect
    assert isinstance(rect.get_properties(), dict)
    assert "area" in rect.get_properties().keys()
    assert "centroid" in rect.get_properties().keys()
    assert "inertia" in rect.get_properties().keys()
    assert isinstance(rect.area, float)
    assert isinstance(rect.centroid, tuple)
    assert isinstance(rect.inertia, tuple)


def test_rectangle_properties_values(dummy_rect):
    rect = dummy_rect
    assert math.isclose(rect.area, 0.5)
    assert math.isclose(rect.centroid[0], 0.5)
    assert math.isclose(rect.centroid[1], 0.25)
    assert math.isclose(rect.inertia[0], 0.04, abs_tol=0.05)
    assert math.isclose(rect.inertia[1], 0.01, abs_tol=0.05)
    assert math.isclose(rect.inertia[2], 0.0, abs_tol=0.05)


# QArc tests
def test_qarc_creation(dummy_material):
    name = "test"
    sub_type = "qarc"
    coords = (0, 0)

    qarc = QArc(
        outer_radius=1.0,
        inner_radius=0.5,
        quadrant=1,
        name=name,
        sub_type=sub_type,
        position=coords,
        material=dummy_material,
    )
    assert isinstance(qarc, QArc)
    # test arc points
    assert (
        len(qarc.points) == 201
    )  # 100 points on outer and inner edges 1 to close the loop
    assert qarc.points[0] == (1, 0)
    assert math.isclose(qarc.points[99][0], 0, abs_tol=0.01)  # (0,1)
    assert math.isclose(qarc.points[99][1], 1.0)
    assert math.isclose(qarc.points[100][0], 0, abs_tol=0.01)  # (0,0.5)
    assert math.isclose(qarc.points[100][1], 0.5)
    assert qarc.points[199] == (0.5, 0.0)


@pytest.fixture
def dummy_qarc(dummy_material):
    name = "dummy_arc"
    sub_type = "arc"
    coords = (0, 0)

    qarc = QArc(
        outer_radius=1.0,
        inner_radius=0.5,
        quadrant=1,
        name=name,
        sub_type=sub_type,
        position=coords,
        material=dummy_material,
    )
    return qarc


def test_qarc_properties(dummy_qarc):
    qarc = dummy_qarc

    assert isinstance(qarc.get_properties(), dict)
    assert "area" in qarc.get_properties().keys()
    assert "centroid" in qarc.get_properties().keys()
    assert "inertia" in qarc.get_properties().keys()
    assert isinstance(qarc.area, float)
    assert isinstance(qarc.centroid, tuple)
    assert isinstance(qarc.inertia, tuple)


def test_qarc_properties_values(dummy_qarc):
    qarc = dummy_qarc

    assert math.isclose(qarc.area, 0.5875, abs_tol=0.05)
    assert math.isclose(qarc.centroid[0], 0.5, abs_tol=0.05)
    assert math.isclose(qarc.centroid[1], 0.5, abs_tol=0.05)
    assert math.isclose(qarc.inertia[0], 0.04, abs_tol=0.05)
    assert math.isclose(qarc.inertia[1], 0.04, abs_tol=0.05)
    assert math.isclose(qarc.inertia[2], -0.03, abs_tol=0.05)


def test_qarc_properties_values_all_q(dummy_material):
    name = "qarc"
    sub_type = "qarc"
    coords = (0, 0)

    for q in [1, 2, 3, 4]:
        qarc = QArc(
            outer_radius=1.0,
            inner_radius=0.5,
            quadrant=q,
            name=name,
            sub_type=sub_type,
            position=coords,
            material=dummy_material,
        )
        if q == 1:
            assert math.isclose(qarc.centroid[0], 0.5, abs_tol=0.05)
            assert math.isclose(qarc.centroid[1], 0.5, abs_tol=0.05)
            assert math.isclose(qarc.inertia[2], -0.03, abs_tol=0.05)
        elif q == 2:
            assert math.isclose(qarc.centroid[0], -0.5, abs_tol=0.05)
            assert math.isclose(qarc.centroid[1], 0.5, abs_tol=0.05)
            assert math.isclose(qarc.inertia[2], 0.03, abs_tol=0.05)
        elif q == 3:
            assert math.isclose(qarc.centroid[0], -0.5, abs_tol=0.05)
            assert math.isclose(qarc.centroid[1], -0.5, abs_tol=0.05)
            assert math.isclose(qarc.inertia[2], -0.03, abs_tol=0.05)
        elif q == 4:
            assert math.isclose(qarc.centroid[0], 0.5, abs_tol=0.05)
            assert math.isclose(qarc.centroid[1], -0.5, abs_tol=0.05)
            assert math.isclose(qarc.inertia[2], 0.03, abs_tol=0.05)
        assert math.isclose(qarc.area, 0.5875, abs_tol=0.05)
        assert math.isclose(qarc.inertia[0], 0.04, abs_tol=0.05)
        assert math.isclose(qarc.inertia[1], 0.04, abs_tol=0.05)


def test_qarc_properties_values_all_angles(dummy_material):
    name = "qarc"
    sub_type = "qarc"
    coords = (0, 0)

    for b in [45, 135, 225, 315]:
        qarc = QArc(
            outer_radius=1.0,
            inner_radius=0.5,
            beta=b,
            name=name,
            sub_type=sub_type,
            position=coords,
            material=dummy_material,
        )
        if b == 45:
            assert math.isclose(qarc.centroid[0], 0.5, abs_tol=0.05)
            assert math.isclose(qarc.centroid[1], 0.5, abs_tol=0.05)
            assert math.isclose(qarc.inertia[2], -0.03, abs_tol=0.05)
        elif b == 135:
            assert math.isclose(qarc.centroid[0], -0.5, abs_tol=0.05)
            assert math.isclose(qarc.centroid[1], 0.5, abs_tol=0.05)
            assert math.isclose(qarc.inertia[2], 0.03, abs_tol=0.05)
        elif b == 225:
            assert math.isclose(qarc.centroid[0], -0.5, abs_tol=0.05)
            assert math.isclose(qarc.centroid[1], -0.5, abs_tol=0.05)
            assert math.isclose(qarc.inertia[2], -0.03, abs_tol=0.05)
        elif b == 315:
            assert math.isclose(qarc.centroid[0], 0.5, abs_tol=0.05)
            assert math.isclose(qarc.centroid[1], -0.5, abs_tol=0.05)
            assert math.isclose(qarc.inertia[2], 0.03, abs_tol=0.05)
        assert math.isclose(qarc.area, 0.5875, abs_tol=0.05)
        assert math.isclose(qarc.inertia[0], 0.04, abs_tol=0.05)
        assert math.isclose(qarc.inertia[1], 0.04, abs_tol=0.05)


# Fillet tests
def test_fillet_creation(dummy_material):
    name = "test"
    sub_type = "Fillet"
    coords = (0, 0)

    fil = Fillet(
        radius=1.0,
        quadrant=1,
        name=name,
        sub_type=sub_type,
        position=coords,
        material=dummy_material,
    )

    assert isinstance(fil, Fillet)
    # test arc points
    assert len(fil.points) == 18  # 17 points on fillet edges 1 to close the loop
    assert fil.points[0] == (0, 0)
    assert fil.points[1] == (1, 0)  # (0,1)
    assert math.isclose(fil.points[-2][0], 0)
    assert math.isclose(fil.points[-2][1], 1)

    assert isinstance(fil.get_properties(), dict)
    assert "area" in fil.get_properties().keys()
    assert "centroid" in fil.get_properties().keys()
    assert "inertia" in fil.get_properties().keys()
    assert isinstance(fil.area, float)
    assert isinstance(fil.centroid, tuple)
    assert isinstance(fil.inertia, tuple)

    # assert math.isclose(fillet.points[100][0], 0, abs_tol=0.01)  # (0,0.5)
    # assert math.isclose(fillet.points[100][1], 0.5)
    # assert fillet.points[199] == (0.5, 0.0)


# Fillet tests
def test_fillet_values_q(dummy_material):
    name = "test"
    sub_type = "Fillet"
    coords = (0, 0)

    for q in [1, 2, 3, 4]:
        fil = Fillet(
            radius=1.0,
            quadrant=q,
            name=name,
            sub_type=sub_type,
            position=coords,
            material=dummy_material,
        )

        if q == 1:
            assert math.isclose(fil.centroid[0], 0.22, abs_tol=0.05)
            assert math.isclose(fil.centroid[1], 0.22, abs_tol=0.05)
        elif q == 2:
            assert math.isclose(fil.centroid[0], -0.22, abs_tol=0.05)
            assert math.isclose(fil.centroid[1], 0.22, abs_tol=0.05)
        elif q == 3:
            assert math.isclose(fil.centroid[0], -0.22, abs_tol=0.05)
            assert math.isclose(fil.centroid[1], -0.22, abs_tol=0.05)
        elif q == 4:
            assert math.isclose(fil.centroid[0], 0.22, abs_tol=0.05)
            assert math.isclose(fil.centroid[1], -0.22, abs_tol=0.05)
        assert math.isclose(fil.inertia[2], 0.0, abs_tol=0.05)
        assert math.isclose(fil.area, 0.22, abs_tol=0.05)
        assert math.isclose(fil.inertia[0], 0.01, abs_tol=0.05)
        assert math.isclose(fil.inertia[1], 0.01, abs_tol=0.05)


# edge points tests
def test_epo_creation(dummy_material):
    name = "edge points"
    sub_type = "epe"
    coords = (0, 0)
    epe = EdgePointElm(
        points=[(-0.5, -0.25), (0.5, -0.25), (0.5, 0.25), (-0.5, 0.25)],
        name=name,
        sub_type=sub_type,
        position=coords,
        material=dummy_material,
    )

    assert isinstance(epe, EdgePointElm)

    assert len(epe.points) == 5  # 4 corners and 1 to close the loop
    assert epe.points == [
        (-0.5, -0.25),
        (0.5, -0.25),
        (0.5, 0.25),
        (-0.5, 0.25),
        (-0.5, -0.25),
    ]

    assert isinstance(epe.get_properties(), dict)
    assert "area" in epe.get_properties().keys()
    assert "centroid" in epe.get_properties().keys()
    assert "inertia" in epe.get_properties().keys()
    assert isinstance(epe.area, float)
    assert isinstance(epe.centroid, tuple)
    assert isinstance(epe.inertia, tuple)

    assert math.isclose(epe.area, 0.5)
    assert math.isclose(epe.centroid[0], 0.0)
    assert math.isclose(epe.centroid[1], 0.0)
    assert math.isclose(epe.inertia[0], 0.04, abs_tol=0.05)
    assert math.isclose(epe.inertia[1], 0.01, abs_tol=0.05)
    assert math.isclose(epe.inertia[2], 0.0, abs_tol=0.05)
