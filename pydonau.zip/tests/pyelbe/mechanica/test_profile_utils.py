from makerspace_mbe_pylantir.pyelbe.mechanica import Profile
from makerspace_mbe_pylantir.pyelbe.mechanica.profiles.utils import PointsCrossSection
from makerspace_mbe_pylantir.pyelbe.matreel import IsoElastic, Material

from pydantic import ValidationError
import pytest
import math
from math import pi
import numpy as np


def test_area():
    # Test rectangle
    # clockwise
    points = [(0, 0), (0, 1), (1, 1), (1, 0)]
    cross_section = PointsCrossSection(points)
    assert cross_section.area == 1.0
    # Counterclockwise
    points = [(0, 0), (1, 0), (1, 1), (0, 1)]
    cross_section = PointsCrossSection(points)
    assert cross_section.area == 1.0
    # Counterclockwise
    points = [(0, 0.25), (1, 0.25), (1, -0.25), (0, -0.25)]
    cross_section = PointsCrossSection(points)
    assert cross_section.area == 0.5

    # Test triangle
    points = [(0, 0), (1, 0), (0.5, 1)]
    cross_section = PointsCrossSection(points)
    assert cross_section.area == 0.5


def test_centroid():
    # Test rectangle
    points = [(0, 0), (0, 1), (1, 1), (1, 0)]
    cross_section = PointsCrossSection(points)
    assert cross_section.centroid == (0.5, 0.5)

    # Test triangle
    points = [(0, 0), (1, 0), (0.5, 1)]
    cross_section = PointsCrossSection(points)
    assert cross_section.centroid == (0.5, 1 / 3)

    # Counterclockwise
    points = [(0, 0.25), (1, 0.25), (1, -0.25), (0, -0.25)]
    cross_section = PointsCrossSection(points)
    assert cross_section.centroid == (0.5, 0.0)


def test_get_coordinates():
    # clockwise
    points = [(0, 0), (0, 1), (1, 1), (1, 0)]
    cross_section = PointsCrossSection(points)
    x, y = cross_section._get_coordinates()
    assert x == [1, 1, 0, 0, 1]
    assert y == [0, 1, 1, 0, 0]
    # Counterclockwise
    points = [(0, 0), (0, 1), (1, 1), (1, 0)]
    cross_section = PointsCrossSection(points)
    x, y = cross_section._get_coordinates()
    assert x == [1, 1, 0, 0, 1]
    assert y == [0, 1, 1, 0, 0]


def test_inertia_square():
    points = [(0, 0), (0, 2), (2, 2), (2, 0)]
    cross_section = PointsCrossSection(points)
    Ixx, Iyy, Ixy = cross_section.inertia
    assert math.isclose(Ixx, 1.333, rel_tol=1e-3)
    assert math.isclose(Iyy, 1.333, rel_tol=1e-3)
    assert math.isclose(Ixy, 0.0, abs_tol=1e-3)


def test_inertia_circle():
    num_points = 300
    radius = 1.0
    points = [
        (
            radius * math.cos(2 * math.pi / num_points * i),
            radius * math.sin(2 * math.pi / num_points * i),
        )
        for i in range(num_points)
    ]
    cross_section = PointsCrossSection(points)
    Ixx, Iyy, Ixy = cross_section.inertia
    assert math.isclose(Ixx, pi / 4, rel_tol=1e-2)
    assert math.isclose(Iyy, pi / 4, rel_tol=1e-2)
    assert math.isclose(Ixy, 0.0, abs_tol=1e-2)


def test_inertia_t_shape():
    points = [
        (0.5, 0),
        (0.5, 3),
        (2, 3),
        (2, 4),
        (-2, 4),
        (-2, 3),
        (-0.5, 3),
        (-0.5, 0),
    ]
    cross_section = PointsCrossSection(points)
    Ixx, Iyy, Ixy = cross_section.inertia
    assert math.isclose(Ixx, 9.44, rel_tol=1e-3)
    assert math.isclose(Iyy, 5.58, rel_tol=1e-3)
    assert math.isclose(Ixy, 0.0, abs_tol=1e-3)


def test_inertia_l_shape():
    points = [(0, 0), (0, 3), (1, 3), (1, 1), (3, 1), (3, 0)]
    cross_section = PointsCrossSection(points)
    Ixx, Iyy, Ixy = cross_section.inertia
    assert math.isclose(Ixx, 3.617, rel_tol=1e-3)
    assert math.isclose(Iyy, 3.617, rel_tol=1e-3)
    assert math.isclose(Ixy, -1.8, rel_tol=1e-3)


# TODO: test for principle axes
