import pytest
from makerspace_mbe_pylantir.pyelbe.mechanica.stress import Stresses


def test_stresses():
    stresses = Stresses("stresses", 1.0, 2.0, 3.0, 4.0, 5.0, 6.0)
    assert stresses.sigma_xx == 1.0
    assert stresses.sigma_yy == 2.0
    assert stresses.sigma_zz == 3.0
    assert stresses.tau_xy == 4.0
    assert stresses.tau_yz == 5.0
    assert stresses.tau_xz == 6.0


def test_stresses_from_list():
    name = "TestStresses"
    stresses_list = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
    stresses = Stresses.from_list(name, stresses_list)

    assert stresses.name == name
    assert stresses.sigma_xx == stresses_list[0]
    assert stresses.sigma_yy == stresses_list[1]
    assert stresses.sigma_zz == stresses_list[2]
    assert stresses.tau_xy == stresses_list[3]
    assert stresses.tau_yz == stresses_list[4]
    assert stresses.tau_xz == stresses_list[5]


def test_stresses_from_dict():
    name = "TestStresses"
    stresses_dict = {"sigma_xx": 1.0, "sigma_yy": 2.0, "sigma_zz": 3.0, "tau_xy": 4.0, "tau_yz": 5.0, "tau_xz": 6.0}
    stresses = Stresses.from_dict(name, stresses_dict)

    assert stresses.name == name
    assert stresses.sigma_xx == stresses_dict["sigma_xx"]
    assert stresses.sigma_yy == stresses_dict["sigma_yy"]
    assert stresses.sigma_zz == stresses_dict["sigma_zz"]
    assert stresses.tau_xy == stresses_dict["tau_xy"]
    assert stresses.tau_yz == stresses_dict["tau_yz"]
    assert stresses.tau_xz == stresses_dict["tau_xz"]
