#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 25 11:00:26 2023

@author: gi11883
"""

from copy import copy
import pytest
from pydantic import ValidationError
from makerspace_mbe_pylantir.pyelbe.matreel import MetallicMaterial, IsoElastic, MetallicAllowables, Billet
from makerspace_mbe_pylantir.pyelbe.morgul.esdu71005 import ESDU71005

tol_1pc = 0.01  # 1% tollerance

n_a = float("nan")  # not available


def rel_diff(ref: float, val: float) -> float:
    """Relative difference."""
    res = (val - ref) / ref
    return res


def test_edsu71005():
    """Test ESDU71005 calculation."""
    name = "ESDU71005_test"
    # ESDU Example
    a = 260.0  # length mm
    b = 200.0  # width mm
    t = 4.5  # thickness mm
    E = 73_000  # material Young's modulus
    nu = 0.34  # Poisson's ratio
    Fty = 383.5  # material yield stress MPa to have f_n = 340 MPa
    m = 16.0  # material Ramberg-Osgood exponent
    constraint = "short sides clamped"  # short sides are clamped, long sides are supported

    K = 8.08  # buckling coefficient from ESDU71005 Figure 1
    q_be = 308  # calculated elastic shear stress at which elastic plate would buckle MPa
    q_b = 198  # shear stress at which plate buckles MPa

    metal = MetallicMaterial(
        name=name,
        specification="",
        properties=IsoElastic(E=E, nu=nu),
        allowables=MetallicAllowables(Fty=Fty, n=m),
        billet=Billet(t),  # thickness 4.5mm
    )
    esdu71005 = ESDU71005(name=name, material=metal, b=b, a=a, t=t, constraint=constraint)
    esdu71005.calculation()
    esdu71005.set_default_formats()

    results = esdu71005.outputs
    results_formatted = results.formatted()

    # check the inputs
    assert esdu71005.name == name
    assert esdu71005.length == a
    assert esdu71005.width == b
    assert esdu71005.thickness == t

    # check the performed calculaiton
    assert rel_diff(K, results_formatted["K"]) <= tol_1pc
    assert rel_diff(q_be, results_formatted["q_be"]) <= tol_1pc
    assert rel_diff(q_b, results_formatted["q_b"]) <= tol_1pc

    # check the example_calculation method that performs the very same calculation
    example_document = ESDU71005.example_calculation()
    variables = example_document.get_variables()

    assert rel_diff(K, variables["K"]) <= tol_1pc
    assert rel_diff(q_be, variables["q_be"]) <= tol_1pc
    assert rel_diff(q_b, variables["q_b"]) <= tol_1pc

    # get method description
    document = esdu71005.method_description()
    assert str(document) == str(example_document)

    err_val_int = 0
    err_val_str = "this is an error"
    test_attributes = {
        "name": name,
        "material": metal,
        "a": a,
        "b": b,
        "t": t,
        "constraint": constraint,
    }
    wrong_attributes = {
        "name": [(err_val_int, "str")],
        "material": [(err_val_str, "Material")],
        "a": [(err_val_str, "float"), (0, "greater than 0")],
        "b": [(err_val_str, "float"), (0, "greater than 0"), (2 * a, "smaller than 'length'")],
        "t": [(err_val_str, "float"), (0, "greater than 0")],
        "constraint": [(err_val_int, "permitted"), (err_val_str, "permitted")],
    }

    # test ValidationError
    for wrong_attribute, errors in wrong_attributes.items():
        attributes = copy(test_attributes)
        for wrong_value, err_message in errors:
            attributes[wrong_attribute] = wrong_value
            with pytest.raises(ValidationError) as excinfo:
                ESDU71005(**attributes)
            assert excinfo.match(err_message)


# if __name__ == "__main__":
#     test_edsu71005()
