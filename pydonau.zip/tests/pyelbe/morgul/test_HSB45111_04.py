import pytest

from makerspace_mbe_pylantir.pyelbe import HSB45111_04
from makerspace_mbe_pylantir.pyelbe.mechanica.plates import Plate
from makerspace_mbe_pylantir.pydonau.isengard import Graph, GraphDataType

from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)


@pytest.fixture
def tmat_2024():
    mat = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-012",
        properties=IsoElastic(E=65500.0, Ec=66900.0, G=24900.0, nu=0.33),
        allowables=MetallicAllowables(
            Fcy=270.0,
            Fty=240.0,
            Fc1=0.0,
            Ft1=0.0,
            Ftu=405.0,
            Fsu=240.0,
            b10=0.0,
            e=0.15,
            n=23.0,
            nc=17.0,
        ),
        billet=Billet(nominal=1.6),
    )
    return mat


def test_instance_HSB_45111_04(tmat_2024):
    plate_width1 = 171.2
    plate_length1 = 125.8
    plate_th1 = 2.0

    plate_test = Plate.rectangular_plate(
        length=plate_length1,
        width=plate_width1,
        thickness=plate_th1,
        material=tmat_2024,
    )

    HSB_test = HSB45111_04(
        sigma_1=5.114044,
        sigma_2=-15.461929,
        sup_cond="simply_sup_all_edge",
        # 'simply_sup_loaded_edge_clamped_unloaded_edge'
        loading_side="on_b",  # 'on_a'
        struct=plate_test,
    )
    assert HSB_test
    assert HSB_test.b_a == pytest.approx(0.7348, 0.1)
    assert HSB_test.relation == pytest.approx(-0.3308, 0.1)
    assert HSB_test.calculation == pytest.approx(12.602, 0.1)
    assert HSB_test.sigma_cr == pytest.approx(192.555, 0.1)


def test_HSB_examples(tmat_2024):
    # case fig 1 left - force stress ratio to 1.0
    plate_thickness_1 = 2.5
    plate_width_1 = 160.0
    plate_length_1 = 120.0

    plate_1 = Plate.rectangular_plate(
        length=plate_length_1,
        width=plate_width_1,
        thickness=plate_thickness_1,
        material=tmat_2024,
    )

    example_1 = HSB45111_04(
        sigma_1=10.0,
        sigma_2=10.0,
        sup_cond="simply_sup_all_edge",
        loading_side="on_b",
        struct=plate_1,
    )
    # example 2 - case fig 1 left - revert sign for sigma 1 and 2
    plate_thickness_2 = 2.5
    plate_width_2 = 160.0
    plate_length_2 = 120.0

    plate_2 = Plate.rectangular_plate(
        length=plate_length_2,
        width=plate_width_2,
        thickness=plate_thickness_2,
        material=tmat_2024,
    )

    example_2 = HSB45111_04(
        sigma_1=-5.5,
        sigma_2=15.2,
        sup_cond="simply_sup_all_edge",
        loading_side="on_b",
        struct=plate_2,
    )
    # case fig 1 right - find edge cases
    plate_thickness_3 = 2.0
    plate_width_3 = 172.0
    plate_length_3 = 115.0

    plate_3 = Plate.rectangular_plate(
        length=plate_length_3,
        width=plate_width_3,
        thickness=plate_thickness_3,
        material=tmat_2024,
    )

    example_3 = HSB45111_04(
        sigma_1=6.1,
        sigma_2=-12.2,
        sup_cond="simply_sup_all_edge",
        loading_side="on_a",
        struct=plate_3,
    )
    # forced stress ratio to be -1.0
    plate_thickness_4 = 2.0
    plate_width_4 = 172.0
    plate_length_4 = 115.0

    plate_4 = Plate.rectangular_plate(
        length=plate_length_4,
        width=plate_width_4,
        thickness=plate_thickness_4,
        material=tmat_2024,
    )

    example_4 = HSB45111_04(
        sigma_1=-6.1,
        sigma_2=6.1,
        sup_cond="simply_sup_all_edge",
        loading_side="on_a",
        struct=plate_4,
    )
    # case fig 2 left - find edge cases
    plate_thickness_5 = 1.8
    plate_width_5 = 185.0
    plate_length_5 = 145.0

    plate_5 = Plate.rectangular_plate(
        length=plate_length_5,
        width=plate_width_5,
        thickness=plate_thickness_5,
        material=tmat_2024,
    )

    example_5 = HSB45111_04(
        sigma_1=7.3,
        sigma_2=-13.4,
        sup_cond="simply_sup_loaded_edge_clamped_unloaded_edge",
        loading_side="on_b",
        struct=plate_5,
    )
    # force stress ratio to be close to -1
    plate_thickness_6 = 1.8
    plate_width_6 = 185.0
    plate_length_6 = 145.0

    plate_6 = Plate.rectangular_plate(
        length=plate_length_6,
        width=plate_width_6,
        thickness=plate_thickness_6,
        material=tmat_2024,
    )

    example_6 = HSB45111_04(
        sigma_1=7.3,
        sigma_2=-7.4,
        sup_cond="simply_sup_loaded_edge_clamped_unloaded_edge",
        loading_side="on_b",
        struct=plate_6,
    )
    # case fig 2 right - find edge cases
    plate_thickness_7 = 2.2
    plate_width_7 = 165.0
    plate_length_7 = 117.0

    plate_7 = Plate.rectangular_plate(
        length=plate_length_7,
        width=plate_width_7,
        thickness=plate_thickness_7,
        material=tmat_2024,
    )

    example_7 = HSB45111_04(
        sigma_1=8.1,
        sigma_2=-14.6,
        sup_cond="simply_sup_loaded_edge_clamped_unloaded_edge",
        loading_side="on_a",
        struct=plate_7,
    )
    # force stress ratio to be close to 0
    plate_thickness_8 = 2.2
    plate_width_8 = 165.0
    plate_length_8 = 117.0

    plate_8 = Plate.rectangular_plate(
        length=plate_length_8,
        width=plate_width_8,
        thickness=plate_thickness_8,
        material=tmat_2024,
    )

    example_8 = HSB45111_04(
        sigma_1=0.1,
        sigma_2=-14.6,
        sup_cond="simply_sup_loaded_edge_clamped_unloaded_edge",
        loading_side="on_a",
        struct=plate_8,
    )

    example_expected = {
        "example_1": {
            "b/a ratio": 0.75,
            "stress ratio": 1.0,
            "bf": 4.578,
            "sigma_cr": 120.13,
        },
        "example_2": {
            "b/a ratio": 0.75,
            "stress ratio": -2.764,
            "bf": 25.0,
            "sigma_cr": 270.0,
        },
        "example_3": {
            "b/a ratio": 0.669,
            "stress ratio": -0.5,
            "bf": 6.699,
            "sigma_cr": 122.489,
        },
        "example_4": {
            "b/a ratio": 0.669,
            "stress ratio": -1.0,
            "bf": 10.969,
            "sigma_cr": 200.576,
        },
        "example_5": {
            "b/a ratio": 0.784,
            "stress ratio": -0.545,
            "bf": 28.801,
            "sigma_cr": 268.314,
        },
        "example_6": {
            "b/a ratio": 0.784,
            "stress ratio": -0.986,
            "bf": 40.818,
            "sigma_cr": 270.0,
        },
        "example_7": {
            "b/a ratio": 0.709,
            "stress ratio": -0.555,
            "bf": 15.357,
            "sigma_cr": 270.0,
        },
        "example_8": {
            "b/a ratio": 0.709,
            "stress ratio": -0.0069,
            "bf": 7.364,
            "sigma_cr": 157.408,
        },
    }

    # example 1
    assert example_expected["example_1"]["b/a ratio"] == pytest.approx(example_1.b_a, 0.01)
    assert example_expected["example_1"]["stress ratio"] == pytest.approx(example_1.relation, 0.01)
    assert example_expected["example_1"]["bf"] == pytest.approx(example_1.calculation, 0.01)
    assert example_expected["example_1"]["sigma_cr"] == pytest.approx(example_1.sigma_cr, 0.01)

    # example 2
    assert example_expected["example_2"]["b/a ratio"] == pytest.approx(example_2.b_a, 0.01)
    assert example_expected["example_2"]["stress ratio"] == pytest.approx(example_2.relation, 0.01)
    assert example_expected["example_2"]["bf"] == pytest.approx(example_2.calculation, 0.01)
    assert example_expected["example_2"]["sigma_cr"] == pytest.approx(example_2.sigma_cr, 0.01)

    # example 3
    assert example_expected["example_3"]["b/a ratio"] == pytest.approx(example_3.b_a, 0.01)
    assert example_expected["example_3"]["stress ratio"] == pytest.approx(example_3.relation, 0.01)
    assert example_expected["example_3"]["bf"] == pytest.approx(example_3.calculation, 0.01)
    assert example_expected["example_3"]["sigma_cr"] == pytest.approx(example_3.sigma_cr, 0.01)

    # example 4
    assert example_expected["example_4"]["b/a ratio"] == pytest.approx(example_4.b_a, 0.01)
    assert example_expected["example_4"]["stress ratio"] == pytest.approx(example_4.relation, 0.01)
    assert example_expected["example_4"]["bf"] == pytest.approx(example_4.calculation, 0.01)
    assert example_expected["example_4"]["sigma_cr"] == pytest.approx(example_4.sigma_cr, 0.01)

    # example 5
    assert example_expected["example_5"]["b/a ratio"] == pytest.approx(example_5.b_a, 0.01)
    assert example_expected["example_5"]["stress ratio"] == pytest.approx(example_5.relation, 0.01)
    assert example_expected["example_5"]["bf"] == pytest.approx(example_5.calculation, 0.01)
    assert example_expected["example_5"]["sigma_cr"] == pytest.approx(example_5.sigma_cr, 0.01)

    # example 6
    assert example_expected["example_6"]["b/a ratio"] == pytest.approx(example_6.b_a, 0.01)
    assert example_expected["example_6"]["stress ratio"] == pytest.approx(example_6.relation, 0.01)
    assert example_expected["example_6"]["bf"] == pytest.approx(example_6.calculation, 0.01)
    assert example_expected["example_6"]["sigma_cr"] == pytest.approx(example_6.sigma_cr, 0.01)

    # example 7
    assert example_expected["example_7"]["b/a ratio"] == pytest.approx(example_7.b_a, 0.01)
    assert example_expected["example_7"]["stress ratio"] == pytest.approx(example_7.relation, 0.01)
    assert example_expected["example_7"]["bf"] == pytest.approx(example_7.calculation, 0.01)
    assert example_expected["example_7"]["sigma_cr"] == pytest.approx(example_7.sigma_cr, 0.01)

    # example 8
    assert example_expected["example_8"]["b/a ratio"] == pytest.approx(example_8.b_a, 0.01)
    assert example_expected["example_8"]["stress ratio"] == pytest.approx(example_8.relation, 0.01)
    assert example_expected["example_8"]["bf"] == pytest.approx(example_8.calculation, 0.01)
    assert example_expected["example_8"]["sigma_cr"] == pytest.approx(example_8.sigma_cr, 0.01)
