import os
from decimal import DivisionByZero
from pathlib import Path

from typing import Any, Union
from makerspace_mbe_pylantir.pydonau.alchemy.alchemy import Ingredients, Solution

from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    IsoElastic,
    Billet,
)
from makerspace_mbe_pylantir.pyelbe.matreel.material import Material
from makerspace_mbe_pylantir.pyelbe.mechanica.fasteners import (
    PinAllowables,
    NutAllowables,
    Standard,
    Pin,
    Nut,
    FastenerSystem,
)
from makerspace_mbe_pylantir.scrolls import get_logger
from makerspace_mbe_pylantir.pyelbe.mechanica import Plate
from makerspace_mbe_pylantir.pyelbe.morgul.HSB_20210_01 import HSB20210_01

import pytest
import logging

logger = get_logger(__name__, level=logging.INFO)
logger_path = Path(__name__ + ".log")


@pytest.fixture(autouse=True)
def cleanup_files():
    """Remove the test files."""
    if logger_path.exists():
        os.remove(logger_path)


TOL_1PC = 0.01  # 1% tolerance

data_folder: Path = Path(__file__).parent / Path("data/HSB20210_01")


def rel_diff(ref: float, val: float) -> float:
    """Relative difference."""
    if ref == 0:
        raise DivisionByZero(f"Cannot calculate relative difference with {ref=}")
    res: float = (val - ref) / ref
    return res


@pytest.fixture
def baseline_input_scenario() -> dict[str, Any]:
    """Test HSB 20210_01 calculation."""
    # HSB20210_01 Example:
    # Plate definition:

    plate_mat = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-012",
        properties=IsoElastic(E=69000, nu=0.33),
        billet=Billet(2),
    )

    plate: Plate = Plate.rectangular_plate(
        name="Rectangular plate",
        width=210.0,
        length=300.0,
        thickness=1.2,
        material=plate_mat,
    )

    # Fastener definition:
    pin_material = MetallicMaterial(
        name="DAN5",
        specification="Ti",
        properties=IsoElastic(E=110000, nu=0.33),
        billet=Billet(2),
    )
    nut_material = MetallicMaterial(
        name="DAN11",
        specification="Al",
        properties=IsoElastic(E=70000, nu=0.33),
        billet=Billet(2),
    )

    pin_allowables = PinAllowables(
        Fsu=11950,
        Ftu=11120,
    )

    nut_allowables = NutAllowables(
        Ftu=7115,
    )

    pin_std = Standard(
        standard="DAN5",
        diameter=4.78,
        dash="6",
        material=pin_material,
        oversized=False,
    )

    nut_std = Standard(
        standard="DAN11",
        diameter=4.78,
        dash="6",
        material=nut_material,
        oversized=False,
    )

    nut = Nut(
        allowables=nut_allowables,
        standard=nut_std.standard,
        diameter=nut_std.diameter,
        dash=nut_std.dash,
        material=nut_std.material,
        oversized=nut_std.oversized,
    )

    pin = Pin(
        allowables=pin_allowables,
        condition="dry",
        installation="permanent",
        family="bolt",
        type="bolt",
        head="flush",
        head_name="flush medium head",
        standard=pin_std.standard,
        diameter=pin_std.diameter,
        dash=pin_std.dash,
        material=pin_std.material,
        oversized=pin_std.oversized,
    )

    fastener = FastenerSystem(pin=pin, nut_collar=nut)
    pin_material: Material = fastener.pin.material
    pin_allowables: PinAllowables = fastener.pin.allowables
    nut_allowables: Union[NutAllowables, None] = fastener.nut_collar.allowables

    shear_load = 8100.0
    tension_load = 4000.0
    bearing_allowable = 11190.0
    fastener_type = "Hi-Lok, screw (titanium, steel)"
    load_scenario = "Crash cases"

    model_scenario_baseline = {
        "fastener_type": fastener_type,
        "fastener": fastener,
        "plate": plate,
        "load_scenario": load_scenario,
        "f_s": shear_load,
        "f_t": tension_load,
        "f_br": bearing_allowable,
    }

    return model_scenario_baseline


@pytest.fixture
def NAS1097KE_input_scenario() -> dict[str, Any]:
    """Test HSB 20210_01 calculation."""
    # HSB20210_01 Example:
    # Plate definition:

    plate_mat = MetallicMaterial(
        name="7075_T6_Sheet",
        specification="WL3.4374T6",
        properties=IsoElastic(E=67500, nu=0.33),
        billet=Billet(3),
    )

    plate: Plate = Plate.rectangular_plate(
        name="Rectangular plate",
        width=200.0,
        length=300.0,
        thickness=4.0,
        material=plate_mat,
    )

    # Fastener definition:
    pin_material = MetallicMaterial(
        name="7050_T73511_Extruded",
        specification="AIMS03-05-029",
        properties=IsoElastic(E=70000, nu=0.33),
        billet=Billet(2),
    )

    pin_allowables = PinAllowables(
        Fsu=3790,
        Ftu=2215,
    )

    pin_std = Standard(
        standard="NAS1097KE",
        diameter=3.96,
        dash="5",
        material=pin_material,
        oversized=False,
    )

    pin_allowables = PinAllowables(
        Fsu=11950,
        Ftu=14150,
    )

    pin = Pin(
        allowables=pin_allowables,
        condition="dry",
        installation="permanent",
        family="rivet",
        type="solid rivet",
        head="flush",
        head_name="reduced flush head",
        standard=pin_std.standard,
        diameter=pin_std.diameter,
        dash=pin_std.dash,
        material=pin_std.material,
        oversized=pin_std.oversized,
    )
    """
    nut_material = MetallicMaterial(
        name="CRES",
        specification="ABS0741-C",
        properties=IsoElastic(E=210000, nu=0.33),
        billet=Billet(3),
    )
    nut_allowables = NutAllowables(
        Ftu=12400,
    )

    nut_std = Standard(
        standard="ASNA2531",
        diameter=4.78,
        dash="3",
        material=nut_material,
        oversized=False,
    )

    nut = Nut(
        allowables=nut_allowables,
        standard=nut_std.standard,
        diameter=nut_std.diameter,
        dash=nut_std.dash,
        material=nut_std.material,
        oversized=nut_std.oversized,
    )
    """
    fastener = FastenerSystem(pin=pin, nut_collar=None)
    pin_material: Material = fastener.pin.material
    pin_allowables: PinAllowables = fastener.pin.allowables

    shear_load = 2500.0
    tension_load = 850.0
    bearing_allowable = 3443.0
    fastener_type = "solid rivet"
    load_scenario = "Normal load cases"

    model_scenario_NAS1097KE: dict[str, Any] = {
        "fastener_type": fastener_type,
        "fastener": fastener,
        "plate": plate,
        "load_scenario": load_scenario,
        "f_s": shear_load,
        "f_t": tension_load,
        "f_br": bearing_allowable,
    }

    return model_scenario_NAS1097KE


@pytest.fixture
def prEN6115K_input_scenario() -> dict[str, Any]:
    """Test HSB 20210_01 calculation."""
    # HSB20210_01 Example:
    # Plate definition:

    plate_mat = MetallicMaterial(
        name="2024-Clad_T351_Sheet",
        specification="AIMS03-04-009_AIMS03-04-013",
        properties=IsoElastic(E=70300, nu=0.33),
        billet=Billet(12),
    )

    plate: Plate = Plate.rectangular_plate(
        name="Rectangular plate",
        width=210.0,
        length=300.0,
        thickness=2.0,
        material=plate_mat,
    )

    # Fastener definition:
    pin_material = MetallicMaterial(
        name="Ti6A4V",
        specification="ABS0114",
        properties=IsoElastic(E=110000, nu=0.33),
        billet=Billet(3),
    )
    nut_material = MetallicMaterial(
        name="CRES",
        specification="ABS0741-C",
        properties=IsoElastic(E=210000, nu=0.33),
        billet=Billet(3),
    )

    pin_allowables = PinAllowables(
        Fsu=11950,
        Ftu=14150,
    )

    nut_allowables = NutAllowables(
        Ftu=12400,
    )

    pin_std = Standard(
        standard="prEN6115K",
        diameter=4.78,
        dash="3",
        material=pin_material,
        oversized=False,
    )

    nut_std = Standard(
        standard="ASNA2531",
        diameter=4.78,
        dash="3",
        material=nut_material,
        oversized=False,
    )

    nut = Nut(
        allowables=nut_allowables,
        standard=nut_std.standard,
        diameter=nut_std.diameter,
        dash=nut_std.dash,
        material=nut_std.material,
        oversized=nut_std.oversized,
    )

    pin = Pin(
        allowables=pin_allowables,
        condition="dry",
        installation="permanent",
        family="bolt",
        type="shear bolt",
        head="protuding",
        head_name="protusion tension head",
        standard=pin_std.standard,
        diameter=pin_std.diameter,
        dash=pin_std.dash,
        material=pin_std.material,
        oversized=pin_std.oversized,
    )

    fastener = FastenerSystem(pin=pin, nut_collar=nut)
    pin_material: Material = fastener.pin.material
    pin_allowables: PinAllowables = fastener.pin.allowables
    nut_allowables: Union[NutAllowables, None] = fastener.nut_collar.allowables

    shear_load = 8100.0
    tension_load = 4000.0
    bearing_allowable = 8365.0
    fastener_type = "Hi-Lok, screw (titanium, steel)"
    load_scenario = "Crash cases"

    model_scenario_en6115k: dict[str, Any] = {
        "fastener_type": fastener_type,
        "fastener": fastener,
        "plate": plate,
        "load_scenario": load_scenario,
        "f_s": shear_load,
        "f_t": tension_load,
        "f_br": bearing_allowable,
    }

    return model_scenario_en6115k


def test_HSB20210_01_baseline(baseline_input_scenario: dict[str, Any]) -> None:
    hsb20210_01 = HSB20210_01(**baseline_input_scenario)
    outputs: Solution = hsb20210_01.calculation
    hsb20210_01.set_default_formats()

    inputs: Ingredients = hsb20210_01.input
    inputs.formatted()
    outputs_formatted = outputs.formatted()

    assert hsb20210_01.curve_type == "Curve A"

    RF = 1.22
    assert rel_diff(RF, outputs_formatted["RF"]) <= TOL_1PC

    hsb20210_01.reference
    hsb20210_01.example_calculation
    hsb20210_01.method_description


def test_HSB20210_01_NAS1097KE(NAS1097KE_input_scenario: dict[str, Any]) -> None:
    hsb20210_01 = HSB20210_01(**NAS1097KE_input_scenario)
    outputs: Solution = hsb20210_01.calculation
    hsb20210_01.set_default_formats()

    inputs: Ingredients = hsb20210_01.input
    inputs.formatted()
    outputs_formatted = outputs.formatted()

    assert hsb20210_01.k_factor == 0.5
    assert hsb20210_01.curve_type == "Curve D"

    RF = 1.462
    assert rel_diff(RF, outputs_formatted["RF"]) <= TOL_1PC

    hsb20210_01.reference
    hsb20210_01.example_calculation
    hsb20210_01.method_description


def test_HSB20210_01_EN6115K(prEN6115K_input_scenario: dict[str, Any]) -> None:
    hsb20210_01 = HSB20210_01(**prEN6115K_input_scenario)
    outputs: Solution = hsb20210_01.calculation
    hsb20210_01.set_default_formats()

    inputs: Ingredients = hsb20210_01.input
    inputs.formatted()
    outputs_formatted = outputs.formatted()

    assert hsb20210_01.k_factor == 1.0
    assert hsb20210_01.curve_type == "Curve A"

    RF = 0.9865
    assert rel_diff(RF, outputs_formatted["RF"]) <= TOL_1PC

    hsb20210_01.reference
    hsb20210_01.example_calculation
    hsb20210_01.method_description
