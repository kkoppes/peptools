import os
from pathlib import Path
from decimal import DivisionByZero
from typing import Any
from makerspace_mbe_pylantir.pydonau.alchemy.alchemy import Solution
from makerspace_mbe_pylantir.pyelbe.morgul.TH3_902 import TH3_902
from makerspace_mbe_pylantir.scrolls import get_logger
import logging
from makerspace_mbe_pylantir.pyelbe.mechanica import Plate
import pytest

logger = get_logger(__name__, level=logging.INFO)


# from makerspace_mbe_pylantir.pyweser.isamilib import TMaterial
from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    IsoElastic,
    Billet,
)

TOL_1PC = 0.01  # 1% tolerance

logger_path = Path(__name__ + ".log")


@pytest.fixture(autouse=True)
def cleanup_files():
    """Remove the test files."""
    if logger_path.exists():
        os.remove(logger_path)


def rel_diff(ref: float, val: float) -> float:
    """Relative difference."""
    if ref == 0:
        raise DivisionByZero(f"Cannot calculate relative difference with {ref=}")
    res: float = (val - ref) / ref
    return res


""" Constraint scenarios:
1- all sides simply supported
2- long sides clamped
3- short sides clamped
4- one long side clamped
5- one short side clamped
6- all sides simply supported

"""
PLATE_NAME = "Rectangular plate with hole"
GEO_PARAMS: dict[str, float] = {
    "a": 300.0,
    "b": 210.0,
    "t": 1.2,
}
MAT_PARAMS: dict[str, Any] = {
    "name": "Al2024",
    "E": 69000,
    "nu": 0.3,
}
metal = MetallicMaterial(
    name=MAT_PARAMS["name"],
    specification="",
    properties=IsoElastic(
        E=MAT_PARAMS["E"],
        nu=MAT_PARAMS["nu"],
    ),
    billet=Billet(GEO_PARAMS["t"]),
)
CONSTRAINTS: dict[int, str] = {
    1: "all sides simply supported",
    2: "one short side clamped",
    3: "short sides clamped",
    4: "one long side clamped",
    5: "long sides clamped",
    6: "all sides clamped",
}


plate: Plate = Plate.rectangular_plate(
    name=PLATE_NAME,
    length=GEO_PARAMS["a"],
    width=GEO_PARAMS["b"],
    thickness=GEO_PARAMS["t"],
    material=metal,
)


@pytest.fixture
def input_scenario_1() -> dict[str, Any]:
    """Test TH3_902 calculation."""

    model_scenario: dict[str, Any] = {
        "analysis_name": "Input scenario 1",
        "plate": plate,
        "constraint": CONSTRAINTS[1],
    }

    return model_scenario


@pytest.fixture
def input_scenario_2() -> dict[str, Any]:
    """Test TH3_902 calculation."""

    model_scenario: dict[str, Any] = {
        "analysis_name": "Input scenario 2",
        "plate": plate,
        "constraint": CONSTRAINTS[2],
    }

    return model_scenario


@pytest.fixture
def input_scenario_3() -> dict[str, Any]:
    """Test TH3_902 calculation."""

    model_scenario: dict[str, Any] = {
        "analysis_name": "Input scenario 3",
        "plate": plate,
        "constraint": CONSTRAINTS[3],
    }

    return model_scenario


@pytest.fixture
def input_scenario_4() -> dict[str, Any]:
    """Test TH3_902 calculation."""

    model_scenario: dict[str, Any] = {
        "analysis_name": "Input scenario 4",
        "plate": plate,
        "constraint": CONSTRAINTS[4],
    }

    return model_scenario


@pytest.fixture
def input_scenario_5() -> dict[str, Any]:
    """Test TH3_902 calculation."""

    model_scenario: dict[str, Any] = {
        "analysis_name": "Input scenario 5",
        "plate": plate,
        "constraint": CONSTRAINTS[5],
    }

    return model_scenario


@pytest.fixture
def input_scenario_6() -> dict[str, Any]:
    """Test TH3_902 calculation."""

    model_scenario: dict[str, Any] = {
        "analysis_name": "Input scenario 6",
        "plate": plate,
        "constraint": CONSTRAINTS[6],
    }

    return model_scenario


def test_input_scenario_1(input_scenario_1: dict[str, Any]) -> None:
    th3_902 = TH3_902(input_scenario_1)
    th3_902.calculation

    inputs, outputs = (th3_902.input, th3_902.outputs)
    inputs.formatted()
    outputs_formatted = outputs.formatted()

    th3_902.set_default_formats()

    assert th3_902.name == "Input scenario 1"
    assert th3_902.plate_length == 300
    assert th3_902.plate_width == 210
    th3_902.outputs

    K = 6.6
    assert rel_diff(K, outputs_formatted["K"]) <= TOL_1PC

    th3_902.reference
    th3_902.example_calculation
    th3_902.method_description


def test_input_scenario_2(input_scenario_2: dict[str, Any]) -> None:
    analysis_model = TH3_902(input_scenario_2)
    analysis_model.calculation
    solution: Solution = analysis_model.outputs

    K = 7.0
    assert rel_diff(K, solution["K"]) <= TOL_1PC


def test_input_scenario_3(input_scenario_3: dict[str, Any]) -> None:
    analysis_model = TH3_902(input_scenario_3)
    analysis_model.calculation
    solution: Solution = analysis_model.outputs

    K = 7.4
    assert rel_diff(K, solution["K"]) <= TOL_1PC


def test_input_scenario_4(input_scenario_4: dict[str, Any]) -> None:
    analysis_model = TH3_902(input_scenario_4)
    analysis_model.calculation
    solution: Solution = analysis_model.outputs

    K = 8.4
    assert rel_diff(K, solution["K"]) <= TOL_1PC


def test_input_scenario_5(input_scenario_5: dict[str, Any]) -> None:
    analysis_model = TH3_902(input_scenario_5)
    analysis_model.calculation
    solution: Solution = analysis_model.outputs

    K = 9.9
    assert rel_diff(K, solution["K"]) <= TOL_1PC


def test_input_scenario_6(input_scenario_6: dict[str, Any]) -> None:
    analysis_model = TH3_902(input_scenario_6)
    analysis_model.calculation
    solution: Solution = analysis_model.outputs

    K = 10.6
    assert rel_diff(K, solution["K"]) <= TOL_1PC
