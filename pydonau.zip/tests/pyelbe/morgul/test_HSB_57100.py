import pytest
from makerspace_mbe_pylantir.pyelbe.morgul.HSB_57100 import (
    HSB_57100_01,
)
from makerspace_mbe_pylantir.pyelbe.mechanica.angle import Angle

from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)


@pytest.fixture
def T42_wrong_Fty_1():
    mat = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-012",
        properties=IsoElastic(E=69000.0, Ec=206900.0, G=26200.0, nu=0.33),
        allowables=MetallicAllowables(
            Fcy=960.0,  # Rc0.2
            Fty=385.0,  # Rp0.2
            Fc1=0.0,
            Ft1=0.0,
            Ftu=430.0,
            Fsu=255.0,
            b10=0.0,
            e=0.15,
            n=22.0,
            nc=22.0,
        ),
        billet=Billet(nominal=20.0),
    )
    return mat


@pytest.fixture
def T42_wrong_Fty_2():
    mat = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-012",
        properties=IsoElastic(E=69000.0, Ec=206900.0, G=26200.0, nu=0.33),
        allowables=MetallicAllowables(
            Fcy=960.0,  # Rc0.2
            Fty=400.0,  # Rp0.2
            Fc1=0.0,
            Ft1=0.0,
            Ftu=430.0,
            Fsu=255.0,
            b10=0.0,
            e=0.15,
            n=22.0,
            nc=22.0,
        ),
        billet=Billet(nominal=20.0),
    )
    return mat


@pytest.fixture
def T42_wrong_Fty_3():
    mat = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-012",
        properties=IsoElastic(E=69000.0, Ec=206900.0, G=26200.0, nu=0.33),
        allowables=MetallicAllowables(
            Fcy=960.0,  # Rc0.2
            Fty=270.0,  # Rp0.2
            Fc1=0.0,
            Ft1=0.0,
            Ftu=430.0,
            Fsu=255.0,
            b10=0.0,
            e=0.15,
            n=22.0,
            nc=22.0,
        ),
        billet=Billet(nominal=20.0),
    )
    return mat


@pytest.fixture
def specific_angle1():  # pitch < 25mm
    """
    angle_length = l
    flange_width = b
    eccentricity = e
    fastener_pitch = p
    thickness = t
    """

    angle = Angle(le=20, b=1, e=20, p=1, t=2.0)

    return angle


@pytest.fixture
def specific_angle2():  # pitch > 25mm
    """
    angle_length = l
    flange_width = b
    eccentricity = e
    fastener_pitch = p
    thickness = t
    """

    angle = Angle(le=100, b=1, e=20, p=30, t=2.0)

    return angle


@pytest.fixture
def specific_angle3():  # pitch = 20mm
    """
    angle_length = l
    flange_width = b
    eccentricity = e
    fastener_pitch = p
    thickness = t
    """

    angle = Angle(le=100, b=1, e=20, p=20, t=2.0)

    return angle


@pytest.fixture
def specific_angle4():  # pitch = 40mm
    """
    angle_length = l
    flange_width = b
    eccentricity = e
    fastener_pitch = p
    thickness = t
    """

    angle = Angle(le=100, b=1, e=20, p=40, t=2.0)

    return angle


def test_HSB_57100_01(
    T42_wrong_Fty_1,
    T42_wrong_Fty_2,
    T42_wrong_Fty_3,
    specific_angle1,
    specific_angle2,
    specific_angle3,
    specific_angle4,
):
    """
    example from HSB method 57100-01, issue I from 2020

    Args:
        T42: material
        specific_angle: angle

    Returns:
        calculated values
    """

    material1 = T42_wrong_Fty_1
    material2 = T42_wrong_Fty_2
    material3 = T42_wrong_Fty_3

    angle1 = specific_angle1
    angle2 = specific_angle2
    angle3 = specific_angle3
    angle4 = specific_angle4

    # example 1
    tensile_failure_load = HSB_57100_01(mat=material1, struct=angle1, nof=3)
    assert tensile_failure_load.single_flange_sheet == pytest.approx(1078, 0.001)
    assert tensile_failure_load.double_flange_sheet == pytest.approx(2695, 0.001)

    assert isinstance(tensile_failure_load.single_flange_sheet_eq, str)
    assert isinstance(tensile_failure_load.double_flange_sheet_eq, str)
    assert isinstance(tensile_failure_load.single_flange_extrusion_eq, str)
    assert isinstance(tensile_failure_load.t_section_extrusion_eq, str)

    # with pytest.raises(ValueError, match="Method not validated for n<6"):
    #     buckling_strength = HSB_41100_01(mat=material, struct=a_beam)

    tensile_failure_load = HSB_57100_01(mat=material2, struct=angle2, nof=3)
    assert tensile_failure_load.single_flange_extrusion == pytest.approx(1208, 0.001)
    assert tensile_failure_load.t_section_extrusion == pytest.approx(3624, 0.001)

    # example 2
    # case A
    tensile_failure_load = HSB_57100_01(mat=material3, struct=angle3, nof=5)
    assert tensile_failure_load.single_flange_sheet == pytest.approx(3780, 0.001)

    # case B
    tensile_failure_load = HSB_57100_01(mat=material3, struct=angle4, nof=3)
    assert tensile_failure_load.single_flange_sheet == pytest.approx(2835, 0.001)
