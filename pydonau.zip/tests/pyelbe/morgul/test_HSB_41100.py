import pytest
from makerspace_mbe_pylantir.pyelbe.morgul.HSB_41100 import (
    HSB_41100_01,
)
from makerspace_mbe_pylantir.pyelbe.mechanica.beam import Beam

from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)


@pytest.fixture
def T42():
    mat = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-012",
        properties=IsoElastic(E=69000.0, Ec=206900.0, G=26200.0, nu=0.33),
        allowables=MetallicAllowables(
            Fcy=960.0,
            Fty=260.0,
            Fc1=0.0,
            Ft1=0.0,
            Ftu=430.0,
            Fsu=255.0,
            b10=0.0,
            e=0.15,
            n=22.0,
            nc=22.0,
        ),
        billet=Billet(nominal=20.0),
    )
    return mat


@pytest.fixture
def T42_wrong_nc():
    mat = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-012",
        properties=IsoElastic(E=69000.0, Ec=206900.0, G=26200.0, nu=0.33),
        allowables=MetallicAllowables(
            Fcy=960.0,
            Fty=260.0,
            Fc1=0.0,
            Ft1=0.0,
            Ftu=430.0,
            Fsu=255.0,
            b10=0.0,
            e=0.15,
            n=22.0,
            nc=5.9,
        ),
        billet=Billet(nominal=20.0),
    )
    return mat


@pytest.fixture
def specific_beam():
    """
    column_length: length of column
    column_area: area of column
    moment_of_inertia: moment of inertia of column
    effective_length_factor: factor based on Fig. 1 of HSB, choose from (0.5, 0.7, 1.0, 2.0)
    both sides fixed = 0.5
    one side fixed, one simple supported = 0.7
    one side fixed, the other supported in length or two sides simple supported = 1.0
    one side fixed, one free = 2.0
    """

    beam = Beam(elf=1.0, cl=560, moi=16760, ca=143.7)

    return beam


# def test_create_instance(T42, T42_wrong_nc, specific_beam):
def test_HSB_41100_01(T42, T42_wrong_nc, specific_beam):
    """
    example from HSB method 41100-01, issue F from 2010

    Args:
        T42: material
        specific_beam: beam

    Returns:
        calculated values
    """

    material = T42
    a_beam = specific_beam

    buckling_strength = HSB_41100_01(mat=material, struct=a_beam)

    assert buckling_strength.min_radius_of_gyration == pytest.approx(10.80, 0.001)
    assert isinstance(buckling_strength.min_radius_of_gyration_eq, str)
    # assert (buckling_strength.sigma_cr == 759.45392017035)
    # assert (buckling_strength.sigma_cr_corrected == pytest.approx(736, 0.003))
    assert buckling_strength.sigma_c07 == pytest.approx(959.8, 0.001)
    assert isinstance(buckling_strength.sigma_c07_eq, str)
    assert buckling_strength.f1_n == pytest.approx(0.06801, 0.001)
    assert isinstance(buckling_strength.f1_n_eq, str)
    assert buckling_strength.f2_n == pytest.approx(1.1472, 0.001)
    assert isinstance(buckling_strength.f2_n_eq, str)
    assert buckling_strength.f3_n == pytest.approx(1.0094, 0.001)
    assert isinstance(buckling_strength.f3_n_eq, str)
    assert buckling_strength.s_0 == pytest.approx(1.0510, 0.001)
    assert isinstance(buckling_strength.s_0_eq, str)
    assert buckling_strength.sigma_0 == pytest.approx(1008, 0.001)
    assert isinstance(buckling_strength.sigma_0_eq, str)
    assert buckling_strength.x == pytest.approx(1.1526, 0.001)
    assert isinstance(buckling_strength.x_eq, str)
    assert buckling_strength.s_i == pytest.approx(0.9161, 0.001)
    assert isinstance(buckling_strength.s_i_eq, str)
    assert buckling_strength.r_i == pytest.approx(0.6612, 0.001)
    assert isinstance(buckling_strength.r_i_eq, str)
    assert buckling_strength.x_i == pytest.approx(0.6779, 0.001)
    assert isinstance(buckling_strength.x_i_eq, str)
    assert buckling_strength.y_i == pytest.approx(0.8716, 0.001)
    assert isinstance(buckling_strength.y_i_eq, str)
    assert buckling_strength.y == pytest.approx(0.73, 0.003)
    assert isinstance(buckling_strength.y_eq, str)
    assert isinstance(buckling_strength.y_final_eq, str)
    assert buckling_strength.s_crit == pytest.approx(736, 0.003)
    assert isinstance(buckling_strength.s_crit_eq, str)
    assert buckling_strength.f_crit == pytest.approx(105800, 0.003)
    assert isinstance(buckling_strength.f_crit_eq, str)

    material = T42_wrong_nc

    with pytest.raises(ValueError, match="Method not validated for n<6"):
        buckling_strength = HSB_41100_01(mat=material, struct=a_beam)
