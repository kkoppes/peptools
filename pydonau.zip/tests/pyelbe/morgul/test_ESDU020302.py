import os
from pathlib import Path
from decimal import DivisionByZero
from typing import Any
import pytest
from makerspace_mbe_pylantir.pydonau.alchemy.opera import Opus
from makerspace_mbe_pylantir.pyelbe.mechanica.plates import Plate
from makerspace_mbe_pylantir.pyelbe.morgul.esdu020302 import ESDU020302
from makerspace_mbe_pylantir.scrolls import get_logger
import logging
import pdb

logger = get_logger(__name__, level=logging.INFO)
logger_path = Path(__name__ + ".log")


@pytest.fixture(autouse=True)
def cleanup_files():
    """Remove the test files."""
    if logger_path.exists():
        os.remove(logger_path)


# from makerspace_mbe_pylantir.pyweser.isamilib import TMaterial
from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    IsoElastic,
    Billet,
)
import pytest

TOL_1PC = 0.01  # 1% tolerance


def rel_diff(ref: float, val: float) -> float:
    """Relative difference."""
    if ref == 0:
        raise DivisionByZero(f"Cannot calculate relative difference with {ref=}")
    res: float = (val - ref) / ref
    return res


@pytest.fixture
def baseline_input_scenario_long_edges_clamped() -> dict[str, Any]:
    """Test ESDU 02.03.02 calculation."""

    NAME = "Long edges clamped scenario"
    GEO_PARAMS: dict[str, float] = {
        "a": 300.0,
        "b": 210.0,
        "t": 3.1,
    }
    MAT_PARAMS: dict[str, float] = {
        "E": 69000,
        "nu": 0.3,
    }
    metal = MetallicMaterial(
        name="metal plate",
        specification="",
        properties=IsoElastic(
            E=MAT_PARAMS["E"],
            nu=MAT_PARAMS["nu"],
        ),
        billet=Billet(GEO_PARAMS["t"]),
    )

    moi = 1950  # stiffener's second moment of inertia
    constraint = "long sides clamped"

    plate: Plate = Plate.rectangular_plate(
        length=GEO_PARAMS["a"],
        width=GEO_PARAMS["b"],
        thickness=GEO_PARAMS["t"],
        material=metal,
    )

    model_scenario_supported: dict[str, Any] = {
        "name": NAME,
        "plate": plate,
        "moi": moi,
        "constraint": constraint,
    }

    return model_scenario_supported


@pytest.fixture
def baseline_input_scenario_long_edges_supported() -> dict[str, Any]:
    """Test ESDU 02.03.02 calculation."""

    NAME = "Long sides simply supported scenario"
    GEO_PARAMS: dict[str, float] = {
        "a": 300.0,
        "b": 210.0,
        "t": 1.2,
    }
    MAT_PARAMS: dict[str, float] = {
        "E": 69000,
        "nu": 0.3,
    }
    metal = MetallicMaterial(
        name="metal plate",
        specification="",
        properties=IsoElastic(
            E=MAT_PARAMS["E"],
            nu=MAT_PARAMS["nu"],
        ),
        billet=Billet(GEO_PARAMS["t"]),
    )

    moi = 1950  # stiffener's second moment of inertia
    constraint = "long sides simply supported"

    plate: Plate = Plate.rectangular_plate(
        length=GEO_PARAMS["a"],
        width=GEO_PARAMS["b"],
        thickness=GEO_PARAMS["t"],
        material=metal,
    )

    model_scenario_supported: dict[str, Any] = {
        "name": NAME,
        "plate": plate,
        "moi": moi,
        "constraint": constraint,
    }

    return model_scenario_supported


def test_ESDU020302_long_edges_clamped(baseline_input_scenario_long_edges_clamped: dict[str, Any]) -> None:
    # pdb.set_trace()
    esdu020302 = ESDU020302(**baseline_input_scenario_long_edges_clamped)

    inputs, outputs = (esdu020302.input, esdu020302.outputs)
    inputs.formatted()
    outputs_formatted = outputs.formatted()

    esdu020302.set_default_formats()

    assert esdu020302.name == "Long edges clamped scenario"
    assert esdu020302.length == 300
    assert esdu020302.width == 210

    esdu020302.outputs
    assert pytest.approx(outputs_formatted["K"], TOL_1PC) == 8.8

    esdu020302.reference()
    method_description: Opus = esdu020302.method_description
    sample_calc: Opus = esdu020302.example_calculation

    assert isinstance(method_description, Opus)
    assert isinstance(sample_calc, Opus)


def test_ESDU020302_long_edges_supported(baseline_input_scenario_long_edges_supported: dict[str, Any]) -> None:
    esdu020302 = ESDU020302(**baseline_input_scenario_long_edges_supported)

    inputs, outputs = (esdu020302.input, esdu020302.outputs)
    inputs.formatted()
    outputs_formatted = outputs.formatted()

    assert esdu020302.width == 210
    esdu020302.outputs

    assert pytest.approx(outputs_formatted["K"], TOL_1PC) == 99
