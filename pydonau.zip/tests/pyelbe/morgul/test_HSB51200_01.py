import json
from pathlib import Path
from typing import Any
from dataclasses import dataclass
from makerspace_mbe_pylantir.pyelbe.morgul.HSB_51200_01 import HSB51200_01

# from makerspace_mbe_pylantir.scrolls import get_logger
# import logging
# logger = get_logger(__name__, level=logging.INFO)

import pytest

TOL_1PC = 0.01  # 1% tolerance


@dataclass
class SharedVariables:
    expected_rf: float


shared_vars = SharedVariables(0)


def rel_diff(ref: float, val: float) -> float:
    """Relative difference."""
    res: float = (val - ref) / ref
    res: float = (val - ref) / ref
    return res


@pytest.fixture
def interaction_curve_scenario() -> dict[str, Any]:
    """Test HSB 51200_01 RF calculation with interaction curves."""

    DATA_FOLDER: Path = Path(__file__).parent / Path("data/HSB51200_01")
    with open(DATA_FOLDER / "test_scenarios.json") as file_data:
        test_scenarios: dict[str, Any] = json.load(file_data)

    # Select here the scenario for the test.
    # Interaction curve scenarios range from 1 to 6
    # i.e. "test_scenario_1", "test_scenario_2", ... to "test_scenario_6"
    selected_scenario = "test_scenario_3"
    test_scenario: dict[str, Any] = {}

    test_scenario.update({"interaction_data": test_scenarios["test_scenario_3"]})

    test_scenario.update({"scenario": test_scenarios[selected_scenario]["scenario"]})
    test_scenario.update(
        {"applied_load": test_scenarios[selected_scenario]["applied_load"]}
    )
    test_scenario.update(
        {"allowable_load": test_scenarios[selected_scenario]["allowable_load"]}
    )
    test_scenario.update(
        {
            "additional input parameters": test_scenarios[selected_scenario][
                "additional input parameters"
            ]
        }
    )
    test_scenario.update({"results": test_scenarios[selected_scenario]["results"]})

    d_a: float = 0
    t: float = 0

    additional_params: dict[str, Any] = test_scenario["additional input parameters"]
    results: dict[str, float] = test_scenario["results"]

    if "d_a" in additional_params:
        d_a = additional_params["d_a"]

    if "t" in additional_params:
        t = additional_params["t"]

    shared_vars.expected_rf = results["RF"]

    model_interaction_curve_scenario: dict[str, Any] = {
        "scenario": test_scenario["scenario"],
        "applied_load": test_scenario["applied_load"],
        "allowable_load": test_scenario["allowable_load"],
        "d_a": d_a,
        "t": t,
    }

    return model_interaction_curve_scenario


@pytest.fixture
def iterative_scenario() -> dict[str, Any]:
    """Test HSB 51200_01 RF calculation with iterative process."""

    DATA_FOLDER: Path = Path(__file__).parent / Path("data/HSB51200_01")
    with open(DATA_FOLDER / "test_scenarios.json") as file_data:
        test_scenarios = json.load(file_data)

    # Select here the scenario for the test.
    # Iterative scenarios are:
    # "test_scenario_7", "test_scenario_9", ... to "test_scenario_12"
    selected_scenario = "test_scenario_9"
    test_scenario: dict[str, Any] = {}
    test_scenario: dict[str, Any] = {}

    test_scenario.update({"interaction_data": test_scenarios})

    test_scenario.update({"scenario": test_scenarios[selected_scenario]["scenario"]})
    test_scenario.update(
        {"applied_load": test_scenarios[selected_scenario]["applied_load"]}
    )
    test_scenario.update(
        {"allowable_load": test_scenarios[selected_scenario]["allowable_load"]}
    )
    test_scenario.update(
        {
            "additional input parameters": test_scenarios[selected_scenario][
                "additional input parameters"
            ]
        }
    )
    test_scenario.update({"results": test_scenarios[selected_scenario]["results"]})

    d_a: float = 0
    t: float = 0

    additional_params: dict[str, Any] = test_scenario["additional input parameters"]
    results: dict[str, float] = test_scenario["results"]
    additional_params: dict[str, Any] = test_scenario["additional input parameters"]
    results: dict[str, float] = test_scenario["results"]

    if "d_a" in additional_params:
        d_a = additional_params["d_a"]

    if "t" in additional_params:
        t = additional_params["t"]

    shared_vars.expected_rf = results["RF"]

    model_iterative_scenario: dict[str, Any] = {
        "scenario": test_scenario["scenario"],
        "applied_load": test_scenario["applied_load"],
        "allowable_load": test_scenario["allowable_load"],
        "d_a": d_a,
        "t": t,
    }

    return model_iterative_scenario


@pytest.fixture
def rf_frma_scenario() -> dict[str, Any]:
    """Test HSB 51200_01 RF calculation with iterative process."""

    DATA_FOLDER = Path(__file__).parent / Path("data/HSB51200_01")
    with open(DATA_FOLDER / "test_scenarios.json") as file_data:
        test_scenarios = json.load(file_data)

    # Select here the scenario for the test.
    # RF frma scenarios are:
    # "test_scenario_8, 10, 11, 13, 14 and 15"
    selected_scenario = "test_scenario_13"
    test_scenario: dict[str, Any] = {}

    test_scenario.update({"scenario": test_scenarios[selected_scenario]["scenario"]})
    test_scenario.update(
        {"applied_load": test_scenarios[selected_scenario]["applied_load"]}
    )
    test_scenario.update(
        {"allowable_load": test_scenarios[selected_scenario]["allowable_load"]}
    )
    test_scenario.update(
        {
            "additional input parameters": test_scenarios[selected_scenario][
                "additional input parameters"
            ]
        }
    )
    test_scenario.update({"results": test_scenarios[selected_scenario]["results"]})

    d_a: float = 0
    t: float = 0

    additional_params: dict[str, Any] = test_scenario["additional input parameters"]
    results: dict[str, float] = test_scenario["results"]

    if "d_a" in additional_params:
        d_a = additional_params["d_a"]

    if "t" in additional_params:
        t = additional_params["t"]

    shared_vars.expected_rf = results["RF"]

    model_RF_frma_scenario: dict[str, Any] = {
        "scenario": test_scenario["scenario"],
        "applied_load": test_scenario["applied_load"],
        "allowable_load": test_scenario["allowable_load"],
        "d_a": d_a,
        "t": t,
    }

    return model_RF_frma_scenario


def test_HSB51200_01_interaction_curve(
    interaction_curve_scenario: dict[str, Any]
) -> None:
    hsb51200_01 = HSB51200_01(**interaction_curve_scenario)
    hsb51200_01.calculation

    hsb51200_01.set_default_formats()

    inputs, outputs = (hsb51200_01.input, hsb51200_01.outputs)

    inputs.formatted()
    outputs.formatted()

    hsb51200_01.outputs

    rf: float = hsb51200_01.outputs["rf"]
    assert rel_diff(rf, shared_vars.expected_rf) <= TOL_1PC

    hsb51200_01.reference
    hsb51200_01.example_calculation
    hsb51200_01.method_description


def test_HSB51200_01_iteration(iterative_scenario: dict[str, Any]) -> None:
    hsb51200_01 = HSB51200_01(**iterative_scenario)
    hsb51200_01.calculation

    hsb51200_01.set_default_formats()

    inputs, outputs = (hsb51200_01.input, hsb51200_01.outputs)

    inputs.formatted()
    outputs.formatted()

    hsb51200_01.outputs

    rf: float = hsb51200_01.outputs["rf"]
    assert rel_diff(rf, shared_vars.expected_rf) <= TOL_1PC

    hsb51200_01.reference
    hsb51200_01.example_calculation
    hsb51200_01.method_description


def test_HSB51200_01_RF_frma(rf_frma_scenario: dict[str, Any]) -> None:
    hsb51200_01 = HSB51200_01(**rf_frma_scenario)
    hsb51200_01.calculation

    hsb51200_01.set_default_formats()

    inputs, outputs = (hsb51200_01.input, hsb51200_01.outputs)

    inputs.formatted()
    outputs.formatted()

    hsb51200_01.outputs

    rf: float = hsb51200_01.outputs["rf"]
    assert rel_diff(rf, shared_vars.expected_rf) <= TOL_1PC

    hsb51200_01.reference
    hsb51200_01.example_calculation
    hsb51200_01.method_description
