import pytest
from makerspace_mbe_pylantir.pyelbe.morgul.stress_strain import StressStrain

from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)


@pytest.fixture
def Ti_6Al():
    mat = MetallicMaterial(
        name="Ti-6Al-4V_b_Annealed_Plate",
        specification="AIMS03-18-007",
        properties=IsoElastic(E=110000.0, Ec=113000.0, G=41000.0, nu=0.34),
        allowables=MetallicAllowables(
            Fcy=770.0,
            Fty=795.0,
            Fc1=0.0,
            Ft1=0.0,
            Ftu=825.0,
            Fsu=485.0,
            b10=0.0,
            e=0.025,
            n=20.0,
            nc=28.0,
        ),
        billet=Billet(nominal=20.0),
    )
    return mat


def test_create_instance(Ti_6Al):
    material = Ti_6Al

    stress_strain = StressStrain(mat=material)

    assert stress_strain
    # ellipse
    # tension
    stress = stress_strain.calculate_stress(theory="ellipse", mode="tens", strain=0.0)
    assert stress == 0

    stress = stress_strain.calculate_stress(theory="ellipse", mode="tens", strain=0.001)
    assert stress == 110

    stress = stress_strain.calculate_stress(theory="ellipse", mode="tens", strain=0.005)
    assert stress == pytest.approx(549.862, 0.001)

    # ellipse
    # compression
    stress = stress_strain.calculate_stress(theory="ellipse", mode="comp", strain=0.0)
    assert stress == 0

    stress = stress_strain.calculate_stress(theory="ellipse", mode="comp", strain=0.001)
    assert stress == 113

    stress = stress_strain.calculate_stress(theory="ellipse", mode="comp", strain=0.005)
    assert stress == pytest.approx(564.961, 0.001)

    # ro_ext
    # tension
    stress = stress_strain.calculate_stress(theory="roext", mode="tens", strain=0.0)
    assert stress == 0

    stress = stress_strain.calculate_stress(theory="roext", mode="tens", strain=0.001)
    assert stress == 110

    stress = stress_strain.calculate_stress(theory="roext", mode="tens", strain=0.005)
    assert stress == pytest.approx(549.862, 0.001)

    # ro_ext
    # compression
    stress = stress_strain.calculate_stress(theory="roext", mode="comp", strain=0.0)
    assert stress == 0

    stress = stress_strain.calculate_stress(theory="roext", mode="comp", strain=0.001)
    assert stress == 113

    stress = stress_strain.calculate_stress(theory="roext", mode="comp", strain=0.005)
    assert stress == pytest.approx(564.961, 0.001)

    # ramberg-osgood values
    assert isinstance(stress_strain.n, float)
    assert isinstance(stress_strain.rp02, float)
    assert isinstance(stress_strain.rc02, float)
