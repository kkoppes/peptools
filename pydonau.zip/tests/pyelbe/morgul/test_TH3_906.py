#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 10 12:00:26 2023

@author: da17779
"""
import os
from pathlib import Path
from decimal import DivisionByZero
from typing import Any
import pytest
from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    IsoElastic,
    Billet,
)

from makerspace_mbe_pylantir.pyelbe.mechanica import Plate
from makerspace_mbe_pylantir.scrolls import get_logger
from makerspace_mbe_pylantir.pyelbe.morgul.TH3_906 import TH3_906
import logging

logger = get_logger(__name__, level=logging.INFO)

pytest_dir: str = os.getcwd()

TOL_1PC = 0.01  # 1% tolerance
ERR_VAL = "this is an error"

logger_path = Path(__name__ + ".log")


@pytest.fixture(autouse=True)
def cleanup_files():
    """Remove the test files."""
    if logger_path.exists():
        os.remove(logger_path)


def rel_diff(ref: float, val: float) -> float:
    """Relative difference."""
    if ref == 0:
        raise DivisionByZero(f"Cannot calculate relative difference with {ref=}")
    res: float = (val - ref) / ref
    return res


# ------------------------------
# ┏┳┓┏┓┏┓┏┳┓  ┏┓┏┓┏┓┳┓┏┓┳┓┳┏┓┏┓
#  ┃ ┣ ┗┓ ┃   ┗┓┃ ┣ ┃┃┣┫┣┫┃┃┃┗┓
#  ┻ ┗┛┗┛ ┻   ┗┛┗┛┗┛┛┗┛┗┛┗┻┗┛┗┛


@pytest.fixture
def E021RP2100205_Buckling_C60_C61_A__test_inputs() -> dict[str, Any]:
    test_inputs: dict[str, Any] = {
        "analysis_name": "Shear buckling analysis - Shear Plate at C60-C61 A",
        "constraint": "all sides simply supported",
        "geometry": {
            "A": 172,
            "B": 147,
            "t": 1.6,
            "hole_diameter": 84,
            "slot_corner_radius": 30,
            "slot_length": 110,
            "slot_width": 84,
            "number_of_holes": 1,
            "stiffener_height": 4.6,
            "stiffener_width": 1.6,
            "hole_area": 0,
        },
        "material_parameters": {
            "E": 65500,
            "nu": 0.33,
            "basis": "B",
            "t_billet": 1,
        },
        "expected_outputs": {
            "K": 7.42,
            "q_b": 27.6,
        },
    }

    return test_inputs


@pytest.fixture
def E021RP2100205_Buckling_C60_C61_B__test_inputs() -> dict[str, Any]:
    test_inputs: dict[str, Any] = {
        "analysis_name": "Shear buckling analysis - Shear Plate at C60-C61 B",
        "constraint": "all sides simply supported",
        "geometry": {
            "A": 177,
            "B": 143.5,
            "t": 1.6,
            "hole_diameter": 84.0,
            "slot_corner_radius": 42,
            "slot_length": 84,
            "slot_width": 84,
            "number_of_holes": 1,
            "stiffener_height": 7.6,
            "stiffener_width": 1.6,
            "hole_area": 0,
        },
        "material_parameters": {
            "E": 65500,
            "nu": 0.33,
            "basis": "B",
            "t_billet": 1,
        },
        "expected_outputs": {
            "K": 7.16,
            "q_b": 37.59,
        },
    }

    return test_inputs


@pytest.fixture
def E021RP2100205_Buckling_C61_C62_A__test_inputs() -> dict[str, Any]:
    test_inputs: dict[str, Any] = {
        "analysis_name": "Shear buckling analysis - Shear Plate at C61-C62 A",
        "constraint": "all sides simply supported",
        "geometry": {
            "A": 177,
            "B": 143.5,
            "t": 1.6,
            "hole_diameter": 84.0,
            "slot_corner_radius": 42,
            "slot_length": 84,
            "slot_width": 84,
            "number_of_holes": 1,
            "stiffener_height": 7.6,
            "stiffener_width": 1.6,
            "hole_area": 0,
        },
        "material_parameters": {
            "E": 65500,
            "nu": 0.33,
            "basis": "B",
            "t_billet": 1,
        },
        "expected_outputs": {
            "K": 7.16,
            "q_b": 37.59,
        },
    }

    return test_inputs


@pytest.fixture
def E021RP2100205_Buckling_C61_C62_B__test_inputs() -> dict[str, Any]:
    test_inputs: dict[str, Any] = {
        "analysis_name": "Shear buckling analysis - Shear Plate at C61-C62 B",
        "constraint": "all sides simply supported",
        "geometry": {
            "A": 252,
            "B": 129.5,
            "t": 1.6,
            "hole_diameter": 84.0,
            "slot_corner_radius": 42,
            "slot_length": 181,
            "slot_width": 84,
            "number_of_holes": 1,
            "stiffener_height": 7.6,
            "stiffener_width": 1.6,
            "hole_area": 0,
        },
        "material_parameters": {
            "E": 65500,
            "nu": 0.33,
            "basis": "B",
            "t_billet": 1,
        },
        "expected_outputs": {
            "K": 7.16,
            "q_b": 37.59,
        },
    }

    return test_inputs


def prepare_scenario_inputs(test_parameters: dict[str, Any]) -> dict[str, Any]:
    analysis_name: str = test_parameters["analysis_name"]
    constraint: str = test_parameters["constraint"]
    geometry: dict[str, float] = test_parameters["geometry"]
    material_parameters: dict[str, float] = test_parameters["material_parameters"]
    expected_outputs: dict[str, float] = test_parameters["expected_outputs"]

    metal = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-010",
        properties=IsoElastic(
            E=material_parameters["E"],
            nu=material_parameters["nu"],
        ),
        billet=Billet(material_parameters["t_billet"]),
        # basis=material_parameters["basis"],
    )

    plate: Plate = Plate.rectangular_plate(
        length=geometry["A"],
        width=geometry["B"],
        thickness=geometry["t"],
        material=metal,
    )

    model_scenario_parameters_for_Buckling_C60_C61_A: dict[str, Any] = {
        "inputs_params": {
            "analysis_name": analysis_name,
            "plate": plate,
            "constraint": constraint,
            "plate_length": geometry["A"],
            "plate_width": geometry["B"],
            "thickness": geometry["t"],
            "modulus_of_elasticity": material_parameters["E"],
            "hole_diameter": geometry["hole_diameter"],
            "slot_corner_radius": geometry["slot_corner_radius"],
            "slot_length": geometry["slot_length"],
            "slot_width": geometry["slot_width"],
            "number_of_holes": geometry["number_of_holes"],
            "hole_area": geometry["hole_area"],
            "stiffener_width": geometry["stiffener_width"],
            "stiffener_height": geometry["stiffener_height"],
        },
        "expected_outputs": {
            "K": expected_outputs["K"],
            "q_b": expected_outputs["q_b"],
        },
    }

    return model_scenario_parameters_for_Buckling_C60_C61_A


# ------------------------------
#         ┏┳┓┏┓┏┓┏┳┓┏┓
#          ┃ ┣ ┗┓ ┃ ┗┓
#          ┻ ┗┛┗┛ ┻ ┗┛


def test_th3_906_ShearPlate_C60_C61(
    E021RP2100205_Buckling_C60_C61_A__test_inputs: dict[str, Any]
) -> None:
    """Test TH3.906 calculation."""
    test_parameters: dict[str, Any] = prepare_scenario_inputs(
        E021RP2100205_Buckling_C60_C61_A__test_inputs
    )
    inputs_params: dict[str, Any] = test_parameters["inputs_params"]
    expected_outputs: dict[str, Any] = test_parameters["expected_outputs"]

    perform_test(inputs_params, expected_outputs)


def test_th3_906_ShearPlate_C60_C61_B(
    E021RP2100205_Buckling_C60_C61_B__test_inputs: dict[str, Any]
) -> None:
    """Test TH3.906 calculation."""
    test_parameters: dict[str, Any] = prepare_scenario_inputs(
        E021RP2100205_Buckling_C60_C61_B__test_inputs
    )
    inputs_params: dict[str, Any] = test_parameters["inputs_params"]
    expected_outputs: dict[str, Any] = test_parameters["expected_outputs"]

    perform_test(inputs_params, expected_outputs)


def test_th3_906_ShearPlate_C61_C62_A(
    E021RP2100205_Buckling_C61_C62_A__test_inputs: dict[str, Any]
) -> None:
    """Test TH3.906 calculation."""
    test_parameters: dict[str, Any] = prepare_scenario_inputs(
        E021RP2100205_Buckling_C61_C62_A__test_inputs
    )
    inputs_params: dict[str, Any] = test_parameters["inputs_params"]
    expected_outputs: dict[str, Any] = test_parameters["expected_outputs"]

    perform_test(inputs_params, expected_outputs)


def test_th3_906_ShearPlate_C61_C62_B(
    E021RP2100205_Buckling_C61_C62_B__test_inputs: dict[str, Any]
) -> None:
    """Test TH3.906 calculation."""
    test_parameters: dict[str, Any] = prepare_scenario_inputs(
        E021RP2100205_Buckling_C61_C62_B__test_inputs
    )
    inputs_params: dict[str, Any] = test_parameters["inputs_params"]
    expected_outputs: dict[str, Any] = test_parameters["expected_outputs"]

    perform_test(inputs_params, expected_outputs)


def perform_test(
    inputs_params: dict[str, Any], expected_outputs: dict[str, Any]
) -> None:
    method_inputs: dict[str, Any] = {
        "analysis_name": inputs_params["analysis_name"],
        "plate": inputs_params["plate"],
        "constraint": inputs_params["constraint"],
        "hole_diameter": inputs_params["hole_diameter"],
        "slot_corner_radius": inputs_params["slot_corner_radius"],
        "slot_length": inputs_params["slot_length"],
        "slot_width": inputs_params["slot_width"],
        "number_of_holes": inputs_params["number_of_holes"],
        "stiffener_width": inputs_params["stiffener_width"],
        "stiffener_height": inputs_params["stiffener_height"],
        "hole_area": inputs_params["hole_area"],
    }

    th3_906 = TH3_906(method_inputs)
    th3_906.set_default_formats()

    inputs, results = (th3_906.input, th3_906.outputs)
    inputs_formatted = inputs.formatted()
    results_formatted = results.formatted()

    # check the inputs
    assert th3_906.name == inputs_params["analysis_name"]
    assert th3_906.plate_constraint == inputs_params["constraint"]
    assert th3_906.slot_corner_radius == inputs_params["slot_corner_radius"]
    assert th3_906.plate_length == inputs_params["plate_length"]
    assert th3_906.plate_width == inputs_params["plate_width"]
    assert th3_906.plate_thickness == inputs_params["thickness"]
    assert th3_906.modulus_of_elasticity == inputs_params["modulus_of_elasticity"]
    assert th3_906.diameter == inputs_params["hole_diameter"]
    assert th3_906.number_of_holes == inputs_params["number_of_holes"]
    assert th3_906.stiffener_width == inputs_params["stiffener_width"]
    assert th3_906.stiffener_height == inputs_params["stiffener_height"]
    assert th3_906.slot_corner_radius == inputs_params["slot_corner_radius"]
    assert th3_906.slot_length == inputs_params["slot_length"]
    assert th3_906.slot_width == inputs_params["slot_width"]

    # check the performed calculation
    assert rel_diff(expected_outputs["K"], inputs_formatted["K"]) <= TOL_1PC
    assert rel_diff(expected_outputs["q_b"], results_formatted["q_b"]) <= TOL_1PC

    # check the example_calculation method that performs the very same calculation
    # example_document: Opus = th3_906.example_calculation()
    # document: Opus = th3_906.method_description()
