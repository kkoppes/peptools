import pytest
from pathlib import Path
from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)
from makerspace_mbe_pylantir.pylech.moria.nastran import NASTRANHDF5
from makerspace_mbe_pylantir.pydonau.alchemy import Solution
from makerspace_mbe_pylantir.pylech.fem import FELoad, LoadSet
from makerspace_mbe_pylantir.pyelbe.morgul.material_strength import (
    MaterialStrength,
    LoadExtractionForMatStrength,
)
from makerspace_mbe_pylantir.pydonau.alchemy.opera import Opus
from makerspace_mbe_pylantir.pylech.moria.nastran.analysis import NASTRANAnalysis

# from makerspace_mbe_pylantir.scrolls import get_logger  # type:ignore
# import logging

# logger: logging.Logger = get_logger(__name__, level=logging.DEBUG)

TEST_FILENAME = "TEST_FEM.h5"
TEST_H5_FILEPATH: Path = (
    Path(__file__).parent.parent.parent / "pylech/moria/nastran/" / TEST_FILENAME
)

TEST_SET_FILENAME = "TEST_FEM_SETS.out"
TEST_SET_FILEPATH: Path = (
    Path(__file__).parent.parent.parent / "pylech/moria/nastran/" / TEST_SET_FILENAME
)
SET_ID = "5"


@pytest.fixture
def mock_fem() -> NASTRANAnalysis:
    """
    A pytest fixture that creates a mock finite element model (FEM) using the NASTRANHDF5 class.

    Returns:
        NASTRANHDF5: An instance of the NASTRANHDF5 class representing the mock FEM model.
    """
    nas_analysis: NASTRANAnalysis = NASTRANHDF5.from_filename(filename=TEST_H5_FILEPATH)
    return nas_analysis


@pytest.fixture
def AIMS03_04_012() -> MetallicMaterial:
    """
    A pytest fixture that creates an instance of the MetallicMaterial class for 2024-Clad T42 sheet.

    Returns:
        MetallicMaterial: An instance of MetallicMaterial representing 2024-Clad T42 material with specified properties
        and allowables.
    """
    mat = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-012",
        properties=IsoElastic(E=69000.0, Ec=70300.0, G=26200.0, nu=0.33),
        allowables=MetallicAllowables(
            Fcy=290.0,
            Fty=260.0,
            Fc1=0.0,
            Ft1=0.0,
            Ftu=430.0,
            Fsu=255.0,
            b10=0.0,
            e=0.15,
            n=23.0,
            nc=17.0,
        ),
        billet=Billet(nominal=4.0),
    )
    return mat


def test_tension(AIMS03_04_012: MetallicMaterial) -> None:
    """
    Test the tension calculation in MaterialStrength for a given material under a specified stress.

    Args:
        AIMS03_04_012 (MetallicMaterial): A fixture providing a 2024-Clad T42 material instance.

    Asserts:
        The correctness of the tension calculation in the MaterialStrength class.
    """
    mat: MetallicMaterial = AIMS03_04_012
    applied_stress = 100
    allowable: float = min(1.5 * mat.allowables["Fty"], mat.allowables["Ftu"])

    # s: Solution = MaterialStrength(
    #     applied_stress=applied_stress, material=mat
    # ).calculation

    # logger.debug(f"applied_stress={s['applied_stress']}")
    # logger.debug(f"allowable={s['allowable']}")
    # logger.debug(f"reserve_factor={s['reserve_factor']}")
    # logger.debug(f"tens_comp={s['tens_comp']}")

    assert MaterialStrength(
        applied_stress=applied_stress, material=mat
    ).calculation == Solution(
        applied_stress=applied_stress,
        allowable=allowable,
        reserve_factor=allowable / applied_stress,
        tens_comp="tension",
    )


def test_method_description(AIMS03_04_012: MetallicMaterial) -> None:
    """
    Test the tension calculation in MaterialStrength for a given material under a specified stress.

    Args:
        AIMS03_04_012 (MetallicMaterial): A fixture providing a 2024-Clad T42 material instance.

    Asserts:
        The correctness of the tension calculation in the MaterialStrength class.
    """
    mat: MetallicMaterial = AIMS03_04_012
    stress = 100
    ms = MaterialStrength(applied_stress=stress, material=mat)

    method_description_opus: Opus = ms.method_description
    assert isinstance(method_description_opus, Opus)
    assert isinstance(method_description_opus.content, str)
    assert "Material strength calculations" in method_description_opus.content


def test_load_extraction(mock_fem: NASTRANAnalysis) -> None:
    """
    Test the load extraction for material strength calculation using the LoadExtractionForMatStrength class.

    Args:
        mock_fem (NASTRANHDF5): A fixture providing a mock finite element model.

    Asserts:
        The type of the result from the calculation method in LoadExtractionForMatStrength is LoadSet.
    """
    LE = LoadExtractionForMatStrength(
        set_path=TEST_SET_FILEPATH, set_id=SET_ID, nas_analysis=mock_fem
    )
    assert isinstance(LE.calculation, LoadSet)


def test_load_extraction_from_dict(mock_fem: NASTRANAnalysis) -> None:
    """
    Test the creation and load extraction of LoadExtractionForMatStrength class from a dictionary input.

    Args:
        mock_fem (NASTRANHDF5): A fixture providing a mock finite element model.

    Asserts:
        The type of the result from the calculation method in LoadExtractionForMatStrength, when instantiated from a
        dictionary, is LoadSet.
    """
    LE: LoadExtractionForMatStrength = LoadExtractionForMatStrength.from_dict(
        {
            "set_path": TEST_SET_FILEPATH,
            "set_id": SET_ID,
            "nas_analysis": TEST_H5_FILEPATH,
        }
    )
    assert isinstance(LE.calculation, LoadSet)


def test_tension_validation(AIMS03_04_012: MetallicMaterial) -> None:
    """
    Test multiple tension cases in MaterialStrength for validation purposes with results from:
    STRESS REPORT A321NEO XLR S17 BULK CARGO DOOR SURROUND (POST MOD 170046)

    Args:
        AIMS03_04_012 (MetallicMaterial): A fixture providing a 2024-Clad T42 material instance.

    Asserts:
        Correct calculation of the tension reserve factor for different applied stress cases in the MaterialStrength
        class.
    """
    mat: MetallicMaterial = AIMS03_04_012
    stress_case_1 = 338.9
    stress_case_2 = 295.1
    stress_case_3 = 339.3
    stress_case_4 = 327.6

    assert MaterialStrength(
        applied_stress=stress_case_1, material=mat
    ).calculation == Solution(
        applied_stress=stress_case_1,
        allowable=min(1.5 * mat.allowables["Fty"], mat.allowables["Ftu"]),
        reserve_factor=pytest.approx(1.1507819, 0.01),
        tens_comp="tension",
    )

    assert MaterialStrength(
        applied_stress=stress_case_2, material=mat
    ).calculation == Solution(
        applied_stress=stress_case_2,
        allowable=min(1.5 * mat.allowables["Fty"], mat.allowables["Ftu"]),
        reserve_factor=pytest.approx(1.3215859, 0.01),
        tens_comp="tension",
    )

    assert MaterialStrength(
        applied_stress=stress_case_3, material=mat
    ).calculation == Solution(
        applied_stress=stress_case_3,
        allowable=min(1.5 * mat.allowables["Fty"], mat.allowables["Ftu"]),
        reserve_factor=pytest.approx(1.149425, 0.01),
        tens_comp="tension",
    )

    assert MaterialStrength(
        applied_stress=stress_case_4, material=mat
    ).calculation == Solution(
        applied_stress=stress_case_4,
        allowable=min(1.5 * mat.allowables["Fty"], mat.allowables["Ftu"]),
        reserve_factor=pytest.approx(1.19047619, 0.01),
        tens_comp="tension",
    )
