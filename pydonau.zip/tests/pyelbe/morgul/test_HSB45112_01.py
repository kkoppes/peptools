import pytest

from makerspace_mbe_pylantir.pyelbe.mechanica.plates import Plate, RectangularPanel
from makerspace_mbe_pylantir.pyelbe.morgul.HSB_45112_01 import HSB45112_01

# from makerspace_mbe_pylantir.pydonau.isengard import Graph, GraphDataType

from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)


@pytest.fixture
def tmat_2024_T3():
    mat = MetallicMaterial(
        name="2024-T3",
        specification="------",
        properties=IsoElastic(E=72400.0, Ec=0.0, G=0.0, nu=0.33),
        allowables=MetallicAllowables(
            # Fcy=0.0,
            # Fty=0.0,
            # Fc1=0.0,
            # Ft1=0.0,
            # Ftu=0.0,
            # Fsu=0.0,
            # b10=0.0,
            # e=0.0,
            # n=0.0,
            # nc=0.0,
        ),
        billet=Billet(nominal=2.0),
    )
    return mat


def test_instance_HSB_45112_01(tmat_2024_T3):
    plate_width1 = 100.0
    plate_length1 = 60.0
    plate_th1 = 2.0

    geometry_test = RectangularPanel(width=plate_width1, length=plate_length1, thickness=plate_th1)

    plate_test = Plate(name="2024-T3", geometry=geometry_test, material=tmat_2024_T3)

    HSB_test = HSB45112_01(
        sup_cond="Curv_35",
        struct=plate_test,
    )
    assert HSB_test
    assert HSB_test.b_a == pytest.approx(0.6, 0.1)
    assert HSB_test.t_b == pytest.approx(0.0333, 0.1)
    assert HSB_test.kdf_t == pytest.approx(0.9, 0.1)
    assert HSB_test.calculation == pytest.approx(0.2254, 0.1)
    assert HSB_test.bf_int == pytest.approx(0.2073, 0.1)
    assert HSB_test.sigma_cr == pytest.approx(13.8576, 0.1)


def test_HSB45112_01_examples(tmat_2024_T3):
    # example 1 -  Curv_1
    plate_width_1 = 200.0
    plate_length_1 = 100.0
    plate_th_1 = 2.0

    geometry_1 = RectangularPanel(width=plate_width_1, length=plate_length_1, thickness=plate_th_1)

    plate_1 = Plate(name="2024-T3", geometry=geometry_1, material=tmat_2024_T3)

    example_1 = HSB45112_01(
        sup_cond="Curv_1",
        struct=plate_1,
    )

    # example 2 -  Curv_2
    plate_width_2 = 200.0
    plate_length_2 = 100.0
    plate_th_2 = 2.0

    geometry_2 = RectangularPanel(width=plate_width_2, length=plate_length_2, thickness=plate_th_2)

    plate_2 = Plate(name="2024-T3", geometry=geometry_2, material=tmat_2024_T3)

    example_2 = HSB45112_01(
        sup_cond="Curv_2",
        struct=plate_2,
    )
    # example 3 -  Curv_3
    plate_width_3 = 200.0
    plate_length_3 = 100.0
    plate_th_3 = 2.0

    geometry_3 = RectangularPanel(width=plate_width_3, length=plate_length_3, thickness=plate_th_3)

    plate_3 = Plate(name="2024-T3", geometry=geometry_3, material=tmat_2024_T3)

    example_3 = HSB45112_01(
        sup_cond="Curv_3",
        struct=plate_3,
    )
    # example 4 -  Curv_4
    plate_width_4 = 200.0
    plate_length_4 = 100.0
    plate_th_4 = 2.0

    geometry_4 = RectangularPanel(width=plate_width_4, length=plate_length_4, thickness=plate_th_4)

    plate_4 = Plate(name="2024-T3", geometry=geometry_4, material=tmat_2024_T3)

    example_4 = HSB45112_01(
        sup_cond="Curv_4",
        struct=plate_4,
    )
    # example 5 -  Curv_5
    plate_width_5 = 200.0
    plate_length_5 = 100.0
    plate_th_5 = 2.0

    geometry_5 = RectangularPanel(width=plate_width_5, length=plate_length_5, thickness=plate_th_5)

    plate_5 = Plate(name="2024-T3", geometry=geometry_5, material=tmat_2024_T3)

    example_5 = HSB45112_01(
        sup_cond="Curv_5",
        struct=plate_5,
    )
    # example 6 -  Curv_6
    plate_width_6 = 200.0
    plate_length_6 = 100.0
    plate_th_6 = 2.0

    geometry_6 = RectangularPanel(width=plate_width_6, length=plate_length_6, thickness=plate_th_6)

    plate_6 = Plate(name="2024-T3", geometry=geometry_6, material=tmat_2024_T3)

    example_6 = HSB45112_01(
        sup_cond="Curv_6",
        struct=plate_6,
    )
    # example 7 -  Curv_7
    plate_width_7 = 200.0
    plate_length_7 = 100.0
    plate_th_7 = 2.0

    geometry_7 = RectangularPanel(width=plate_width_7, length=plate_length_7, thickness=plate_th_7)

    plate_7 = Plate(name="2024-T3", geometry=geometry_7, material=tmat_2024_T3)

    example_7 = HSB45112_01(
        sup_cond="Curv_7",
        struct=plate_7,
    )
    # example 8 -  Curv_8
    plate_width_8 = 200.0
    plate_length_8 = 100.0
    plate_th_8 = 2.0

    geometry_8 = RectangularPanel(width=plate_width_8, length=plate_length_8, thickness=plate_th_8)

    plate_8 = Plate(name="2024-T3", geometry=geometry_8, material=tmat_2024_T3)

    example_8 = HSB45112_01(
        sup_cond="Curv_8",
        struct=plate_8,
    )
    # example 9 -  Curv_9
    plate_width_9 = 200.0
    plate_length_9 = 100.0
    plate_th_9 = 2.0

    geometry_9 = RectangularPanel(width=plate_width_9, length=plate_length_9, thickness=plate_th_9)

    plate_9 = Plate(name="2024-T3", geometry=geometry_9, material=tmat_2024_T3)

    example_9 = HSB45112_01(
        sup_cond="Curv_9",
        struct=plate_9,
    )
    # example 10 -  Curv_10
    plate_width_10 = 200.0
    plate_length_10 = 100.0
    plate_th_10 = 2.0

    geometry_10 = RectangularPanel(width=plate_width_10, length=plate_length_10, thickness=plate_th_10)

    plate_10 = Plate(name="2024-T3", geometry=geometry_10, material=tmat_2024_T3)

    example_10 = HSB45112_01(
        sup_cond="Curv_10",
        struct=plate_10,
    )
    # example 11 -  Curv_11
    plate_width_11 = 200.0
    plate_length_11 = 100.0
    plate_th_11 = 2.0

    geometry_11 = RectangularPanel(width=plate_width_11, length=plate_length_11, thickness=plate_th_11)

    plate_11 = Plate(name="2024-T3", geometry=geometry_11, material=tmat_2024_T3)

    example_11 = HSB45112_01(
        sup_cond="Curv_11",
        struct=plate_11,
    )
    # example 12 -  Curv_12
    plate_width_12 = 200.0
    plate_length_12 = 100.0
    plate_th_12 = 2.0

    geometry_12 = RectangularPanel(width=plate_width_12, length=plate_length_12, thickness=plate_th_12)

    plate_12 = Plate(name="2024-T3", geometry=geometry_12, material=tmat_2024_T3)

    example_12 = HSB45112_01(
        sup_cond="Curv_12",
        struct=plate_12,
    )
    # example 13 -  Curv_13
    plate_width_13 = 200.0
    plate_length_13 = 100.0
    plate_th_13 = 2.0

    geometry_13 = RectangularPanel(width=plate_width_13, length=plate_length_13, thickness=plate_th_13)

    plate_13 = Plate(name="2024-T3", geometry=geometry_13, material=tmat_2024_T3)

    example_13 = HSB45112_01(
        sup_cond="Curv_13",
        struct=plate_13,
    )
    # example 14 -  Curv_14
    plate_width_14 = 200.0
    plate_length_14 = 100.0
    plate_th_14 = 2.0

    geometry_14 = RectangularPanel(width=plate_width_14, length=plate_length_14, thickness=plate_th_14)

    plate_14 = Plate(name="2024-T3", geometry=geometry_14, material=tmat_2024_T3)

    example_14 = HSB45112_01(
        sup_cond="Curv_14",
        struct=plate_14,
    )
    # example 15 -  Curv_15
    plate_width_15 = 200.0
    plate_length_15 = 100.0
    plate_th_15 = 2.0

    geometry_15 = RectangularPanel(width=plate_width_15, length=plate_length_15, thickness=plate_th_15)

    plate_15 = Plate(name="2024-T3", geometry=geometry_15, material=tmat_2024_T3)

    example_15 = HSB45112_01(
        sup_cond="Curv_15",
        struct=plate_15,
    )
    # example 16 -  Curv_16
    plate_width_16 = 200.0
    plate_length_16 = 100.0
    plate_th_16 = 2.0

    geometry_16 = RectangularPanel(width=plate_width_16, length=plate_length_16, thickness=plate_th_16)

    plate_16 = Plate(name="2024-T3", geometry=geometry_16, material=tmat_2024_T3)

    example_16 = HSB45112_01(
        sup_cond="Curv_16",
        struct=plate_16,
    )
    # example 17 -  Curv_17
    plate_width_17 = 200.0
    plate_length_17 = 100.0
    plate_th_17 = 2.0

    geometry_17 = RectangularPanel(width=plate_width_17, length=plate_length_17, thickness=plate_th_17)

    plate_17 = Plate(name="2024-T3", geometry=geometry_17, material=tmat_2024_T3)

    example_17 = HSB45112_01(
        sup_cond="Curv_17",
        struct=plate_17,
    )
    # example 18 -  Curv_18
    plate_width_18 = 200.0
    plate_length_18 = 100.0
    plate_th_18 = 2.0

    geometry_18 = RectangularPanel(width=plate_width_18, length=plate_length_18, thickness=plate_th_18)

    plate_18 = Plate(name="2024-T3", geometry=geometry_18, material=tmat_2024_T3)

    example_18 = HSB45112_01(
        sup_cond="Curv_18",
        struct=plate_18,
    )
    # example 19 -  Curv_19
    plate_width_19 = 200.0
    plate_length_19 = 100.0
    plate_th_19 = 2.0

    geometry_19 = RectangularPanel(width=plate_width_19, length=plate_length_19, thickness=plate_th_19)

    plate_19 = Plate(name="2024-T3", geometry=geometry_19, material=tmat_2024_T3)

    example_19 = HSB45112_01(
        sup_cond="Curv_19",
        struct=plate_19,
    )
    # example 20 -  Curv_20
    plate_width_20 = 200.0
    plate_length_20 = 100.0
    plate_th_20 = 2.0

    geometry_20 = RectangularPanel(width=plate_width_20, length=plate_length_20, thickness=plate_th_20)

    plate_20 = Plate(name="2024-T3", geometry=geometry_20, material=tmat_2024_T3)

    example_20 = HSB45112_01(
        sup_cond="Curv_20",
        struct=plate_20,
    )
    # example 21 -  Curv_21
    plate_width_21 = 200.0
    plate_length_21 = 100.0
    plate_th_21 = 2.0

    geometry_21 = RectangularPanel(width=plate_width_21, length=plate_length_21, thickness=plate_th_21)

    plate_21 = Plate(name="2024-T3", geometry=geometry_21, material=tmat_2024_T3)

    example_21 = HSB45112_01(
        sup_cond="Curv_21",
        struct=plate_21,
    )
    # example 22 -  Curv_22
    plate_width_22 = 200.0
    plate_length_22 = 100.0
    plate_th_22 = 2.0

    geometry_22 = RectangularPanel(width=plate_width_22, length=plate_length_22, thickness=plate_th_22)

    plate_22 = Plate(name="2024-T3", geometry=geometry_22, material=tmat_2024_T3)

    example_22 = HSB45112_01(
        sup_cond="Curv_22",
        struct=plate_22,
    )
    # example 23 -  Curv_23
    plate_width_23 = 200.0
    plate_length_23 = 100.0
    plate_th_23 = 2.0

    geometry_23 = RectangularPanel(width=plate_width_23, length=plate_length_23, thickness=plate_th_23)

    plate_23 = Plate(name="2024-T3", geometry=geometry_23, material=tmat_2024_T3)

    example_23 = HSB45112_01(
        sup_cond="Curv_23",
        struct=plate_23,
    )
    # example 24 -  Curv_24
    plate_width_24 = 200.0
    plate_length_24 = 100.0
    plate_th_24 = 2.0

    geometry_24 = RectangularPanel(width=plate_width_24, length=plate_length_24, thickness=plate_th_24)

    plate_24 = Plate(name="2024-T3", geometry=geometry_24, material=tmat_2024_T3)

    example_24 = HSB45112_01(
        sup_cond="Curv_24",
        struct=plate_24,
    )
    # example 25 -  Curv_25
    plate_width_25 = 200.0
    plate_length_25 = 100.0
    plate_th_25 = 2.0

    geometry_25 = RectangularPanel(width=plate_width_25, length=plate_length_25, thickness=plate_th_25)

    plate_25 = Plate(name="2024-T3", geometry=geometry_25, material=tmat_2024_T3)

    example_25 = HSB45112_01(
        sup_cond="Curv_25",
        struct=plate_25,
    )
    # example 26 -  Curv_26
    plate_width_26 = 200.0
    plate_length_26 = 100.0
    plate_th_26 = 2.0

    geometry_26 = RectangularPanel(width=plate_width_26, length=plate_length_26, thickness=plate_th_26)

    plate_26 = Plate(name="2024-T3", geometry=geometry_26, material=tmat_2024_T3)

    example_26 = HSB45112_01(
        sup_cond="Curv_26",
        struct=plate_26,
    )
    # example 27 -  Curv_27
    plate_width_27 = 200.0
    plate_length_27 = 100.0
    plate_th_27 = 2.0

    geometry_27 = RectangularPanel(width=plate_width_27, length=plate_length_27, thickness=plate_th_27)

    plate_27 = Plate(name="2024-T3", geometry=geometry_27, material=tmat_2024_T3)

    example_27 = HSB45112_01(
        sup_cond="Curv_27",
        struct=plate_27,
    )
    # example 28 -  Curv_28
    plate_width_28 = 200.0
    plate_length_28 = 100.0
    plate_th_28 = 2.0

    geometry_28 = RectangularPanel(width=plate_width_28, length=plate_length_28, thickness=plate_th_28)

    plate_28 = Plate(name="2024-T3", geometry=geometry_28, material=tmat_2024_T3)

    example_28 = HSB45112_01(
        sup_cond="Curv_28",
        struct=plate_28,
    )
    # example 29 -  Curv_29
    plate_width_29 = 200.0
    plate_length_29 = 100.0
    plate_th_29 = 2.0

    geometry_29 = RectangularPanel(width=plate_width_29, length=plate_length_29, thickness=plate_th_29)

    plate_29 = Plate(name="2024-T3", geometry=geometry_29, material=tmat_2024_T3)

    example_29 = HSB45112_01(
        sup_cond="Curv_29",
        struct=plate_29,
    )
    # example 30 -  Curv_30
    plate_width_30 = 2000.0
    plate_length_30 = 1000.0
    plate_th_30 = 2.0

    geometry_30 = RectangularPanel(width=plate_width_30, length=plate_length_30, thickness=plate_th_30)

    plate_30 = Plate(name="2024-T3", geometry=geometry_30, material=tmat_2024_T3)

    example_30 = HSB45112_01(
        sup_cond="Curv_30",
        struct=plate_30,
    )
    # example 31 -  Curv_31
    plate_width_31 = 2000.0
    plate_length_31 = 1000.0
    plate_th_31 = 1.0

    geometry_31 = RectangularPanel(width=plate_width_31, length=plate_length_31, thickness=plate_th_31)

    plate_31 = Plate(name="2024-T3", geometry=geometry_31, material=tmat_2024_T3)

    example_31 = HSB45112_01(
        sup_cond="Curv_31",
        struct=plate_31,
    )
    # example 32 -  Curv_32
    plate_width_32 = 200.0
    plate_length_32 = 100.0
    plate_th_32 = 2.0

    geometry_32 = RectangularPanel(width=plate_width_32, length=plate_length_32, thickness=plate_th_32)

    plate_32 = Plate(name="2024-T3", geometry=geometry_32, material=tmat_2024_T3)

    example_32 = HSB45112_01(
        sup_cond="Curv_32",
        struct=plate_32,
    )
    # example 33 -  Curv_33
    plate_width_33 = 200.0
    plate_length_33 = 100.0
    plate_th_33 = 2.0

    geometry_33 = RectangularPanel(width=plate_width_33, length=plate_length_33, thickness=plate_th_33)

    plate_33 = Plate(name="2024-T3", geometry=geometry_33, material=tmat_2024_T3)

    example_33 = HSB45112_01(
        sup_cond="Curv_33",
        struct=plate_33,
    )
    # example 34 -  Curv_34
    plate_width_34 = 200.0
    plate_length_34 = 100.0
    plate_th_34 = 2.0

    geometry_34 = RectangularPanel(width=plate_width_34, length=plate_length_34, thickness=plate_th_34)

    plate_34 = Plate(name="2024-T3", geometry=geometry_34, material=tmat_2024_T3)

    example_34 = HSB45112_01(
        sup_cond="Curv_34",
        struct=plate_34,
    )

    example_expected = {
        "example_1": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 10.2435,
            "buckling factor interpolate": 10.2435,
            "sigma_cr": 265.5908,
        },
        "example_2": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 8.2501,
            "buckling factor interpolate": 8.2501,
            "sigma_cr": 213.9077,
        },
        "example_3": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 6.5365,
            "buckling factor interpolate": 6.5365,
            "sigma_cr": 169.4778,
        },
        "example_4": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 10.2350,
            "buckling factor interpolate": 10.2350,
            "sigma_cr": 265.3694,
        },
        "example_5": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 10.1376,
            "buckling factor interpolate": 10.1376,
            "sigma_cr": 262.8447,
        },
        "example_6": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 8.1638,
            "buckling factor interpolate": 8.1638,
            "sigma_cr": 211.6692,
        },
        "example_7": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 8.6191,
            "buckling factor interpolate": 8.6191,
            "sigma_cr": 223.4747,
        },
        "example_8": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 6.7475,
            "buckling factor interpolate": 6.7475,
            "sigma_cr": 174.9488,
        },
        "example_9": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 6.6432,
            "buckling factor interpolate": 6.6432,
            "sigma_cr": 172.2437,
        },
        "example_10": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 1.6453,
            "buckling factor interpolate": 1.5074,
            "sigma_cr": 39.0855,
        },
        "example_11": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 1.0653,
            "buckling factor interpolate": 0.9758,
            "sigma_cr": 25.3025,
        },
        "example_12": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 0.4594,
            "buckling factor interpolate": 0.4284,
            "sigma_cr": 11.1092,
        },
        "example_13": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 0.1324,
            "buckling factor interpolate": 0.1203,
            "sigma_cr": 3.1212,
        },
        "example_14": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 8.1353,
            "buckling factor interpolate": 7.6545,
            "sigma_cr": 198.4628,
        },
        "example_15": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 8.1353,
            "buckling factor interpolate": 7.6559,
            "sigma_cr": 198.4998,
        },
        "example_16": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 7.9460,
            "buckling factor interpolate": 7.4831,
            "sigma_cr": 194.0203,
        },
        "example_17": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 6.1983,
            "buckling factor interpolate": 5.8186,
            "sigma_cr": 150.8632,
        },
        "example_18": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 6.1983,
            "buckling factor interpolate": 5.8214,
            "sigma_cr": 150.9371,
        },
        "example_19": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 6.1346,
            "buckling factor interpolate": 5.7652,
            "sigma_cr": 149.4779,
        },
        "example_20": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 2.7507,
            "buckling factor interpolate": 2.5605,
            "sigma_cr": 66.3884,
        },
        "example_21": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 2.3391,
            "buckling factor interpolate": 2.1740,
            "sigma_cr": 56.3678,
        },
        "example_22": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 1.7660,
            "buckling factor interpolate": 1.6435,
            "sigma_cr": 42.6130,
        },
        "example_23": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 2.4304,
            "buckling factor interpolate": 2.2590,
            "sigma_cr": 58.5716,
        },
        "example_24": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 1.9334,
            "buckling factor interpolate": 1.7928,
            "sigma_cr": 46.4853,
        },
        "example_25": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 1.2285,
            "buckling factor interpolate": 1.1343,
            "sigma_cr": 29.4109,
        },
        "example_26": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 4.5981,
            "buckling factor interpolate": 4.2984,
            "sigma_cr": 111.4485,
        },
        "example_27": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 4.5837,
            "buckling factor interpolate": 4.2876,
            "sigma_cr": 111.1675,
        },
        "example_28": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 4.3798,
            "buckling factor interpolate": 4.1024,
            "sigma_cr": 106.3659,
        },
        "example_29": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 1.5484,
            "buckling factor interpolate": 1.4240,
            "sigma_cr": 36.9220,
        },
        "example_30": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.002,
            "kdf_t": 0.99,
            "buckling factor": 0.4507,
            "buckling factor interpolate": 0.4196,
            "sigma_cr": 0.1110,
        },
        "example_31": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.001,
            "kdf_t": 1.0,
            "buckling factor": 2.2822,
            "buckling factor interpolate": 2.1183,
            "sigma_cr": 0.1415,
        },
        "example_32": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 1.6302,
            "buckling factor interpolate": 1.5048,
            "sigma_cr": 39.0182,
        },
        "example_33": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 0.8104,
            "buckling factor interpolate": 0.7414,
            "sigma_cr": 19.2240,
        },
        "example_34": {
            "b/a ratio": 0.5,
            "t/b ratio": 0.02,
            "kdf_t": 0.97,
            "buckling factor": 1.2502,
            "buckling factor interpolate": 1.1478,
            "sigma_cr": 29.7600,
        },
    }

    # example 1
    assert example_expected["example_1"]["b/a ratio"] == pytest.approx(example_1.b_a, 0.01)
    assert example_expected["example_1"]["t/b ratio"] == pytest.approx(example_1.t_b, 0.01)
    assert example_expected["example_1"]["kdf_t"] == pytest.approx(example_1.kdf_t, 0.01)
    assert example_expected["example_1"]["buckling factor"] == pytest.approx(example_1.calculation, 0.01)
    assert example_expected["example_1"]["buckling factor interpolate"] == pytest.approx(example_1.bf_int, 0.01)

    assert example_expected["example_1"]["sigma_cr"] == pytest.approx(example_1.sigma_cr, 0.01)

    # example 2
    assert example_expected["example_2"]["b/a ratio"] == pytest.approx(example_2.b_a, 0.01)
    assert example_expected["example_2"]["t/b ratio"] == pytest.approx(example_2.t_b, 0.01)
    assert example_expected["example_2"]["kdf_t"] == pytest.approx(example_2.kdf_t, 0.01)
    assert example_expected["example_2"]["buckling factor"] == pytest.approx(example_2.calculation, 0.01)
    assert example_expected["example_2"]["buckling factor interpolate"] == pytest.approx(example_2.bf_int, 0.01)
    assert example_expected["example_2"]["sigma_cr"] == pytest.approx(example_2.sigma_cr, 0.01)

    # example 3
    assert example_expected["example_3"]["b/a ratio"] == pytest.approx(example_3.b_a, 0.01)
    assert example_expected["example_3"]["t/b ratio"] == pytest.approx(example_3.t_b, 0.01)
    assert example_expected["example_3"]["kdf_t"] == pytest.approx(example_3.kdf_t, 0.01)
    assert example_expected["example_3"]["buckling factor"] == pytest.approx(example_3.calculation, 0.01)
    assert example_expected["example_3"]["buckling factor interpolate"] == pytest.approx(example_3.bf_int, 0.01)
    assert example_expected["example_3"]["sigma_cr"] == pytest.approx(example_3.sigma_cr, 0.01)

    # example 4
    assert example_expected["example_4"]["b/a ratio"] == pytest.approx(example_4.b_a, 0.01)
    assert example_expected["example_4"]["t/b ratio"] == pytest.approx(example_4.t_b, 0.01)
    assert example_expected["example_4"]["kdf_t"] == pytest.approx(example_4.kdf_t, 0.01)
    assert example_expected["example_4"]["buckling factor"] == pytest.approx(example_4.calculation, 0.01)
    assert example_expected["example_4"]["buckling factor interpolate"] == pytest.approx(example_4.bf_int, 0.01)
    assert example_expected["example_4"]["sigma_cr"] == pytest.approx(example_4.sigma_cr, 0.01)

    # example 5
    assert example_expected["example_5"]["b/a ratio"] == pytest.approx(example_5.b_a, 0.01)
    assert example_expected["example_5"]["t/b ratio"] == pytest.approx(example_5.t_b, 0.01)
    assert example_expected["example_5"]["kdf_t"] == pytest.approx(example_5.kdf_t, 0.01)
    assert example_expected["example_5"]["buckling factor"] == pytest.approx(example_5.calculation, 0.01)
    assert example_expected["example_5"]["buckling factor interpolate"] == pytest.approx(example_5.bf_int, 0.01)
    assert example_expected["example_5"]["sigma_cr"] == pytest.approx(example_5.sigma_cr, 0.01)

    # example 6
    assert example_expected["example_6"]["b/a ratio"] == pytest.approx(example_6.b_a, 0.01)
    assert example_expected["example_6"]["t/b ratio"] == pytest.approx(example_6.t_b, 0.01)
    assert example_expected["example_6"]["kdf_t"] == pytest.approx(example_6.kdf_t, 0.01)
    assert example_expected["example_6"]["buckling factor"] == pytest.approx(example_6.calculation, 0.01)
    assert example_expected["example_6"]["buckling factor interpolate"] == pytest.approx(example_6.bf_int, 0.01)
    assert example_expected["example_6"]["sigma_cr"] == pytest.approx(example_6.sigma_cr, 0.01)

    # example 7
    assert example_expected["example_7"]["b/a ratio"] == pytest.approx(example_7.b_a, 0.01)
    assert example_expected["example_7"]["t/b ratio"] == pytest.approx(example_7.t_b, 0.01)
    assert example_expected["example_7"]["kdf_t"] == pytest.approx(example_7.kdf_t, 0.01)
    assert example_expected["example_7"]["buckling factor"] == pytest.approx(example_7.calculation, 0.01)
    assert example_expected["example_7"]["buckling factor interpolate"] == pytest.approx(example_7.bf_int, 0.01)
    assert example_expected["example_7"]["sigma_cr"] == pytest.approx(example_7.sigma_cr, 0.01)

    # example 8
    assert example_expected["example_8"]["b/a ratio"] == pytest.approx(example_8.b_a, 0.01)
    assert example_expected["example_8"]["t/b ratio"] == pytest.approx(example_8.t_b, 0.01)
    assert example_expected["example_8"]["kdf_t"] == pytest.approx(example_8.kdf_t, 0.01)
    assert example_expected["example_8"]["buckling factor"] == pytest.approx(example_8.calculation, 0.01)
    assert example_expected["example_8"]["buckling factor interpolate"] == pytest.approx(example_8.bf_int, 0.01)
    assert example_expected["example_8"]["sigma_cr"] == pytest.approx(example_8.sigma_cr, 0.01)

    # example 9
    assert example_expected["example_9"]["b/a ratio"] == pytest.approx(example_9.b_a, 0.01)
    assert example_expected["example_9"]["t/b ratio"] == pytest.approx(example_9.t_b, 0.01)
    assert example_expected["example_9"]["kdf_t"] == pytest.approx(example_9.kdf_t, 0.01)
    assert example_expected["example_9"]["buckling factor"] == pytest.approx(example_9.calculation, 0.01)
    assert example_expected["example_9"]["buckling factor interpolate"] == pytest.approx(example_9.bf_int, 0.01)
    assert example_expected["example_9"]["sigma_cr"] == pytest.approx(example_9.sigma_cr, 0.01)

    # example 10
    assert example_expected["example_10"]["b/a ratio"] == pytest.approx(example_10.b_a, 0.01)
    assert example_expected["example_10"]["t/b ratio"] == pytest.approx(example_10.t_b, 0.01)
    assert example_expected["example_10"]["kdf_t"] == pytest.approx(example_10.kdf_t, 0.01)
    assert example_expected["example_10"]["buckling factor"] == pytest.approx(example_10.calculation, 0.01)
    assert example_expected["example_10"]["buckling factor interpolate"] == pytest.approx(example_10.bf_int, 0.01)
    assert example_expected["example_10"]["sigma_cr"] == pytest.approx(example_10.sigma_cr, 0.01)

    # example 11
    assert example_expected["example_11"]["b/a ratio"] == pytest.approx(example_11.b_a, 0.01)
    assert example_expected["example_11"]["t/b ratio"] == pytest.approx(example_11.t_b, 0.01)
    assert example_expected["example_11"]["kdf_t"] == pytest.approx(example_11.kdf_t, 0.01)
    assert example_expected["example_11"]["buckling factor"] == pytest.approx(example_11.calculation, 0.01)
    assert example_expected["example_11"]["buckling factor interpolate"] == pytest.approx(example_11.bf_int, 0.01)
    assert example_expected["example_11"]["sigma_cr"] == pytest.approx(example_11.sigma_cr, 0.01)

    # example 12
    assert example_expected["example_12"]["b/a ratio"] == pytest.approx(example_12.b_a, 0.01)
    assert example_expected["example_12"]["t/b ratio"] == pytest.approx(example_12.t_b, 0.01)
    assert example_expected["example_12"]["kdf_t"] == pytest.approx(example_12.kdf_t, 0.01)
    assert example_expected["example_12"]["buckling factor"] == pytest.approx(example_12.calculation, 0.01)
    assert example_expected["example_12"]["buckling factor interpolate"] == pytest.approx(example_12.bf_int, 0.01)
    assert example_expected["example_12"]["sigma_cr"] == pytest.approx(example_12.sigma_cr, 0.01)

    # example 13
    assert example_expected["example_13"]["b/a ratio"] == pytest.approx(example_13.b_a, 0.01)
    assert example_expected["example_13"]["t/b ratio"] == pytest.approx(example_13.t_b, 0.01)
    assert example_expected["example_13"]["kdf_t"] == pytest.approx(example_13.kdf_t, 0.01)
    assert example_expected["example_13"]["buckling factor"] == pytest.approx(example_13.calculation, 0.01)
    assert example_expected["example_13"]["buckling factor interpolate"] == pytest.approx(example_13.bf_int, 0.01)
    assert example_expected["example_13"]["sigma_cr"] == pytest.approx(example_13.sigma_cr, 0.01)

    # example 14
    assert example_expected["example_14"]["b/a ratio"] == pytest.approx(example_14.b_a, 0.01)
    assert example_expected["example_14"]["t/b ratio"] == pytest.approx(example_14.t_b, 0.01)
    assert example_expected["example_14"]["kdf_t"] == pytest.approx(example_14.kdf_t, 0.01)
    assert example_expected["example_14"]["buckling factor"] == pytest.approx(example_14.calculation, 0.01)
    assert example_expected["example_14"]["buckling factor interpolate"] == pytest.approx(example_14.bf_int, 0.01)
    assert example_expected["example_14"]["sigma_cr"] == pytest.approx(example_14.sigma_cr, 0.01)

    # example 15
    assert example_expected["example_15"]["b/a ratio"] == pytest.approx(example_15.b_a, 0.01)
    assert example_expected["example_15"]["t/b ratio"] == pytest.approx(example_15.t_b, 0.01)
    assert example_expected["example_15"]["kdf_t"] == pytest.approx(example_15.kdf_t, 0.01)
    assert example_expected["example_15"]["buckling factor"] == pytest.approx(example_15.calculation, 0.01)
    assert example_expected["example_15"]["buckling factor interpolate"] == pytest.approx(example_15.bf_int, 0.01)
    assert example_expected["example_15"]["sigma_cr"] == pytest.approx(example_15.sigma_cr, 0.01)

    # example 16
    assert example_expected["example_16"]["b/a ratio"] == pytest.approx(example_16.b_a, 0.01)
    assert example_expected["example_16"]["t/b ratio"] == pytest.approx(example_16.t_b, 0.01)
    assert example_expected["example_16"]["kdf_t"] == pytest.approx(example_16.kdf_t, 0.01)
    assert example_expected["example_16"]["buckling factor"] == pytest.approx(example_16.calculation, 0.01)
    assert example_expected["example_16"]["buckling factor interpolate"] == pytest.approx(example_16.bf_int, 0.01)
    assert example_expected["example_16"]["sigma_cr"] == pytest.approx(example_16.sigma_cr, 0.01)

    # example 17
    assert example_expected["example_17"]["b/a ratio"] == pytest.approx(example_17.b_a, 0.01)
    assert example_expected["example_17"]["t/b ratio"] == pytest.approx(example_17.t_b, 0.01)
    assert example_expected["example_17"]["kdf_t"] == pytest.approx(example_17.kdf_t, 0.01)
    assert example_expected["example_17"]["buckling factor"] == pytest.approx(example_17.calculation, 0.01)
    assert example_expected["example_17"]["buckling factor interpolate"] == pytest.approx(example_17.bf_int, 0.01)
    assert example_expected["example_17"]["sigma_cr"] == pytest.approx(example_17.sigma_cr, 0.01)

    # example 18
    assert example_expected["example_18"]["b/a ratio"] == pytest.approx(example_18.b_a, 0.01)
    assert example_expected["example_18"]["t/b ratio"] == pytest.approx(example_18.t_b, 0.01)
    assert example_expected["example_18"]["kdf_t"] == pytest.approx(example_18.kdf_t, 0.01)
    assert example_expected["example_18"]["buckling factor"] == pytest.approx(example_18.calculation, 0.01)
    assert example_expected["example_18"]["buckling factor interpolate"] == pytest.approx(example_18.bf_int, 0.01)
    assert example_expected["example_18"]["sigma_cr"] == pytest.approx(example_18.sigma_cr, 0.01)

    # example 19
    assert example_expected["example_19"]["b/a ratio"] == pytest.approx(example_19.b_a, 0.01)
    assert example_expected["example_19"]["t/b ratio"] == pytest.approx(example_19.t_b, 0.01)
    assert example_expected["example_19"]["kdf_t"] == pytest.approx(example_19.kdf_t, 0.01)
    assert example_expected["example_19"]["buckling factor"] == pytest.approx(example_19.calculation, 0.01)
    assert example_expected["example_19"]["buckling factor interpolate"] == pytest.approx(example_19.bf_int, 0.01)
    assert example_expected["example_19"]["sigma_cr"] == pytest.approx(example_19.sigma_cr, 0.01)

    # example 20
    assert example_expected["example_20"]["b/a ratio"] == pytest.approx(example_20.b_a, 0.01)
    assert example_expected["example_20"]["t/b ratio"] == pytest.approx(example_20.t_b, 0.01)
    assert example_expected["example_20"]["kdf_t"] == pytest.approx(example_20.kdf_t, 0.01)
    assert example_expected["example_20"]["buckling factor"] == pytest.approx(example_20.calculation, 0.01)
    assert example_expected["example_20"]["buckling factor interpolate"] == pytest.approx(example_20.bf_int, 0.01)
    assert example_expected["example_20"]["sigma_cr"] == pytest.approx(example_20.sigma_cr, 0.01)

    # example 21
    assert example_expected["example_21"]["b/a ratio"] == pytest.approx(example_21.b_a, 0.01)
    assert example_expected["example_21"]["t/b ratio"] == pytest.approx(example_21.t_b, 0.01)
    assert example_expected["example_21"]["kdf_t"] == pytest.approx(example_21.kdf_t, 0.01)
    assert example_expected["example_21"]["buckling factor"] == pytest.approx(example_21.calculation, 0.01)
    assert example_expected["example_21"]["buckling factor interpolate"] == pytest.approx(example_21.bf_int, 0.01)
    assert example_expected["example_21"]["sigma_cr"] == pytest.approx(example_21.sigma_cr, 0.01)

    # example 22
    assert example_expected["example_22"]["b/a ratio"] == pytest.approx(example_22.b_a, 0.01)
    assert example_expected["example_22"]["t/b ratio"] == pytest.approx(example_22.t_b, 0.01)
    assert example_expected["example_22"]["kdf_t"] == pytest.approx(example_22.kdf_t, 0.01)
    assert example_expected["example_22"]["buckling factor"] == pytest.approx(example_22.calculation, 0.01)
    assert example_expected["example_22"]["buckling factor interpolate"] == pytest.approx(example_22.bf_int, 0.01)
    assert example_expected["example_22"]["sigma_cr"] == pytest.approx(example_22.sigma_cr, 0.01)

    # example 23
    assert example_expected["example_23"]["b/a ratio"] == pytest.approx(example_23.b_a, 0.01)
    assert example_expected["example_23"]["t/b ratio"] == pytest.approx(example_23.t_b, 0.01)
    assert example_expected["example_23"]["kdf_t"] == pytest.approx(example_23.kdf_t, 0.01)
    assert example_expected["example_23"]["buckling factor"] == pytest.approx(example_23.calculation, 0.01)
    assert example_expected["example_23"]["buckling factor interpolate"] == pytest.approx(example_23.bf_int, 0.01)
    assert example_expected["example_23"]["sigma_cr"] == pytest.approx(example_23.sigma_cr, 0.01)

    # example 24
    assert example_expected["example_24"]["b/a ratio"] == pytest.approx(example_24.b_a, 0.01)
    assert example_expected["example_24"]["t/b ratio"] == pytest.approx(example_24.t_b, 0.01)
    assert example_expected["example_24"]["kdf_t"] == pytest.approx(example_24.kdf_t, 0.01)
    assert example_expected["example_24"]["buckling factor"] == pytest.approx(example_24.calculation, 0.01)
    assert example_expected["example_24"]["buckling factor interpolate"] == pytest.approx(example_24.bf_int, 0.01)
    assert example_expected["example_24"]["sigma_cr"] == pytest.approx(example_24.sigma_cr, 0.01)

    # example 25
    assert example_expected["example_25"]["b/a ratio"] == pytest.approx(example_25.b_a, 0.01)
    assert example_expected["example_25"]["t/b ratio"] == pytest.approx(example_25.t_b, 0.01)
    assert example_expected["example_25"]["kdf_t"] == pytest.approx(example_25.kdf_t, 0.01)
    assert example_expected["example_25"]["buckling factor"] == pytest.approx(example_25.calculation, 0.01)
    assert example_expected["example_25"]["buckling factor interpolate"] == pytest.approx(example_25.bf_int, 0.01)
    assert example_expected["example_25"]["sigma_cr"] == pytest.approx(example_25.sigma_cr, 0.01)

    # example 26
    assert example_expected["example_26"]["b/a ratio"] == pytest.approx(example_26.b_a, 0.01)
    assert example_expected["example_26"]["t/b ratio"] == pytest.approx(example_26.t_b, 0.01)
    assert example_expected["example_26"]["kdf_t"] == pytest.approx(example_26.kdf_t, 0.01)
    assert example_expected["example_26"]["buckling factor"] == pytest.approx(example_26.calculation, 0.01)
    assert example_expected["example_26"]["buckling factor interpolate"] == pytest.approx(example_26.bf_int, 0.01)
    assert example_expected["example_26"]["sigma_cr"] == pytest.approx(example_26.sigma_cr, 0.01)

    # example 27
    assert example_expected["example_27"]["b/a ratio"] == pytest.approx(example_27.b_a, 0.01)
    assert example_expected["example_27"]["t/b ratio"] == pytest.approx(example_27.t_b, 0.01)
    assert example_expected["example_27"]["kdf_t"] == pytest.approx(example_27.kdf_t, 0.01)
    assert example_expected["example_27"]["buckling factor"] == pytest.approx(example_27.calculation, 0.01)
    assert example_expected["example_27"]["buckling factor interpolate"] == pytest.approx(example_27.bf_int, 0.01)
    assert example_expected["example_27"]["sigma_cr"] == pytest.approx(example_27.sigma_cr, 0.01)

    # example 28
    assert example_expected["example_28"]["b/a ratio"] == pytest.approx(example_28.b_a, 0.01)
    assert example_expected["example_28"]["t/b ratio"] == pytest.approx(example_28.t_b, 0.01)
    assert example_expected["example_28"]["kdf_t"] == pytest.approx(example_28.kdf_t, 0.01)
    assert example_expected["example_28"]["buckling factor"] == pytest.approx(example_28.calculation, 0.01)
    assert example_expected["example_28"]["buckling factor interpolate"] == pytest.approx(example_28.bf_int, 0.01)
    assert example_expected["example_28"]["sigma_cr"] == pytest.approx(example_28.sigma_cr, 0.01)

    # example 29
    assert example_expected["example_29"]["b/a ratio"] == pytest.approx(example_29.b_a, 0.01)
    assert example_expected["example_29"]["t/b ratio"] == pytest.approx(example_29.t_b, 0.01)
    assert example_expected["example_29"]["kdf_t"] == pytest.approx(example_29.kdf_t, 0.01)
    assert example_expected["example_29"]["buckling factor"] == pytest.approx(example_29.calculation, 0.01)
    assert example_expected["example_29"]["buckling factor interpolate"] == pytest.approx(example_29.bf_int, 0.01)
    assert example_expected["example_29"]["sigma_cr"] == pytest.approx(example_29.sigma_cr, 0.01)

    # example 30
    assert example_expected["example_30"]["b/a ratio"] == pytest.approx(example_30.b_a, 0.01)
    assert example_expected["example_30"]["t/b ratio"] == pytest.approx(example_30.t_b, 0.01)
    assert example_expected["example_30"]["kdf_t"] == pytest.approx(example_30.kdf_t, 0.01)
    assert example_expected["example_30"]["buckling factor"] == pytest.approx(example_30.calculation, 0.01)
    assert example_expected["example_30"]["buckling factor interpolate"] == pytest.approx(example_30.bf_int, 0.01)
    assert example_expected["example_30"]["sigma_cr"] == pytest.approx(example_30.sigma_cr, 0.01)

    # example 31
    assert example_expected["example_31"]["b/a ratio"] == pytest.approx(example_31.b_a, 0.01)
    assert example_expected["example_31"]["t/b ratio"] == pytest.approx(example_31.t_b, 0.01)
    assert example_expected["example_31"]["kdf_t"] == pytest.approx(example_31.kdf_t, 0.01)
    assert example_expected["example_31"]["buckling factor"] == pytest.approx(example_31.calculation, 0.01)
    assert example_expected["example_31"]["buckling factor interpolate"] == pytest.approx(example_31.bf_int, 0.01)
    assert example_expected["example_31"]["sigma_cr"] == pytest.approx(example_31.sigma_cr, 0.01)

    # example 32
    assert example_expected["example_32"]["b/a ratio"] == pytest.approx(example_32.b_a, 0.01)
    assert example_expected["example_32"]["t/b ratio"] == pytest.approx(example_32.t_b, 0.01)
    assert example_expected["example_32"]["kdf_t"] == pytest.approx(example_32.kdf_t, 0.01)
    assert example_expected["example_32"]["buckling factor"] == pytest.approx(example_32.calculation, 0.01)
    assert example_expected["example_32"]["buckling factor interpolate"] == pytest.approx(example_32.bf_int, 0.01)
    assert example_expected["example_32"]["sigma_cr"] == pytest.approx(example_32.sigma_cr, 0.01)

    # example 33
    assert example_expected["example_33"]["b/a ratio"] == pytest.approx(example_33.b_a, 0.01)
    assert example_expected["example_33"]["t/b ratio"] == pytest.approx(example_33.t_b, 0.01)
    assert example_expected["example_33"]["kdf_t"] == pytest.approx(example_33.kdf_t, 0.01)
    assert example_expected["example_33"]["buckling factor"] == pytest.approx(example_33.calculation, 0.01)
    assert example_expected["example_33"]["buckling factor interpolate"] == pytest.approx(example_33.bf_int, 0.01)
    assert example_expected["example_33"]["sigma_cr"] == pytest.approx(example_33.sigma_cr, 0.01)

    # example 34
    assert example_expected["example_34"]["b/a ratio"] == pytest.approx(example_34.b_a, 0.01)
    assert example_expected["example_34"]["t/b ratio"] == pytest.approx(example_34.t_b, 0.01)
    assert example_expected["example_34"]["kdf_t"] == pytest.approx(example_34.kdf_t, 0.01)
    assert example_expected["example_34"]["buckling factor"] == pytest.approx(example_34.calculation, 0.01)
    assert example_expected["example_34"]["buckling factor interpolate"] == pytest.approx(example_34.bf_int, 0.01)
    assert example_expected["example_34"]["sigma_cr"] == pytest.approx(example_34.sigma_cr, 0.01)
