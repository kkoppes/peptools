from typing import Any
import pytest
from makerspace_mbe_pylantir.pydonau.alchemy.alchemy import Solution
from makerspace_mbe_pylantir.pydonau.alchemy.opera import Opus
from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)

from makerspace_mbe_pylantir.pyelbe.morgul.neuber_mitigation_corner import (
    NeuberMitigationTension,
)


@pytest.fixture
def AIMS03_04_012() -> MetallicMaterial:
    mat = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-012",
        properties=IsoElastic(
            E=69000.0,
            Ec=70300.0,
            G=26200.0,
            nu=0.33,
        ),
        allowables=MetallicAllowables(
            Fcy=290.0,
            Fty=260.0,
            Fc1=0.0,
            Ft1=0.0,
            Ftu=430.0,
            Fsu=255.0,
            b10=0.0,
            e=0.15,
            n=23.0,
            nc=17.0,
        ),
        billet=Billet(nominal=4.0),
    )
    return mat


@pytest.fixture
def AIMS03_04_012_dict() -> dict[str, Any]:
    mat: dict[str, Any] = {
        "name": "2024-Clad_T42_Sheet",
        "specification": "AIMS03-04-012",
        "properties": {
            "E": 69000.0,
            "Ec": 70300.0,
            "G": 26200.0,
            "nu": 0.33,
        },
        "allowables": {
            "Fcy": 290.0,
            "Fty": 260.0,
            "Fc1": 0.0,
            "Ft1": 0.0,
            "Ftu": 430.0,
            "Fsu": 255.0,
            "b10": 0.0,
            "e": 0.15,
            "n": 23.0,
            "nc": 17.0,
            "basis": "B",
            "orientation": "L",
        },
        "billet": 4.0,
    }

    return mat


@pytest.fixture
def AIMS03_18_007() -> MetallicMaterial:
    mat = MetallicMaterial(
        name="Ti-6Al-4V_b_Annealed_Plate",
        specification="AIMS03-18-007",
        properties=IsoElastic(
            E=116500.0,
            Ec=113000.0,
            G=41000.0,
            nu=0.34,
        ),
        allowables=MetallicAllowables(
            Fcy=770.0,
            Fty=910.0,
            Fc1=0.0,
            Ft1=0.0,
            Ftu=980.0,
            Fsu=485.0,
            b10=0.0,
            e=0.025,
            n=33.0,
            nc=28.0,
            basis="B",
            orientation="L",
        ),
        billet=Billet(nominal=20.0),
    )
    return mat


@pytest.fixture
def neuber_mitigation(AIMS03_04_012: MetallicMaterial) -> NeuberMitigationTension:
    material: MetallicMaterial = AIMS03_04_012
    applied_stress = 448.31  # Example load value
    ultimate_e_neuber_all = 0.025
    theory = "ellipse"
    load_type = "ultimate"
    mode = "tension"
    input_dict: dict[str, Any] = {
        "analysis_name": "Neuber mitigation test using MetallicMaterial object as input",
        "material": material,
        "applied_stress": applied_stress,
        "ultimate_e_neuber_all": ultimate_e_neuber_all,
        "hsb34201_01_analysis_method": "Analysis using Ramberg-Osgood equation for stress-strain law",
        "theory": theory,
        "load_type": load_type,
        "mode": mode,
    }
    return NeuberMitigationTension(input_dict=input_dict)


@pytest.fixture
def neuber_mitigation_mat_dict(
    AIMS03_04_012_dict: dict[str, Any]
) -> NeuberMitigationTension:
    material: dict[str, Any] = AIMS03_04_012_dict
    applied_stress = 448.31  # Example load value
    ultimate_e_neuber_all = 0.025
    theory = "ellipse"
    load_type = "ultimate"
    mode = "tension"
    input_dict: dict[str, Any] = {
        "analysis_name": "Neuber mitigation test using dict[str, Any] material as input",
        "material": material,
        "applied_stress": applied_stress,
        "ultimate_e_neuber_all": ultimate_e_neuber_all,
        "hsb34201_01_analysis_method": "Analysis using Ramberg-Osgood equation for stress-strain law",
        "theory": theory,
        "load_type": load_type,
        "mode": mode,
    }
    return NeuberMitigationTension(input_dict=input_dict)


@pytest.fixture
def neuber_mitigation_method_3_2(
    AIMS03_18_007: MetallicMaterial,
) -> NeuberMitigationTension:
    material: MetallicMaterial = AIMS03_18_007
    applied_stress = 1730.0
    input_dict: dict[str, Any] = {
        "analysis_name": "Neuber mitigation test using method 3.2, i.e. tabulated stress-strain curve",
        "material": material,
        "applied_stress": applied_stress,
        "hsb34201_01_analysis_method": "Analysis using tabulated stress-strain law",
        "x_axis_list": [
            0,
            0.0052,
            0.006,
            0.0069,
            0.0091,
            0.0164,
            0.0199,
            0.0248,
            0.0315,
            0.0408,
            0.0535,
        ],
        "y_axis_list": [0, 600, 700, 800, 900, 950, 960, 970, 980, 990, 1000],
        "x_axis_comp_list": [],
        "y_axis_comp_list": [],
    }
    return NeuberMitigationTension(input_dict=input_dict)


def test_mitigate(neuber_mitigation: NeuberMitigationTension) -> None:
    result: Solution = neuber_mitigation.calculation
    assert result["neuber_stress"] == pytest.approx(273.9634)


def test_mitigate_mat_dict(neuber_mitigation_mat_dict: NeuberMitigationTension) -> None:
    result: Solution = neuber_mitigation_mat_dict.calculation
    assert result["neuber_stress"] == pytest.approx(273.9634)


# def test_mitigate_method_3_1(
#     neuber_mitigation_method_3_1: NeuberMitigationTension,
# ) -> None:
#     result: Solution = neuber_mitigation_method_3_1.calculation
#     assert result["neuber_stress"] == pytest.approx(972.43, 0.001)
#     assert result["neuber_rf"] == pytest.approx(1.0078, 0.001)


def test_mitigate_method_3_2(
    neuber_mitigation_method_3_2: NeuberMitigationTension,
) -> None:
    result: Solution = neuber_mitigation_method_3_2.calculation
    method_calculation: Opus = neuber_mitigation_method_3_2.example_calculation
    assert result["neuber_stress"] == pytest.approx(972.43, 0.001)
    assert result["neuber_rf"] == pytest.approx(1.0078, 0.001)
    assert isinstance(method_calculation, Opus)


# def test_mitigate_method_3_3(
#     neuber_mitigation_method_3_3: NeuberMitigationTension,
# ) -> None:
#     result: Solution = neuber_mitigation_method_3_3.calculation
#     assert result["neuber_stress"] == pytest.approx(972.43, 0.001)
#     assert result["neuber_rf"] == pytest.approx(1.0078, 0.001)
