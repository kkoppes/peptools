import os
from pathlib import Path
from typing import Any
import pytest
from makerspace_mbe_pylantir.pyelbe.matreel.material import (
    Billet,
    IsoElastic,
    MetallicAllowables,
    MetallicMaterial,
)

# from makerspace_mbe_pylantir.pyelbe.morgul.HSB_34201 import (
#     HSB_34201_01,
# )
from makerspace_mbe_pylantir.pyelbe.morgul.HSB_34201 import (
    HSB34201_01_Method31,
    HSB34201_01_Method33,
)

from makerspace_mbe_pylantir.scrolls import get_logger  # type: ignore
import logging

logger: logging.Logger = get_logger(__name__, level=logging.DEBUG)

logger_path = Path(__name__ + ".log")


@pytest.fixture(autouse=True)
def cleanup_files():
    """Remove the test files."""
    if logger_path.exists():
        os.remove(logger_path)


# ------------------------------
# ┏┳┓┏┓┏┓┏┳┓  ┏┓┏┓┏┓┳┓┏┓┳┓┳┏┓┏┓
#  ┃ ┣ ┗┓ ┃   ┗┓┃ ┣ ┃┃┣┫┣┫┃┃┃┗┓
#  ┻ ┗┛┗┛ ┻   ┗┛┗┛┗┛┛┗┛┗┛┗┻┗┛┗┛


@pytest.fixture
def input_set_1() -> dict[str, Any]:
    """Test HSB_34201_01 class."""
    # Manual material definition for method 3.1
    model_scenario: dict[str, Any] = {
        "analysis_name::str": "Neuber Analysis using Ramberg-Osgood equation for stress-strain law",
        "material::dict": {
            "name": "2024-Clad_T42_Sheet",
            "specification": "AIMS03-04-012",
            "properties": {
                "E": 69000.0,
                "Ec": 70300.0,
                "G": 26200.0,
                "nu": 0.33,
            },
            "allowables": {
                "Fcy": 290.0,
                "Fty": 260.0,
                "Fc1": 0.0,
                "Ft1": 0.0,
                "Ftu": 430.0,
                "Fsu": 255.0,
                "b10": 0.0,
                "e": 0.15,
                "n": 23.0,
                "nc": 17.0,
                "basis": "B",
                "orientation": "L",
            },
            "billet": 4.0,
        },
        "s_linear::float": 1730,
        "e_neuber_allowable::float": 0.025,
        "theory::str": "ellipse",
        "loading_type::str": "ultimate",
        "mode::str": "tension",
    }
    return model_scenario


@pytest.fixture
def input_set_2() -> dict[str, Any]:
    """Test HSB_34201_01 class."""
    # Manual material definition for method 3.3
    model_scenario: dict[str, Any] = {
        "analysis_name::str": "Neuber Analysis using Ramberg-Osgood equation for stress-strain law",
        "material::dict": {
            "name": "2024-Clad_T42_Sheet",
            "specification": "AIMS03-04-012",
            "properties": {
                "E": 69000.0,
                "Ec": 70300.0,
                "G": 26200.0,
                "nu": 0.33,
            },
            "allowables": {
                "Fcy": 290.0,
                "Fty": 260.0,
                "Fc1": 0.0,
                "Ft1": 0.0,
                "Ftu": 430.0,
                "Fsu": 255.0,
                "b10": 0.0,
                "e": 0.15,
                "n": 23.0,
                "nc": 17.0,
                "basis": "B",
                "orientation": "L",
            },
            "billet": 4.0,
        },
        "s_linear_ult::float": 1730,
        "s_linear_lim::float": 1153,
        "e_neuber_allowable_ult::float": 0.025,
        "e_neuber_allowable_lim::float": 0.005,
        "theory::Literal['ellipse','roext','rostd']": "ellipse",
        "loading_type::Literal['limit','ultimate']": "ultimate",
        "mode::Literal['tension','compression']": "tension",
    }
    return model_scenario


@pytest.fixture
def AIMS03_18_007() -> MetallicMaterial:
    mat = MetallicMaterial(
        name="Ti-6Al-4V_b_Annealed_Plate",
        specification="AIMS03-18-007",
        properties=IsoElastic(
            E=116500.0,
            Ec=113000.0,
            G=41000.0,
            nu=0.34,
        ),
        allowables=MetallicAllowables(
            Fcy=770.0,
            Fty=910.0,
            Fc1=0.0,
            Ft1=0.0,
            Ftu=980.0,
            Fsu=485.0,
            b10=0.0,
            e=0.025,
            n=33.0,
            nc=28.0,
            basis="B",
            orientation="L",
        ),
        billet=Billet(nominal=20.0),
    )
    return mat


@pytest.fixture
def test_inputs_with_mat_object(AIMS03_18_007: MetallicMaterial) -> dict[str, Any]:
    analysis_name = "Neuber mitigation test using MetallicMaterial object as input"
    material: MetallicMaterial = AIMS03_18_007
    s_linear = 1730
    ultimate_e_neuber_all = 0.025
    theory = "ellipse"
    load_type = "ultimate"
    mode = "tension"
    input_dict: dict[str, Any] = {
        "analysis_name::str": analysis_name,
        "material::MetallicMaterial": material,
        "s_linear::float": s_linear,
        "e_neuber_allowable::float": ultimate_e_neuber_all,
        "theory::str": theory,
        "loading_type::str": load_type,
        "mode::str": mode,
    }
    return input_dict


def test_scenario_1() -> None:
    """Test with default attributes from json file."""

    hsb34201 = HSB34201_01_Method31()

    assert (
        hsb34201.input["analysis_name"]
        == "Neuber Analysis using Ramberg-Osgood equation for stress-strain law"
    )
    assert hsb34201.material.name == "Ti-6Al-4V_b_Annealed_Plate"
    assert hsb34201.material.specification == "AIMS03-18-007"
    assert hsb34201.input["mode"] == "tension"
    assert round(hsb34201.ramberg_osgood_exponent, 2) == pytest.approx(33, 0.001)  # type: ignore
    assert round(hsb34201.modulus_of_elasticity, 2) == pytest.approx(116500, 0.001)  # type: ignore
    assert round(hsb34201.yield_strength, 2) == pytest.approx(910, 0.001)  # type: ignore
    assert round(hsb34201.ultimate_strength, 2) == pytest.approx(980, 0.001)  # type: ignore
    assert round(hsb34201.sigma_linear, 2) == pytest.approx(1730, 0.001)  # type: ignore
    assert round(hsb34201.neuber_stress, 2) == pytest.approx(972.8, 0.001)  # type: ignore
    assert round(hsb34201.neuber_rf, 2) == pytest.approx(1.01, 0.001)  # type: ignore
    assert isinstance(hsb34201.__str__(), str)


def test_scenario_2(input_set_1: dict[str, Any]) -> None:
    """Test with default attributes from json file."""
    hsb34201 = HSB34201_01_Method31(input_set_1)  # type: ignore

    assert (
        hsb34201.input["analysis_name"]
        == "Neuber Analysis using Ramberg-Osgood equation for stress-strain law"
    )
    assert hsb34201.material.name == "2024-Clad_T42_Sheet"
    assert hsb34201.material.specification == "AIMS03-04-012"
    assert hsb34201.input["mode"] == "tension"
    assert round(hsb34201.ramberg_osgood_exponent, 2) == pytest.approx(23, 0.001)  # type: ignore
    assert round(hsb34201.modulus_of_elasticity, 2) == pytest.approx(69000, 0.001)  # type: ignore
    assert round(hsb34201.yield_strength, 2) == pytest.approx(260, 0.001)  # type: ignore
    assert round(hsb34201.ultimate_strength, 2) == pytest.approx(1.5 * 260, 0.001)  # type: ignore
    assert round(hsb34201.sigma_linear, 2) == pytest.approx(1730, 0.001)  # type: ignore
    assert round(hsb34201.neuber_stress, 2) == pytest.approx(312.19, 0.001)  # type: ignore
    assert round(hsb34201.neuber_rf, 2) == pytest.approx(1.25, 0.001)  # type: ignore
    assert isinstance(hsb34201.__str__(), str)


def test_scenario_3() -> None:
    """Test with default attributes from json file."""
    hsb34201 = HSB34201_01_Method33()

    assert (
        hsb34201.input["analysis_name"]
        == "Neuber Analysis using Ramberg-Osgood equation for stress-strain law"
    )
    assert (
        hsb34201.input["analysis_name"]
        == "Neuber Analysis using Ramberg-Osgood equation for stress-strain law"
    )
    assert hsb34201.material.name == "Ti-6Al-4V_b_Annealed_Plate"
    assert hsb34201.material.specification == "AIMS03-18-007"
    assert hsb34201.input["mode"] == "tension"
    assert round(hsb34201.modulus_of_elasticity, 2) == pytest.approx(116500, 0.001)  # type: ignore
    assert round(hsb34201.proof_strength, 2) == pytest.approx(910, 0.001)  # type: ignore
    assert round(hsb34201.e_neuber_allowable_ult, 3) == pytest.approx(0.025, 0.001)  # type: ignore
    assert round(hsb34201.e_neuber_allowable_lim, 3) == pytest.approx(0.005, 0.001)  # type: ignore
    assert round(hsb34201.sigma_linear_ult, 2) == pytest.approx(1730, 0.001)  # type: ignore
    assert round(hsb34201.sigma_linear_lim, 2) == pytest.approx(1153, 0.001)  # type: ignore
    assert round(hsb34201.neuber_rf_ult, 2) == pytest.approx(1.08, 0.001)  # type: ignore
    assert round(hsb34201.neuber_rf_lim, 2) == pytest.approx(1.01, 0.001)  # type: ignore
    assert isinstance(hsb34201.__str__(), str)


def test_scenario_4(input_set_2: dict[str, Any]) -> None:
    """Test with default attributes from json file."""
    hsb34201 = HSB34201_01_Method33(input_set_2)  # type: ignore

    assert (
        hsb34201.input["analysis_name"]
        == "Neuber Analysis using Ramberg-Osgood equation for stress-strain law"
    )
    assert hsb34201.material.name == "2024-Clad_T42_Sheet"
    assert hsb34201.material.specification == "AIMS03-04-012"
    assert hsb34201.input["mode"] == "tension"
    assert round(hsb34201.modulus_of_elasticity, 2) == pytest.approx(69000, 0.001)  # type: ignore
    assert round(hsb34201.proof_strength, 2) == pytest.approx(260, 0.001)  # type: ignore
    assert round(hsb34201.e_neuber_allowable_ult, 3) == pytest.approx(0.025, 0.001)  # type: ignore
    assert round(hsb34201.e_neuber_allowable_lim, 3) == pytest.approx(0.005, 0.001)  # type: ignore
    assert round(hsb34201.sigma_linear_ult, 2) == pytest.approx(1730, 0.001)  # type: ignore
    assert round(hsb34201.sigma_linear_lim, 2) == pytest.approx(1153, 0.001)  # type: ignore
    assert round(hsb34201.neuber_rf_ult, 2) == pytest.approx(0.42, 0.001)  # type: ignore
    assert round(hsb34201.neuber_rf_lim, 2) == pytest.approx(0.34, 0.001)  # type: ignore
    assert isinstance(hsb34201.__str__(), str)


def test_scenario_5(test_inputs_with_mat_object: dict[str, Any]) -> None:
    """Test with default attributes from json file."""
    hsb34201 = HSB34201_01_Method31(test_inputs_with_mat_object)

    assert (
        hsb34201.input["analysis_name"]
        == "Neuber mitigation test using MetallicMaterial object as input"
    )
    assert hsb34201.material.name == "Ti-6Al-4V_b_Annealed_Plate"
    assert hsb34201.material.specification == "AIMS03-18-007"
    assert hsb34201.input["theory"] == "ellipse"
    assert hsb34201.input["mode"] == "tension"
    assert hsb34201.input["s_linear"] == 1730
    assert round(hsb34201.ramberg_osgood_exponent, 2) == pytest.approx(33, 0.001)  # type: ignore
    assert round(hsb34201.modulus_of_elasticity, 2) == pytest.approx(116500, 0.001)  # type: ignore
    assert round(hsb34201.yield_strength, 2) == pytest.approx(910, 0.001)  # type: ignore
    assert round(hsb34201.ultimate_strength, 2) == pytest.approx(980, 0.001)  # type: ignore
    assert round(hsb34201.sigma_linear, 2) == pytest.approx(1730, 0.001)  # type: ignore
    assert round(hsb34201.neuber_stress, 2) == pytest.approx(972.8, 0.001)  # type: ignore
    assert round(hsb34201.neuber_rf, 2) == pytest.approx(1.01, 0.001)  # type: ignore
    assert isinstance(hsb34201.__str__(), str)
