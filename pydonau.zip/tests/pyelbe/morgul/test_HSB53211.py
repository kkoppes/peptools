import pytest
import sys
import math
from abc import ABC, abstractmethod

from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)

from makerspace_mbe_pylantir.pyweser.isamilib import TMaterial


for path in sys.path:
    print(path)
from makerspace_mbe_pylantir.pyelbe.morgul.HSB53211_01_crippling.crippling_utils import (
    ElmBasicAvgWidthFunc as utl,
)
from makerspace_mbe_pylantir.pyelbe.morgul.HSB53211_01_crippling.met_sec_crippl import (
    Met_Elm_Crippling_Strength as mtlcrp,
    Met_Section_Crippling_Load as mtlcrpload,
)

from makerspace_mbe_pylantir.pyelbe.mechanica.profiles.profile_mapping import (
    ProfElmConnF,
    ProfElmConnLS,
    ProfElmConnLE,
    ProfElmConnT,
    ProfElm,
    ProfMapp,
)
from makerspace_mbe_pylantir.pyelbe.morgul.HSB53211_01_crippling.profile_crippl import (
    ProfCripplCalc,
)


# @pytest.fixture
# def mat_7175_T7351_Plate():
#    isami_version = "v11.4.0"
#    material_name = "7175_T7351_Plate"
#    specification = "AIMS03-02-008"
#    billet = 50.0
#    basis = "B"
#    orientation = "L"

#    tmat = TMaterial(
#        version=isami_version,
#        name=material_name,
#    )
#    tmat.get_material(
#        spec=specification, billet=billet, basis=basis, orientation=orientation
#    )
#    return tmat.material


@pytest.fixture
def mat_7175_T7351_Plate():
    mat = MetallicMaterial(
        name="2024-Clad_T3510",
        specification="AIMS..-..-...",
        properties=IsoElastic(E=71000.0, Ec=73000.0, G=26900.0, nu=0.33),
        allowables=MetallicAllowables(
            Fcy=380.0,
            Fty=395.0,
            Fc1=0.0,
            Ft1=0.0,
            Ftu=470.0,
            Fsu=290.0,
            b10=0.0,
            e=0.06,
            n=15.0,
            nc=16.0,
        ),
        billet=Billet(nominal=50.0),
    )
    return mat


@pytest.fixture
def material():
    mat = MetallicMaterial(
        name="2024-Clad_T3510",
        specification="AIMS..-..-...",
        properties=IsoElastic(E=75900.0, Ec=75900.0, G=26200.0, nu=0.33),
        allowables=MetallicAllowables(
            Fcy=235.0,
            Fty=290.0,
            Fc1=0.0,
            Ft1=0.0,
            Ftu=430.0,
            Fsu=255.0,
            b10=0.0,
            e=0.15,
            n=22.0,
            nc=22.0,
        ),
        billet=Billet(nominal=20.0),
    )
    return mat


class TestBasic:
    @pytest.fixture
    def profile_type(self):
        profile = "E"
        return profile

    @pytest.fixture
    def flange_width(self):
        width = 25
        return width

    @pytest.fixture
    def flange_thk(self):
        thk = 2.5
        return thk

    @pytest.fixture
    def web_width(self):
        width = 40
        return width

    @pytest.fixture
    def web_thk(self):
        thk = 2.5
        return thk

    @pytest.fixture
    def radius(self):
        radius = 2.5
        return radius

    @pytest.fixture
    def flange_avg_width(self, flange_width, flange_thk, web_thk, radius, profile_type):
        avg_width = utl.avg_width_E_prof(
            elm_out_width=flange_width,
            elm_thk=flange_thk,
            adj_elm_thk=web_thk,
            radius=radius,
            Profile_Type=profile_type,
            Elm_Type="Flange",
        )
        return avg_width

    @pytest.fixture
    def web_avg_width(self, web_width, web_thk, flange_thk, radius, profile_type):
        avg_width = utl.avg_width_E_prof(
            elm_out_width=web_width,
            elm_thk=web_thk,
            adj_elm_thk=flange_thk,
            radius=radius,
            Profile_Type=profile_type,
            Elm_Type="Web",
        )
        return avg_width

    @pytest.fixture
    def flange_elm(self, profile_type, flange_avg_width, flange_thk, radius, material):
        elm_crippl = mtlcrp(
            profile_type=profile_type,
            elm_type="Flange",
            elm_support="one_side",
            elm_avg_width=flange_avg_width,
            elm_thk=flange_thk,
            radius=radius,
            Rp02=material.allowables.Fty,
            Rc02=material.allowables.Fcy,
            Ec=material.properties.Ec,
        )
        return elm_crippl

    @pytest.fixture
    def web_support_cond(self, web_width, flange_width, flange_thk):
        support_cond = utl.support_criteria(
            elm_out_width=web_width,
            adj_elm_out_width=flange_width,
            adj_elm_thk=flange_thk,
        )
        return support_cond

    @pytest.fixture
    def web_elm(self, profile_type, web_avg_width, web_thk, radius, material):
        elm_crippl = mtlcrp(
            profile_type=profile_type,
            elm_type="Web",
            elm_support="both_sides",
            elm_avg_width=web_avg_width,
            elm_thk=web_thk,
            radius=radius,
            Rp02=material.allowables.Fty,
            Rc02=material.allowables.Fcy,
            Ec=material.properties.Ec,
        )
        return elm_crippl

    @pytest.fixture
    def crippl_load_allow(self, flange_elm, web_elm, material):
        profile_elm_list = [flange_elm, flange_elm, web_elm]
        Rc02 = material.allowables.Fcy
        crippl_load = mtlcrpload(list_elm=profile_elm_list, cutoff="True", Rc02=Rc02)
        return crippl_load

    def test_main(
        self,
        material,
        flange_avg_width,
        web_avg_width,
        flange_elm,
        web_support_cond,
        web_elm,
        crippl_load_allow,
    ):
        assert material.allowables.Fcy == 235.0
        assert flange_avg_width == 24.0
        assert web_avg_width == 38.0
        assert round(flange_elm.sig_crip, 0) == 237
        assert web_support_cond
        assert round(web_elm.sig_crip, 0) == 316
        assert round(crippl_load_allow.crippling_load, 0) == 50525.0


class TestProfileZ:
    @pytest.fixture
    def list_conns(self):
        conn1 = ProfElmConnF(conn_id=1, conn_elm_ids=[1])
        conn2 = ProfElmConnLE(conn_id=2, conn_elm_ids=[1, 2], radius_inner=3)
        conn3 = ProfElmConnLE(conn_id=3, conn_elm_ids=[2, 3], radius_inner=3)
        conn4 = ProfElmConnF(conn_id=4, conn_elm_ids=[3])
        return [conn1, conn2, conn3, conn4]

    @pytest.fixture
    def list_elements(self, mat_7175_T7351_Plate, list_conns):
        elm1 = ProfElm(
            elm_id=1,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=30,
            elm_thk=2,
            conn_A=list_conns[0],
            conn_B=list_conns[1],
            elm_support=["unsupported", "supported"],
        )

        elm2 = ProfElm(
            elm_id=2,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=60,
            elm_thk=2,
            conn_A=list_conns[1],
            conn_B=list_conns[2],
            elm_support=["supported", "supported"],
        )

        elm3 = ProfElm(
            elm_id=3,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=30,
            elm_thk=2,
            conn_A=list_conns[2],
            conn_B=list_conns[3],
            elm_support=["supported", "unsupported"],
        )
        return [elm1, elm2, elm3]

    @pytest.fixture
    def profileZ(self, list_conns, list_elements):
        profile = ProfMapp(
            list_elements=list_elements, list_elm_conns=list_conns, cutoff=True
        )
        return profile

    @pytest.fixture
    def profile_crippl(self, profileZ):
        profcrip = ProfCripplCalc(profile=profileZ, cutoff=True)
        return profcrip

    def test_crippl_load(self, profile_crippl):
        crippl_load = profile_crippl.profcrippload.crippling_load
        assert math.floor(crippl_load) == 53433


class TestProfileT:
    @pytest.fixture
    def list_conns(self):
        conn1 = ProfElmConnF(conn_id=1, conn_elm_ids=[1])
        conn2 = ProfElmConnT(conn_id=2, conn_elm_ids=[1, 2, 3], radius_inner=3)
        conn3 = ProfElmConnF(conn_id=3, conn_elm_ids=[2])
        conn4 = ProfElmConnF(conn_id=4, conn_elm_ids=[3])
        return [conn1, conn2, conn3, conn4]

    @pytest.fixture
    def list_elements(self, mat_7175_T7351_Plate, list_conns):
        elm1 = ProfElm(
            elm_id=1,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=30,
            elm_thk=2,
            conn_A=list_conns[0],
            conn_B=list_conns[1],
            elm_support=["unsupported", "supported"],
        )

        elm2 = ProfElm(
            elm_id=2,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=30,
            elm_thk=2,
            conn_A=list_conns[1],
            conn_B=list_conns[2],
            elm_support=["supported", "unsupported"],
        )

        elm3 = ProfElm(
            elm_id=3,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=58,
            elm_thk=2,
            conn_A=list_conns[1],
            conn_B=list_conns[3],
            elm_support=["supported", "unsupported"],
        )
        return [elm1, elm2, elm3]

    @pytest.fixture
    def profileT(self, list_conns, list_elements):
        profile = ProfMapp(
            list_elements=list_elements, list_elm_conns=list_conns, cutoff=True
        )
        return profile

    @pytest.fixture
    def profile_crippl(self, profileT):
        profcrip = ProfCripplCalc(profile=profileT, cutoff=True)
        return profcrip

    def test_crippl_load(self, profile_crippl):
        crippl_load = profile_crippl.profcrippload.crippling_load
        assert math.floor(crippl_load) == 34544


class TestProfileI:
    @pytest.fixture
    def list_conns(self):
        conn1 = ProfElmConnF(conn_id=1, conn_elm_ids=[1])
        conn2 = ProfElmConnT(conn_id=2, conn_elm_ids=[1, 2, 3], radius_inner=4)
        conn3 = ProfElmConnF(conn_id=3, conn_elm_ids=[2])
        conn4 = ProfElmConnF(conn_id=4, conn_elm_ids=[4])
        conn5 = ProfElmConnT(conn_id=5, conn_elm_ids=[5, 4, 3], radius_inner=4)
        conn6 = ProfElmConnF(conn_id=6, conn_elm_ids=[5])
        return [conn1, conn2, conn3, conn4, conn5, conn6]

    @pytest.fixture
    def list_elements(self, mat_7175_T7351_Plate, list_conns):
        elm1 = ProfElm(
            elm_id=1,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=20,
            elm_thk=4,
            conn_A=list_conns[0],
            conn_B=list_conns[1],
            elm_support=["unsupported", "supported"],
        )

        elm2 = ProfElm(
            elm_id=2,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=20,
            elm_thk=4,
            conn_A=list_conns[1],
            conn_B=list_conns[2],
            elm_support=["supported", "unsupported"],
        )

        elm3 = ProfElm(
            elm_id=3,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=40,
            elm_thk=3,
            conn_A=list_conns[1],
            conn_B=list_conns[4],
            elm_support=["supported", "supported"],
        )

        elm4 = ProfElm(
            elm_id=4,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=20,
            elm_thk=4,
            conn_A=list_conns[3],
            conn_B=list_conns[4],
            elm_support=["unsupported", "supported"],
        )

        elm5 = ProfElm(
            elm_id=5,
            elm_geom="Flat",
            elm_mat=mat_7175_T7351_Plate,
            elm_out_width=20,
            elm_thk=4,
            conn_A=list_conns[4],
            conn_B=list_conns[5],
            elm_support=["supported", "unsupported"],
        )

        return [elm1, elm2, elm3, elm4, elm5]

    @pytest.fixture
    def profileT(self, list_conns, list_elements):
        profile = ProfMapp(
            list_elements=list_elements, list_elm_conns=list_conns, cutoff=True
        )
        return profile

    @pytest.fixture
    def profile_crippl(self, profileT):
        profcrip = ProfCripplCalc(profile=profileT, cutoff=True)
        return profcrip

    def test_crippl_load(self, profile_crippl):
        crippl_load = profile_crippl.profcrippload.crippling_load
        assert math.floor(crippl_load) == 163058
