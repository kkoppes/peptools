import pytest
from makerspace_mbe_pylantir.pyelbe.morgul.HSB45131 import HSB45131_01
from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)


@pytest.fixture
def tmat_2024():
    mat = MetallicMaterial(
        name="2024-Clad_T42_Sheet",
        specification="AIMS03-04-012",
        properties=IsoElastic(E=65500.0, Ec=66900.0, G=24900.0, nu=0.33),
        allowables=MetallicAllowables(
            Fcy=270.0,
            Fty=240.0,
            # Fc1=0.0,
            # Ft1=0.0,
            Ftu=405.0,
            Fsu=240.0,
            # b10=0.0,
            e=0.15,
            n=23.0,
            nc=17.0,
        ),
        billet=Billet(nominal=1.6),
    )
    return mat


def test_create_instance(tmat_2024):
    material = tmat_2024
    s = 26
    t = 1.6
    c = 1.5
    HSB_test = HSB45131_01(
        fastener_pitch_s=s,
        sheet_thickness_t=t,
        clamping_factor_c=c,
        material=material,
    )
    assert HSB_test
    assert HSB_test.parameter == pytest.approx(0.93, 0.01)
    assert HSB_test.critical_inter_rivet_buckling_stress_scrirb == pytest.approx(
        196.76, 0.01
    )


def test_HSB_examples(tmat_2024):
    mat = tmat_2024
    mat.allowables.set(Fcy=290)
    mat.properties.set(Ec=73800)

    # Validation through examples of HSB sheet.
    fastener_pitch_s = 24
    sheet_thickness_t = 1.6

    # Example 1: solid rivet, flush head C = 1.5
    clamping_factor_c = 1.5
    example_1 = HSB45131_01(fastener_pitch_s, sheet_thickness_t, clamping_factor_c, mat)
    # Example 2: solid rivet, normal head C = 3.0
    clamping_factor_c = 3.0
    example_2 = HSB45131_01(fastener_pitch_s, sheet_thickness_t, clamping_factor_c, mat)
    # Example 3: lockbolt, flush head C = 2.0
    clamping_factor_c = 2.0
    example_3 = HSB45131_01(fastener_pitch_s, sheet_thickness_t, clamping_factor_c, mat)
    # Example 4:lockbolt, protruding head C = 4.0
    clamping_factor_c = 4.0
    example_4 = HSB45131_01(fastener_pitch_s, sheet_thickness_t, clamping_factor_c, mat)
    # Example 5: blind rivet, flush head C = 1.0
    clamping_factor_c = 1.0
    example_5 = HSB45131_01(fastener_pitch_s, sheet_thickness_t, clamping_factor_c, mat)
    # Example 5:blind rivet, normal head C = 2.0
    clamping_factor_c = 2.0
    example_6 = HSB45131_01(fastener_pitch_s, sheet_thickness_t, clamping_factor_c, mat)

    example_expected = {
        "example_1": {"phi": 0.8466, "sigma_cr": 222},
        "example_2": {"phi": 0.5986, "sigma_cr": 249},
        "example_3": {"phi": 0.7332, "sigma_cr": 235},
        "example_4": {"phi": 0.5184, "sigma_cr": 257},
        "example_5": {"phi": 1.0369, "sigma_cr": 197},
        "example_6": {"phi": 0.7332, "sigma_cr": 235},
    }

    assert example_expected["example_1"]["phi"] == pytest.approx(
        example_1.parameter, 0.01
    )
    assert example_expected["example_1"]["sigma_cr"] == pytest.approx(
        example_1.critical_inter_rivet_buckling_stress_scrirb, 0.5
    )

    assert example_expected["example_2"]["phi"] == pytest.approx(
        example_2.parameter, 0.01
    )
    assert example_expected["example_2"]["sigma_cr"] == pytest.approx(
        example_2.critical_inter_rivet_buckling_stress_scrirb, 0.5
    )

    assert example_expected["example_3"]["phi"] == pytest.approx(
        example_3.parameter, 0.01
    )
    assert example_expected["example_3"]["sigma_cr"] == pytest.approx(
        example_3.critical_inter_rivet_buckling_stress_scrirb, 0.5
    )

    assert example_expected["example_4"]["phi"] == pytest.approx(
        example_4.parameter, 0.01
    )
    assert example_expected["example_4"]["sigma_cr"] == pytest.approx(
        example_4.critical_inter_rivet_buckling_stress_scrirb, 0.5
    )

    assert example_expected["example_5"]["phi"] == pytest.approx(
        example_5.parameter, 0.01
    )
    assert example_expected["example_5"]["sigma_cr"] == pytest.approx(
        example_5.critical_inter_rivet_buckling_stress_scrirb, 0.5
    )
    assert example_expected["example_6"]["phi"] == pytest.approx(
        example_6.parameter, 0.01
    )
    assert example_expected["example_6"]["sigma_cr"] == pytest.approx(
        example_6.critical_inter_rivet_buckling_stress_scrirb, 0.5
    )
