import pytest
import warnings
from makerspace_mbe_pylantir.pyelbe.morgul.HSB21030 import (
    HSB21030_01,
    HSB21030Pin,
    HSB_FastenerGroup,
)
from makerspace_mbe_pylantir.scrolls import HSBReference
from makerspace_mbe_pylantir.pyelbe.matreel import (
    Material,
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)

from makerspace_mbe_pylantir.pyelbe.mechanica import PinAllowables


@pytest.fixture
def fastener_group_4():
    fastener_group_dict = {
        "fasteners": {
            "fastener_1": {"shear": 18500, "tension": 12000},
            "fastener_2": {"shear": 18500, "tension": 12000},
            "fastener_3": {"shear": 18500, "tension": 12000},
            "fastener_4": {"shear": 18500, "tension": 12000},
        },
        "locations": {
            "fastener_1": {"x": 0, "y": -70, "z": 35},
            "fastener_2": {"x": 0, "y": -40, "z": 35},
            "fastener_3": {"x": 0, "y": -40, "z": 15},
            "fastener_4": {"x": 0, "y": -60, "z": 15},
        },
    }
    group = HSB_FastenerGroup.from_dict(fastener_group_dict)
    return group


def test_fastener_group():
    fastener_group_dict = {
        "fasteners": {
            "fastener_1": {"shear": 18500, "tension": 12000},
            "fastener_2": {"shear": 18500, "tension": 12000},
            "fastener_3": {"shear": 18500, "tension": 12000},
            "fastener_4": {"shear": 18500, "tension": 12000},
        },
        "locations": {
            "fastener_1": {"x": 0, "y": -70, "z": 35},
            "fastener_2": {"x": 0, "y": -40, "z": 35},
            "fastener_3": {"x": 0, "y": -40, "z": 15},
            "fastener_4": {"x": 0, "y": -60, "z": 15},
        },
    }
    group = HSB_FastenerGroup.from_dict(fastener_group_dict)

    # *************** example from HSB **************
    # Shear yS = -52.5 mm zS = +25.0 mm
    assert group.centroid_s.x == 0
    assert group.centroid_s.y == -52.5
    assert group.centroid_s.z == 25.0

    # Tension yT = −52.5 mm zT = +25.0 mm
    assert group.centroid_t.x == 0
    assert group.centroid_t.y == -52.5
    assert group.centroid_t.z == 25.0


def test_HSB21030_01_init():
    test_method = HSB21030_01(name="Test", iterate_tension=False)
    assert test_method.name == "Test"
    # assert test_method.topology =


def test_HSB21030_01_reference():
    test_method = HSB21030_01(name="Test", iterate_tension=False)
    reference = HSBReference(
        title="HSB",
        version="1.4.0",
        issue="D",
        chapter_title="Internal load distribution of fastener groups",
        chapter="21030-01",
        link="https://hsb-2l51-d.epaas.eu.airbus.corp/separatedChapters/HSB-English-v1-4-0_chapter_20000-00.pdf",
        page=92,
    )
    assert test_method.reference == reference


def test_method_pin_initialization():
    # Test initialization of MethodPin
    method_pin = HSB21030Pin(standard="Standard1", Fsu=100.0, Ftu=200.0)
    assert method_pin.standard == "Standard1"
    assert method_pin.diameter == 1.0
    assert method_pin.dash == "1"
    assert isinstance(method_pin.allowables, PinAllowables)
    assert method_pin.allowables.Fsu == 100.0
    assert method_pin.allowables.Ftu == 200.0


def test_HSB_examples():
    input_dict = {
        "name": "test",
        "fasteners": {
            "fastener_1": {"shear": 18500, "tension": 12000},
            "fastener_2": {"shear": 18500, "tension": 12000},
            "fastener_3": {"shear": 18500, "tension": 12000},
            "fastener_4": {"shear": 18500, "tension": 12000},
        },
        "locations": {
            "fastener_1": {"x": 0, "y": -70, "z": 35},
            "fastener_2": {"x": 0, "y": -40, "z": 35},
            "fastener_3": {"x": 0, "y": -40, "z": 15},
            "fastener_4": {"x": 0, "y": -60, "z": 15},
        },
        "loads": {
            "forces": {"force_x": 10000, "force_y": 12000, "force_z": -2000},
            "moments": {"moment_x": -240000, "moment_y": 200000, "moment_z": 0},
            "application_point": {"x": 30, "y": 0, "z": 0},
            "reference_point": {"x": 0, "y": 0, "z": 0},
        },
    }

    hsb_calc = HSB21030_01.from_dict(input_dict)

    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # # Trigger the property
        _ = hsb_calc.fastener_tension_reserve_factor
        # # Ensure no warnings were raised
        assert len(w) == 0, f"Unexpected warnings: {w}"

    assert hsb_calc.moments_u.moment_x == -240000
    assert hsb_calc.moments_u.moment_y == 260000
    assert hsb_calc.moments_u.moment_z == 360000

    assert hsb_calc.moments_s_tens.moment_x == pytest.approx(-45000)
    assert hsb_calc.moments_s_tens.moment_y == pytest.approx(+10000)
    assert hsb_calc.moments_s_tens.moment_z == pytest.approx(-165000)

    assert hsb_calc.fastener_group_tens.centroid_s.y == -52.5
    assert hsb_calc.fastener_group_tens.centroid_s.z == 25.0

    assert hsb_calc.fastener_group_tens.centroid_t.y == -52.5
    assert hsb_calc.fastener_group_tens.centroid_t.z == 25.0

    HSB_Results = {
        "yi": [
            -70.0,
            -40.0,
            -40.0,
            -60.0,
        ],
        "zi": [
            +35.0,
            +35.0,
            +15.0,
            +15.0,
        ],
        "Fsyi": [
            +3420,
            +3420,
            +2580,
            +2580,
        ],
        "Fszi": [
            +230,
            -1020,
            -1020,
            -190,
        ],
        "Fsi": [
            +3430,
            +3570,
            +2780,
            +2590,
        ],
        "Fti": [
            -1120,
            +6620,
            +4830,
            -330,
        ],
    }

    assert all([a == pytest.approx(b) for a, b in zip(hsb_calc.result_dict_tens["Y"], HSB_Results["yi"])])
    assert all([a == pytest.approx(b) for a, b in zip(hsb_calc.result_dict_tens["Z"], HSB_Results["zi"])])
    # rounding error in HSB: 2.58kN vs 2581.4N
    assert all(
        [a == pytest.approx(b, rel=1e-2) for a, b in zip(hsb_calc.result_dict_tens["Fsyi"], HSB_Results["Fsyi"])]
    )
    # rounding error in HSB: -0.19kN vs -186.05N
    assert all(
        [a == pytest.approx(b, rel=3e-2) for a, b in zip(hsb_calc.result_dict_tens["Fszi"], HSB_Results["Fszi"])]
    )
    #  rounding error in HSB: 2.59kN vs 2588N
    assert all(
        [a == pytest.approx(b, rel=1e-2) for a, b in zip(hsb_calc.result_dict_tens["Shear Force"], HSB_Results["Fsi"])]
    )
    #  rounding error in HSB: -0.33kN vs -326.9N
    assert all(
        [
            a == pytest.approx(b, rel=1e-2)
            for a, b in zip(hsb_calc.result_dict_tens["Tension Force"], HSB_Results["Fti"])
        ]
    )

    #  rounding error in HSB
    assert hsb_calc.fastener_group.centroid_s.y == pytest.approx(-52.5, rel=1e-2)
    assert hsb_calc.fastener_group.centroid_s.z == pytest.approx(25.0)
    #  rounding error in HSB
    assert hsb_calc.fastener_group.centroid_t.y == pytest.approx(-69.9, rel=2e-2)
    assert hsb_calc.fastener_group.centroid_t.z == pytest.approx(25.0)

    # Shear Mx,S = −45 N · m
    # Tension My,S = +10 N · m
    # Tension Mz,S = −339 N · m

    assert hsb_calc.moments_s.moment_x == pytest.approx(-45000, rel=1e-2)
    assert hsb_calc.moments_s.moment_y == pytest.approx(10000)
    assert hsb_calc.moments_s.moment_z == pytest.approx(-339000, rel=1e-2)

    HSB_Results_dummy_fast = {
        "yi": [
            -70.0,
            -40.0,
            -40.0,
            -60.0,
            -70.0,
        ],
        "zi": [
            +35.0,
            +35.0,
            +15.0,
            +15.0,
            +25.0,
        ],
        "Fsyi": [
            +3420,
            +3420,
            +2580,
            +2580,
            0.00001,
        ],
        "Fszi": [
            +230,
            -1020,
            -1020,
            -190,
            0,
        ],
        "Fsi": [
            +3430,
            +3570,
            +2780,
            +2590,
            0,
        ],
        "Fti": [0, +6170, +5170, 0, -1330],
    }

    assert all([a == pytest.approx(b) for a, b in zip(hsb_calc.result_dict["Y"], HSB_Results_dummy_fast["yi"])])
    assert all([a == pytest.approx(b) for a, b in zip(hsb_calc.result_dict["Z"], HSB_Results_dummy_fast["zi"])])
    # rounding error in HSB: 34.2kN vs 3418.6N
    assert all(
        [
            a == pytest.approx(b, rel=1e-2)
            for a, b in zip(hsb_calc.result_dict["Fsyi"][:-1], HSB_Results_dummy_fast["Fsyi"][:-1])
        ]
    )
    # Dummy fastener
    assert all(
        [
            a == pytest.approx(b, abs=1e-2)
            for a, b in zip(hsb_calc.result_dict["Fsyi"][-1:], HSB_Results_dummy_fast["Fsyi"][-1:])
        ]
    )
    # rounding error in HSB: 0.23kN vs 232.55N
    assert all(
        [
            a == pytest.approx(b, rel=3e-2)
            for a, b in zip(hsb_calc.result_dict["Fszi"][:-1], HSB_Results_dummy_fast["Fszi"][:-1])
        ]
    )
    # Dummy fastener
    assert all(
        [
            a == pytest.approx(b, abs=1e-2)
            for a, b in zip(hsb_calc.result_dict["Fszi"][-1:], HSB_Results_dummy_fast["Fszi"][-1:])
        ]
    )

    # rounding error in HSB: 2.59kN vs 2588.09N
    assert all(
        [
            a == pytest.approx(b, rel=1e-2)
            for a, b in zip(
                hsb_calc.result_dict["Shear Force"][:-1],
                HSB_Results_dummy_fast["Fsi"][:-1],
            )
        ]
    )
    # Dummy fastener
    assert all(
        [
            a == pytest.approx(b, abs=1e-2)
            for a, b in zip(
                hsb_calc.result_dict["Shear Force"][-1:],
                HSB_Results_dummy_fast["Fsi"][-1:],
            )
        ]
    )
    #  rounding error in HSB: -0.33kN vs -326.9N
    assert all(
        [
            a == pytest.approx(b, rel=1e-2)
            for a, b in zip(hsb_calc.result_dict["Tension Force"], HSB_Results_dummy_fast["Fti"])
        ]
    )
