import pytest
import os

# from makerspace_mbe_pylantir.pyelbe.ithil import HD5_Elm_Results_Extraction


class TestFEResults:
    @pytest.fixture
    def set_id(self):
        set_id = "1"
        return set_id

    @pytest.fixture
    def element_type(self):
        element_type = "2D"
        return element_type

    @pytest.fixture
    def result_type(self):
        result_type = "Element_Forces"
        return result_type

    @pytest.fixture
    def load_set(self):
        load_set = [2, 3]
        return load_set

    @pytest.fixture
    def returned_data_type(self):
        returned_data_type = "json"
        return returned_data_type

    @pytest.fixture
    def hd5file(self):
        hd5file = r"D:\\00_DATA\\100_Programming\\08_Step_41_Stress_Automation\
        \\A321NeoXLR_Conf1_10_AC_SMM4_TL_FGU_NR_nNFF_S17.h5"
        return os.path.realpath(hd5file)

    @pytest.fixture
    def setfile(self):
        setfile = (
            r"D:\\00_DATA\\100_Programming\\08_Step_41_Stress_Automation\\elm_set.out"
        )
        return os.path.realpath(setfile)

    # @pytest.fixture
    # def hd5_results(
    #     self,
    #     hd5file,
    #     setfile,
    #     element_type,
    #     result_type,
    #     set_id,
    #     load_set,
    #     returned_data_type,
    # ):
    #     hd5_results = HD5_Elm_Results_Extraction(
    #         HD5_File_Path=hd5file,
    #         set_elm_path=setfile,
    #         element_type=element_type,
    #         result_type=result_type,
    #         elm_set_ID=set_id,
    #         load_set=load_set,
    #         returned_data_type=returned_data_type,
    #     )
    #     return hd5_results

    # def test_2D_elm_forces(self, hd5_results):
    #     print("The test starts.")
    #     hd5_2d_elm_forces = hd5_results.get_results()
    #     print(hd5_2d_elm_forces)
    #     # assert ('C_302', 'P_46') in list(csvmap.get_loc_dic().keys())
