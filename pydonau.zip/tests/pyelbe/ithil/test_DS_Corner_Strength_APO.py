import os
import sys

import json

sys.path.append("D://GIT//makerspace-mbe-pylantir//src")

from typing import Any
import pandas as pd
import pytest
from pathlib import Path
from makerspace_mbe_pylantir.pydonau.alchemy.alchemy import SolutionSet
from makerspace_mbe_pylantir.pyelbe.ithil.material_strength_corner import (
    MaterialStrengthEdgeFEM,
)  # Adjust the import path to match your project structure
from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)
from makerspace_mbe_pylantir.pyelbe.morgul.material_strength import (
    LoadExtractionForMatStrength,
)
from makerspace_mbe_pylantir.pylech.fem import LoadSet
from makerspace_mbe_pylantir.scrolls import get_logger  # type:ignore
import logging

logger: logging.Logger = get_logger(__name__, level=logging.DEBUG)


TEST_DATA_FOLDER_FILEPATH: Path = Path(__file__).parent / "data/DS_Corner_Strength_APO"
TEST_FEM_FILES_FILEPATH: Path = TEST_DATA_FOLDER_FILEPATH / "fem"

TEST_LHS_SCENARIOS_JSON_PATH: Path = TEST_DATA_FOLDER_FILEPATH / "LHS_tests_params.json"
TEST_RHS_SCENARIOS_JSON_PATH: Path = TEST_DATA_FOLDER_FILEPATH / "RHS_tests_params.json"

MATERIALS_JSON_PATH: Path = TEST_DATA_FOLDER_FILEPATH / "materials.json"
FEM_PARAMS_JSON_PATH: Path = TEST_DATA_FOLDER_FILEPATH / "fem_params.json"


OUTPUT_FOLDER: Path = Path("D:/Temp/data_corner_apo/output_test")

logger_path = Path(__name__ + ".log")


@pytest.fixture(autouse=True)
def cleanup_files():
    """Remove the test files."""
    if logger_path.exists():
        os.remove(logger_path)


@pytest.fixture()
def test_scenarios() -> dict[str, Any]:
    """Return a dictionary of all test scenarios available in the json file."""
    lh_scenarios: dict[str, Any] = {}
    rh_scenarios: dict[str, Any] = {}
    with open(TEST_LHS_SCENARIOS_JSON_PATH) as file:
        lh_scenarios = json.load(file)

    with open(TEST_RHS_SCENARIOS_JSON_PATH) as file:
        rh_scenarios = json.load(file)

    return {"lhs": lh_scenarios, "rhs": rh_scenarios}


@pytest.fixture()
def materials() -> dict[str, Any]:
    """Return a dictionary of all materials available in the json file."""
    mat_data: dict[str, Any] = {}
    with open(MATERIALS_JSON_PATH) as file:
        mat_data = json.load(file)

    return mat_data


@pytest.fixture()
def fem_params() -> dict[str, Any]:
    """Return a dictionary of all fem_parameters available in the json file."""
    fem_data: dict[str, Any] = {}
    with open(FEM_PARAMS_JSON_PATH) as file:
        fem_data = json.load(file)

    return fem_data


# Test MaterialStrengthEdgeFEM functionality
class TestMaterialStrengthEdgeFEM:
    """Class for performing material strength tests."""

    def get_material(self, mat_dict: dict[str, Any]) -> MetallicMaterial:
        properties = mat_dict["properties"]["IsoElastic"]
        allowables = mat_dict["allowables"]["MetallicAllowables"]
        billet_nominal = mat_dict["billet"]["Billet"]["nominal"]

        metal: MetallicMaterial = MetallicMaterial(
            name=mat_dict["name"],
            specification=mat_dict["specification"],
            properties=IsoElastic(
                E=properties["E"],
                Ec=properties["Ec"],
                G=properties["G"],
                nu=properties["nu"],
            ),
            allowables=MetallicAllowables(
                Fcy=allowables["Fcy"],
                Fty=allowables["Fty"],
                Fc1=allowables["Fc1"],
                Ft1=allowables["Ft1"],
                Ftu=allowables["Ftu"],
                Fsu=allowables["Fsu"],
                b10=allowables["b10"],
                e=allowables["e"],
                n=allowables["n"],
                nc=allowables["nc"],
                basis=allowables["basis"],
                orientation=allowables["orientation"],
            ),
            billet=Billet(nominal=billet_nominal),
        )
        return metal

    # def test_material_strength(
    #     self,
    #     test_scenarios: dict[str, Any],
    #     materials: dict[str, Any],
    #     fem_params: dict[str, Any],
    # ) -> None:
    #     """Runs tests on all test scenarios defined for RHS & LHS."""

    #     for side in ["lhs", "rhs"]:
    #         scenarios = test_scenarios[side]
    #         available_scenarios = list(scenarios.keys())

    #         for test_scenario in available_scenarios:
    #             # Extract test scenario data:
    #             inp_params: dict[str, Any] = scenarios[test_scenario][
    #                 "input_parameters"
    #             ]
    #             sol_params: dict[str, Any] = scenarios[test_scenario]["expected_output"]

    #             set_group: str = inp_params["set_group"]

    #             material_data: dict[str, Any] = materials[inp_params["material"]]
    #             metal: MetallicMaterial = self.get_material(material_data)

    #             # load extraction:
    #             # root_path: Path = Path(__file__).parents[3] / "pylech/moria/nastran/"
    #             test_h5_filepath: Path = (
    #                 TEST_FEM_FILES_FILEPATH / fem_params["test_fem_filename"]
    #             )
    #             test_set_filepath: Path = (
    #                 TEST_FEM_FILES_FILEPATH
    #                 / fem_params["group"][set_group]["test_set_filename"]
    #             )
    #             set_id: str = fem_params["group"][set_group]["set_id"]
    #             analysis_location: str = fem_params["group"][set_group][
    #                 "analysis_location"
    #             ]
    #             part_name: str = scenarios[test_scenario]["input_parameters"][
    #                 "part_name"
    #             ]

    #             LE: LoadExtractionForMatStrength = (
    #                 LoadExtractionForMatStrength.from_dict(
    #                     {
    #                         "set_path": test_set_filepath,
    #                         "set_id": set_id,
    #                         "nas_analysis": test_h5_filepath,
    #                     },
    #                 )
    #             )

    #             load_set: LoadSet = LE.calculation

    #             # strength calculation:
    #             inp: dict[str, Any] = {
    #                 "analysis_name": inp_params["analysis_name"],
    #                 "load_set": load_set,
    #                 "mitigation": inp_params["mitigation"],
    #                 "hsb34201_01_analysis_method": inp_params[
    #                     "hsb34201_01_analysis_method"
    #                 ],
    #                 "compression_factor": inp_params["compression_factor"],
    #                 "ultimate_e_neuber_all": inp_params["ultimate_e_neuber_all"],
    #                 "theory": inp_params["theory"],
    #                 "load_type": inp_params["load_type"],
    #                 "moe_tens_fem": inp_params["moe_tens_fem"],
    #                 "moe_comp_fem": inp_params["moe_comp_fem"],
    #                 "material": metal,
    #             }
    #             target_data: dict[str, Any] = {
    #                 "lcid": sol_params["lcid"],
    #                 "eid": sol_params["eid"],
    #                 "fapp": sol_params["fapp"],
    #                 "fall": sol_params["fall"],
    #                 "rf": sol_params["rf"],
    #                 "load_type": sol_params["load_type"],
    #                 "method": sol_params["method"],
    #             }

    #             edge_strength: MaterialStrengthEdgeFEM = (
    #                 MaterialStrengthEdgeFEM.from_dict(input_dict=inp)
    #             )
    #             edge_strength.strength_analysis()
    #             results: SolutionSet = edge_strength.results
    #             # logger.debug(f"{len(results)=}")

    #             df: pd.DataFrame = results.dataframe  # type: ignore
    #             df_LCid: pd.DataFrame = df[df["loadcase_id"] == target_data["lcid"]]  # type: ignore
    #             df_LCid_elid: pd.DataFrame = df_LCid[df_LCid["element_id"] == target_data["eid"]]  # type: ignore
    #             df_LCid_elid_reset: pd.DataFrame = df_LCid_elid.reset_index(drop=True)  # type: ignore

    #             columns_ordered: list[str] = [
    #                 "loadcase_id",
    #                 "element_id",
    #                 "E_gfem",
    #                 "E_tens",
    #                 "E_comp",
    #                 "strain",
    #                 "sigma_part",
    #                 "applied_stress",
    #                 "allowable",
    #                 "reserve_factor",
    #                 "tens_comp",
    #                 "method",
    #             ]
    #             separator = ";"
    #             load_type = inp["load_type"]
    #             df.to_csv(
    #                 f"{OUTPUT_FOLDER}/{analysis_location}_{part_name}_{load_type[:3]}_strength_test.csv",
    #                 sep=separator,
    #                 columns=columns_ordered,
    #                 index=False,
    #             )

    #             logger.debug(f"{analysis_location}, {inp_params['test_description']}")

    #             assert df_LCid_elid_reset.loc[0, "loadcase_id"] == target_data["lcid"]
    #             assert df_LCid_elid_reset.loc[0, "element_id"] == target_data["eid"]
    #             assert df_LCid_elid_reset.loc[0, "applied_stress"] == pytest.approx(
    #                 target_data["fapp"], 0.001
    #             )
    #             assert df_LCid_elid_reset.loc[0, "allowable"] == pytest.approx(
    #                 target_data["fall"], 0.001
    #             )
    #             assert (
    #                 df_LCid_elid_reset.loc[0, "tens_comp"] == target_data["load_type"]
    #             )
    #             assert df_LCid_elid_reset.loc[0, "method"] == target_data["method"]
    #             assert df_LCid_elid_reset.loc[0, "reserve_factor"] == pytest.approx(
    #                 target_data["rf"], 0.01
    #             )
