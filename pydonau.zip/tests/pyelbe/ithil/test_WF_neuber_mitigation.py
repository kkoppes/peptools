import os
import json
from typing import Any
import pytest
from pathlib import Path
from makerspace_mbe_pylantir.pydonau.alchemy.alchemy import SolutionSet
from makerspace_mbe_pylantir.pyelbe.ithil.material_strength_corner import (
    MaterialStrengthEdgeFEM,
)  # Adjust the import path to match your project structure
from makerspace_mbe_pylantir.pyelbe.matreel import (
    MetallicMaterial,
    MetallicAllowables,
    IsoElastic,
    Billet,
)

from makerspace_mbe_pylantir.scrolls import get_logger  # type:ignore
import logging

logger: logging.Logger = get_logger(__name__, level=logging.DEBUG)

COMPRESSION_FACTOR = 1.4
TEST_DATA_FOLDER_FILEPATH: Path = Path(__file__).parent / "data/WF_neuber_mitigation"

TEST_LHS_SCENARIOS_JSON_PATH: Path = TEST_DATA_FOLDER_FILEPATH / "LHS_tests_params.json"
TEST_RHS_SCENARIOS_JSON_PATH: Path = TEST_DATA_FOLDER_FILEPATH / "RHS_tests_params.json"

MATERIALS_JSON_PATH: Path = TEST_DATA_FOLDER_FILEPATH / "materials.json"

OUTPUT_FOLDER: Path = Path("D:/Temp/data_corner_apo/output_test")

logger_path = Path(__name__ + ".log")

"""
Available data in solution set:
    "loadcase_id"
    "element_id"
    "E_gfem"
    "E_tens"
    "E_comp"
    "strain"
    "sigma_part"
    "applied_stress"
    "allowable"
    "reserve_factor"
    "tens_comp"
    "method"
"""


@pytest.fixture(autouse=True)
def cleanup_files():
    """Remove the test files."""
    if logger_path.exists():
        os.remove(logger_path)


def get_material(mat_dict: dict[str, Any]) -> MetallicMaterial:
    properties = mat_dict["properties"]["IsoElastic"]
    allowables = mat_dict["allowables"]["MetallicAllowables"]
    billet_nominal = mat_dict["billet"]["Billet"]["nominal"]

    metal: MetallicMaterial = MetallicMaterial(
        name=mat_dict["name"],
        specification=mat_dict["specification"],
        properties=IsoElastic(
            E=properties["E"],
            Ec=properties["Ec"],
            G=properties["G"],
            nu=properties["nu"],
        ),
        allowables=MetallicAllowables(
            Fcy=allowables["Fcy"],
            Fty=allowables["Fty"],
            Fc1=allowables["Fc1"],
            Ft1=allowables["Ft1"],
            Ftu=allowables["Ftu"],
            Fsu=allowables["Fsu"],
            b10=allowables["b10"],
            e=allowables["e"],
            n=allowables["n"],
            nc=allowables["nc"],
            basis=allowables["basis"],
            orientation=allowables["orientation"],
        ),
        billet=Billet(nominal=billet_nominal),
    )
    return metal


@pytest.fixture()
def test_scenarios() -> dict[str, Any]:
    """Return a dictionary of all test scenarios available in the json file."""
    lh_scenarios: dict[str, Any] = {}
    rh_scenarios: dict[str, Any] = {}
    with open(TEST_LHS_SCENARIOS_JSON_PATH) as file:
        lh_scenarios = json.load(file)

    with open(TEST_RHS_SCENARIOS_JSON_PATH) as file:
        rh_scenarios = json.load(file)

    return {"lhs": lh_scenarios, "rhs": rh_scenarios}


@pytest.fixture()
def materials() -> dict[str, Any]:
    """Return a dictionary of all materials available in the json file."""
    mat_data: dict[str, Any] = {}
    with open(MATERIALS_JSON_PATH) as file:
        mat_data = json.load(file)

    return mat_data


# Test MaterialStrengthEdgeFEM functionality
class TestMaterialStrengthEdgeFEM:
    def test_material_strength(
        self,
        test_scenarios: dict[str, Any],
        materials: dict[str, Any],
    ) -> None:
        """Runs tests on all test scenarios defined for RHS & LHS."""

        for side in ["lhs", "rhs"]:
            scenarios = test_scenarios[side]
            available_scenarios = list(scenarios.keys())

            for test_scenario in available_scenarios:
                # Extract test scenario data:
                inp_params: dict[str, Any] = scenarios[test_scenario][
                    "input_parameters"
                ]
                expected_output: dict[str, Any] = scenarios[test_scenario][
                    "expected_output"
                ]

                material_data: dict[str, Any] = materials[inp_params["material"]]
                metal: MetallicMaterial = get_material(material_data)
                # analysis_location: str = scenarios[test_scenario]["input_parameters"][
                #     "analysis_location"
                # ]
                # part_name: str = scenarios[test_scenario]["input_parameters"][
                #     "part_name"
                # ]

                # strength calculation:
                inp: dict[str, Any] = {
                    "analysis_name": inp_params["analysis_name"],
                    "load_set": inp_params["load_set"],
                    "mitigation": inp_params["mitigation"],
                    "hsb34201_01_analysis_method": inp_params[
                        "hsb34201_01_analysis_method"
                    ],
                    "compression_factor": inp_params["compression_factor"],
                    "ultimate_e_neuber_all": inp_params["ultimate_e_neuber_all"],
                    "theory": inp_params["theory"],
                    "load_type": inp_params["load_type"],
                    "moe_tens_fem": metal.properties["E"],
                    "moe_comp_fem": metal.properties["Ec"],
                    "material": metal,
                }
                target_data: dict[str, Any] = {
                    "allowable": expected_output["allowable"],
                    "sigma_part": expected_output["sigma_part"],
                    "applied_stress": expected_output["applied_stress"],
                    "reserve_factor": expected_output["reserve_factor"],
                    "method": expected_output["method"],
                }

                edge_strength: MaterialStrengthEdgeFEM = (
                    MaterialStrengthEdgeFEM.from_dict(input_dict=inp)
                )
                edge_strength.strength_analysis(load_sets=inp["load_set"])
                results: SolutionSet = edge_strength.results

                logger.debug(f"strain={results[1]['strain']}")
                logger.debug(f"sigma_part={results[1]['sigma_part']}")
                logger.debug(f"applied_stress={results[1]['applied_stress']}")
                logger.debug(f"allowable={results[1]['allowable']}")
                logger.debug(f"reserve_factor={results[1]['reserve_factor']}")
                logger.debug(f"method={results[1]['method']}")

                # results: SolutionSet = edge_strength.results
                assert len(edge_strength.results) > 0
                assert results[1]["allowable"] == pytest.approx(  # type: ignore
                    target_data["allowable"], 0.01
                )
                assert results[1]["sigma_part"] == pytest.approx(  # type: ignore
                    target_data["sigma_part"], 0.01
                )
                assert results[1]["applied_stress"] == pytest.approx(  # type: ignore
                    target_data["applied_stress"], 0.01
                )
                assert results[1]["reserve_factor"] == pytest.approx(  # type: ignore
                    target_data["reserve_factor"], 0.01
                )
                assert results[1]["method"] == target_data["method"]
