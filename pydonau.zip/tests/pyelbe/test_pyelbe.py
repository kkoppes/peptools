import pytest
from makerspace_mbe_pylantir.pyelbe.pyelbe import AdvancedAI


def test_advanced_ai():
    ai = AdvancedAI()
    assert ai.intelligence == "superior"
    assert ai.mood == "serious"
    assert ai.task is None

    ai.analyze_data([1, 2, 3, 4, 5])
    assert ai.task == "analyzing data"
    ai.task = None

    ai.predict_future([1, 2, 3, 4, 5])
    assert ai.task == "predicting future"
    ai.task = None

    ai.talk_to_humans("Hello AI!")
    assert ai.task == "talking to humans"
    ai.task = None
