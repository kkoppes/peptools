import pytest
from makerspace_mbe_pylantir.pylech.fem import FELoad, LoadSet


def test_feload_creation():
    load = FELoad(element_id=1, loadcase_id="LC1", load_type="type1", load_value=100.0)
    assert load.element_id == 1
    assert load.loadcase_id == "LC1"
    assert load.load_type == "type1"
    assert load.load_value == 100.0


def test_loadset_creation():
    load_set = LoadSet()
    assert load_set.uuid is not None
    assert isinstance(load_set.loads, list)


def test_loadset_add_element_data():
    load_set = LoadSet()
    load_set.add_element_data(
        {
            "element_id": 2,
            "loadcase_id": "LC2",
            "load_type": "type2",
            "load_value": 200.0,
        }
    )
    assert len(load_set.loads) == 1
    assert load_set.loads[0].element_id == 2


def test_feload_invalid_data():
    with pytest.raises(ValueError):
        FELoad(
            element_id="invalid", loadcase_id="LC1", load_type="type1", load_value=100.0
        )
