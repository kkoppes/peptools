from pathlib import Path
import pytest
from arpeggio import ParserPython, NoMatch, visit_parse_tree
from makerspace_mbe_pylantir.pylech.moria.nastran.parse.nastran_bulk import (
    anything,
    comment_line,
    empty_line,
    free_format_start_field,
    free_format_field,
    free_format_line,
    large_field_start,
    large_field_keyword_start,
    large_field,
    large_field_end,
    small_field,
    large_field_line,
    small_field_start,
    small_field_line,
    other_line,
    file_structure,
    NASTRANBulkVisitor,
    bulk_parser,
    parse_bulk_string,
    parse_bulk_file,
    small_field_keyword_start_line,
    small_field_keyword_start,
    card,
)


# Your code here ...


def test_anything():
    parser = ParserPython(anything, skipws=False, ws=" \t")

    # Test with a simple string
    result = parser.parse("hello")
    assert result == "hello"

    # Test with a string containing special characters
    result = parser.parse("hello@world!")
    assert result == "hello@world!"

    # Test with an empty string
    result = parser.parse("")
    assert result is None

    # Test with a string containing newline
    result = parser.parse("hello\nworld")
    assert result == "hello"


def test_comment_line():
    parser = ParserPython(comment_line, skipws=False, ws=" \t")

    # Test with a valid comment line
    result = parser.parse("$ This is a comment\n")
    assert result[1] == " This is a comment"

    # Test with a comment line containing special characters
    result = parser.parse("$ Comment with @ and !\n")
    assert result[1] == " Comment with @ and !"

    # Test with an empty comment line
    result = parser.parse("$\n")
    assert result[1] == "\n"

    # Test with a string that doesn't start with a comment symbol
    with pytest.raises(NoMatch):
        parser.parse("This is not a comment\n")

    # Test with a string that starts with a comment symbol but doesn't end with a newline
    with pytest.raises(NoMatch):
        parser.parse("$ This is a comment")


def test_empty_line():
    parser = ParserPython(empty_line, skipws=False, ws=" \t")

    # Test with a valid empty line
    result = parser.parse("\n")
    assert result.value == "\n"

    # Test with a string that isn't empty
    with pytest.raises(NoMatch):
        parser.parse("This is not an empty line\n")


def test_free_format_start_field():
    parser = ParserPython(free_format_start_field, skipws=False, ws=" \t")

    # Test with a valid start field
    result = parser.parse("123456789,")
    assert result == "123456789,"

    # Test with a smaller start field
    result = parser.parse("1234,")
    assert result == "1234,"

    # Test with a larger start field
    # it should fail because the field is too large
    with pytest.raises(NoMatch):
        parser.parse("1234567890,")

    # Test with a string that doesn't start with a start field
    with pytest.raises(NoMatch):
        parser.parse("This is not a start field\n")


def test_free_format_field():
    parser = ParserPython(free_format_field, skipws=False, ws=" \t")

    # Test with a valid field
    result = parser.parse("123456789,")
    assert result == "123456789,"

    # Test with a smaller field
    result = parser.parse("1234,")
    assert result == "1234,"

    # Test with a larger field
    with pytest.raises(NoMatch):
        parser.parse("1234567890,")

    # Test with a string that doesn't start with a field
    with pytest.raises(NoMatch):
        parser.parse("This is not a field\n")


def test_free_format_line():
    parser = ParserPython(free_format_line, skipws=False, ws=" \t")

    # Test with a valid line
    result = parser.parse(
        "123456789,123456789,123456789,123456789,123456789,123456789,123456789,123456789,\n"
    )
    assert result[0] == "123456789,"
    assert result[1] == "123456789,"
    assert result[5] == "123456789,"
    result[8] == "\n"
    # Test with a smaller line
    result = parser.parse("1234,1234,1234,1234,1234,1234,1234,1234,\n")
    assert result[0] == "1234,"
    assert result[1] == "1234,"
    assert result[5] == "1234,"
    result[8] == "\n"


def test_large_field_start():
    parser = ParserPython(large_field_start, skipws=False, ws=" \t")

    # Test with a valid start field
    result = parser.parse("*       ")
    assert result == "*       "

    # Test with a smaller start field
    with pytest.raises(NoMatch):
        parser.parse("MAT2*   ")

    # Test with a larger start field
    # it should fail because the field is too large
    with pytest.raises(NoMatch):
        parser.parse(
            "12345678901234567890123456789012345678901234567890123456789012345678901*"
        )

    # Test with a string that doesn't start with a start field
    with pytest.raises(NoMatch):
        parser.parse("This is not a start field\n")


def test_large_keyword_start():
    parser = ParserPython(large_field_keyword_start, skipws=False, ws=" \t")

    # Test with a valid start field
    result = parser.parse("PSHELL* ")
    assert result == "PSHELL* "

    # Test with a valid start field
    result = parser.parse("PBEAM*  ")
    assert result == "PBEAM*  "

    # Test with a valid start field
    result = parser.parse("PROD*   ")
    assert result == "PROD*   "

    # Test with a valid start field
    result = parser.parse("PSHEAR* ")
    assert result == "PSHEAR* "

    # Test with a valid start field
    result = parser.parse("MAT1*   ")
    assert result == "MAT1*   "

    # Test with a valid start field
    result = parser.parse("MAT2*   ")
    assert result == "MAT2*   "

    # Test with a smaller start field
    with pytest.raises(NoMatch):
        parser.parse("MAT2    ")

    # Test with a larger start field
    # it should fail because the field is too large
    with pytest.raises(NoMatch):
        parser.parse(
            "12345678901234567890123456789012345678901234567890123456789012345678901*"
        )

    # Test with a string that doesn't start with a start field
    with pytest.raises(NoMatch):
        parser.parse("This is not a start field\n")


def test_large_field():
    parser = ParserPython(large_field, skipws=False, ws=" \t")

    # Test with a valid field
    result = parser.parse("1234567890123456")
    assert result == "1234567890123456"

    # Test with a smaller field
    result = parser.parse(
        "1234567890123456123456789012345612345678901234561234567890123456"
    )
    assert result == "1234567890123456"

    # Test with a string that doesn't start with a field
    with pytest.raises(NoMatch):
        parser.parse("Not a field")


def test_large_field_line():
    parser = ParserPython(large_field_line, skipws=False, ws=" \t")

    # Test with a valid line
    result = parser.parse(
        "*                   4810                         43248.4             0.0*       \n"
    )
    assert result[0] == "*       "
    assert result[1] == "            4810"
    assert result[2] == "                "
    assert result[3] == "         43248.4"
    assert result[4] == "             0.0"
    assert result[5] == "*       "
    assert result[6] == "\n"

    # Test with a valid line
    result = parser.parse(
        "*       123456789012345612345678901234561234567890123456123456789012345612345678\n"
    )
    assert result[0] == "*       "
    assert (
        result[1]
        == result[2]
        == result[3]
        == result[3]
        == result[3]
        == "1234567890123456"
    )
    assert result[5] == "12345678"
    assert result[6] == "\n"

    # Test with a valid line
    result = parser.parse(
        "*               51937.56        4.135-13         15212.9        2.3732-6*       \n"
    )
    assert result[0] == "*       "
    # assert isinstance(result[1], large_field)
    assert result[5] == "*       "
    assert result[6] == "\n"

    # Test with a string that isn't a large field line
    with pytest.raises(NoMatch):
        parser.parse("no fld")

    with pytest.raises(NoMatch):
        parser.parse(
            "        123456789012345612345678901234561234567890123456123456789012345612345678\n"
        )


def large_field_keyword_start_line():
    parser = ParserPython(large_field_keyword_start_line, skipws=False, ws=" \t")

    # Test with a valid line
    result = parser.parse(
        "CORD2R*             4810                         43248.4             0.0*       \n"
    )
    assert result[0] == "CORD2R* "
    assert result[1] == "            4810"
    assert result[2] == "                "
    assert result[3] == "         43248.4"
    assert result[4] == "             0.0"
    assert result[5] == "*       "
    assert result[6] == "\n"

    # Test with a valid line
    result = parser.parse(
        "GRID*   123456789012345612345678901234561234567890123456123456789012345612345678\n"
    )
    assert result[0] == "GRID*   "
    assert (
        result[1]
        == result[2]
        == result[3]
        == result[3]
        == result[3]
        == "1234567890123456"
    )
    assert result[5] == "12345678"
    assert result[6] == "\n"

    # Test with a valid line
    result = parser.parse(
        "MAT2*           14904200        58513.86        14797.87        -1.09-14*       \n"
    )
    assert result[0] == "MAT2*    "
    assert isinstance(result[1], large_field)
    assert result[5] == "*       "
    assert result[6] == "\n"

    # Test with a string that isn't a small field line
    with pytest.raises(NoMatch):
        parser.parse("no fld")

    with pytest.raises(NoMatch):
        parser.parse(
            "        123456789012345612345678901234561234567890123456123456789012345612345678\n"
        )


def test_small_field():
    parser = ParserPython(small_field, skipws=False, ws=" \t")

    # Test with a valid field
    result = parser.parse("12345678")
    assert result == "12345678"

    # Test with a smaller field
    with pytest.raises(NoMatch):
        parser.parse("1234567")

    # Test with a larger field
    result = parser.parse("123456789")
    assert result == "12345678"

    # Test with a string that doesn't start with a field
    with pytest.raises(NoMatch):
        parser.parse("no fld")


def test_small_start():
    parser = ParserPython(small_field_start, skipws=False, ws=" \t")

    # Test with a valid field
    result = parser.parse("1       ")
    assert result == "1       "

    # Test with a valid field
    result = parser.parse("+       ")
    assert result == "+       "
    # Test with a smaller field
    with pytest.raises(NoMatch):
        parser.parse("+      ")

    # Test with a smaller field
    with pytest.raises(NoMatch):
        parser.parse("1234567*")

    # Test with a string that doesn't start with a field
    with pytest.raises(NoMatch):
        parser.parse("no fld")


def test_small_field_line():
    parser = ParserPython(small_field_line, skipws=False, ws=" \t")

    # Test with a valid line
    result = parser.parse(
        "        123456781234567812345678123456781234567812345678123456781234567812345678\n"
    )
    assert result[0] == "        "
    assert result[1] == result[2] == result[3] == "12345678"
    assert result[9] == "12345678"
    assert result[10] == "\n"


def test_small_field_keyword_start_line():
    parser = ParserPython(small_field_keyword_start_line, skipws=False, ws=" \t")
    # Test with a valid line
    result = parser.parse("PSHELL   1       1       .253      1               1\n")
    assert result[0] == "PSHELL  "
    assert result[1] == " 1      "
    assert result[2] == " 1      "
    assert result[3] == " .253   "
    assert result[4] == "   1    "
    assert result[5] == "        "
    assert result[6] == "   1"
    assert result[7] == "\n"

    # Test with a string that isn't a small field line
    with pytest.raises(NoMatch):
        parser.parse("no fld\n")

    with pytest.raises(NoMatch):
        parser.parse(
            "*       123456781234567812345678123456781234567812345678123456781234567812345678\n"
        )


def test_card():
    parser = ParserPython(card, skipws=False, ws=" \t")

    card_str_large = """MAT2*           14904200        58513.86        14797.87        -1.09-14*       
*               51937.56        4.135-13         15212.9        2.3732-6*       
*               1.7472-5        2.0317-5        -5.03-22                *       
*                                                                       
"""

    # Test with a valid field
    result = parser.parse(card_str_large)

    assert result[0][0] == "MAT2*   "
    assert len(result) == 4

    card_str_small = """MAT2    14904200 58513.8 14797.8-1.09-14 51937.5 4.135-1 15212.9  2.37-6        
        1.7472-5 2.0317-5 -5.03-22  
"""

    # Test with a valid field
    result = parser.parse(card_str_small)

    assert result[0][0] == "MAT2    "
    assert len(result) == 2


def test_parse_bulk_file():
    TEST_FILENAME = "test_bulk.dat"

    filename = Path(__file__).parent / TEST_FILENAME
    with open(filename, "r") as file:
        parse_tree = parse_bulk_file(file.read())

    assert parse_tree[0][1] == "this is a comment"
    assert parse_tree[1][0][0] == "CORD2R* "


def test_NASTRANBulkVisitor():
    TEST_FILENAME = "test_bulk.dat"

    filename = Path(__file__).parent / TEST_FILENAME
    with open(filename, "r") as file:
        parse_tree = bulk_parser.parse(file.read())

    bulk = visit_parse_tree(parse_tree, NASTRANBulkVisitor())

    assert 'CORD2R* ' in [con for con in bulk.content[0].content]
