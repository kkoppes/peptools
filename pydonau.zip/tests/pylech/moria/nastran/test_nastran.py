#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep  4 11:29:49 2023

@author: gi11883
"""
import time
from dataclasses import dataclass
from pathlib import Path
from pydantic import ValidationError
from arpeggio import visit_parse_tree
import pytest
import polars as pl
from makerspace_mbe_pylantir.pyelbe.matreel import IsoElastic
from makerspace_mbe_pylantir.pylech.fem import FELoad, LoadSet
from makerspace_mbe_pylantir.pylech.moria.nastran import (
    NASTRANAnalysis,
    NASTRANModel,
    NASTRANHDF5,
    WrongHDF5Format,
    NASTRANAnalysisProcessor,
)
from makerspace_mbe_pylantir.pylech.moria.fe_results.element_forces import (
    ElementForces,
    ElementForces1D,
    ElementForces2D,
)
from makerspace_mbe_pylantir.pylech.moria.fe_results.fe_result import (
    Principal2D,
    Resultant1D,
)
from makerspace_mbe_pylantir.pylech.moria.nastran.parse import (
    set_parser,
    NASTRANSetVisitor,
)
from makerspace_mbe_pylantir.pylech.moria.nastran.model import (
    ModelSet,
    GRID,
    CBEAM,
    CQUAD4,
    CTRIA3,
    CORD2R,
    MAT1,
)


TEST_FILEPATH = ""  # deine the global variable to be modified in the functions below
NOT_NASTRAN = "TEST_NOT_NASTRAN.h5"
TEST_NOT_FILEPATH = Path(__file__).parent / NOT_NASTRAN

ELEM_ID = int
LOAD_ID = int

SET_FILENAME = "TEST_FEM_SETS.out"
TEST_FILENAME = "TEST_FEM.h5"

TEST_H5_FILEPATH = Path(__file__).parent / TEST_FILENAME
TEST_SET_FILEPATH = Path(__file__).parent / SET_FILENAME


@pytest.fixture
def nas_processor():
    """Fixture to create a NASTRANAnalysisProcessor object for testing."""
    return NASTRANAnalysisProcessor(
        set_filename=TEST_SET_FILEPATH, h5_filepath=TEST_H5_FILEPATH
    )


@dataclass
class TestTemplate:
    model_filename: str
    mat1_set: ModelSet
    grid_set: ModelSet
    cord2r_set: ModelSet
    elem_1D_set: ModelSet
    elem_2D_set: ModelSet
    mat1_properties: IsoElastic
    results_test: dict[str, tuple[set[ELEM_ID], set[LOAD_ID]]]


def get_set(set_filename, set_id):
    filename = Path(__file__).parent / set_filename
    with open(filename, "r") as file:
        # get the parse tree
        parse_tree = set_parser.parse(file.read())
        # pass the parse tree to the visitor and get a dictionary containing ModelSet objects
        set_dict = visit_parse_tree(parse_tree, NASTRANSetVisitor())
    return set_dict[set_id]


def __test_case_devx__():
    global TEST_FILEPATH
    set_filename = "TEST_FEM_SETS.out"
    test_filename = "TEST_FEM.h5"

    TEST_FILEPATH = Path(__file__).parent / test_filename

    # material test
    mat_id = 1
    mat1_properties = IsoElastic(E=73000.0, nu=0.33, rho=2.7e-6, alpha=2.1e-5)

    # element 1D max element force test
    elem_1D_id = 98
    elem_1D_load_id = 4

    # element 2D max element force test
    elem_2D_id = 17
    elem_2D_load_id = 2

    grid_set_id = "2"
    elem_1d_set_id = "5"
    elem_2d_set_id = "1"
    grid_set = get_set(set_filename=set_filename, set_id=grid_set_id)
    elem_1D_set = get_set(set_filename=set_filename, set_id=elem_1d_set_id)
    elem_2D_set = get_set(set_filename=set_filename, set_id=elem_2d_set_id)
    cord2r_set = ModelSet(id=1, name="coordinate set", content=[0])
    mat1_set = ModelSet(id=1, name="material set", content=[mat_id])
    test_template = TestTemplate(
        model_filename=test_filename,
        mat1_set=mat1_set,
        grid_set=grid_set,
        cord2r_set=cord2r_set,
        elem_1D_set=elem_1D_set,
        elem_2D_set=elem_2D_set,
        mat1_properties=mat1_properties,
        results_test={
            "1D": (set([elem_1D_id]), set([elem_1D_load_id])),
            "2D": (set([elem_2D_id]), set([elem_2D_load_id])),
        },
    )
    return test_template


def __test_case_local__():
    global TEST_FILEPATH
    set_filename = "TEST_SETS.out"
    test_filename = "GFEM_MOD_MAT.h5"

    TEST_FILEPATH = Path(__file__).parent / test_filename

    # material test
    mat_id = 2000110
    mat1_properties = IsoElastic(E=62693.74, G=25322.36, rho=1.58e-6, alpha=1.0163e-6)

    # element 1D max element force test
    elem_1D_id = 5307910
    elem_1D_load_id = 776

    # element 2D max element force test
    elem_2D_id = 16923480
    elem_2D_load_id = 98

    grid_set_id = "4"
    elem_1d_set_id = "5"
    elem_2d_set_id = "3"
    grid_set = get_set(set_filename=set_filename, set_id=grid_set_id)
    elem_1D_set = get_set(set_filename=set_filename, set_id=elem_1d_set_id)
    elem_2D_set = get_set(set_filename=set_filename, set_id=elem_2d_set_id)
    cord2r_set = ModelSet(id=1, name="coordinate set", content=[0])
    mat1_set = ModelSet(id=1, name="material set", content=[mat_id])
    test_template = TestTemplate(
        model_filename=test_filename,
        mat1_set=mat1_set,
        grid_set=grid_set,
        cord2r_set=cord2r_set,
        elem_1D_set=elem_1D_set,
        elem_2D_set=elem_2D_set,
        mat1_properties=mat1_properties,
        results_test={
            "1D": (set([elem_1D_id]), set([elem_1D_load_id])),
            "2D": (set([elem_2D_id]), set([elem_2D_load_id])),
        },
    )
    return test_template


def test_hdf5():
    test_template = __test_case_local__()

    if not TEST_FILEPATH.exists():
        test_template = __test_case_devx__()
    nas_analysis = NASTRANHDF5.from_filename(filename=TEST_FILEPATH)

    model = nas_analysis.model

    assert isinstance(model, NASTRANModel)
    assert isinstance(nas_analysis, NASTRANHDF5)
    assert isinstance(nas_analysis, NASTRANAnalysis)
    assert nas_analysis.hdf5.filename == TEST_FILEPATH
    assert nas_analysis.hdf5.isopen
    assert nas_analysis.get_table("NASTRAN", "RESULT")
    assert nas_analysis.get_table("NASTRAN", "INPUT")

    all_set = ModelSet.all()
    grid_all = model.grid(model_set=all_set)
    grid_subset = model.grid(model_set=test_template.grid_set)
    assert isinstance(grid_all, GRID)
    assert isinstance(grid_subset, GRID)

    mat1_all = MAT1()
    mat1_subset = MAT1()
    model.get(mat1_all, model_set=all_set)
    model.get(mat1_subset, model_set=test_template.mat1_set)
    assert isinstance(mat1_all, MAT1)
    assert isinstance(mat1_subset, MAT1)

    mid_subset = test_template.mat1_set
    mid = mid_subset.to_list()[0]

    E = test_template.mat1_properties.E
    G = test_template.mat1_properties.G
    nu = test_template.mat1_properties.nu
    rho = test_template.mat1_properties.rho
    alpha = test_template.mat1_properties.alpha

    for material in [mat1_all, mat1_subset]:
        properties = material.to_properties(mid=mid)
        assert isinstance(properties, IsoElastic)
        assert properties.E == E
        assert properties.G == pytest.approx(G)
        assert properties.nu == pytest.approx(nu)
        assert properties.rho == rho
        assert properties.alpha == alpha

    elem_1D_set = test_template.elem_1D_set
    print("1D Elements")
    start = time.time()
    el_forces_1D_set = nas_analysis.results.element_forces(
        model_set=elem_1D_set, element_type="1D"
    )
    end = time.time()
    assert isinstance(el_forces_1D_set, ElementForces)

    el_forces_1D = el_forces_1D_set.get("1D")

    assert isinstance(el_forces_1D, ElementForces1D)
    assert isinstance(el_forces_1D.to_polars(), pl.DataFrame)
    assert isinstance(el_forces_1D.to_dict(), dict)
    n_lines = len(el_forces_1D)
    print(
        f"Got {n_lines} CBEAM element forces for {len(elem_1D_set.to_set())} elements in"
        + f" {end - start} seconds"
    )

    start = time.time()
    scaled_el_forces_1D = el_forces_1D.scale(factor=2.0)
    end = time.time()
    print(f"Got {n_lines} scaled forces in {end - start} seconds")
    assert isinstance(scaled_el_forces_1D, ElementForces1D)

    start = time.time()
    # max_res = res.max(elements=set(elem_2D_set), load_cases=set([2, 3, 4]))
    max_force_components_1D = el_forces_1D.max(
        elements=elem_1D_set.to_set(), envelope=False
    )
    end = time.time()
    print(f"Got maximum forces by component in {end - start} seconds")
    assert isinstance(max_force_components_1D, ElementForces1D)

    max_force_1D_by_component = max_force_components_1D.max()
    assert isinstance(max_force_1D_by_component, ElementForces1D)

    sel_element, sel_loadcase = test_template.results_test["1D"]

    max_force_1D_extract = max_force_1D_by_component.max(
        elements=sel_element, load_cases=sel_loadcase
    )
    max_force_1D_extract_df = max_force_1D_extract.to_polars()
    assert set(max_force_1D_extract_df["EID"].to_list()) == sel_element
    assert set(max_force_1D_extract_df["LCID"].to_list()) == sel_loadcase

    start = time.time()
    # max_res = res.max(elements=set(elem_2D_set), load_cases=set([2, 3, 4]))
    min_force_components_1D = el_forces_1D.min(
        elements=elem_1D_set.to_set(), envelope=False
    )
    end = time.time()
    print(f"Got minimum forces by component in {end - start} seconds")
    assert isinstance(min_force_components_1D, ElementForces1D)

    start = time.time()
    # max_res = res.max(elements=set(elem_2D_set), load_cases=set([2, 3, 4]))
    resultant = el_forces_1D.resultant()
    end = time.time()
    print(f"Got resultant forces in {end - start} seconds")
    assert isinstance(resultant, Resultant1D)

    start = time.time()
    scaled_resultant = resultant.scale(factor=2.0)
    end = time.time()
    print(f"Got {n_lines} scaled resultant in {end - start} seconds")
    assert isinstance(scaled_resultant, Resultant1D)

    cbeam = model.beam(model_set=elem_1D_set)
    cord2r = CORD2R()
    model.get(cord2r, model_set=all_set)
    beam_ijk = cbeam.coordinate_systems(grid=grid_all, coord=cord2r)
    assert isinstance(cbeam, CBEAM)
    assert isinstance(beam_ijk, CORD2R)

    print("2D Elements")
    start = time.time()
    elem_2D_set = test_template.elem_2D_set
    el_forces_2D_set = nas_analysis.results.element_forces(
        model_set=elem_2D_set, element_type="2D"
    )
    # el_forces_2D = nas_analysis.results.element_forces(model_set=all_set, element_type="2D")
    end = time.time()
    el_forces_2D = el_forces_2D_set.get("2D")
    assert isinstance(el_forces_2D, ElementForces2D)
    assert isinstance(el_forces_2D.to_polars(), pl.DataFrame)
    assert isinstance(el_forces_2D.to_dict(), dict)
    n_lines = len(el_forces_2D)
    print(
        f"Got {n_lines} CQUAD4 and CTRIA3 element forces for {len(elem_2D_set.to_set())} elements in "
        + f"{end - start} seconds"
    )
    start = time.time()
    max_force_components_2D = el_forces_2D.max(
        elements=elem_2D_set.to_set(), envelope=False
    )
    end = time.time()
    print(f"Got maximum forces by component in {end - start} seconds")
    assert isinstance(max_force_components_2D, ElementForces2D)

    max_force_2D_by_component = max_force_components_2D.max()
    assert isinstance(max_force_2D_by_component, ElementForces2D)

    sel_element, sel_loadcase = test_template.results_test["2D"]

    max_force_2D_extract = max_force_2D_by_component.max(
        elements=sel_element, load_cases=sel_loadcase
    )
    max_force_2D_extract_df = max_force_2D_extract.to_polars()
    assert set(max_force_2D_extract_df["EID"].to_list()) == sel_element
    assert set(max_force_2D_extract_df["LCID"].to_list()) == sel_loadcase

    start = time.time()
    min_force_components_2D = el_forces_2D.min(
        elements=elem_2D_set.to_set(), envelope=False
    )
    end = time.time()
    print(f"Got minimum forces by component in {end - start} seconds")
    assert isinstance(min_force_components_2D, ElementForces2D)
    start = time.time()
    principals = el_forces_2D.principals()
    end = time.time()
    print(f"Got 2D principal components in {end - start} seconds")
    assert isinstance(principals, Principal2D)
    start = time.time()
    nas_analysis.results.to_material(el_forces_2D, components=["Fx", "Fy", "Fxy"])
    end = time.time()
    print(
        f"Tranformation from elemental to material coordinate system in {end - start} seconds"
    )

    cquad4, ctria3 = model.shell(model_set=all_set)
    assert isinstance(cquad4, CQUAD4)
    assert isinstance(ctria3, CTRIA3)

    assert nas_analysis.results.strains(model_set=elem_2D_set, element_type="2D")
    assert nas_analysis.results


def test_hdf5_errors():
    with pytest.raises(ValidationError) as exc_info:
        NASTRANHDF5.from_hdf5(hdf5=["this is not an HDF5 object"])
    assert exc_info.match("HDF5 required")
    # test a wrong format
    with pytest.raises(WrongHDF5Format) as exc_info:
        NASTRANHDF5.from_filename(filename=TEST_NOT_FILEPATH)
    assert exc_info.match("does not have a child named ``NASTRAN``")


# def create_hdf5_test():
#     import tables

#     h5file = tables.open_file("TEST_NOT_NASTRAN.h5", mode="w", title="Test file")
#     group = h5file.create_group("/", "detector", "Detector information")
#     table = h5file.create_table(group, "readout", tables.Particle, "Readout example")
#     table.flush()
#     h5file.close()


# if __name__ == "__main__":
#     test_hdf5()
#     test_hdf5_errors()
#     create_hdf5_test()


class TestNASTRANAnalysisProcessor:
    def test_initialization(self, nas_processor):
        assert nas_processor.h5_filepath == TEST_H5_FILEPATH
        assert nas_processor.set_filename == TEST_SET_FILEPATH
        # Additional assertions based on initialization

    def test_get_element_forces(self, nas_processor):
        set_id = "5"  # Replace with valid set ID
        df = nas_processor.get_element_forces(set_id)
        # Asserts for the dataframe
        assert not df.is_empty()

    def test_process_forces(self, nas_processor):
        set_id = "5"
        df = nas_processor.get_element_forces(set_id)
        processed_df = nas_processor.process_forces(df)
        # Asserts for processed dataframe
        assert not processed_df.is_empty()

    def test_get_element_Af_A(self, nas_processor):
        set_id = "5"
        load_set = nas_processor.get_element_Af_A(set_id)
        assert isinstance(load_set, LoadSet)
        assert load_set.loads[0] == FELoad(
            element_id=98,
            loadcase_id="2",
            load_type="Af_A",
            load_value=0.006779202242251728,
        )

        assert load_set.loads[1] == FELoad(
            element_id=99,
            loadcase_id="2",
            load_type="Af_A",
            load_value=0.006108539653600887,
        )
        # Additional asserts for load_set
