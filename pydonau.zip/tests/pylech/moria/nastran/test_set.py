#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug  3 10:13:58 2023

@author: gi11883
"""
import pytest
from pathlib import Path
from arpeggio import visit_parse_tree
from makerspace_mbe_pylantir.pylech.moria.nastran.parse import set_parser, NASTRANSetVisitor, NASTRANFESetCollection
from makerspace_mbe_pylantir.pylech.moria.fe_model import FESet

TEST_FILENAME = "TEST_SETS.out"


def test_sets():
    filename = Path(__file__).parent / TEST_FILENAME
    with open(filename, "r") as file:
        # get the parse tree
        parse_tree = set_parser.parse(file.read())
        # pass the parse tree to the visitor and get a dictionary containing ModelSet objects
        set_dict = visit_parse_tree(parse_tree, NASTRANSetVisitor())
        # check the first set
        subset_1 = set([3706730, 3706830, 5006230, 5006330, 5006430, 5006530, 5006630, 5006730, 5006830])
        set_1 = set_dict["1"]

        assert len(set_1) == 55
        assert sorted(list(set_1.to_set())) == sorted(set_1.to_list())
        assert subset_1.issubset(set_1.to_set())
        # check the second set
        set_2 = set_dict["3"]
        range_1 = range(16723101, 16723122 + 1)
        assert range_1 in set_2.content


class TestNASTRANFESetCollection:

    @pytest.fixture
    def sample_filename(self):
        # Assuming you have a sample NASTRAN set file for testing
        filename = Path(__file__).parent / TEST_FILENAME
        return filename

    def test_initialization(self, sample_filename):
        # Test the initialization of NASTRANFESetCollection
        collection = NASTRANFESetCollection(sample_filename)
        assert isinstance(collection, NASTRANFESetCollection)

    def test_load_sets(self, sample_filename):
        # Test if sets are loaded correctly
        collection = NASTRANFESetCollection(sample_filename)
        assert collection.sets  # Check if sets are not empty

    def test_get_set(self, sample_filename):
        # Test getting a specific set
        collection = NASTRANFESetCollection(sample_filename)
        set_id = "1"  # Assuming there is a set with ID 1 in your sample file
        fe_set = collection.get_set(set_id)
        assert isinstance(fe_set, FESet)
        assert str(fe_set.id) == set_id

    def test_all_sets(self, sample_filename):
        # Test getting all sets
        collection = NASTRANFESetCollection(sample_filename)
        all_sets = collection.all_sets()
        assert isinstance(all_sets, dict)
        assert all_sets  # Check if the dictionary of sets is not empty

# if __name__ == "__main__":
#     test_sets()
