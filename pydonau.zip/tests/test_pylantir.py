import pytest
from makerspace_mbe_pylantir.pylantir import add_numbers
from makerspace_mbe_pylantir import __version__
from makerspace_mbe_pylantir.scrolls import (
    get_math_from_docs,
    get_math_from_docs_multiple,
)


def test_version():
    assert __version__


def test_add_numbers():
    result = add_numbers(1, 2)
    assert result == 3, f"Expected 3 but got {result}"
    result = add_numbers(1, 1)
    assert result == 2, f"Expected 2 but got {result}"


def test_get_math_from_docs():
    doc_string_with_math = """
    This is a test docstring.
    It includes some math.
    :math:`y = mx + b`
    """

    doc_string_no_math = """
    This is a test docstring.
    It does not include any math.
    """

    assert (
        get_math_from_docs(doc_string_with_math)
        == r"\begin{equation}y = mx + b\end{equation}"
    )
    assert (
        get_math_from_docs(doc_string_no_math)
        == "no formula marker :math: in docstring"
    )


def test_get_math_from_docs_multiple():
    doc_string_with_math = """
    This is a test docstring.
    It includes some math.
    :math:`y = mx + b`
    :math:`y = mx + b`
    """

    doc_string_with_1_math = """
    This is a test docstring.
    It includes some math.
    :math:`y = mx + b`
    """

    doc_string_no_math = """
    This is a test docstring.
    It does not include any math.
    """

    assert get_math_from_docs_multiple(doc_string_with_math) == [
        r"\begin{equation}y = mx + b\end{equation}",
        r"\begin{equation}y = mx + b\end{equation}",
    ]
    assert (
        get_math_from_docs_multiple(doc_string_no_math)
        == "no formula marker :math: in docstring"
    )
    assert (
        get_math_from_docs_multiple(doc_string_with_math, return_string=True)
        == "\\begin{equation}y = mx + b\\end{equation}\n\\begin{equation}y = mx + b\\end{equation}"
    )
    assert get_math_from_docs_multiple(doc_string_with_1_math) == [
        "\\begin{equation}y = mx + b\\end{equation}"
    ]
    assert (
        get_math_from_docs_multiple(doc_string_with_1_math, return_string=True)
        == "\\begin{equation}y = mx + b\\end{equation}"
    )
