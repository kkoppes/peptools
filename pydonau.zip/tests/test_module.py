import unittest
from makerspace_mbe_pylantir import mod_name


class TestModule(unittest.TestCase):
    def test_basic(self):
        value = mod_name.generate_something()
        self.assertNotEqual(len(value), 0)


if __name__ == "__main__":
    unittest.main()
