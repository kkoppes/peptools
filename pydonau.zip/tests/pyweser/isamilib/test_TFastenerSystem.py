#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Unit test for the TMaterial class
"""
import pytest

import os
from pathlib import Path
from pydantic import ValidationError
from makerspace_mbe_pylantir.pyweser.isamilib import IsamiDB, TFastenerSystem


from makerspace_mbe_pylantir.pyweser.isamilib.utils import DatabaseError

from makerspace_mbe_pylantir.pyweser.isamilib.tfastenersystem.tfastenersystem import (
    StandardNotFound,
    InconsistentDiameters,
    WrongCombination,
)

from makerspace_mbe_pylantir.pyweser.isamilib.isamidb.isamidb import (
    VersionNotFound,
)

cur_dir = os.getcwd()
db_path = "tests/pyweser/isamilib"
db_filename = "TestFastenerLibrary.db"
wrong_db_filename = "UserMaterialLibrary.db"
db_version = "test"

if db_path in cur_dir:
    db_filepath = Path(cur_dir)
else:
    db_filepath = Path(cur_dir) / Path(db_path)

wrong_db_filepath = db_filepath / Path(wrong_db_filename)
db_filepath /= Path(db_filename)


def test_TFastener():
    isami_db = IsamiDB(database=db_filepath, version=db_version)

    tfast = TFastenerSystem(version="test", name="test", source=isami_db)
    pin = "prEN6115T"
    dash = "3A"
    nut = "ASNA2528"
    washer = None

    # test pin with nut/collar
    check_combination = True
    tfast.get_standard(
        pin=pin,
        dash=dash,
        nut_collar=nut,
        washer=washer,
        check_combination=check_combination,
    )
    fastener_system = tfast.fastener_system
    # test pin
    assert fastener_system.pin.standard == "prEN6115T"
    assert fastener_system.pin.dash == "3A"
    assert fastener_system.pin.diameter == 5.56
    # test nut_collar
    assert fastener_system.nut_collar.standard == "ASNA2528"
    assert fastener_system.nut_collar.dash == "3A"
    assert fastener_system.nut_collar.diameter == 5.56
    # test washer
    washer = "NSA5379C"
    washer_dash = "3A"
    check_combination = True
    tfast.get_standard(
        pin=pin,
        dash=dash,
        nut_collar=nut,
        washer=washer,
        washer_dash=washer_dash,
        check_combination=check_combination,
    )
    fastener_system = tfast.fastener_system
    assert fastener_system.pin.standard == "prEN6115T"
    assert fastener_system.pin.dash == "3A"
    assert fastener_system.pin.diameter == 5.56
    # test nut_collar
    assert fastener_system.nut_collar.standard == "ASNA2528"
    assert fastener_system.nut_collar.dash == "3A"
    assert fastener_system.nut_collar.diameter == 5.56
    # test whasher
    assert fastener_system.washer.standard == "NSA5379C"
    assert fastener_system.nut_collar.dash == "3A"
    assert fastener_system.nut_collar.diameter == 5.56
    # test without check_combination
    collar = "EN6054"
    collar_dash = "060"
    check_combination = False
    tfast.get_standard(
        pin=pin,
        dash=dash,
        nut_collar=collar,
        nut_collar_dash=collar_dash,
        washer=washer,
        check_combination=check_combination,
    )
    fastener_system = tfast.fastener_system
    assert fastener_system.pin.standard == "prEN6115T"
    assert fastener_system.pin.dash == "3A"
    assert fastener_system.pin.diameter == 5.56
    # test nut_collar
    assert fastener_system.nut_collar.standard == "EN6054"
    assert fastener_system.nut_collar.dash == "060"
    assert fastener_system.nut_collar.diameter == 5.56


def test_TFastener_errors():
    name = "test"
    # test a wrong database
    wrong_isami_db = IsamiDB(database=wrong_db_filepath, version=db_version)

    with pytest.raises(DatabaseError):
        TFastenerSystem(version=db_version, name=name, source=wrong_isami_db)
    # test errors from a correct database
    isami_db = IsamiDB(database=db_filepath, version=db_version)

    pin = "prEN6115T"
    dash = "3A"
    nut = "ASNA2528"
    nut_dash = "3"
    collar = "EN6054"
    collar_dash = "060"
    washer = "NSA5379C"
    washer_dash = "3A"

    with pytest.raises(VersionNotFound):
        TFastenerSystem(version=1, name=name)
    tfast = TFastenerSystem(version=db_version, name=name, source=isami_db)
    # test missing input
    with pytest.raises(TypeError):
        TFastenerSystem()
    with pytest.raises(TypeError):
        TFastenerSystem(isami_db=isami_db)
    with pytest.raises(TypeError):
        TFastenerSystem(name=name)
    with pytest.raises(TypeError):
        tfast.get_standard(pin="this_not_exists")
    with pytest.raises(TypeError):
        tfast.get_standard(dash="-")
    # test not existing fastener
    with pytest.raises(StandardNotFound):
        tfast.get_standard(pin="this_not_exists", dash="-", nut_collar=nut)
    with pytest.raises(StandardNotFound):
        tfast.get_standard(pin=pin, dash="-", nut_collar=nut)
    # test not existing nut/collar
    with pytest.raises(StandardNotFound):
        tfast.get_standard(pin=pin, dash=dash, nut_collar="this_not_exists")
    # test not existing washer
    with pytest.raises(StandardNotFound):
        tfast.get_standard(pin=pin, dash=dash, nut_collar=nut, washer="this_not_exists")
    with pytest.raises(StandardNotFound):
        tfast.get_standard(
            pin=pin, dash=dash, nut_collar=nut, washer=washer, washer_dash="-"
        )
    # test pin without nut/collar
    with pytest.raises(TypeError):
        tfast.get_standard(pin=pin, dash=dash)
    # test wrong pin and nut/collar combination
    with pytest.raises(WrongCombination):
        tfast.get_standard(
            pin=pin, dash=dash, nut_collar=collar, nut_collar_dash=collar_dash
        )
    # test inconsitent diameters
    with pytest.raises(InconsistentDiameters):
        tfast.get_standard(
            pin=pin,
            dash=dash,
            nut_collar=nut,
            nut_collar_dash=nut_dash,
            washer=washer,
            washer_dash=washer_dash,
        )


# if __name__ == "__main__":
#     test_TFastener()
#     test_TFastener_errors()
