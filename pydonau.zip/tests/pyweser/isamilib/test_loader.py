import importlib
import pytest

from makerspace_mbe_pylantir.pyweser.isamilib.loader import (
    PluginInterface,
    import_module,
    load_plugins,
)


@pytest.fixture
def mock_plugin(monkeypatch):
    class MockPlugin(PluginInterface):
        def __init__(self):
            self.initialized = False

        def initialize(self):
            self.initialized = True

    plugin = MockPlugin()
    monkeypatch.setattr(importlib, "import_module", lambda x: plugin)
    return plugin


def test_import_module(mock_plugin):
    result = import_module("dummy_module")
    assert result == mock_plugin


def test_load_plugins(mock_plugin):
    plugins = ["dummy_module"]
    load_plugins(plugins)
    assert mock_plugin.initialized
