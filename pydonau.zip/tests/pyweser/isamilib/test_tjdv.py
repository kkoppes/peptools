import pytest
from pathlib import Path
import os
from makerspace_mbe_pylantir.pyweser.isamilib.tjdv.tjdv import (
    TJDVSinglePlateJoint,
    TJDV,
    TJDVPart,
    TJDVAnalysis,
)
from makerspace_mbe_pylantir.pyweser.isamilib import TMaterial, TFastenerSystem
from makerspace_mbe_pylantir.pyweser.isamilib.isamidb.isamidb import (
    VersionNotFound,
    DatabaseNotFound,
    DatabaseNotSupported,
    SQLConnectionError,
    IsamiDB,
)

curdir = Path(__file__).parent
db_jdv_filename = "Fuselage_JDV_Tables_dummy.db"
db_material_filename = "UserMaterialLibrary.db"
db_fastener_filename = "TestFastenerLibrary.db"
db_fastener_filename = "TestFastenerLibrary.db"
db_curve_filename = "TestCurveLibrary.db"
db_jdv_filepath = curdir / Path(db_jdv_filename)
db_version = "test"
db_material_filepath = curdir / Path(db_material_filename)
db_curve_filepath = curdir / Path(db_curve_filename)
db_fastener_filepath = curdir / Path(db_fastener_filename)


@pytest.fixture
def isamijdvdb():
    isamidb = IsamiDB(database=db_jdv_filepath, version=db_version)
    return isamidb


@pytest.fixture
def tjdvsingleplatejoint(isamijdvdb):
    tjdvsingle = TJDVSinglePlateJoint(
        name="Joint_Test",
        mat_spec="AIMS03-18-006",
        pin_code="prEN6115T",
        nut_code="ASNA2528",
        fastener_diameter=5.56,
        calculation_type="Ultimate",
        billet_dimension=10,
        part_thickness=2,
        jdv_db=isamijdvdb,
    )
    return tjdvsingle


@pytest.fixture
def material():
    isami_material_db = IsamiDB(database=db_material_filepath, version=db_version)
    isami_curve_db = IsamiDB(database=db_curve_filepath, version=db_version)
    tmat = TMaterial(
        name="test",
        version="test",
        source=isami_material_db,
        source_curve=isami_curve_db,
    )
    spec = "AIMS03-18-006"
    basis = "A"
    billet = 20.0
    orientation = "L"
    tmat.get_material_data(spec=spec)
    tmat.get_material_attributes(billet=billet, basis=basis, orientation=orientation)
    tmat.get_material(spec=spec, billet=billet, basis=basis, orientation=orientation)
    return tmat.material


@pytest.fixture
def fastener_system():
    isami_db = IsamiDB(database=db_fastener_filepath, version=db_version)
    tfast = TFastenerSystem(version="test", name="test", source=isami_db)
    pin = "prEN6115T"
    dash = "3A"
    nut = "ASNA2528"
    washer = None

    check_combination = True
    tfast.get_standard(
        pin=pin,
        dash=dash,
        nut_collar=nut,
        washer=washer,
        check_combination=check_combination,
    )
    return tfast.fastener_system


@pytest.fixture
def tjdv_part(material):
    part = TJDVPart(part_name="Testpart", material=material, thickness=2, eD=2)
    return part


@pytest.fixture
def tjdv_analysis(fastener_system, tjdv_part, isamijdvdb):
    analysis = TJDVAnalysis(
        calculation="TJDVAnalysis",
        version="test",
        load_type="Shear",
        calculation_type="Ultimate",
        boundary_condition="unsupported",
        fastener_system=fastener_system,
        joint_parts=[tjdv_part, tjdv_part],
        jdv_db=isamijdvdb,
    )
    return analysis


def test_database_connect(tjdvsingleplatejoint):
    assert isinstance(tjdvsingleplatejoint.jdv_db, IsamiDB)


def test_get_material_key(tjdvsingleplatejoint):
    mat_key = tjdvsingleplatejoint._TJDVSinglePlateJoint__get_material_key(
        plate_mat_spec="AIMS03-18-006", plate_billet="50", criteria_type="Ultimate"
    )
    assert mat_key == "Ultimate1"


def test_get_material_name(tjdvsingleplatejoint):
    mat_name = tjdvsingleplatejoint._TJDVSinglePlateJoint__get_material_name(
        plate_mat_spec="AIMS03-18-006", plate_billet="50", criteria_type="Ultimate"
    )
    assert mat_name == "Ti-6Al-4V_ab_Annealed_Plate"


def test__get_fastenersystem_key_list(tjdvsingleplatejoint):
    fastsystemkeylist = (
        tjdvsingleplatejoint._TJDVSinglePlateJoint__get_fastenersystem_key_list(
            pin_code="prEN6115T", nut_code="ASNA2528"
        )
    )
    assert fastsystemkeylist[0] == "1"


def test__get_fastenersystem_key_from_BC_table(tjdvsingleplatejoint):
    fastsystemkeylist = tjdvsingleplatejoint._TJDVSinglePlateJoint__get_fastenersystem_key_from_BC_table(
        fastenersystemkeylist=["1"], boundary_condition="unsupported"
    )
    assert fastsystemkeylist[0] == "1"


def test__get_fastenersystemkey_of_diameter(tjdvsingleplatejoint):
    fastsystemkeylist = (
        tjdvsingleplatejoint._TJDVSinglePlateJoint__get_fastenersystemkey_of_diameter(
            fastenersystemkey="1", fastener_diameter="5.56"
        )
    )
    assert fastsystemkeylist[0] == "1"


def test__get_allowable_table_no(tjdvsingleplatejoint):
    tableno = tjdvsingleplatejoint._TJDVSinglePlateJoint__get_allowable_table_no(
        materialkey="Ultimate1",
        fastenerkey="1",
        loadtype="Shear",
        materialposition="Head",
    )
    assert tableno[0] == "1.1.1.1 (a)"


def test__allowable_interpolation(tjdvsingleplatejoint):
    interp = tjdvsingleplatejoint._TJDVSinglePlateJoint__allowable_interpolation(
        thk_plate="3",
        thk_lower="2",
        allow_lower="10000",
        thk_higher="4",
        allow_higher="20000",
    )
    assert interp == 15000


def test__get_joint_allowable_from_table_direct_thickness(tjdvsingleplatejoint):
    joint_allow = (
        tjdvsingleplatejoint._TJDVSinglePlateJoint__get_joint_allowable_from_table(
            table_id="1.1.1.1 (a)", plate_thk="2", fastener_diameter="5.56"
        )
    )
    assert joint_allow == "10000"


def test__get_boltbearing_joint_allowable_from_table_list(tjdvsingleplatejoint):
    joint_allow = tjdvsingleplatejoint._TJDVSinglePlateJoint__get_boltbearing_joint_allowable_from_table_list(
        table_id_list=["1.1.1.1 (a)"], plate_thk="2", fastener_diameter="5.56"
    )
    assert joint_allow[0] == "10000"


def test__get_boltbearing_joint_allowable(tjdvsingleplatejoint):
    joint_allow = (
        tjdvsingleplatejoint._TJDVSinglePlateJoint__get_boltbearing_joint_allowable(
            mat_spec=tjdvsingleplatejoint.mat_spec,
            billet_dimension=tjdvsingleplatejoint.billet_dimension,
            calculation_type=tjdvsingleplatejoint.calculation_type,
            pin_code=tjdvsingleplatejoint.pin_code,
            nut_code=tjdvsingleplatejoint.nut_code,
            boundary_condition=tjdvsingleplatejoint.boundary_condition,
            fastener_diameter=tjdvsingleplatejoint.fastener_diameter,
            load_type=tjdvsingleplatejoint.load_type,
            part_position=tjdvsingleplatejoint.part_position,
            part_thickness=tjdvsingleplatejoint.part_thickness,
        )
    )

    assert joint_allow[0] == "10000"


def test_get_joint_allowable_nut_head_plate(tjdvsingleplatejoint):
    joint_allow = (
        tjdvsingleplatejoint._TJDVSinglePlateJoint__get_joint_allowable_nut_head_plate()
    )
    assert joint_allow["Ultimate Allowable"] == "10000"


def test_boltbearing_allowable_property(tjdvsingleplatejoint):
    joint_allow = tjdvsingleplatejoint.allowables
    assert joint_allow["Ultimate Allowable"] == "10000"


def test_joint_part(tjdv_part):
    assert tjdv_part.part_name == "Testpart"
    assert tjdv_part.material.specification == "AIMS03-18-006"


def test_tjdv_analysis(tjdv_analysis):
    assert tjdv_analysis.boundary_condition == "unsupported"


def test_tjdvanalysis__get_part_allowables(tjdv_analysis):
    print(tjdv_analysis.fastener_system.pin.diameter)
    allowables = tjdv_analysis._TJDVAnalysis__get_part_allowables(
        part=tjdv_analysis.joint_parts[0], part_position="Head"
    )
    assert allowables["Ultimate Allowable"] == "10000"


def test_get_allowables(tjdv_analysis):
    allowables = tjdv_analysis.allowables
    assert allowables["Testpart"]["Ultimate Allowable"] == "10000"
    assert allowables["Part_2"]["Ultimate Allowable"] == "10000"
