import pytest
import os
from pathlib import Path
from PIL import Image
from makerspace_mbe_pylantir.pyweser.isamilib import (
    IsamiDB,
    TProfile,
    TProfileIdentifier,
    tprofile_factory,
)

from makerspace_mbe_pylantir.pyelbe.matreel import IsoElastic, Material

cur_dir = os.getcwd()
db_path = "tests/pyweser/isamilib"
db_filename = "GenericProfileLibrary.db"

if db_path in cur_dir:
    db_filepath = Path(cur_dir)
else:
    db_filepath = Path(cur_dir) / Path(db_path)
db_filepath /= Path(db_filename)


@pytest.fixture
def db_for_test():
    db_version = "test"

    isamidb = IsamiDB(database=db_filepath, version=db_version)
    return isamidb


@pytest.fixture
def dim_Metal_Stg_Z_01_a():
    dimensions = {
        "ba": 20.0,
        "bf": 10.0,
        "h": 100.0,
        "ra": 8.0,
        "rf": 8.0,
        "ta": 5.0,
        "tf": 5.0,
        "tw": 4.0,
    }
    return dimensions


@pytest.fixture
def profile_Metal_Stg_Z_01_a(db_for_test):
    # Create TProfile object
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier(
        mattype="Metal", structtype="Stg", family="Z", number="01", variant="a"
    )
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    return profile


def test_TProfileIdentifier_from_query():
    """test for TProfileIdentifier.from_query"""
    query_result = (1, b"Compo", b"Clp", b"C", b"01", b"e")
    tpid = TProfileIdentifier.from_query(query_result)
    assert isinstance(tpid, TProfileIdentifier)
    assert tpid.mattype == "Compo"
    assert tpid.structtype == "Clp"
    assert tpid.family == "C"
    assert tpid.number == "01"
    assert tpid.variant == "e"
    assert tpid.id_string == "Compo_Clp_C_01_e"
    assert tpid.identifiers == ("Compo", "Clp", "C", "01", "e")


def test_TProfile(db_for_test):
    """test for TProfile"""
    isami_db = db_for_test
    name = "testprofile"
    profile = TProfile(name=name, isami_db=isami_db)
    assert isinstance(profile, TProfile)


def test_TProfile_list(db_for_test):
    """test for TProfile"""
    isami_db = db_for_test
    name = "testprofile"
    profile = TProfile(name=name, isami_db=isami_db)
    profile_list = profile.get_profiles_list()
    assert profile_list[0] == (445, "Compo", "Clp", "C", "01", "e")


def test_TProfile_id(db_for_test):
    """test for TProfile"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    profile_id = profile.profile_id
    assert profile_id == 445


def test_TProfile_geom(db_for_test):
    """test for TProfile"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    profile_geom = profile.geometry
    assert profile_geom[0] == ["Layer", "Layer1", "T"]


def test_TProfile_info(db_for_test):
    """test for TProfile"""
    isami_db = db_for_test
    name = "testprofile"

    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)

    profile_info = profile.info
    assert profile_info[0][:6] == (445, "Compo", "Clp", "C", "01", "e")


def test_TProfile_from_list(db_for_test):
    """test for TProfile.from_list"""
    isami_db = db_for_test
    name = "testprofile"
    args = [name, isami_db, ["Compo", "Clp", "C", "01", "e"], None, None, None]
    profile = TProfile.from_list(args)
    assert isinstance(profile, TProfile)
    assert profile.identifiers.mattype == "Compo"


def test_TProfile_invalid_identifiers(db_for_test):
    """test for TProfile with invalid identifiers"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Invalid", "Invalid", "Invalid", "00", "a")
    with pytest.raises(ValueError):
        _ = TProfile(name=name, isami_db=isami_db, identifiers=_id)


def test_TProfile_no_isami_db():
    """test for TProfile without an IsamiDB object"""
    name = "testprofile"
    with pytest.raises(TypeError):
        _ = TProfile(name=name)


def test_TProfile_get_profile_dimensions(db_for_test):
    """test for TProfile.__get_profile_dimensions"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    profile_dimensions = profile._TProfile__get_profile_dimensions()
    assert isinstance(profile_dimensions, list)
    assert len(profile_dimensions) > 0
    for dimension in profile_dimensions:
        assert isinstance(dimension, tuple)
        assert len(dimension) == 5
        assert isinstance(dimension[0], int)  # PRF_ID
        assert isinstance(dimension[1], str)  # DIM_Name
        assert isinstance(dimension[2], float)  # DIM_Value
        assert isinstance(dimension[3], str)  # DIM_Type
        assert isinstance(dimension[4], str)  # DIM_Unit


def test_TProfile_get_profile_image(db_for_test):
    """test for TProfile.__get_profile_image"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    profile_image = profile._TProfile__get_profile_image()
    assert isinstance(profile_image, Image.Image)


def test_TProfile_get_elm_by_name(db_for_test):
    """test for TProfile._get_elm_by_name"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    elm_name = "Layer1"
    element = profile._TProfile__get_elm_by_name(elm_name)
    assert element.elm_name == elm_name


def test_TProfile_get_elm_by_type(db_for_test):
    """test for TProfile.__get_elm_by_type"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    elm_type = "Outline"
    element = profile._TProfile__get_elm_by_type(elm_type)
    assert element.elm_type == elm_type


def test_TProfile_get_elm_by_dim(db_for_test):
    """test for TProfile._get_elm_by_dim"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    dim = "h"
    element = profile._TProfile__get_elm_by_dim(dim)
    assert element.dim_name == dim


def test_TProfile_get_outline(db_for_test):
    """test for TProfile._get_outline"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    outline = profile._TProfile__get_outline()
    assert outline.elm_type == "Outline"


def test_TProfile_get_anchor(db_for_test):
    """test for TProfile._get_anchor"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    anchor = profile._TProfile__get_anchor()
    assert anchor.elm_type == "Anchor"


def test_TProfile_get_anchor_point(db_for_test):
    """test for TProfile._get_anchor_point"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    anchor_point = profile._TProfile__get_anchor_point()
    assert anchor_point


def test_TProfile_get_outline_names(db_for_test):
    """test for TProfile._get_outline_names"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    outline_names = profile._TProfile__get_outline_names()
    assert outline_names


def test_TProfile_get_outline_elm_list(db_for_test):
    """test for TProfile._get_outline_elm_list"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    outline_elm_list = profile._TProfile__get_outline_elm_list()

    # Check if the returned list is not empty
    assert outline_elm_list

    # Check if the returned list has the correct length
    outline_names = profile._TProfile__get_outline_names()
    assert len(outline_elm_list) == len(outline_names)

    # Check if the elements in the list are correctly ordered
    _ = [elm.point_1 for elm in outline_elm_list]
    # assert profile.anchor_point in first_point_list
    # anchor_elm_index = first_point_list.index(profile.anchor_point)
    # assert outline_elm_list[anchor_elm_index].point_1 == profile.anchor_point

    for i in range(len(outline_elm_list)):
        current_elm = outline_elm_list[i]
        next_elm = outline_elm_list[(i + 1) % len(outline_elm_list)]
        assert current_elm.get_points()[-1] == next_elm.get_points()[0]


def test_TProfile_get_outline_points(db_for_test):
    """test for TProfile._get_outline_points"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    outline_point_list = profile._TProfile__get_outline_points()

    # Check if the returned list is not empty
    assert outline_point_list

    # Check if there are no consecutive duplicates in the list
    for i in range(len(outline_point_list) - 1):
        assert outline_point_list[i] != outline_point_list[i + 1]

    # Check if the list starts and ends with the same point, indicating a closed loop
    assert outline_point_list[0] == outline_point_list[-1]


def test_TProfile_get_outline_points_coord_list(db_for_test):
    """test for TProfile._get_outline_points_coord_list"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    coord_list = profile._TProfile__get_outline_points_coord_list()

    # Check if the returned list is not empty
    assert coord_list

    # Check if the list contains tuples of coordinates (x, y)
    for coord in coord_list:
        assert isinstance(coord, tuple)
        assert len(coord) == 2
        assert isinstance(coord[0], (int, float))
        assert isinstance(coord[1], (int, float))


# def test_TProfile_fix_outline(db_for_test):
#     """test for TProfile._fix_outline"""
#     isami_db = db_for_test
#     name = "testprofile"
#     _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
#     profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
#     profile._fix_outline()

#     outline_elm_list = profile._TProfile__get_outline_elm_list()

#     # Check if the first and last elements' points coincide
#     points_first_elm = outline_elm_list[0].get_points()
#     points_last_elm = outline_elm_list[-1].get_points()
#     first_point = last_point = set(points_first_elm).intersection(points_last_elm).pop()
#     assert outline_elm_list[0].get_points()[0] == first_point
#     assert outline_elm_list[-1].get_points()[-1] == last_point

#     # Check if the first point of an element matches the last point of the previous element
#     for i in range(1, len(outline_elm_list)):
#         assert (
#             outline_elm_list[i].get_points()[0]
#             == outline_elm_list[i - 1].get_points()[-1]
#        )


# def test_TProfile_get_dimension_elements(db_for_test):
#     """test for TProfile._get_dimension_elements"""
#     isami_db = db_for_test
#     name = "testprofile"
#     _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
#     profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
#     dimension_elements = profile._TProfile__get_dimension_elements()

#     # Check if the returned list is not empty
#     assert len(dimension_elements) > 0

#     # Check if all elements in the list have the 'dim_name' attribute
#     for elm in dimension_elements:
#         assert "dim_name" in elm.get_attributes()


def test_TProfile_points_fixed(db_for_test):
    """test for TProfile._points_fixed"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)

    profile.set_dimension(profile.anchor.point_1, "_x_fix", True)
    profile.set_dimension(profile.anchor.point_1, "_y_fix", True)
    fixed_points_x, fixed_points_y = profile._TProfile__points_fixed()

    # Check if the returned lists are not empty
    assert len(fixed_points_x) > 0
    assert len(fixed_points_y) > 0

    # Check if all elements in the lists have "P" in their name
    for point_name in fixed_points_x:
        assert "P" in point_name

    for point_name in fixed_points_y:
        assert "P" in point_name

    # Check if all elements in the lists are fixed in x or y direction
    for point_name in fixed_points_x:
        point = profile._TProfile__get_elm_by_name(point_name)
        assert point._x_fix

    for point_name in fixed_points_y:
        point = profile._TProfile__get_elm_by_name(point_name)
        assert point._y_fix


def test_apply_point_on_line(db_for_test, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    profile.set_dimension(profile.anchor.point_1, "_x_fix", True)
    profile.set_dimension(profile.anchor.point_1, "_y_fix", True)

    # ... set up other required objects and attributes ...
    point_on_line_elm_name = "C14"

    pol_elm = profile._TProfile__get_elm_by_name(point_on_line_elm_name)
    pol_elm_line_1 = pol_elm.line_1
    line_elm = profile._TProfile__get_elm_by_name(pol_elm_line_1)

    # Call the __apply_point_on_line method
    profile._TProfile__apply_point_on_line(pol_elm)

    # Check the expected results
    # (Replace with your actual checks)

    line_elm_point_1 = profile._TProfile__get_elm_by_name(line_elm.point_1)
    line_elm_point_2 = profile._TProfile__get_elm_by_name(line_elm.point_2)

    p1_xfix = line_elm_point_1._x_fix
    p2_xfix = line_elm_point_2._x_fix
    p1_yfix = line_elm_point_1._y_fix
    p2_yfix = line_elm_point_2._y_fix

    assert p1_xfix is False
    assert p2_xfix is False

    assert p1_yfix is True
    assert p2_yfix is True

    # ... set up other required objects and attributes ...
    point_on_line_elm_name = "C15"

    pol_elm = profile._TProfile__get_elm_by_name(point_on_line_elm_name)
    pol_elm_line_1 = pol_elm.line_1

    line_elm = profile._TProfile__get_elm_by_name(pol_elm_line_1)

    # Call the __apply_point_on_line method
    profile._TProfile__apply_point_on_line(pol_elm)

    # Check the expected results
    # (Replace with your actual checks)

    line_elm_point_1 = profile._TProfile__get_elm_by_name(line_elm.point_1)
    line_elm_point_2 = profile._TProfile__get_elm_by_name(line_elm.point_2)

    p1_xfix = line_elm_point_1._x_fix
    p2_xfix = line_elm_point_2._x_fix
    p1_yfix = line_elm_point_1._y_fix
    p2_yfix = line_elm_point_2._y_fix

    assert p1_xfix is True
    assert p2_xfix is True

    assert p1_yfix is False
    assert p2_yfix is False


def test_apply_verticality(db_for_test, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    # Set up required objects and attributes

    vert_elm_name = "C11"
    ver_elm = profile._TProfile__get_elm_by_name(vert_elm_name)

    ver_elm_point_1 = ver_elm.point_1
    ver_elm_point_2 = ver_elm.point_2

    # Set the first point as fixed in x
    point_1 = profile._TProfile__get_elm_by_name(ver_elm_point_1)
    profile.set_dimension(point_1.elm_name, "_x_fix", True)

    # Call the __apply_verticality method
    profile._TProfile__apply_verticality(ver_elm)

    # Check the expected results
    point_1_updated = profile._TProfile__get_elm_by_name(ver_elm_point_1)
    point_2_updated = profile._TProfile__get_elm_by_name(ver_elm_point_2)

    assert point_1_updated._x_fix is True
    assert point_2_updated._x_fix is True
    assert point_1_updated.x_coord == point_2_updated.x_coord


def test_apply_horizontality(db_for_test, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    # Set up required objects and attributes

    hor_elm_name = "C2"
    hor_elm = profile._TProfile__get_elm_by_name(hor_elm_name)

    hor_elm_point_1 = hor_elm.point_1
    hor_elm_point_2 = hor_elm.point_2

    # Set the first point as fixed in y
    point_1 = profile._TProfile__get_elm_by_name(hor_elm_point_1)
    profile.set_dimension(point_1.elm_name, "_y_fix", True)

    # Call the __apply_horizontality method
    profile._TProfile__apply_horizontality(hor_elm)

    # Check the expected results
    point_1_updated = profile._TProfile__get_elm_by_name(hor_elm_point_1)
    point_2_updated = profile._TProfile__get_elm_by_name(hor_elm_point_2)

    assert point_1_updated._y_fix is True
    assert point_2_updated._y_fix is True
    assert point_1_updated.y_coord == point_2_updated.y_coord


def test_apply_horizontal_distance(
    db_for_test, dim_Metal_Stg_Z_01_a, profile_Metal_Stg_Z_01_a
):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    # Set up required objects and attributes

    dimensions = dim_Metal_Stg_Z_01_a

    dim_value = dimensions["bf"]

    hd_elm_name = "C24"
    hd_elm = profile._TProfile__get_elm_by_name(hd_elm_name)

    hd_elm_point_1 = hd_elm.point_1
    hd_elm_point_2 = hd_elm.point_2

    # Set the first point as fixed in x
    point_1 = profile._TProfile__get_elm_by_name(hd_elm_point_1)
    profile.set_dimension(point_1.elm_name, "_x_fix", True)

    # Call the __apply_horizontal_distance method
    profile._TProfile__apply_horizontal_distance(rel_elm=hd_elm, dimensions=dimensions)

    # Check the expected results
    point_1_updated = profile._TProfile__get_elm_by_name(hd_elm_point_1)
    point_2_updated = profile._TProfile__get_elm_by_name(hd_elm_point_2)

    assert point_1_updated._x_fix is True
    assert point_2_updated._x_fix is True
    assert point_2_updated.x_coord == point_1_updated.x_coord + dim_value


def test_apply_vertical_distance(
    db_for_test, dim_Metal_Stg_Z_01_a, profile_Metal_Stg_Z_01_a
):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    # Set up required objects and attributes
    vd_elm_name = "C31"
    dimensions = dim_Metal_Stg_Z_01_a

    dim_value = dimensions["h"]

    vd_elm = profile._TProfile__get_elm_by_name(vd_elm_name)

    vd_elm_point_1 = vd_elm.point_1
    vd_elm_point_2 = vd_elm.point_2

    # Set the first point as fixed in y
    profile.set_dimension(vd_elm_point_1, "_y_fix", True)

    # Call the __apply_vertical_distance method
    profile._TProfile__apply_vertical_distance(rel_elm=vd_elm, dimensions=dimensions)

    # Check the expected results
    point_1_updated = profile._TProfile__get_elm_by_name(vd_elm_point_1)
    point_2_updated = profile._TProfile__get_elm_by_name(vd_elm_point_2)

    assert point_1_updated._y_fix is True
    assert point_2_updated._y_fix is True
    assert point_2_updated.y_coord == point_1_updated.y_coord + dim_value


def test_apply_circle_arc(db_for_test, dim_Metal_Stg_Z_01_a, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    # Set up required objects and attributes
    arc_elm_name = "A2"
    arc_elm = profile._TProfile__get_elm_by_name(arc_elm_name)

    arc_point_1 = arc_elm.point_1
    arc_point_2 = arc_elm.point_2

    # Set the first point as fixed in x and y
    point_1 = profile._TProfile__get_elm_by_name(arc_point_1)
    profile.set_dimension(point_1.elm_name, "_x_fix", True)
    profile.set_dimension(point_1.elm_name, "_y_fix", True)

    # Set the circle arc dimension value
    dimensions = {
        "ba": 20.0,
        "bf": 10.0,
        "h": 100.0,
        "ra": 8.0,
        "rf": 8.0,
        "ta": 5.0,
        "tf": 5.0,
        "tw": 4.0,
    }

    # TODO CHECK VALUE dim_value = dimensions["rf"]

    # Call the __apply_circle_arc method
    profile._TProfile__apply_circle_arc(arc_elm=arc_elm, dimensions=dimensions)

    # Check the expected results
    point_1_updated = profile._TProfile__get_elm_by_name(arc_point_1)
    point_2_updated = profile._TProfile__get_elm_by_name(arc_point_2)

    assert point_1_updated.x_coord == 15.0
    assert point_1_updated.y_coord == 190.0
    assert point_2_updated.x_coord == 23.0
    assert point_2_updated.y_coord == 198.0


def test_find_relative_elms(db_for_test, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    # Set up required objects and attributes

    point_name = "P1"

    # Call the __find_relative_elms method
    relative_elements = profile._TProfile__find_relative_elms(point_name)

    # Check the expected results
    # Add a list of expected relative elements based on your test scenario
    expected_relative_elements = ["C14", "C15"]
    assert set(relative_elements) == set(expected_relative_elements)


def test_set_arcs(db_for_test, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    # Set up required objects and attributes

    # Assuming you have already added arc elements to the profile

    # Call the __set_arcs method
    profile._TProfile__set_arcs()

    # Check the expected results
    # Iterate through the arc elements and check their _clockwise and _clockwise_set properties
    for arc_elm in [el for el in profile.elements if el.elm_type == "CircleArc"]:
        assert arc_elm._clockwise is not None
        assert arc_elm._clockwise_set is True


def test_loop_both_fixed(db_for_test, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    # Set up required objects and attributes

    # Assuming you have already added constraints and elements to the profile
    profile.set_dimension(profile.anchor.point_1, "_x_fix", True)
    profile.set_dimension(profile.anchor.point_1, "_y_fix", True)

    constraints = [
        "PointOnLine",
        "Distance",  # distance on a dimension
        "DistanceToLine",  # distance to a line
        "CircleArc",  # radius of an arc
    ]

    running_points = ["P1"]  # List of point names in the running_points

    # Call the __loop_both_fixed method
    profile._TProfile__loop_both_fixed(
        constraints=constraints, running_points=running_points
    )

    P1_xset = profile._TProfile__get_elm_by_name("P1")._x_fix
    P1_yset = profile._TProfile__get_elm_by_name("P1")._y_fix

    P2_xset = profile._TProfile__get_elm_by_name("P2")._x_fix
    P2_yset = profile._TProfile__get_elm_by_name("P2")._y_fix

    P3_xset = profile._TProfile__get_elm_by_name("P3")._x_fix
    P3_yset = profile._TProfile__get_elm_by_name("P3")._y_fix

    P13_xset = profile._TProfile__get_elm_by_name("P13")._x_fix
    P13_yset = profile._TProfile__get_elm_by_name("P13")._y_fix

    P14_xset = profile._TProfile__get_elm_by_name("P14")._x_fix
    P14_yset = profile._TProfile__get_elm_by_name("P14")._y_fix

    assert P1_xset is True
    assert P1_yset is True
    assert P2_xset is True
    assert P2_yset is False
    assert P3_xset is True
    assert P3_yset is False
    assert P13_xset is False
    assert P13_yset is True
    assert P14_xset is False
    assert P14_yset is True


def test_loop_x_fixed(db_for_test, dim_Metal_Stg_Z_01_a, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a
    dimensions = dim_Metal_Stg_Z_01_a
    # Set up required objects and attributes

    # Assuming you have already added constraints and elements to the profile
    profile.set_dimension("P3", "_x_fix", True)

    x_constraints = [
        "HorizontalDistance",  # x_coord_2 == x_coord_1 + distance
        "Verticality",  # x_coord_2 == x_coord_1
        "CircleArc",  # radius of an arc
    ]

    running_points = ["P3"]  # List of point names in the running_points

    # Call the __loop_both_fixed method
    profile._TProfile__loop_x_fixed(
        x_constraints=x_constraints,
        running_points_x=running_points,
        dimensions=dimensions,
    )

    P3_xset = profile._TProfile__get_elm_by_name("P3")._x_fix
    P3_yset = profile._TProfile__get_elm_by_name("P3")._y_fix

    P4_xset = profile._TProfile__get_elm_by_name("P4")._x_fix
    P4_yset = profile._TProfile__get_elm_by_name("P4")._y_fix

    assert P3_xset is True
    assert P3_yset is False
    assert P4_xset is True
    assert P4_yset is False


def test_loop_y_fixed(db_for_test, dim_Metal_Stg_Z_01_a, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a
    dimensions = dim_Metal_Stg_Z_01_a
    # Set up required objects and attributes

    # Assuming you have already added constraints and elements to the profile
    profile.set_dimension("P13", "_y_fix", True)

    y_constraints = [
        "Horizontality",  # y_coord_2 == y_coord_1
        "VerticalDistance",  # y_coord_2 == y_coord_1 + distance
        "CircleArc",  # radius of an arc
    ]

    running_points = ["P13"]  # List of point names in the running_points

    # Call the __loop_both_fixed method
    profile._TProfile__loop_y_fixed(
        y_constraints=y_constraints,
        running_points_y=running_points,
        dimensions=dimensions,
    )

    P13_xset = profile._TProfile__get_elm_by_name("P13")._x_fix
    P13_yset = profile._TProfile__get_elm_by_name("P13")._y_fix

    P14_xset = profile._TProfile__get_elm_by_name("P14")._x_fix
    P14_yset = profile._TProfile__get_elm_by_name("P14")._y_fix

    assert P13_xset is False
    assert P13_yset is True
    assert P14_xset is False
    assert P14_yset is True


def test_update_all_point_set(db_for_test, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    # Set up required objects and attributes

    # Assuming you have already added constraints and elements to the profile
    profile.set_dimension(profile.anchor.point_1, "_x_fix", True)
    profile.set_dimension(profile.anchor.point_1, "_y_fix", True)

    all_point_set = {"P1", "P2", "P3", "P4"}
    points_done = set()
    both_fixed = {"P1"}
    running_points = ["P1", "P2"]
    running_points_x = ["P3"]
    running_points_y = ["P4"]

    # Call the __update_all_point_set method
    (
        updated_all_point_set,
        updated_points_done,
    ) = profile._TProfile__update_all_point_set(
        all_point_set,
        points_done,
        both_fixed,
        running_points,
        running_points_x,
        running_points_y,
    )

    # Check the expected results
    assert updated_all_point_set == {"P2", "P3", "P4"}
    assert updated_points_done == {"P1"}


def test_apply_dims(db_for_test, dim_Metal_Stg_Z_01_a, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a
    dimensions = dim_Metal_Stg_Z_01_a
    # Set up required objects and attributes

    # Call the __loop_both_fixed method
    profile._TProfile__apply_dims(dimensions=dimensions)

    P1_xset = profile._TProfile__get_elm_by_name("P1")._x_fix
    P10_xset = profile._TProfile__get_elm_by_name("P10")._x_fix
    P12_xset = profile._TProfile__get_elm_by_name("P12")._x_fix
    P13_xset = profile._TProfile__get_elm_by_name("P13")._x_fix
    P14_xset = profile._TProfile__get_elm_by_name("P14")._x_fix
    P19_xset = profile._TProfile__get_elm_by_name("P19")._x_fix
    P2_xset = profile._TProfile__get_elm_by_name("P2")._x_fix
    P21_xset = profile._TProfile__get_elm_by_name("P21")._x_fix
    P3_xset = profile._TProfile__get_elm_by_name("P3")._x_fix
    P4_xset = profile._TProfile__get_elm_by_name("P4")._x_fix
    P9_xset = profile._TProfile__get_elm_by_name("P9")._x_fix

    P1_yset = profile._TProfile__get_elm_by_name("P1")._y_fix
    P10_yset = profile._TProfile__get_elm_by_name("P10")._y_fix
    P12_yset = profile._TProfile__get_elm_by_name("P12")._y_fix
    P13_yset = profile._TProfile__get_elm_by_name("P13")._y_fix
    P14_yset = profile._TProfile__get_elm_by_name("P14")._y_fix
    P19_yset = profile._TProfile__get_elm_by_name("P19")._y_fix
    P2_yset = profile._TProfile__get_elm_by_name("P2")._y_fix
    P21_yset = profile._TProfile__get_elm_by_name("P21")._y_fix
    P3_yset = profile._TProfile__get_elm_by_name("P3")._y_fix
    P4_yset = profile._TProfile__get_elm_by_name("P4")._y_fix
    P9_yset = profile._TProfile__get_elm_by_name("P9")._y_fix

    assert P1_xset is True
    assert P10_xset is True
    assert P12_xset is True
    assert P13_xset is True
    assert P14_xset is True
    assert P19_xset is True
    assert P2_xset is True
    assert P21_xset is True
    assert P3_xset is True
    assert P4_xset is True
    assert P9_xset is True

    assert P1_yset is True
    assert P10_yset is True
    assert P12_yset is True
    assert P13_yset is True
    assert P14_yset is True
    assert P19_yset is True
    assert P2_yset is True
    assert P21_yset is True
    assert P3_yset is True
    assert P4_yset is True
    assert P9_yset is True


def test_dimension_list(db_for_test, dim_Metal_Stg_Z_01_a, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    assert profile.dimension_list == ["bf", "ba", "tw", "h", "rf", "ra", "ta", "tf"]


def test_get_properties(db_for_test, dim_Metal_Stg_Z_01_a, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a

    assert profile.get_properties


def test_outline_coords(db_for_test, dim_Metal_Stg_Z_01_a, profile_Metal_Stg_Z_01_a):
    # Create TProfile object
    profile = profile_Metal_Stg_Z_01_a
    profile.dimensions = dim_Metal_Stg_Z_01_a
    assert profile.outline_coords == [
        (4.0, 0.0),
        (4.0, 87.0),
        (12.0, 95.0),
        (10.0, 95.0),
        (10.0, 100.0),
        (0.0, 100.0),
        (0.0, 13.0),
        (-8.0, 5.0),
        (-16.0, 5.0),
        (-16.0, 0.0),
        (4.0, 0.0),
    ]
