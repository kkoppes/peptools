import pytest
import os
from pathlib import Path

from makerspace_mbe_pylantir.pyweser.isamilib import IsamiDB, TProfile, tprofile_factory
from makerspace_mbe_pylantir.pyelbe.mechanica.profiles.elm_factory import (
    create_subelm_plugin as new_subel,
)

from makerspace_mbe_pylantir.pyweser.isamilib.tprofile.tprofile import (
    TProfileIdentifier,
)
from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.anchor import (
    IsamiProfileAnchor,
)
from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.angle import (
    IsamiProfileAngle,
)
from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.circle_arc import (
    IsamiProfileCircleArc,
)

from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.distance import (
    IsamiProfileDistance,
)

from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.fiber import (
    IsamiProfileFiber,
)

from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.horizontality import (
    IsamiProfileHorizontality,
)

from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.horizontal_distance import (
    IsamiProfileHorizontalDistance,
)

from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.layer import (
    IsamiProfileLayer,
)

from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.line import (
    IsamiProfileLine,
)
from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.middle_point import (
    IsamiProfileMiddlePoint,
)
from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.outline import (
    IsamiProfileOutline,
)
from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.point_on_line import (
    IsamiProfilePointOnLine,
)
from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.point import (
    IsamiProfilePoint,
)
from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.radius import (
    IsamiProfileRadius,
)

from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.tangency import (
    IsamiProfileTangency,
)

from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.vertical_distance import (
    IsamiProfileVerticalDistance,
)

from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.verticality import (
    IsamiProfileVerticality,
)

from makerspace_mbe_pylantir.pyelbe.matreel import IsoElastic, Material

cur_dir = os.getcwd()
db_path = "tests/pyweser/isamilib"
db_filename = "GenericProfileLibrary.db"

if db_path in cur_dir:
    db_filepath = Path(cur_dir)
else:
    db_filepath = Path(cur_dir) / Path(db_path)
db_filepath /= Path(db_filename)


@pytest.fixture
def db_for_test():
    db_version = "test"

    isamidb = IsamiDB(database=db_filepath, version=db_version)
    return isamidb


def test_TProfile(db_for_test):
    """test for TProfile"""
    isami_db = db_for_test
    name = "testprofile"
    profile = TProfile(name=name, isami_db=isami_db)
    assert isinstance(profile, TProfile)


def test_TProfile_list(db_for_test):
    """test for TProfile"""
    isami_db = db_for_test
    name = "testprofile"
    profile = TProfile(name=name, isami_db=isami_db)
    profile_list = profile.get_profiles_list()
    assert profile_list[0] == (445, "Compo", "Clp", "C", "01", "e")


def test_TProfile_id(db_for_test):
    """test for TProfile"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    profile_id = profile.profile_id
    assert profile_id == 445


def test_TProfile_geom(db_for_test):
    """test for TProfile"""
    isami_db = db_for_test
    name = "testprofile"
    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)
    profile_geom = profile.geometry
    assert profile_geom[0] == ["Layer", "Layer1", "T"]


def test_TProfile_info(db_for_test):
    """test for TProfile"""
    isami_db = db_for_test
    name = "testprofile"

    _id = TProfileIdentifier("Compo", "Clp", "C", "01", "e")
    profile = TProfile(name=name, isami_db=isami_db, identifiers=_id)

    profile_info = profile.info
    assert profile_info[0][:6] == (445, "Compo", "Clp", "C", "01", "e")


def test_plugin_anchor():
    values = {
        "elm_type": "tprofile.Anchor",
        "elm_name": "C11",
        "point_1": "P26",
        "x_fix": "0.00",
        "y_fix": "0.00",
        "layer_id": "Layer1",
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("Anchor", values)
    assert isinstance(plugin, IsamiProfileAnchor)
    assert plugin.elm_type == "tprofile.Anchor"
    assert plugin.elm_name == "C11"
    assert plugin.point_1 == "P26"
    assert plugin.x_fix == 0.0
    assert plugin.y_fix == 0.0
    assert plugin.layer_id == "Layer1"
    assert plugin.get_points() == ["P26"]
    plugin.reverse_points()
    assert plugin.point_1 == "P26"


def test_plugin_angle():
    """
    ['Angle', 'C9', 'P4', 'P8', 'P8', 'P7', '90.00', 'Layer1', '20.00']

    """

    values = {
        "elm_type": "tprofile.Angle",
        "elm_name": "C9",
        "point_1": "P4",
        "point_2": "P8",
        "point_3": "P8",
        "point_4": "P7",
        "dim_name": "90.00",
        "layer_id": "Layer1",
        "r": "20.00",
    }  # TODO: check}}

    plugin = tprofile_factory.create_tprofile_elm_plugin("Angle", values)
    assert isinstance(plugin, IsamiProfileAngle)
    assert plugin.elm_type == "tprofile.Angle"
    assert plugin.elm_name == "C9"
    assert (plugin.point_1, plugin.point_2, plugin.point_3, plugin.point_4) == (
        "P4",
        "P8",
        "P8",
        "P7",
    )
    assert plugin.dim_name == "90.00"
    assert plugin.r == 20.0
    assert plugin.layer_id == "Layer1"
    assert plugin.get_points() == ["P4", "P8", "P8", "P7"]
    plugin.reverse_points()
    assert (plugin.point_1, plugin.point_2, plugin.point_3, plugin.point_4) == (
        "P7",
        "P8",
        "P8",
        "P4",
    )
    assert plugin.get_points() == ["P7", "P8", "P8", "P4"]


def test_CircleArc():
    """
    #['CircleArc', 'A1', 'P22', 'P15', 'P12', 'Layer1']

    """

    values = {
        "elm_type": "tprofile.circle_arc",
        "elm_name": "A1",
        "center_pt": "P22",
        "point_1": "P15",
        "point_2": "P12",
        "layer_id": "Layer1",
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("CircleArc", values)
    assert isinstance(plugin, IsamiProfileCircleArc)
    assert plugin.elm_type == "tprofile.circle_arc"
    assert plugin.elm_name == "A1"
    assert (plugin.point_1, plugin.point_2) == ("P15", "P12")
    assert plugin.center_pt == "P22"
    assert plugin.layer_id == "Layer1"
    assert plugin.get_points() == ["P15", "P12"]
    plugin.reverse_points()
    assert (plugin.point_1, plugin.point_2) == ("P12", "P15")
    assert plugin.get_points() == ["P12", "P15"]


def test_Distance():
    """
    #['Distance', 'C42', 'P26', 'P8', 'ba', 'Layer1', '-10.58', '-1.32']

    """

    values = {
        "elm_type": "tprofile.distance",
        "elm_name": "C42",
        "point_1": "P26",
        "point_2": "P8",
        "dim_name": "ba",
        "layer_id": "Layer1",
        "delta_x": -10.58,  # todo: check
        "delta_y": -1.32,  # todo: check
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("Distance", values)
    assert isinstance(plugin, IsamiProfileDistance)
    assert plugin.elm_type == "tprofile.distance"
    assert plugin.elm_name == "C42"
    assert (plugin.point_1, plugin.point_2) == ("P26", "P8")
    assert plugin.dim_name == "ba"
    assert plugin.layer_id == "Layer1"
    assert plugin.delta_x == -10.58
    assert plugin.delta_y == -1.32

    assert plugin.get_points() == ["P26", "P8"]
    plugin.reverse_points()
    assert (plugin.point_1, plugin.point_2) == ("P8", "P26")
    assert plugin.get_points() == ["P8", "P26"]


def test_Fiber():
    """
    #['Fiber', 'F1', 'tw', 'L3', 'F', 'L5', 'T', 'L4', 'T']

    """

    values = {
        "elm_type": "tprofile.fiber",
        "elm_name": "F1",
        "dim_name": "tw",
        "list_of_crap": ["L3", "F", "L5", "T", "L4", "T"],  # todo: implement
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("Fiber", values)
    assert isinstance(plugin, IsamiProfileFiber)
    assert plugin.elm_type == "tprofile.fiber"
    assert plugin.elm_name == "F1"


def test_IsamiProfileHorizontality():
    """
    ['Horizontality', 'C49', 'P17', 'P18', 'Layer1']

    """

    values = {
        "elm_type": "tprofile.horizontality",
        "elm_name": "C49",
        "point_1": "P17",
        "point_2": "P18",
        "layer_id": "Layer1",
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("Horizontality", values)
    assert isinstance(plugin, IsamiProfileHorizontality)
    assert plugin.elm_type == "tprofile.horizontality"
    assert plugin.elm_name == "C49"
    assert (plugin.point_1, plugin.point_2) == ("P17", "P18")
    assert plugin.layer_id == "Layer1"
    assert plugin.get_points() == ["P17", "P18"]
    plugin.reverse_points()
    assert (plugin.point_1, plugin.point_2) == ("P18", "P17")
    assert plugin.get_points() == ["P18", "P17"]


def test_IsamiProfileHorizontalDistance():
    """
    ['HorizontalDistance', 'C8', 'P14', 'P18', 'bf', 'Layer1', '10.00', '0.00']

    """

    values = {
        "elm_type": "tprofile.horizontal_distance",
        "elm_name": "C8",
        "point_1": "P14",
        "point_2": "P18",
        "layer_id": "Layer1",
        "dim_name": "bf",
        "dist_x": 10.00,
        "dist_y": 0.00,
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("HorizontalDistance", values)
    assert isinstance(plugin, IsamiProfileHorizontalDistance)
    assert plugin.elm_type == "tprofile.horizontal_distance"
    assert plugin.elm_name == "C8"
    assert (plugin.point_1, plugin.point_2) == ("P14", "P18")
    assert plugin.layer_id == "Layer1"
    assert plugin.dim_name == "bf"
    assert plugin.get_points() == ["P14", "P18"]
    plugin.reverse_points()
    assert (plugin.point_1, plugin.point_2) == ("P18", "P14")
    assert plugin.get_points() == ["P18", "P14"]


def test_IsamiProfileLayer():
    """
    ['Layer', 'Layer1', 'T']

    """

    values = {"elm_type": "tprofile.layer", "elm_name": "Layer1", "layer_type": "T"}

    plugin = tprofile_factory.create_tprofile_elm_plugin("Layer", values)
    assert isinstance(plugin, IsamiProfileLayer)
    assert plugin.elm_type == "tprofile.layer"
    assert plugin.elm_name == "Layer1"
    assert plugin.layer_type == "T"
    assert plugin.layer_id == "Layer1"


def test_IsamiProfileLine():
    """
    ['Line', 'L5', 'P13', 'P10', 'Layer1']

    """

    values = {
        "elm_type": "tprofile.line",
        "elm_name": "L5",
        "point_1": "P13",
        "point_2": "P10",
        "layer_id": "Layer1",
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("Line", values)
    assert isinstance(plugin, IsamiProfileLine)
    assert plugin.elm_type == "tprofile.line"
    assert plugin.elm_name == "L5"
    assert plugin.point_1 == "P13"
    assert plugin.point_2 == "P10"
    assert plugin.layer_id == "Layer1"


def test_IsamiProfileMiddlePoint():
    """
    ['MiddlePoint', 'C6', 'P19', 'P20', 'P18', 'Layer1']

    """

    values = {
        "elm_type": "tprofile.middle_point",
        "elm_name": "C6",
        "point_1": "P19",
        "point_2": "P20",
        "point_3": "P18",
        "layer_id": "Layer1",
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("MiddlePoint", values)
    assert isinstance(plugin, IsamiProfileMiddlePoint)
    assert plugin.elm_type == "tprofile.middle_point"
    assert plugin.elm_name == "C6"
    assert plugin.point_1 == "P19"
    assert plugin.point_2 == "P20"
    assert plugin.point_3 == "P18"
    assert plugin.layer_id == "Layer1"


def test_IsamiProfileOutline():
    """
    ['Outline', 'O1', 'Global', 'L14', 'L12', 'A5', 'L2', 'A3', 'L8', 'L9', 'L7', 'A1', 'L1', 'A4', 'L11']

    """

    values = {
        "elm_type": "tprofile.outline",
        "elm_name": "O1",
        "outline_type": "Global",
        "input_list": [
            "L14",
            "L12",
            "A5",
            "L2",
            "A3",
            "L8",
            "L9",
            "L7",
            "A1",
            "L1",
            "A4",
            "L11",
        ],
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("Outline", values)
    assert isinstance(plugin, IsamiProfileOutline)
    assert plugin.elm_type == "tprofile.outline"
    assert plugin.elm_name == "O1"
    assert plugin.outline_type == "Global"
    assert plugin.input_list[0] == "L14"


def test_IsamiProfilePointOnLine():
    """
    #['PointOnLine', 'C41', 'P26', 'L12', 'Layer1']

    """

    values = {
        "elm_type": "tprofile.point_on_line",
        "elm_name": "C41",
        "point_1": "P26",
        "line_1": "L12",
        "layer_id": "Layer1",
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("PointOnLine", values)
    assert isinstance(plugin, IsamiProfilePointOnLine)
    assert plugin.elm_type == "tprofile.point_on_line"
    assert plugin.elm_name == "C41"
    assert plugin.point_1 == "P26"
    assert plugin.line_1 == "L12"
    assert plugin.layer_id == "Layer1"


def test_IsamiProfilePoint():
    """
    ['Point', 'P3', '12.37', '11.95', 'Layer1'],
    """

    values = {
        "elm_type": "tprofile.point",
        "elm_name": "P3",
        "_x_coord": 12.37,
        "_y_coord": 11.95,
        "layer_id": "Layer1",
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("Point", values)
    assert isinstance(plugin, IsamiProfilePoint)
    assert plugin.elm_type == "tprofile.point"
    assert plugin.elm_name == "P3"
    assert plugin.x_coord == 12.37
    assert plugin.y_coord == 11.95
    assert plugin.layer_id == "Layer1"


def test_IsamiProfileRadius():
    """
    ['Radius', 'C43', 'A1', 'rf', 'Layer1', '1.53', '-2.95'],
    """

    values = {
        "elm_type": "tprofile.radius",
        "elm_name": "C43",
        "arc_1": "A1",
        "dim_name": "rf",
        "layer_id": "Layer1",
        "x_something": 1.53,
        "y_something": -2.95,
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("Radius", values)
    assert isinstance(plugin, IsamiProfileRadius)
    assert plugin.elm_type == "tprofile.radius"
    assert plugin.elm_name == "C43"
    assert plugin.arc_1 == "A1"
    assert plugin.dim_name == "rf"
    assert plugin.x_something == 1.53
    assert plugin.y_something == -2.95
    assert plugin.layer_id == "Layer1"


def test_IsamiProfileTangency():
    """
    ['Tangency', 'C13', 'L7', 'A1', 'Layer1']
    """

    values = {
        "elm_type": "tprofile.tangency",
        "elm_name": "P3",
        "line_1": "L7",
        "arc_1": "A1",
        "layer_id": "Layer1",
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("Tangency", values)
    assert isinstance(plugin, IsamiProfileTangency)
    assert plugin.elm_type == "tprofile.tangency"
    assert plugin.elm_name == "P3"
    assert plugin.line_1 == "L7"
    assert plugin.arc_1 == "A1"
    assert plugin.layer_id == "Layer1"


def test_IsamiProfileVerticalDistance():
    """
    #['VerticalDistance', 'C35', 'P26', 'P9', '59.48', 'Layer2', '-25.49', '0.88']
    """

    values = {
        "elm_type": "tprofile.vertical_distance",
        "elm_name": "C35",
        "point_1": "P26",
        "point_2": "P9",
        "dim_name": "59.48",
        "x_something": -25.49,
        "y_something": 0.88,
        "layer_id": "Layer2",
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("VerticalDistance", values)
    assert isinstance(plugin, IsamiProfileVerticalDistance)
    assert plugin.elm_type == "tprofile.vertical_distance"
    assert plugin.elm_name == "C35"
    assert plugin.point_1 == "P26"
    assert plugin.point_2 == "P9"
    assert plugin.dim_name == "59.48"
    assert plugin.layer_id == "Layer2"

    assert (plugin.point_1, plugin.point_2) == ("P26", "P9")
    assert plugin.get_points() == ["P26", "P9"]
    plugin.reverse_points()
    assert (plugin.point_1, plugin.point_2) == ("P9", "P26")
    assert plugin.get_points() == ["P9", "P26"]


def test_IsamiProfileVerticality():
    """
    ['Verticality', 'C24', 'P14', 'P6', 'Layer1']

    """

    values = {
        "elm_type": "tprofile.verticality",
        "elm_name": "C24",
        "point_1": "P14",
        "point_2": "P6",
        "layer_id": "Layer1",
    }

    plugin = tprofile_factory.create_tprofile_elm_plugin("Verticality", values)
    assert isinstance(plugin, IsamiProfileVerticality)
    assert plugin.elm_type == "tprofile.verticality"
    assert plugin.elm_name == "C24"
    assert plugin.point_1 == "P14"
    assert plugin.point_2 == "P6"
    assert plugin.layer_id == "Layer1"
    assert (plugin.point_1, plugin.point_2) == ("P14", "P6")
    assert plugin.get_points() == ["P14", "P6"]
    plugin.reverse_points()
    assert (plugin.point_1, plugin.point_2) == ("P6", "P14")
    assert plugin.get_points() == ["P6", "P14"]
