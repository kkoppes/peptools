import pytest

# from pathlib import Path
import os
from pathlib import Path
from makerspace_mbe_pylantir.pyweser.isamilib import IsamiDB
from makerspace_mbe_pylantir.pyweser.isamilib.isamidb.isamidb import (
    VersionNotFound,
    DatabaseNotFound,
    DatabaseNotSupported,
    SQLConnectionError,
)

cur_dir = os.getcwd()
db_path = "tests/pyweser/isamilib"
db_filename = "UserMaterialLibrary.db"

if db_path in cur_dir:
    db_filepath = Path(cur_dir)
else:
    db_filepath = Path(cur_dir) / Path(db_path)
db_filepath /= Path(db_filename)


# TODO: fix test or environment, only works in env where isami is installed
# def test_database_not_supported_error():
#     db_filename = "NotSupported.db"
#     db_version = "v11.4.0"
#     with pytest.raises(DatabaseNotSupported) as exc_info:
#         _ = IsamiDB(database=db_filename, version=db_version)
#     assert str(exc_info.value) == f" {db_filename} is not a known ISAMI database"


def test_database_not_found_error():
    db_filename = "NotExisting.db"
    db_version = "test"
    with pytest.raises(DatabaseNotFound) as exc_info:
        _ = IsamiDB(database=db_filename, version=db_version)
    assert str(exc_info.value) == "ISAMI database 'NotExisting.db' not found"


# test raise TypeError("IsamiDB required")
# test except json.JSONDecodeError as exc:


def test_version_not_found_error():
    db_version = "not_existing"
    if db_path in cur_dir:
        db_filepath = Path(cur_dir)
    else:
        db_filepath = Path(cur_dir) / Path(db_path)
    db_filepath /= Path(db_filename)
    with pytest.raises(VersionNotFound) as exc_info:
        _ = IsamiDB(database=db_filepath, version=db_version)
    assert str(exc_info.value) == "ISAMI version 'not_existing' not found"


# TODO: create db test files (Each ISAMI version should have it's own test version)
# def test_sql_connection_error():


def test_database_connect():
    db_version = "test"

    isamidb = IsamiDB(database=db_filepath, version=db_version)
    assert isinstance(isamidb, IsamiDB)
    assert isamidb.get_column_names("Specification") == ["OID", "Name"]
    assert isamidb.sql_query("SELECT Name FROM Specification LIMIT 1") == [
        ("AIMS03-02-004",)
    ]
    assert isamidb.sql_query("SELECT Name FROM Specification", 3) == [
        ("AIMS03-02-004",),
        ("AIMS03-18-006",),
        ("BS-L-97",),
    ]
    with pytest.raises(TypeError) as exc_info:
        isamidb.sql_query("SELECT Name FROM Specification LIMIT 1", "not an int")
    assert str(exc_info.value) == "argument 'fetch' must be an integer"


# if __name__ == "__main__":
#     # test_database_not_supported_error()
#     test_database_not_found_error()
#     test_version_not_found_error()
#     test_database_connect()
