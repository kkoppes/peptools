import pytest
from makerspace_mbe_pylantir.pyweser.isamilib.utils import (
    isami2bool,
    reorder_list,
    find_quadrant,
    is_clockwise,
)
from makerspace_mbe_pylantir.pyweser.isamilib.plugins.tprofile.point import (
    IsamiProfilePoint,
)


def test_isami2bool_with_valid_input():
    assert isami2bool("TRUE")
    assert isami2bool("true")


def test_isami2bool_with_invalid_input():
    with pytest.raises(ValueError):
        isami2bool("INVALID")


# Test function for pytest
def test_reorder_list():
    # Test with value, same first and last elements
    input_list = ["a", "b", "c", "d", "e", "f", "a"]
    start_element = "c"
    result = reorder_list(input_list, start_element)
    assert result == ["c", "d", "e", "f", "a", "b", "c"]

    # Test with index, same first and last elements
    input_list = ["a", "b", "c", "d", "e", "f", "a"]
    start_index = 2
    result = reorder_list(input_list, start_index, by_index=True)
    assert result == ["c", "d", "e", "f", "a", "b", "c"]

    # Test with value, different first and last elements
    input_list = ["a", "b", "c", "d"]
    start_element = "b"
    result = reorder_list(input_list, start_element)
    assert result == ["b", "c", "d", "a"]

    # Test with index, different first and last elements
    input_list = ["a", "b", "c", "d"]
    start_index = 1
    result = reorder_list(input_list, start_index, by_index=True)
    assert result == ["b", "c", "d", "a"]


def test_find_quadrant():
    assert find_quadrant(3, 5) == 1, "Positive x and positive y should be in Quadrant 1"

    assert (
        find_quadrant(-3, 5) == 2
    ), "Negative x and positive y should be in Quadrant 2"

    assert (
        find_quadrant(-3, -5) == 3
    ), "Negative x and negative y should be in Quadrant 3"
    assert (
        find_quadrant(3, -5) == 4
    ), "Positive x and negative y should be in Quadrant 4"

    assert find_quadrant(0, 5) == 0, "Point on the y-axis should return 0"

    assert find_quadrant(3, 0) == 0, "Point on the x-axis should return 0"

    assert find_quadrant(0, 0) == 0, "Origin should return 0"


def test_is_clockwise():
    """test for is_clockwise"""
    center = IsamiProfilePoint(
        elm_type="Point",
        elm_name="test",
        _x_coord=0,
        _y_coord=0,
        x_fixed=True,
        y_fixed=True,
    )

    # Clockwise case
    point_1 = IsamiProfilePoint(
        elm_type="Point",
        elm_name="test1",
        _x_coord=1,
        _y_coord=1,
        x_fixed=True,
        y_fixed=True,
    )
    point_2 = IsamiProfilePoint(
        elm_type="Point",
        elm_name="test2",
        _x_coord=2,
        _y_coord=0,
        x_fixed=True,
        y_fixed=True,
    )
    assert is_clockwise(center, point_1, point_2)

    # Counter-clockwise case
    point_1 = IsamiProfilePoint(
        elm_type="Point",
        elm_name="test3",
        _x_coord=2,
        _y_coord=0,
        x_fixed=True,
        y_fixed=True,
    )
    point_2 = IsamiProfilePoint(
        elm_type="Point",
        elm_name="test4",
        _x_coord=1,
        _y_coord=1,
        x_fixed=True,
        y_fixed=True,
    )
    assert not is_clockwise(center, point_1, point_2)
