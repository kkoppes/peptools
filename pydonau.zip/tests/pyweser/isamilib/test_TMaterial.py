#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Unit test for the TMaterial class
"""
import os
from pathlib import Path
import pdb

# from pydantic import ValidationError
from makerspace_mbe_pylantir.pyweser.isamilib import IsamiDB, TMaterial
from makerspace_mbe_pylantir.pyweser.isamilib.tmaterial.tmaterial import (
    MaterialNotFound,
    MaterialNotUnique,
)
from makerspace_mbe_pylantir.pyweser.isamilib.isamidb.isamidb import (
    VersionNotFound,
)

import pytest

cur_dir = os.getcwd()
db_path = "tests/pyweser/isamilib"
db_material_filename = "UserMaterialLibrary.db"
db_curve_filename = "TestCurveLibrary.db"
db_version = "test"

if db_path in cur_dir:
    db_filepath = Path(cur_dir)
else:
    db_filepath = Path(cur_dir) / Path(db_path)
db_material_filepath = db_filepath / Path(db_material_filename)
db_curve_filepath = db_filepath / Path(db_curve_filename)


def __TMaterial_metallic_get_material(tmaterial):
    # test billet
    assert tmaterial.material.billet.nominal == 20.0
    assert tmaterial.material.billet.min == 12.0
    assert tmaterial.material.billet.max == 40.0
    # test allowables
    allowables = tmaterial.material.allowables
    # test via dictionary
    assert allowables.get_attributes()["Ftu"] == 900.0
    # test via MetallicAllowables property
    assert allowables.Fsu == 545.0
    # test properties
    properties = tmaterial.material.properties
    assert properties.E == 110300.0
    assert properties.get_attributes()["nu"] == 0.31


def test_TMaterial_metallic_get_material():
    isami_material_db = IsamiDB(database=db_material_filepath, version=db_version)
    isami_curve_db = IsamiDB(database=db_curve_filepath, version=db_version)
    tmat = TMaterial(
        name="test",
        version="test",
        source=isami_material_db,
        source_curve=isami_curve_db,
    )
    spec = "AIMS03-18-006"
    basis = "A"
    billet = 20.0
    orientation = "L"
    # test the get_material_data and get_material_attributes methods
    tmat.get_material_data(spec=spec)
    tmat.get_material_attributes(billet=billet, basis=basis, orientation=orientation)
    __TMaterial_metallic_get_material(tmat)
    # test the get_material method
    tmat.get_material(spec=spec, billet=billet, basis=basis, orientation=orientation)
    __TMaterial_metallic_get_material(tmat)
    billets_list = tmat.billets
    orientations_dict = tmat.orientations
    # the first range should be from 6 to 12
    assert billets_list[0].min == 6
    assert billets_list[0].max == 12
    # the LT and ST must be into the 6-12 billet for A basis
    assert "LT" in orientations_dict["6-12"]["A"]
    assert "ST" in orientations_dict["6-12"]["A"]
    # test minimum allowables
    orientation = "minimum"
    tmat.get_material(spec=spec, billet=billet, basis=basis, orientation=orientation)
    allowables = tmat.material.allowables
    orientations = dict([orientation.split(":") for orientation in allowables.orientation.split(",")])
    assert allowables.Fsu == 490.0
    assert orientations["Fsu"] == "ST"
    name = tmat.isami_name
    assert name == "Ti-6Al-4V_ab_Annealed_Plate_user"


def test_TMaterial_composite_get_material():
    name = "IMA_M21E_194_0.184_user"
    isami_material_db = IsamiDB(database=db_material_filepath, version=db_version)
    isami_curve_db = IsamiDB(database=db_curve_filepath, version=db_version)
    tmat = TMaterial(
        name="test",
        version="test",
        source=isami_material_db,
        source_curve=isami_curve_db,
    )
    tmat.get_material(name=name)
    allowables = tmat.material.allowables
    # test allowables
    assert allowables.f1_t == 2610.0
    assert allowables.f13_s == 68.0
    # test properties
    properties = tmat.material.properties
    assert properties.E1 == 154000.0
    assert properties.nu23 == 0.264880952380952
    name = tmat.isami_name
    assert name == "IMA_M21E_194_0.184_user"


def test_TMaterial_composite_get_material_list():
    name = "IMA_M21E_194_0.184_user"
    isami_material_db = IsamiDB(database=db_material_filepath, version=db_version)
    isami_curve_db = IsamiDB(database=db_curve_filepath, version=db_version)
    tmat = TMaterial(
        name="test",
        version="test",
        source=isami_material_db,
        source_curve=isami_curve_db,
    )
    tmat.get_material(name=name)

    mat_list = tmat.get_materials_list()
    assert mat_list == {
        "Ti-6Al-4V_ab_Annealed_Plate_user": ["AIMS03-18-006"],
        "IMA_M21E_194_0.184_user": ["IPS05-27-002-01"],
        "2024_T351_Plate_user": ["AIMS03-02-004", "BS-L-97"],
        "IMA_M21E_134_0.127_user": ["IPS05-27-002-01"],
    }


#
#
def test_TMaterial_errors():
    isami_material_db = IsamiDB(database=db_material_filepath, version=db_version)
    isami_curve_db = IsamiDB(database=db_curve_filepath, version=db_version)
    name = "test"

    with pytest.raises(VersionNotFound):
        TMaterial(version=None, name=name)
    with pytest.raises(TypeError):
        TMaterial()
    with pytest.raises(TypeError):
        TMaterial(version="v11.4.0")
    with pytest.raises(TypeError):
        TMaterial(name=name)
    tmat = TMaterial(
        version="test",
        name=name,
        source=isami_material_db,
        source_curve=isami_curve_db,
    )
    # test not existing materials
    with pytest.raises(MaterialNotFound):
        tmat.get_material(name="this_not_exists")
    with pytest.raises(MaterialNotFound):
        tmat.get_material(spec="this_not_exists")
    with pytest.raises(MaterialNotFound):
        tmat.get_material(name="this_not_exists", spec="this_not_exists")
    # test not unique materials
    with pytest.raises(MaterialNotUnique):
        tmat.get_material(spec="IPS05-27-002-01")
    with pytest.raises(MaterialNotUnique):
        tmat.get_material(name="2024_T351_Plate_user")
    # TypeError for missing parameters    # tmat.get_material(name="2024_T351_Plate", spec="AIMS03-02-004")
    with pytest.raises(TypeError):
        # missing billet and basis
        tmat.get_material(name="2024_T351_Plate_user", spec="AIMS03-02-004")
    with pytest.raises(TypeError):
        # missing basis
        tmat.get_material(name="2024_T351_Plate_user", spec="AIMS03-02-004", billet=10.0)
    with pytest.raises(TypeError):
        # missing orientation
        tmat.get_material(
            name="2024_T351_Plate_user",
            spec="AIMS03-02-004",
            billet=10.0,
            basis="A",
        )


# if __name__ == "__main__":
#     test_TMaterial_metallic_get_material()
#     test_TMaterial_composite_get_material()
#     test_TMaterial_composite_get_material_list()
#     test_TMaterial_errors()
