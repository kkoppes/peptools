import pytest
from typing import Tuple
from makerspace_mbe_pylantir.sanitas.validity import (
    ArgumentsType,
    EnumType,
    ABCEnumMeta,
    TypeValidator,
)


# test ABCEnumMeta
# test for EnumType
# test ArgumentsType


def test_ArgumentsType_is_subclass_of_EnumType():
    assert issubclass(ArgumentsType, EnumType)


def test_ArgumentsType_is_not_abstract():
    with pytest.raises(TypeError):
        ArgumentsType()


def test_ArgumentsType_has_expected_enum_values():
    assert hasattr(ArgumentsType, "STR")
    assert hasattr(ArgumentsType, "NUM")
    assert hasattr(ArgumentsType, "DIC")


def test_ArgumentsType_enum_values_are_expected_types():
    assert isinstance(ArgumentsType.STR, ArgumentsType)
    assert isinstance(ArgumentsType.NUM, ArgumentsType)
    assert isinstance(ArgumentsType.DIC, ArgumentsType)


def test_ArgumentsType_str_representation_is_correct():
    assert str(ArgumentsType.STR) == "string"
    assert str(ArgumentsType.NUM) == "number"
    assert str(ArgumentsType.DIC) == "dictionary"


def test_ArgumentsType_type_property_is_correct():
    assert ArgumentsType.STR.type == (str,)
    assert ArgumentsType.NUM.type == (float, int)
    assert ArgumentsType.DIC.type == (dict,)


def test_ArgumentsType_cast_method_returns_correct_value():
    assert ArgumentsType.STR.cast("hello") == "hello"
    assert ArgumentsType.NUM.cast(3) == 3.0
    assert ArgumentsType.NUM.cast(3.14) == 3.14
    with pytest.raises(TypeError):
        ArgumentsType.STR.cast(3)


def test_ABCEnumMeta_prevents_instantiation_of_abstract_class():
    with pytest.raises(TypeError):

        class AbstractEnum(EnumType, metaclass=ABCEnumMeta):
            pass

        AbstractEnum()


# test TypeValidator
def test_typevalidator_validates_types():
    """Test that TypeValidator validates the type of the provided values"""

    class TestSource:
        __slots__ = ["a", "b"]

        def __init__(self, a, b):
            self.a = a
            self.b = b

    types = [ArgumentsType.NUM, ArgumentsType.STR]
    source = TestSource(1, "value")
    validator = TypeValidator(source, types)
    validator.validate()
    assert isinstance(source.a, float)
    assert isinstance(source.b, str)


def test_typevalidator_raises_error_for_incorrect_type():
    """Test that TypeValidator raises an error for incorrect type"""

    class TestSource:
        __slots__ = ["a", "b"]

        def __init__(self, a, b):
            self.a = a
            self.b = b

    types = [ArgumentsType.NUM, ArgumentsType.STR]
    source = TestSource("value", 1)
    validator = TypeValidator(source, types)
    with pytest.raises(TypeError, match="the argument a must be a number"):
        validator.validate()


def test_typevalidator_uses_variables_argument():
    """Test that TypeValidator uses the variables argument to validate the type"""

    class TestSource:
        __slots__ = ["a", "b"]

        def __init__(self, a, b):
            self.a = a
            self.b = b

    types = [ArgumentsType.NUM, ArgumentsType.STR]
    source = TestSource("test", 2)
    variables = ["b", "a"]
    validator = TypeValidator(source, types, variables)
    validator.validate()
    assert isinstance(source.b, float)
    assert isinstance(source.a, str)


# test TypeNotEqualValidator
