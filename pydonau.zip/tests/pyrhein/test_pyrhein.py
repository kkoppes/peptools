import pytest
from makerspace_mbe_pylantir.pyrhein.pyrhein import do


def test_do():
    assert do()[0:17] == "The Zen of Python"
