import pytest
from pydantic import ValidationError
from makerspace_mbe_pylantir.pyrhein.khazad.dum import (
    PLMLink,
    Part,
    StandardPart,
    Assembly,
    DesignSolution,
    LinkObject,
    Effectivity,
    ConfigurationItem,
    ConstituentAssembly,
    DesignData,
)
from makerspace_mbe_pylantir.pyelbe.matreel import (
    Material,
    IsoElastic,
    MetallicAllowables,
)

from makerspace_mbe_pylantir.pydonau.alchemy import Ingredients, Solution


# Assuming the classes from the provided code are imported here
@pytest.fixture
def dummy_material():
    E = 110.3e3
    G = 42.75e3
    nu = 310e-3

    iso = IsoElastic(
        E=E,
        G=G,
        nu=nu,
    )
    allowables = {
        "Fcy": 855.0,
        "Fty": 830.0,
        "Ftu": 900.0,
        "Fsu": 490.0,
        "b10": 1245.0,
        "e": 0.06,
        "n": 28.0,
        "nc": 28.0,
    }
    info = {
        "Fcy": "L",
        "Fty": "L",
        "Ftu": "L",
        "Fsu": "ST",
        "b10": "L",
        "e": "ST",
        "n": "ST",
        "nc": "ST",
    }
    allow = MetallicAllowables(**allowables, info=info)
    name = "Ti-6Al-4V_ab_Annealed_Plate"
    spec = "AIMS03-18-006"
    mat = Material(name=name, specification=spec, properties=iso, allowables=allow)

    return mat


def test_part_creation(dummy_material):
    part = Part(part_number="P123", description="Test Part", material=dummy_material)
    assert part.part_number == "P123"
    assert part.description == "Test Part"


def test_standard_part_creation(dummy_material):
    spart = StandardPart(
        part_number="SP123",
        description="Standard Test Part",
        material=dummy_material,
        standard_details="Standard Details",
    )
    assert spart.part_number == "SP123"
    assert spart.description == "Standard Test Part"
    assert spart.standard_details == "Standard Details"


def test_assembly_creation():
    assembly = Assembly(assembly_number="A123", assembly_description="Test Assembly", children=[])
    assert assembly.assembly_number == "A123"
    assert assembly.assembly_description == "Test Assembly"


def test_design_solution_creation():
    ds = DesignSolution(description="Design Solution Test", details="Details", content=[])
    assert ds.description == "Design Solution Test"
    assert ds.details == "Details"


def test_effectivity_creation():
    effectivity = Effectivity(AC_list=[1, 2, 3], details="Effectivity Details")
    assert effectivity.AC_list == [1, 2, 3]
    assert effectivity.details == "Effectivity Details"


def test_link_object_creation():
    effectivity = Effectivity(AC_list=[1, 2, 3])
    lo = LinkObject(location_description="Front", effectivity=effectivity, design_solutions=[])
    assert lo.location_description == "Front"
    assert lo.effectivity.AC_list == [1, 2, 3]


def test_configuration_item_creation():
    ci = ConfigurationItem(configuration_description="Configuration Test", link_objects=[])
    assert ci.configuration_description == "Configuration Test"


def test_constituent_assembly_creation():
    ca = ConstituentAssembly(configuration_description="Constituent Assembly Test", ci_objects=[])
    assert ca.configuration_description == "Constituent Assembly Test"


def test_invalid_part_creation():
    with pytest.raises(ValidationError):
        Part()


# Assuming the classes from the provided code are imported here


def test_design_data_creation_from_ingredients(dummy_material):
    plm_link = PLMLink(oid="12345", source="PLM/Windchill")
    part = Part(
        part_number="P123",
        description="Test Part",
        material=dummy_material,
        plm_link=plm_link,
    )

    # Create an Ingredients instance
    ingredients = Ingredients(part=part)

    # Convert Ingredients to DesignData
    design_data = DesignData.from_ingredients(ingredients)
    print("design_data._inputs")
    print(design_data.__dict__)
    # Assertions
    assert design_data.part.part_number == "P123"
    assert design_data.part.description == "Test Part"
    assert design_data.part.plm_link.oid == "12345"
    assert design_data.part.plm_link.source == "PLM/Windchill"
    # Convert DesignData to Solution
    solution = design_data.to_solution()

    solution_part = solution.get_attributes()["part"]
    # Assertions for Solution
    assert solution_part.part_number == "P123"
    assert solution_part.description == "Test Part"
    assert solution_part.plm_link.oid == "12345"
    assert solution_part.plm_link.source == "PLM/Windchill"


# def test_invalid_design_data_creation():
#     # Create an Ingredients instance with invalid data (missing required fields)
#     ingredients = Ingredients()

#     # Expecting a ValidationError when trying to convert to DesignData
#     with pytest.raises(ValidationError):
#         DesignData.from_ingredients(ingredients)


def test_design_data(dummy_material):
    plm_link = PLMLink(oid="12345", source="PLM/Windchill")

    part = Part(
        part_number="P123",
        description="Test Part",
        material=dummy_material,
        plm_link=plm_link,
    )

    spart = StandardPart(
        part_number="SP123",
        description="Standard Test Part",
        material=dummy_material,
        standard_details="Standard Details",
    )

    assembly = Assembly(assembly_number="A123", assembly_description="Test Assembly", children=[])

    ds = DesignSolution(description="Design Solution Test", details="Details", content=[])

    effectivity = Effectivity(AC_list=[1, 2, 3], details="Effectivity Details")

    # effectivity = Effectivity(AC_list=[1, 2, 3])
    lo = LinkObject(location_description="Front", effectivity=effectivity, design_solutions=[])

    ci = ConfigurationItem(configuration_description="Configuration Test", link_objects=[])

    ca = ConstituentAssembly(configuration_description="Constituent Assembly Test", ci_objects=[])

    # element_list = [part, spart, assembly, ds, effectivity, ci, ca, plm_link]
    # for elem in element_list:
    #     elem_attr = eval(elem)
    #     elem = eval(str(elem))

    # Create an Ingredients instance
    # ingredients = Ingredients(elem_attr=elem)
    # ingredients = Ingredients(elem=elem)
    ingredients = Ingredients(part=part)

    # Convert Ingredients to DesignData
    design_data = DesignData.from_ingredients(ingredients)
    print("design_data._inputs")
    print(design_data.__dict__)

    # if elem == part:
    # Assertions
    # test_part_creation(dummy_material)
    assert design_data.part.part_number == "P123"
    assert design_data.part.description == "Test Part"
    assert design_data.part.plm_link.oid == "12345"
    assert design_data.part.plm_link.source == "PLM/Windchill"

    # Convert DesignData to Solution
    solution = design_data.to_solution()

    # solution_elem = solution.get_attributes()[str(elem)]
    solution_part = solution.get_attributes()[str("part")]
    # Assertions for Solution
    assert solution_part.part_number == "P123"
    assert solution_part.description == "Test Part"
    assert solution_part.plm_link.oid == "12345"
    assert solution_part.plm_link.source == "PLM/Windchill"

    # elif elem == spart:
    #     pass

    # Create an Ingredients instance
    ingredients = Ingredients(standard_part=spart)

    # Convert Ingredients to DesignData
    design_data = DesignData.from_ingredients(ingredients)
    print("design_data._inputs")
    print(design_data.__dict__)

    # Assertions
    assert design_data.standard_part.part_number == "SP123"
    assert design_data.standard_part.description == "Standard Test Part"
    assert design_data.standard_part.material == dummy_material
    assert design_data.standard_part.standard_details == "Standard Details"

    # Convert DesignData to Solution
    solution = design_data.to_solution()

    solution_spart = solution.get_attributes()[str("standard_part")]
    # Assertions for Solution
    assert solution_spart.part_number == "SP123"
    assert solution_spart.description == "Standard Test Part"

    # Create an Ingredients instance
    ingredients = Ingredients(assembly=assembly)

    # Convert Ingredients to DesignData
    design_data = DesignData.from_ingredients(ingredients)
    print("design_data._inputs")
    print(design_data.__dict__)

    # Assertions
    assert design_data.assembly.assembly_number == "A123"
    assert design_data.assembly.assembly_description == "Test Assembly"
    assert design_data.assembly.children == []

    # Convert DesignData to Solution
    solution = design_data.to_solution()

    solution_assembly = solution.get_attributes()[str("assembly")]
    # Assertions for Solution
    assert solution_assembly.assembly_number == "A123"
    assert solution_assembly.assembly_description == "Test Assembly"
    assert solution_assembly.children == []

    # Create an Ingredients instance
    ingredients = Ingredients(design_solution=ds)

    # Convert Ingredients to DesignData
    design_data = DesignData.from_ingredients(ingredients)
    print("design_data._inputs")
    print(design_data.__dict__)

    # Assertions
    assert design_data.design_solution.description == "Design Solution Test"
    assert design_data.design_solution.details == "Details"
    assert design_data.design_solution.content == []

    # Convert DesignData to Solution
    solution = design_data.to_solution()

    solution_ds = solution.get_attributes()[str("design_solution")]
    # Assertions for Solution
    assert solution_ds.description == "Design Solution Test"
    assert solution_ds.details == "Details"
    assert solution_ds.content == []

    # Create an Ingredients instance
    ingredients = Ingredients(effectivity=effectivity)

    # Convert Ingredients to DesignData
    design_data = DesignData.from_ingredients(ingredients)
    print("design_data._inputs")
    print(design_data.__dict__)

    # Assertions
    assert design_data.effectivity.AC_list == [1, 2, 3]
    assert design_data.effectivity.details == "Effectivity Details"

    # Convert DesignData to Solution
    solution = design_data.to_solution()

    solution_effectivity = solution.get_attributes()[str("effectivity")]
    # Assertions for Solution
    assert solution_effectivity.AC_list == [1, 2, 3]
    assert solution_effectivity.details == "Effectivity Details"

    # Create an Ingredients instance
    ingredients = Ingredients(link_object=lo)

    # Convert Ingredients to DesignData
    design_data = DesignData.from_ingredients(ingredients)
    print("design_data._inputs")
    print(design_data.__dict__)

    # Assertions
    assert design_data.link_object.location_description == "Front"
    assert design_data.link_object.effectivity == effectivity
    assert design_data.link_object.design_solutions == []

    # Convert DesignData to Solution
    solution = design_data.to_solution()

    solution_link_object = solution.get_attributes()[str("link_object")]
    # Assertions for Solution
    assert solution_link_object.location_description == "Front"
    assert solution_link_object.effectivity == effectivity
    assert solution_link_object.design_solutions == []

    # Create an Ingredients instance
    ingredients = Ingredients(configuration_item=ci)

    # Convert Ingredients to DesignData
    design_data = DesignData.from_ingredients(ingredients)
    print("design_data._inputs")
    print(design_data.__dict__)

    # Assertions
    assert design_data.configuration_item.configuration_description == "Configuration Test"
    assert design_data.configuration_item.link_objects == []

    # Convert DesignData to Solution
    solution = design_data.to_solution()

    solution_configuration_item = solution.get_attributes()[str("configuration_item")]
    # Assertions for Solution
    assert solution_configuration_item.configuration_description == "Configuration Test"
    assert solution_configuration_item.link_objects == []

    # Create an Ingredients instance
    ingredients = Ingredients(constituent_assembly=ca)

    # Convert Ingredients to DesignData
    design_data = DesignData.from_ingredients(ingredients)
    print("design_data._inputs")
    print(design_data.__dict__)

    # Assertions
    assert design_data.constituent_assembly.configuration_description == "Constituent Assembly Test"
    assert design_data.constituent_assembly.ci_objects == []

    # Convert DesignData to Solution
    solution = design_data.to_solution()

    solution_constituent_assembly = solution.get_attributes()[str("constituent_assembly")]
    # Assertions for Solution
    assert solution_constituent_assembly.configuration_description == "Constituent Assembly Test"
    assert solution_constituent_assembly.ci_objects == []
