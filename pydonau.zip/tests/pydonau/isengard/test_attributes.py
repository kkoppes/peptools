#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 15:12:43 2024

@author: gi11883
"""

from makerspace_mbe_pylantir.pydonau.isengard.data import Attribute, DataAttributes


def test_attributes():
    """Test the DataAttributes class."""
    test_value = 1234.6
    test_value_c = "this is a test"
    test_value_b = 2.1
    test_value_a = 1
    test_main_attr = Attribute(name="test", value=test_value)
    test_meta_attr = Attribute(name="meta_1", value=test_value, tag="meta")
    test_hidden_attr = Attribute(name="hidden_1", value=test_value, tag="hidden")
    attributes = DataAttributes(test_main_attr, test_meta_attr, test_hidden_attr, a=test_value_a)
    # test set main/public attributes
    attributes.set_public(b=test_value_b)
    attributes.set_main(c=test_value_c)

    # assess emptiness
    assert not attributes.is_empty()
    attributes_2 = DataAttributes()
    # test append
    # only public attributes are checked for emptiness
    attributes_2.append_hidden(hidden_1=test_value)
    attributes_2.append_meta(meta_1=test_value)
    assert attributes_2.is_empty()
    attributes_2.append_main(a=test_value_a)
    attributes_2.append_public(b=test_value_b)
    assert not attributes_2.is_empty()
    assert attributes_2["a"] == test_value_a
    assert attributes_2.get_public("a").value == test_value_a
    assert attributes_2.get_public("b").value == test_value_b
    assert attributes_2.get_meta("meta_1").value == test_value
    assert attributes_2.get_hidden("hidden_1").value == test_value

    attributes_3 = attributes_2.copy()
    assert attributes_3["a"] == test_value_a
    assert attributes_3.get_public("a").value == test_value_a
    assert attributes_3.get_public("b").value == test_value_b
    assert attributes_3.get_meta("meta_1").value == test_value
    assert attributes_3.get_hidden("hidden_1").value == test_value

    # test main/public attributes
    assert attributes["a"] == test_value_a
    assert attributes["b"] == test_value_b
    assert attributes["c"] == test_value_c
    assert attributes["test"] == test_value

    assert attributes.get_main("a").value == test_value_a
    assert attributes.get_main("b").value == test_value_b
    assert attributes.get_main("c").value == test_value_c
    assert attributes.get_main("test").value == test_value

    assert attributes.get_public("a").value == test_value_a
    assert attributes.get_public("b").value == test_value_b
    assert attributes.get_public("c").value == test_value_c
    assert attributes.get_public("test").value == test_value

    # test meta attributes
    attributes.set_meta(meta_2=test_value_a)
    assert attributes.get_meta("meta_1").value == test_value
    assert attributes.get_meta("meta_2").value == test_value_a

    # test hidden/private attributes
    attributes.set_hidden(hidden_2=test_value_a)
    assert attributes.get_hidden("hidden_1").value == test_value
    assert attributes.get_hidden("hidden_2").value == test_value_a

    # test reset
    attributes.reset_public(a=test_value_b, c=test_value_a)
    assert attributes.get_main("a").value == test_value_b
    assert attributes.get_main("b") is None
    assert attributes.get_main("c").value == test_value_a
    assert attributes.get_meta("meta_1").value == test_value
    assert attributes.get_meta("meta_2").value == test_value_a
    assert attributes.get_hidden("hidden_1").value == test_value
    assert attributes.get_hidden("hidden_2").value == test_value_a

    attributes.reset_meta(meta_3=test_value_b)
    assert attributes.get_main("a").value == test_value_b
    assert attributes.get_main("b") is None
    assert attributes.get_main("c").value == test_value_a
    assert attributes.get_meta("meta_1") is None
    assert attributes.get_meta("meta_2") is None
    assert attributes.get_meta("meta_3").value == test_value_b
    assert attributes.get_hidden("hidden_1").value == test_value
    assert attributes.get_hidden("hidden_2").value == test_value_a

    attributes.reset_hidden(hidden_3=test_value_c)
    assert attributes.get_main("a").value == test_value_b
    assert attributes.get_main("b") is None
    assert attributes.get_main("c").value == test_value_a
    assert attributes.get_meta("meta_1") is None
    assert attributes.get_meta("meta_2") is None
    assert attributes.get_meta("meta_3").value == test_value_b
    assert attributes.get_hidden("hidden_1") is None
    assert attributes.get_hidden("hidden_2") is None
    assert attributes.get_hidden("hidden_3").value == test_value_c


# if __name__ == "__main__":
#     test_attributes()
