import pytest

# from pathlib import Path
import os
import sqlite3
from pathlib import Path
from makerspace_mbe_pylantir.pyweser.isamilib import IsamiDB
from makerspace_mbe_pylantir.pydonau.isengard.plugins.files.sql import SQLdatabase
from makerspace_mbe_pylantir.pyweser.isamilib.isamidb.isamidb import (
    VersionNotFound,
    DatabaseNotFound,
    DatabaseNotSupported,
    SQLConnectionError,
)


class PathNotFound(Exception):
    """
    raise an error when the path is not found
    """


root_dir = Path(__file__).parent.parent.parent.parent
material_db_folder_path = "tests/pyweser/isamilib"
material_db_filename = "UserMaterialLibrary.db"
new_mat_db_filename = "NewUserMaterialLibrary.db"
material_db_path = (
    Path(root_dir) / Path(material_db_folder_path) / Path(material_db_filename)
)
new_mat_db_path = Path(__file__).parent / Path(new_mat_db_filename)
print("The file path is: ", material_db_path)
if material_db_path.exists():
    db_filepath = material_db_path
else:
    raise PathNotFound
new_db_filepath = new_mat_db_path


def test_get_database_schema():
    """_summary_
    it extracts the schema, as a list of queries, of the UserMaterial.db and
    the recreates it, as an empty database, under the name New_UserMaterialLibrary.db
    """
    sqldb = SQLdatabase(filename=db_filepath)
    schema_db = sqldb.get_schema()
    assert schema_db[0].split()[0] == "CREATE"


def test_recreate_database():
    """_summary_"""
    sqldb = SQLdatabase(filename=db_filepath)
    schema_db = sqldb.get_schema()
    if new_db_filepath.exists():
        new_db_filepath.unlink()
        sqldb.recreate_database_from_schema(new_database=new_db_filepath)
    else:
        sqldb.recreate_database_from_schema(new_database=new_db_filepath)
    new_sqldb = SQLdatabase(filename=new_db_filepath)
    schema_new_db = new_sqldb.get_schema()
    assert schema_db == schema_new_db


def test_insert_data_in_sql_db():
    """
    inserts data in sql database
    """
    data = {
        "MaterialName": [
            {
                "OID": "MaterialOID1",
                "Type": "Composite",
                "Name": "MaterialName1",
                "CalculatedName": "CalculatedName1",
                "Family": "Family1",
                "Subfamily": "Subfamily1",
            }
        ]
    }

    if new_db_filepath.exists():
        SQLdatabase.insert_data_to_db(filepath=new_db_filepath, data=data)
        sql_exist_tables = "SELECT name FROM MaterialName;"
        conn = sqlite3.connect(new_db_filepath)
        cursor = conn.cursor()
        cursor.execute(sql_exist_tables)
        mat_name = cursor.fetchall()[0][0]
        assert mat_name == "MaterialName1"
    else:
        raise DatabaseNotFound
