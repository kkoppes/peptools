#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun  5 13:22:53 2023

@author: gi11883
"""
import os
from pathlib import Path
from pydantic import BaseModel, ValidationError
import pytest
from makerspace_mbe_pylantir.pydonau.isengard import Graph, GraphDataType
from makerspace_mbe_pylantir.pydonau.isengard.plugins.graphs.scatter import (
    ScatterPlot,
    ScatterPlotType,
)
import numpy as np
import pandas as pd

from makerspace_mbe_pylantir.pydonau.isengard.graph import InterpolationError

from makerspace_mbe_pylantir.scrolls import get_logger  # type:ignore
import logging

logger: logging.Logger = get_logger(__name__, level=logging.DEBUG)
logger_path = Path(__name__ + ".log")
test_svg = Path("test.svg")
test_json = Path("test.json")


@pytest.fixture(autouse=True)
def cleanup_files():
    """Remove the test files."""
    if test_svg.exists():
        os.remove(test_svg)
    if test_json.exists():
        os.remove(test_json)
    if logger_path.exists():
        os.remove(logger_path)


# It's a Graph!
class ItsAGraph(BaseModel):
    graph: Graph
    data_type: GraphDataType


def create_quantitative_dataframe():
    n_points = 500
    theta = np.linspace(0, np.pi * 2, num=n_points)
    fun = {"theta": theta}
    k_values = [1.0, 2.0]
    n_dim = len(k_values)
    for k_value in k_values:
        fun[f"{k_value}"] = [k_value * np.sin(x) ** 2 for x in theta]

    return n_dim, pd.DataFrame.from_dict(fun)


def create_categorical_dataframe():
    n_points = 500
    theta = np.linspace(0, np.pi * 2, num=n_points)
    fun = {"theta": theta}
    k_items = {"a": 1.0, "b": 2.0}
    n_dim = len(k_items)
    for k_name, k_value in k_items.items():
        fun[k_name] = [k_value * np.sin(x) ** 2 for x in theta]

    return n_dim, pd.DataFrame.from_dict(fun)


def test_graph():
    """Test Graph creation from a pandas data frame."""
    n_dim, df = create_quantitative_dataframe()

    graph = Graph.from_dataframe(data_frame=df, plot_type=ScatterPlotType, x_name="theta")

    # Check pydanticl type validation
    its_a_graph = ItsAGraph(graph=graph, data_type=GraphDataType())

    its_a_graph.graph.add_annotations(x=np.pi * 0.5, y=1.0, text="this is a test")
    its_a_graph.graph.render(renderer="svg")

    assert graph.n_dim == n_dim
    value = graph.interpolate(x=np.pi * 0.5, name=1.0, kind="cubic")
    assert f"{value:.1f}" == str(1.0)
    value = graph.interpolate(x=np.pi * 0.5, parameter=1.5, kind="cubic-linear")
    assert f"{value:.1f}" == str(1.5)
    values = graph.interpolate(x=np.pi * 0.5)
    assert f"{values[0]:.1f},{values[1]:.1f}" == (str(1.0) + "," + str(2.0))

    # test save in html
    # graph.save("test.html") #TODO: add this test!

    # test save and load from json
    graph.save(test_json, format="json")
    copy_from_json = Graph.from_json(test_json)

    assert copy_from_json.n_dim == n_dim
    value = copy_from_json.interpolate(x=np.pi * 0.5, name=1.0)
    assert f"{value:.1f}" == str(1.0)
    value = copy_from_json.interpolate(x=np.pi * 0.5, parameter=1.5, kind="slinear-linear")
    assert f"{value:.1f}" == str(1.5)
    value = copy_from_json.interpolate(x=np.pi * 0.5, parameter=1.5, kind="linear-slinear")
    assert f"{value:.1f}" == str(1.5)
    values = copy_from_json.interpolate(x=np.pi * 0.5)
    assert f"{values[0]:.1f},{values[1]:.1f}" == (str(1.0) + "," + str(2.0))

    # open from Path
    copy2_from_json = Graph.from_json(Path(test_json))

    assert copy2_from_json.n_dim == n_dim
    value = copy2_from_json.interpolate(x=np.pi * 0.5, name=1.0, kind="slinear")
    assert f"{value:.1f}" == str(1.0)
    value = copy2_from_json.interpolate(x=np.pi * 0.5, parameter=1.5, kind="cubic-linear")
    assert f"{value:.1f}" == str(1.5)
    values = copy2_from_json.interpolate(x=np.pi * 0.5)
    assert f"{values[0]:.1f},{values[1]:.1f}" == (str(1.0) + "," + str(2.0))

    # open from BufferReader
    with open(test_json, "r", encoding="utf-8") as file:
        copy3_from_json = Graph.from_json(file)

    assert copy3_from_json.n_dim == n_dim
    value = copy3_from_json.interpolate(x=np.pi * 0.5, name=1.0)
    assert f"{value:.1f}" == str(1.0)
    value = copy3_from_json.interpolate(x=np.pi * 0.5, parameter=1.5)
    assert f"{value:.1f}" == str(1.5)
    values = copy3_from_json.interpolate(x=np.pi * 0.5)
    assert f"{values[0]:.1f},{values[1]:.1f}" == (str(1.0) + "," + str(2.0))

    # test save to svg
    graph.save(test_svg, format="svg")

    # test ScatterPlot plugin
    copy_of_scatter = graph.get().copy()
    assert copy_of_scatter.n_dim == n_dim
    assert copy_of_scatter.is_quantitative() is True

    new_scatter_from_figure = ScatterPlot().from_figure(figure=copy_of_scatter.figure)
    assert new_scatter_from_figure.n_dim == n_dim
    assert new_scatter_from_figure.is_quantitative() is True

    # Reset the Plot
    n_dim2, df2 = create_categorical_dataframe()
    graph2 = Graph.from_dataframe(data_frame=df2, plot_type=ScatterPlotType, x_name="theta")
    graph.set(graph2.get())


def test_graph_errors():
    """Test Graph exceptions from a pandas data frame."""
    n_dim, df = create_quantitative_dataframe()
    graph = Graph.from_dataframe(data_frame=df, plot_type=ScatterPlotType, x_name="theta")

    # internal interpolation error, cubic interpolation canno be used on two values
    with pytest.raises(ValueError):
        graph.interpolate(x=np.pi * 0.5, parameter=1.5, kind="cubic")
    with pytest.raises(ValueError):
        graph.interpolate(x=np.pi * 0.5, parameter=1.5, kind="linear-cubic")
    with pytest.raises(ValueError):
        graph.interpolate(x=np.pi * 0.5, parameter=1.5, kind="slinear-cubic")
    with pytest.raises(ValueError):
        graph.interpolate(x=np.pi * 0.5, parameter=4)
    with pytest.raises(ValueError):
        graph.interpolate(x=np.pi * 0.5, name=4)

    # check for interpolation errors
    n_dim2, df2 = create_categorical_dataframe()
    graph2 = Graph.from_dataframe(data_frame=df2, plot_type=ScatterPlotType, x_name="theta")
    # check on categorical quantities
    with pytest.raises(InterpolationError):
        graph2.interpolate(x=np.pi * 0.5, parameter=1.5, kind="cubic-slinear")
    # check name and parameter mutual exclusivity
    with pytest.raises(InterpolationError):
        graph2.interpolate(x=np.pi * 0.5, name="a", parameter=1.5)

    # type check
    with pytest.raises(ValidationError):
        # ItsAGraph requires a Graph object
        ItsAGraph(graph=3)
    with pytest.raises(ValidationError):
        # ItsAGraph requires a Graph object and a GraphDataType
        ItsAGraph(graph=graph, data_type=[])
    with pytest.raises(TypeError):
        # grap.set() requires a Plot Object
        graph.set([])
    with pytest.raises(ValidationError):
        # from_json requires a str, Path, TextIOWrapper
        Graph().from_json(1)
    with pytest.raises(TypeError):
        # set() requires a Plot object
        graph2.set([])
    with pytest.raises(TypeError):
        # from_dataframe requires a Pandas data frame
        Graph().from_dataframe(data_frame=[], plot_type=ScatterPlotType, x_name="theta")
    with pytest.raises(TypeError):
        # plot_type requires a type object
        Graph().from_dataframe(data_frame=df2, plot_type="this is not a type", x_name="theta")


# if __name__ == "__main__":
#     test_graph()
#     test_graph_errors()
