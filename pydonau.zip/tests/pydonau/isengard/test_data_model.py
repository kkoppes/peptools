#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 28 11:55:05 2024

@author: gi11883
"""
from uuid import uuid4
from typing import Literal, Optional, Union

import pytest
from pydantic import BaseModel
from pydantic import ValidationError
from pydantic import conint, confloat, StrictFloat
from makerspace_mbe_pylantir.pydonau.isengard.data import DataModel, DataDescriptor

test_descriptor = DataDescriptor(name="Test", description="This is a test", uuid=str(uuid4()))

barbara_default = "duck"


class TestArg(BaseModel):
    """Dummy test argument class."""

    a: int = 0
    descriptor: DataDescriptor = test_descriptor


class Test(DataModel):
    """This is a test."""

    albert: conint(strict=True, lt=0)  # type: ignore
    barbara: Literal["donald", "duck"] = barbara_default  # type: ignore
    christian: confloat(strict=True, gt=0.0)  # type: ignore
    john: Optional[Union[Union[StrictFloat, int], TestArg]] = None
    lisa: Optional[TestArg] = None
    descriptor: DataDescriptor = test_descriptor
    __test: int = 0


class TestNoDescriptor(DataModel):
    """DataModel shall have a descriptor."""

    integer: int = 0


def test_datamodel():
    """Test the DataModel class."""
    albert = -1
    christian = 2.0
    lisa_a = 12
    john_1 = 1.0
    john_2 = 1
    john_3 = TestArg()
    __test = 12

    # test DataModel
    test = Test(albert=albert, christian=christian, lisa=TestArg(a=lisa_a))
    test._DataModel__attributes.get_hidden("__test").value = __test
    assert test.albert == albert
    assert test.barbara == barbara_default
    assert test.christian == christian
    assert test.lisa.a == lisa_a
    assert test.john is None
    assert test._DataModel__attributes.get_hidden("__test").value == __test

    test.albert = 2 * test.albert
    assert test.albert == 2 * albert

    test.lisa = TestArg(a=2 * christian)
    test.john = TestArg(a=christian)
    assert test.lisa.a == 2 * christian
    assert test.john.a == christian

    # test 'donald' Literal for barbara
    test_donald = Test(albert=-1, barbara="donald", christian=2.0)
    assert test_donald.barbara == "donald"

    # test 'duck' Literal for barbara
    test_duck = Test(albert=-1, barbara="duck", christian=2.0)
    assert test_duck.barbara == "duck"
    assert test_duck._DataModel__attributes.get_hidden("__test").value == 0

    # check StrictFloat in Union for john
    test_john_1 = Test(albert=albert, christian=christian, john=john_1)
    assert test_john_1.john == john_1

    # check int in Union
    test_john_2 = Test(albert=albert, christian=christian, john=john_2)
    assert test_john_2.john == john_2

    # test the casting for the type int
    test_john_2 = Test(albert=albert, christian=christian, john=str(john_2))
    assert test_john_2.john == john_2

    # check TestArg in Union
    test_john_3 = Test(albert=albert, christian=christian, john=john_3)
    assert test_john_3.john.a == 0

    # test errors
    # missing descriptor
    with pytest.raises(TypeError) as exc:
        # DataModel shall have a descriptor
        TestNoDescriptor()
    assert exc.match("Can't instantiate class TestNoDescriptor without 'descriptor'")
    # missing non-Optional attributes
    with pytest.raises(TypeError) as exc:
        Test(christian=christian)
    assert exc.match("Missing")
    assert exc.match("albert")

    with pytest.raises(TypeError) as exc:
        Test(albert=albert)
    assert exc.match("Missing")
    assert exc.match("christian")

    # check validation errors for the attributes
    with pytest.raises(ValidationError) as exc:
        # albert  must be less than 0
        Test(albert=1, christian=christian)
    assert exc.match("albert")
    assert exc.match("less")

    with pytest.raises(ValidationError) as exc:
        # same test done on an already instantiated class
        # albert  must be less than 0
        test.albert = 1
    assert exc.match("albert")
    assert exc.match("less")

    # with pytest.raises(ValidationError) as exc:
    # albert must be an integer less than 0 not a string
    # Test(albert="", christian=christian)

    with pytest.raises(ValidationError) as exc:
        # christian must be greater 0.0
        Test(albert=albert, christian=-2.0)
    assert exc.match("christian")
    assert exc.match("greater")

    with pytest.raises(ValidationError) as exc:
        # same test done on an already instantiated class
        # christian must be greater 0.0
        test.christian = -2.0
    assert exc.match("christian")
    assert exc.match("greater")

    with pytest.raises(ValidationError) as exc:
        # lisa shall be a TestArg or None
        Test(albert=albert, christian=christian, lisa=[])
    assert exc.match("lisa")
    assert exc.match("valid TestArg")

    with pytest.raises(ValidationError) as exc:
        # same test done on an already instantiated class
        # lisa shall be a TestArg or None
        test.lisa = []
    assert exc.match("lisa")
    assert exc.match("valid TestArg")

    with pytest.raises(ValidationError) as exc:
        # barbara must be either 'donald' or 'duck'
        Test(albert=albert, barbara="mickey", christian=christian)
    assert exc.match("barbara")
    assert exc.match("mickey")
    assert exc.match("donald|duck")

    with pytest.raises(ValidationError) as exc:
        # john must be a StrictFloat, an int, a TestArg or None (Optional)
        Test(albert=albert, christian=christian, john="1.0")
    assert exc.match("john")
    assert exc.match("1.0")


# if __name__ == "__main__":
#     test_datamodel()
