import pytest
import subprocess
from makerspace_mbe_pylantir.pydonau.alchemy.utils import pandoc_latex2markdown


@pytest.mark.skipif("command not found" in subprocess.getoutput("pandoc --help"), reason="Pandoc is installed")
def test_simple_conversion():
    latex = r"\textbf{bold text}"
    expected_markdown = "**bold text**\n"
    assert pandoc_latex2markdown(latex) == expected_markdown


@pytest.mark.skipif("command not found" in subprocess.getoutput("pandoc --help"), reason="Pandoc is installed")
def test_invalid_latex():
    invalid_latex = r"\invalidcommand{test}"
    # Assuming the function returns None or an error message for invalid LaTeX
    assert pandoc_latex2markdown(invalid_latex) is None


@pytest.mark.skipif("command not found" in subprocess.getoutput("pandoc --help"), reason="Pandoc is installed")
def test_conversion_with_pandoc_installed():
    # Test a known conversion when Pandoc is installed
    latex = "Some simple LaTeX text."
    expected_markdown = "Some simple LaTeX text.\n"
    assert pandoc_latex2markdown(latex) == expected_markdown


@pytest.mark.skipif("command not found" not in subprocess.getoutput("pandoc --help"), reason="Pandoc is installed")
def test_error_when_pandoc_not_installed():
    latex = "Some LaTeX text."
    # The function should return None or an appropriate error message
    assert pandoc_latex2markdown(latex) is None
