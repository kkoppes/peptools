#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul  3 09:49:57 2023

@author: gi11883
"""

import pytest
from pydantic import BaseModel, ValidationError

from makerspace_mbe_pylantir.pydonau.alchemy.alchemy import (
    ElementsFormatter,
    Elements,
    Ingredients,
    Solution,
    SolutionSet,
)


class CheckType(BaseModel):
    a: Elements
    b: Ingredients
    c: Solution


def get_elements():
    """Create test Element objects."""
    elem_1 = Elements(a=1.229, b=-13.6566, c="this_is_a_test")
    elem_2 = Elements(d={"pi": 3.14}, e=[1, 2, 3])
    return elem_1, elem_2


def test_formatter():
    """Test ElementsFormatter class."""
    fmt = ElementsFormatter()
    # truncate a float the the second decimal place
    assert "1.22" == fmt.format("{:.2tf}", 1.229)
    # round a float to the second decimal place
    assert "1.23" == fmt.format("{:.2f}", 1.229)
    # round a float to an integer
    assert "1" == fmt.format("{:i}", 1.229)
    # same as above but using the caster function to get a number instead of a string
    # truncate a float the the second decimal place
    assert 1.22 == fmt.caster(fmt.format("{:.2tf}", 1.229))
    # round a float to the second decimal place
    assert 1.23 == fmt.caster(fmt.format("{:.2f}", 1.229))
    # round a float to an integer
    assert 1 == fmt.caster(fmt.format("{:i}", 1.229))
    # do nothing to a string
    assert ".1.test" == fmt.caster(fmt.format("{0}", ".1.test"))


def test_elements():
    """Test Elements class."""
    # Initialize two Elements objects
    elem_1, elem_2 = get_elements()
    assert not elem_1.is_empty()
    # check if a elements object is an elements
    assert isinstance(Elements(), Elements)
    # check for the attributes
    assert set(["a", "b", "c"]) == elem_1.names
    assert elem_1.are_attributes("a", "b", "c")
    assert elem_1.are_attributes("a", "b", "d", partial=True)  # check if some are attributes
    assert not elem_1.are_attributes("a", "b", "d", partial=False)  # check if all are attributes
    # check .get()
    assert 1.229 == elem_1.get("a")
    assert -13.6566 == elem_1.get("b")
    assert "this_is_a_test" == elem_1.get("c")
    # check .get() with the default argument
    assert elem_1.get("test") is None
    assert elem_1.get("test", default="") == ""
    assert elem_1.get("test", default=0) == 0
    # check __getitem__
    # elem_1
    assert 1.229 == elem_1["a"]
    assert -13.6566 == elem_1["b"]
    assert "this_is_a_test" == elem_1["c"]
    # elem_2
    assert 3.14 == elem_2["d"]["pi"]
    assert [1, 2, 3] == elem_2["e"]
    # test __repr__
    assert isinstance(elem_1.__repr__(), str)


def test_elements_formatting():
    """Test Elements class formatting capabilities."""
    # Initialize two Elements objects
    elem_1, elem_2 = get_elements()
    round_float = "{:.2f}"  # round to 2 decimals
    trunc_float = "{:.2tf}"  # round to 2 decimals
    # add formats
    elem_1.add_formats(a=round_float, b=trunc_float)
    # get formats
    formats = elem_1.get_formats()
    assert round_float == formats["a"]
    assert trunc_float == formats["b"]
    # formats the attributes
    elem_fmt = elem_1.formatted()
    assert 1.23 == elem_fmt["a"]
    assert -13.65 == elem_fmt["b"]
    # update the formats
    elem_1.add_formats(a=trunc_float)  # truncate to 2 decimals
    elem_fmt = elem_1.formatted()
    assert 1.22 == elem_fmt["a"]
    # update through the formatted method
    elem_fmt = elem_1.formatted(a=round_float, test="{0}")
    assert 1.23 == elem_fmt["a"]
    # delete formats
    elem_1.del_formats("a")  # delete the format of the attribute "a""
    elem_fmt = elem_1.formatted()
    assert 1.229 == elem_fmt["a"]


def test_elements_operation():
    """Test Elements class algebraic operations capabilities."""
    # Initialize two Elements objects
    elem_1, elem_2 = get_elements()
    elem_3 = elem_1 + elem_2
    assert elem_1.copy() == elem_1
    assert elem_3 != elem_1
    # check the sum of two Elements
    assert 5 == len(elem_3)
    assert 1.229 == elem_3["a"]
    assert -13.6566 == elem_3["b"]
    assert "this_is_a_test" == elem_3["c"]
    assert 3.14 == elem_3["d"]["pi"]
    assert [1, 2, 3] == elem_3["e"]
    # check the subtraction of two Elements
    elem_3 -= elem_1
    assert len(elem_2) == len(elem_3)
    assert elem_3.get("a") is None
    assert elem_3.get("b") is None
    assert elem_3.get("c") is None
    assert 3.14 == elem_3["d"]["pi"]
    assert [1, 2, 3] == elem_3["e"]
    # check subtraction of non existing attributes
    elem_3 -= Elements(test="test")  # do nothing
    # the very same check above must give the same result
    assert len(elem_2) == len(elem_3)
    assert elem_3.get("a") is None
    assert elem_3.get("b") is None
    assert elem_3.get("c") is None
    assert 3.14 == elem_3["d"]["pi"]
    assert [1, 2, 3] == elem_3["e"]


def test_elements_methods():
    """Test the Elements methods."""
    # Initialize two Elements objects
    elem_1, elem_2 = get_elements()
    # append attributes
    elem_2.append(a=1.229, b=-13.6566)
    assert 1.229 == elem_2["a"]
    assert -13.6566 == elem_2["b"]
    with pytest.raises(KeyError) as excinfo:
        elem_2.append(a=(2.0) ** 0.5)
    assert excinfo.match(r"attribute \[\'a\'\] is already defined, use the overwrite method instead")
    with pytest.raises(KeyError) as excinfo:
        elem_2.append(a=(2.0) ** 0.5, b="test")
    assert excinfo.match(r"attributes \[\'a\', \'b\'\] are already defined, use the overwrite method instead")
    # overwrite attributes
    a = 2.0**0.5
    b = "test"
    elem_2.overwrite(a=a, b=b)
    assert a == elem_2["a"]
    assert b == elem_2["b"]
    assert 3.14 == elem_2["d"]["pi"]
    assert [1, 2, 3] == elem_2["e"]
    # get attributes
    attributes = elem_2.get_attributes()
    assert attributes == {"a": a, "b": b, "d": {"pi": 3.14}, "e": [1, 2, 3]}
    # test pop()
    assert 1.229 == elem_1.pop("a")  # pop the attribute named "a"
    assert [-13.6566, "this_is_a_test"] == elem_1.pop("b", "c")  # pop the attribute named "b" and "c"
    assert elem_1.pop("test") is None
    # test len() after pop
    assert len(elem_1) == 0
    # check emptiness
    assert elem_1.is_empty()
    # test remove
    assert 3.14 == elem_2["d"]["pi"]
    elem_2.remove("d")
    assert elem_2.get("d") is None


def test_ingredients_and_solution():
    """Test Ingredients class."""
    elem_1, elem_2 = get_elements()
    inputs = Ingredients.from_dict(elem_1.get_attributes())

    assert elem_1.get_attributes() == inputs.get_attributes()

    outputs = Solution(**elem_2.get_attributes())
    assert elem_2.get_attributes() == outputs.get_attributes()

    outputs_2 = Solution.from_dict(elem_2.get_attributes())
    assert outputs_2.get_attributes() == outputs.get_attributes()

    # test update: all the values shall be updated otherwise nothing is done
    new_values = {"d": {"pi": 3.14159265359}, "e": [4, 5, 6]}
    outputs_2.update(**new_values)
    for attribute_name in outputs_2.names:
        assert outputs_2[attribute_name] == new_values[attribute_name]

    inputs_2 = Ingredients.from_solution(outputs)
    # inputs_2 and outputs are different objects
    assert inputs_2 != outputs
    # but share the same attributes
    assert inputs_2.get_attributes() == outputs.get_attributes()

    # Test to_json()
    inputs_json = '{"a:float": "1.229", "b:float": "-13.6566", "c:str": "this_is_a_test"}'
    assert inputs.to_json() == inputs_json
    with pytest.raises(TypeError) as excinfo:
        inputs_2.to_json()
    excinfo.match("'dict' in attribute 'd'")
    # TODO: from_schema to be implemented
    outputs_3 = Solution.from_schema(None)
    assert outputs_3.is_empty()


def test_errors():
    """Test errors."""
    # Initialize two Elements objects
    elem_1, elem_2 = get_elements()
    with pytest.raises(TypeError):
        elem_1 + []
    with pytest.raises(TypeError):
        elem_1 - []

    with pytest.raises(ValidationError) as excinfo:
        CheckType(a=[], b=Ingredients(), c=Solution())
    excinfo.match("Elements")

    with pytest.raises(ValidationError) as excinfo:
        CheckType(a=Elements(), b=[], c=Solution())
    excinfo.match("Ingredients")

    with pytest.raises(ValidationError) as excinfo:
        CheckType(a=Elements(), b=Ingredients(), c=[])
    excinfo.match("Solution")

    outputs = Solution(**elem_2.get_attributes())

    with pytest.raises(ValueError):
        # missing attributes
        outputs.update()

    with pytest.raises(ValueError):
        # "a" is not a valid attribute
        outputs.update(a="test", e=1, d=2)

    with pytest.raises(ValueError):
        # "a" and f are not valid attributes
        outputs.update(a="test", f="another test", e=1, d=2)

    with pytest.raises(ValueError):
        # "d" is missing
        outputs.update(e=1)


class TestSolutionSet:
    @pytest.fixture
    def sample_solutions(self):
        # Assuming Solution takes a dictionary of attributes in its constructor
        return [Solution(value=10), Solution(value=20), Solution(value=5)]

    def test_initialization(self):
        solution_set = SolutionSet([])
        assert isinstance(solution_set, SolutionSet)
        assert len(solution_set) == 0

    def test_add_solution(self, sample_solutions):
        solution_set = SolutionSet()
        for solution in sample_solutions:
            solution_set.add_solution(solution)

        assert len(solution_set) == 3

    def test_min_value(self, sample_solutions):
        solution_set = SolutionSet()
        for solution in sample_solutions:
            solution_set.add_solution(solution)

        min_solution = solution_set.min_value("value")
        assert min_solution.get_attributes() == {"value": 5}

    def test_max_value(self, sample_solutions):
        solution_set = SolutionSet()
        for solution in sample_solutions:
            solution_set.add_solution(solution)

        max_solution = solution_set.max_value("value")
        assert max_solution.get_attributes() == {"value": 20}

    def test_get_less_than(self, sample_solutions):
        solution_set = SolutionSet()
        for solution in sample_solutions:
            solution_set.add_solution(solution)

        filtered_set = solution_set.get_less_than("value", 15)
        assert len(filtered_set) == 2


# if __name__ == "__main__":
#     test_formatter()
#     test_elements()
#     test_elements_operation()
#     test_elements_methods()
#     test_elements_formatting()
#     test_ingredients_and_solution()
#     test_errors()
