#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 25 10:05:48 2023

@author: gi11883
"""
import pytest
import pandas as pd
from pydantic import BaseModel, ValidationError
from pathlib import Path
from makerspace_mbe_pylantir.pydonau.alchemy.alchemy import Ingredients, Solution
from makerspace_mbe_pylantir.pydonau.alchemy import (
    Carta,
    Imago,
    Formula,
    Tabula,
    Opera,
    Opus,
    Scriptores,
    Scripture,
)

imago_test_template = "test_template/imago_test_template.tex"
imago_test_image = "test_template/test.png"


def division(variables: Ingredients) -> Solution:
    """Perform a division."""
    return Solution(c=variables["a"] / variables["b"])


class CheckType(BaseModel):
    """Class for type validation."""

    a: Scriptores
    b: Scripture
    c: Formula
    d: Imago
    e: Tabula
    f: Opus
    g: Opera
    h: Carta


def test_types():
    """Test type validation."""
    john_doe = ("John", "Nobody", "Doe", "john.doe@area51.gov", "Area51")
    image_filename = Path(__file__).parent / Path(imago_test_image)
    authors = Scriptores(authors=(john_doe,), uuids=("",))
    formula = Formula(name="", formula=Scripture(description=""), function=division, variables=Ingredients(a=1, b=1))
    scripture = Scripture(description="", variables=Ingredients())
    image = Imago(name="test", filename=image_filename, description=scripture, caption=scripture)
    table = Tabula(name="test", caption=scripture, description=scripture, data_frame=pd.DataFrame())
    opus = scripture + formula + image + table
    opera = Opera(title="test", opera=(scripture + formula, image + table))
    carta = Carta(document="", title="test", authors=authors, opera=opera)

    with pytest.raises(ValidationError) as excinfo:
        # requires Scriptores
        CheckType(a=[], b=scripture, c=formula, d=image, e=table, f=opus, g=opera, h=carta)
    assert excinfo.match("Scriptores")

    with pytest.raises(ValidationError) as excinfo:
        # requires Scripture
        CheckType(a=authors, b=[], c=formula, d=image, e=table, f=opus, g=opera, h=carta)
    assert excinfo.match("Scripture")

    with pytest.raises(ValidationError) as excinfo:
        # requires Formula
        CheckType(a=authors, b=scripture, c=[], d=image, e=table, f=opus, g=opera, h=carta)
    assert excinfo.match("Formula")

    with pytest.raises(ValidationError) as excinfo:
        # requires Imago
        CheckType(a=authors, b=scripture, c=formula, d=[], e=table, f=opus, g=opera, h=carta)
    assert excinfo.match("Imago")

    with pytest.raises(ValidationError) as excinfo:
        # requires Tabula
        CheckType(a=authors, b=scripture, c=formula, d=image, e=[], f=opus, g=opera, h=carta)
    assert excinfo.match("Tabula")

    with pytest.raises(ValidationError) as excinfo:
        # requires Opus
        CheckType(a=authors, b=scripture, c=formula, d=image, e=table, f=[], g=opera, h=carta)
    assert excinfo.match("Opus")

    with pytest.raises(ValidationError) as excinfo:
        # requires Opera
        CheckType(a=authors, b=scripture, c=formula, d=image, e=table, f=opus, g=[], h=carta)
    assert excinfo.match("Opera")

    with pytest.raises(ValidationError) as excinfo:
        # requires Carta
        CheckType(a=authors, b=scripture, c=formula, d=image, e=table, f=opus, g=opera, h=[])
    assert excinfo.match("Carta")
