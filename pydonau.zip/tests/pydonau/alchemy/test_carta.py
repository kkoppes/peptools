#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 25 10:04:50 2023

@author: gi11883

"""
import pytest
from pydantic import ValidationError
from pathlib import Path
from makerspace_mbe_pylantir.pydonau.alchemy.alchemy import Ingredients
from makerspace_mbe_pylantir.pydonau.alchemy import Carta, Opera, ParseError, Scriptores


def get_authors() -> tuple[Scriptores, set]:
    """Provide two test authors."""
    john_doe = ("John", "Nobody", "Doe", "john.doe@area51.gov", "Area51")
    jane_doe = ("Jane", "", "Doe", "?.?@whoami.null", "TwilightZone")

    # the set of authors
    # because to avoid repetitions Scriptores internally use a set, and because the set are ordered alphabetically,
    # a set of author tuple is used for the testing
    author_set = set([john_doe, jane_doe])
    # test __init__ and __add__
    authors = Scriptores(authors=(john_doe,), uuids=("",)) + Scriptores(authors=(jane_doe,), uuids=("",))
    return authors, author_set


carta_test_template = "test_template/test_document.tex"
json_test_template = "test_template/test.json"
test_error_wrong_field_format = "test_template/test_error_wrong_field_format.json"
test_error_wrong_attributes = "test_template/test_error_wrong_attributes.json"
test_error_wrong_boolean = "test_template/test_error_wrong_boolean.json"
test_error_wrong_list = "test_template/test_error_wrong_list.json"


def test_carta():
    """Test Carta class."""
    carta_uuid = "carta_uuid"
    template_path = Path(__file__).parent / Path(carta_test_template)
    json_path = Path(__file__).parent / Path(json_test_template)
    # test from Path
    carta = Carta.from_json(filename=json_path)
    # test from string
    carta = Carta.from_json(filename=str(json_path))

    assert carta.uuid == carta_uuid
    assert carta.title == "This is a test document"
    assert carta.template_filename == str(template_path)

    assert str(carta) == carta.document
    assert carta.to_markdown() == carta._repr_markdown_()
    assert carta.document.find(r"| c | c | c |") >= 0  # layout is set to "c c c"
    assert carta.document.find(r"\hline") < 0  # no hline because hline is set to False in the json file

    variables = Ingredients(a=5, b=6)
    carta.set_variables(variables)
    assert variables == carta.get_variables()


def test_carta_errors():
    """Test Carta class errors."""
    template_path = Path(__file__).parent / Path(test_error_wrong_field_format)
    # wrong field format
    with pytest.raises(ParseError) as excinfo:
        Carta.from_json(filename=template_path)
    assert excinfo.match("json field")

    # wrong attributes
    template_path = Path(__file__).parent / Path(test_error_wrong_attributes)
    with pytest.raises(ParseError) as excinfo:
        Carta.from_json(filename=template_path)
    assert excinfo.match("the attributes for the json field")

    # wrong boolean
    template_path = Path(__file__).parent / Path(test_error_wrong_boolean)
    with pytest.raises(ParseError) as excinfo:
        Carta.from_json(filename=template_path)
    assert excinfo.match("boolean")

    # wrong field format
    template_path = Path(__file__).parent / Path(test_error_wrong_list)
    with pytest.raises(ParseError) as excinfo:
        Carta.from_json(filename=template_path)
    assert excinfo.match("list")

    # wrong path type
    with pytest.raises(TypeError) as excinfo:
        Carta.from_json(filename=2)
    assert excinfo.match("PathLike")

    # wrong path type
    with pytest.raises(TypeError) as excinfo:
        Carta.from_template(template_filename=2, title="", authors=None, opera=None)
    assert excinfo.match("PathLike")

    # not a dictionary
    with pytest.raises(TypeError) as excinfo:
        Carta.from_dict(dictionary="this_is_not_a dictionary")
    assert excinfo.match("dictionary")

    # file does not exist
    with pytest.raises(OSError) as excinfo:
        Carta.from_json(filename="this_file_does_not_exist.file")
    assert excinfo.match("No such file")

    # ValidationError
    authors, author_set = get_authors()
    template_path = Path(__file__).parent / Path(carta_test_template)
    # wrong title
    with pytest.raises(ValidationError) as excinfo:
        Carta.from_template(template_filename=template_path, title=2, authors=authors, opera=Opera())
    assert excinfo.match("title")
    # wrong authors object
    with pytest.raises(ValidationError) as excinfo:
        Carta.from_template(template_filename=template_path, title="", authors=[], opera=Opera())
    assert excinfo.match("authors")
    # wrong opera object
    with pytest.raises(ValidationError) as excinfo:
        Carta.from_template(template_filename=template_path, title="", authors=authors, opera=[])
    assert excinfo.match("opera")

    # test set_variables
    carta = Carta.from_template(template_filename=template_path, title="", authors=authors, opera=Opera())
    with pytest.raises(TypeError) as excinfo:
        carta.set_variables(variables=[])
    assert excinfo.match("Ingredients")
