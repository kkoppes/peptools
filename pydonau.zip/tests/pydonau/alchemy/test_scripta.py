#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul  3 09:50:11 2023

@author: gi11883
"""
from pathlib import Path

import pytest
import pandas as pd
from jinja2 import Template
from pydantic import ValidationError
from makerspace_mbe_pylantir.pydonau.alchemy.alchemy import Ingredients, Solution
from makerspace_mbe_pylantir.pydonau.alchemy import Scriptores, Scripture, Formula, Imago, Tabula
from makerspace_mbe_pylantir.pydonau.alchemy import Opus, Opera

scripture_test_template = "test_template/scripture_test_template.tex"
formula_test_template = "test_template/formula_test_template.tex"
tabula_test_template = "test_template/tabula_test_template.tex"
imago_test_template = "test_template/imago_test_template.tex"
imago_test_image = "test_template/test.png"

# TODO: do other checks for the object attributes through the Validator classes


def get_authors() -> tuple[Scriptores, set]:
    """Provide two test authors."""
    john_doe = ("John", "Nobody", "Doe", "john.doe@area51.gov", "Area51")
    jane_doe = ("Jane", "", "Doe", "?.?@whoami.null", "TwilightZone")

    # the set of authors
    # because to avoid repetitions Scriptores internally use a set, and because the set are ordered alphabetically,
    # a set of author tuple is used for the testing
    author_set = set([john_doe, jane_doe])
    # test __init__ and __add__
    authors = Scriptores(authors=(john_doe,), uuids=("",)) + Scriptores(authors=(jane_doe,), uuids=("",))
    return authors, author_set


def division(variables: Ingredients) -> Solution:
    """Perform a division."""
    return Solution(c=variables["a"] / variables["b"])


def multiplication(variables: Ingredients) -> Solution:
    """Perform a multiplication."""
    return Solution(c=variables["a"] * variables["b"])


def wrong_function(variables: Ingredients) -> float:
    """Perform a multiplication returning a float."""
    return variables["a"] * variables["b"]


def test_scriptores():
    """Test Scriptores for authors."""
    authors, author_set = get_authors()

    # test __len__
    assert len(authors) == 2
    # test __iter__ and __next__
    for idx, author in enumerate(authors):
        assert author in author_set
    # test __getitem__
    for idx, author in enumerate(author_set):
        # the authors are returned in alphabetical order
        assert author == authors[idx + 1]
    # test pop()and append()
    popped = authors.pop(1)
    assert len(authors) == 1
    authors.append(
        first_name=popped[0], middle_name=popped[1], last_name=popped[2], email=popped[3], department=popped[4]
    )
    assert len(authors) == 2


def test_scripture():
    """Test Scripture for text."""
    value = "test"
    uuid = "test_id"
    variables = Ingredients(value=value)
    script = Scripture(description=r"\section{test}This is a VAR{value}.", variables=variables, uuid=uuid)
    # check Scripture data
    assert script.uuid == uuid
    assert str(script) == r"\section{test}This is a " + "{}.".format(value)
    assert script.to_markdown() == "###  test\nThis is a test."
    assert script.description == str(script)
    assert script.__repr__() == str(script)
    assert script.to_markdown() == script._repr_markdown_()
    assert script.variables.get_attributes() == variables.get_attributes()
    assert script.copy() == script  # TODO: to be verified what == actually compare

    # change the variables and update the Scripture
    value = "drill"
    variables.overwrite(value=value)
    assert script.variables.get_attributes() != variables.get_attributes()
    script.set_variables(variables)
    assert str(script) == r"\section{test}This is a " + "{}.".format(value)

    # check the sum of two Scripture
    opus = script + Scripture(description=r"I told you that this VAR{var}", variables=Ingredients(var="is just a test"))
    assert isinstance(opus, Opus)
    opus.level = ""  # no header
    opus.separator = ""  # no separator
    assert opus.document == r"\section{test}This is a drill.I told you that this is just a test"

    # load template from Path
    template_path = Path(__file__).parent / Path(scripture_test_template)
    with open(template_path) as template_file:
        template_file_content = template_file.read()
        from_template = Scripture.from_template(template_filename=template_path, variables=variables, uuid="test_id")
        assert from_template.template_filename == str(template_path.absolute())
        assert from_template.template_source == template_file_content
        assert isinstance(from_template.template, Template)

    # load template from string
    template_path_str = str(template_path.absolute())
    with open(template_path_str) as template_file:
        template_file_content = template_file.read()
        from_template = Scripture.from_template(
            template_filename=template_path_str, variables=variables, uuid="test_id"
        )
        assert from_template.template_filename == template_path_str
        assert from_template.template_source == template_file_content
        assert isinstance(from_template.template, Template)


def test_formula():
    """Test Formula objects."""
    name = "division"
    division_latex = r"\begin{equation}\label{VAR{name}}\frac{VAR{a}}{VAR{b}}=VAR{c}\end{equation}"
    multiplicaiton_latex = r"\begin{equation}\label{VAR{name}}VAR{a} \cdot {VAR{b}=VAR{c}\end{equation}"
    variables = Ingredients(a=1, b=2)
    script = Scripture(description=division_latex)
    uuid = "test_id"
    formula = Formula(
        name=name,
        formula=script,
        function=division,
        variables=variables,
        uuid=uuid,
    )
    assert formula.name == name
    assert formula.uuid == uuid
    assert formula.variables == variables
    assert formula.to_markdown() == formula._repr_markdown_()
    assert formula.function == division
    assert formula.formula.description == script.description
    assert str(formula) == str(script)
    assert formula.outputs == division(variables)

    # update the formula
    variables.overwrite(b=5)
    formula.set_variables(variables)
    formula.compute()
    new_uuid = "new_uuid"
    formula.reset_uuid(new_uuid)
    assert formula.uuid == new_uuid
    assert formula.outputs == division(variables)
    assert formula.to_markdown() == formula._repr_markdown_()

    formula.set_function(multiplication)
    new_script = Scripture(description=multiplicaiton_latex)
    formula.set_formula(new_script)
    formula.compute()
    assert formula.outputs == multiplication(variables)

    # check decoupling
    variables.overwrite(b=10)
    assert formula.outputs != multiplication(variables)

    # test addition of formulas
    opus = formula + formula
    isinstance(opus, Opus)
    opus.level = ""  # no header
    opus.separator = r"\newline"  # \newline between objects
    assert opus.document == (str(formula) + opus.separator + str(formula) + opus.separator)
    opus = Scripture(description="this is a test") + formula
    opus.level = ""  # no header
    opus.separator = r"\newline"  # \newline between objects
    isinstance(opus, Opus)
    assert opus.document == ("this is a test" + opus.separator + str(formula) + opus.separator)
    # test from_template
    # load template from Path
    template_path = Path(__file__).parent / Path(formula_test_template)
    with open(template_path) as template_file:
        template_file_content = template_file.read()
        from_template = Formula.from_template(
            template_filename=template_path, name=name, function=division, variables=variables, uuid=uuid
        )
        assert from_template.template_filename == str(template_path.absolute())
        assert from_template.template_source == template_file_content
        assert from_template.uuid == uuid
        assert isinstance(from_template.template, Template)

    # load template from string
    template_path_str = str(template_path.absolute())
    with open(template_path_str) as template_file:
        template_file_content = template_file.read()
        from_template = Formula.from_template(
            template_filename=template_path_str, name=name, function=division, variables=variables, uuid=uuid
        )
        assert from_template.template_filename == template_path_str
        assert from_template.uuid == uuid
        assert from_template.template_source == template_file_content
        assert isinstance(from_template.template, Template)


def test_imago():
    """Test Imago objects."""
    name = "test"
    uuid = "test_image_id"
    image_description = (
        r"\begin{figure}[ht]\includegraphics[VAR{options}]{VAR{filename}}"
        + r"\caption{VAR{caption}}\label{fig:VAR{name}}\end{figure}"
    )
    filename = Path(__file__).parent / Path(imago_test_image)
    image_caption = r"This is only a test"
    caption = Scripture(description=image_caption, variables=Ingredients())
    description = Scripture(
        description=image_description,
        variables=Ingredients(options=r"width=\linewidth", filename=str(filename), name="test", caption=str(caption)),
    )
    custom_args = Ingredients(test="this is a test", b=2)
    image = Imago(
        name=name,
        filename=filename.absolute(),
        description=description,
        caption=caption,
        uuid=uuid,
        custom_arguments=custom_args,
    )
    assert image.uuid == uuid
    assert image.caption == caption
    assert image.description == str(description)
    assert image.filename == str(filename)
    assert image.custom_arguments == custom_args
    assert image.to_markdown() == image._repr_markdown_()
    # load template from Path
    template_path = Path(__file__).parent / Path(imago_test_template)
    with open(template_path) as template_file:
        template_file_content = template_file.read()
        from_template = Imago.from_template(
            template_filename=template_path,
            image_filename=filename,
            name=name,
            caption=caption,
            uuid=uuid,
            custom_arguments=custom_args,
        )
        assert from_template.template_filename == str(template_path.absolute())
        assert from_template.template_source == template_file_content
        assert from_template.uuid == uuid
        assert isinstance(from_template.template, Template)

    # load template from string
    template_path_str = str(template_path.absolute())
    with open(template_path_str) as template_file:
        template_file_content = template_file.read()
        from_template = Imago.from_template(
            template_filename=template_path_str,
            image_filename=filename,
            name=name,
            caption=caption,
            uuid=uuid,
            custom_arguments=custom_args,
        )
        assert from_template.template_filename == template_path_str
        assert from_template.uuid == uuid
        assert from_template.template_source == template_file_content
        assert isinstance(from_template.template, Template)


def test_tabula():
    """Test Tabula objects."""
    df = pd.DataFrame.from_dict({"a": [1, 2, 3], "b": [4, 5, 6], "c": [7, 8, 9]})
    headers = ["alpha", "beta", "gamma"]
    uuid = "test_table_id"
    name = "test"
    latex_table = r"\begin{table}[ht]\label{tab:VAR{name}}\begin{center}\begin{tabular}{VAR{layout}}"
    latex_table += r"VAR{table}\end{tabular}\caption{VAR{caption}}\end{center}\end{table}"
    description = Scripture(description=latex_table)
    caption = Scripture(description="This is a test table")
    table = Tabula(name=name, caption=caption, description=description, data_frame=df, uuid=uuid)
    assert table.name == name
    assert table.uuid == uuid
    assert table.description == str(table)
    assert table.to_markdown() == table._repr_markdown_()
    table.set_headers(headers)
    assert table.headers == headers
    assert "gamma" in table.to_markdown()

    # load template from Path
    template_path = Path(__file__).parent / Path(tabula_test_template)
    with open(template_path) as template_file:
        template_file_content = template_file.read()
        from_template = Tabula.from_template(
            template_filename=template_path,
            name=name,
            caption=caption,
            data_frame=df,
            headers=headers,
            uuid=uuid,
        )

        assert from_template.template_filename == str(template_path.absolute())
        assert from_template.template_source == template_file_content
        assert from_template.uuid == uuid
        assert isinstance(from_template.template, Template)

    # load template from string
    template_path_str = str(template_path.absolute())
    with open(template_path_str) as template_file:
        template_file_content = template_file.read()
        from_template = Tabula.from_template(
            template_filename=template_path_str,
            name=name,
            caption=caption,
            data_frame=df,
            headers=headers,
            uuid=uuid,
        )

        assert from_template.template_filename == template_path_str
        assert from_template.template_source == template_file_content
        assert from_template.uuid == uuid
        assert isinstance(from_template.template, Template)


def test_opus_and_opera():
    """Test Opus and Opera classes."""
    # test Opus
    image_filename = Path(__file__).parent / Path(imago_test_image)
    description = "This ia a description"
    scripture = Scripture(description=description, variables=Ingredients())
    latex_formula = r"VAR{a} \cdot VAR{b}"
    formula = Formula(
        name="",
        formula=Scripture(description=latex_formula),
        function=multiplication,
        variables=Ingredients(a=2, b=3),
    )
    image = Imago(name="test", filename=image_filename, description=scripture, caption=scripture)
    table = Tabula(name="test", caption=scripture, description=scripture, data_frame=pd.DataFrame())

    alchemic = (scripture,)
    opus_uuid = "opus_id"
    opus_title = "This is an Opus"
    opus = Opus(title=opus_title, opus=alchemic, uuid=opus_uuid)
    assert opus.uuid == opus_uuid
    assert opus.title == opus_title
    assert opus.document == str(opus)
    assert opus.document == "\n" + r"\section{" + f"{opus_title}" + r"}" + f"\n{description}\\\\"
    assert opus.to_markdown() == opus._repr_markdown_()

    separator = r"\newline"
    level = r"\chapter"
    opus.separator = separator
    opus.level = level
    opus.append(formula, table)
    check_opus_document = f"\n{level}" + r"{" + f"{opus_title}" + r"}"
    check_opus_document += f"\n{description}{separator}{str(formula)}{separator}{str(table)}{separator}"
    assert opus.document == check_opus_document
    assert (opus + formula).document == (check_opus_document + str(formula) + separator)

    # set new variables and update the formula
    a = 5
    b = 12
    new_latex_formula = latex_formula.replace(r"VAR{a}", f"{a}").replace(r"VAR{b}", f"{b}")
    opus.set_variables(Ingredients(a=a, b=b))
    assert str(opus) != check_opus_document
    assert new_latex_formula in str(opus)

    # check append
    opus.append(opus)
    opus.title = ""
    assert "Unnamed" in opus.document

    opus_uuid_2 = "opus_uuid_2"
    opus_2 = Opus.from_alchemy(scripture, formula, image, table, title="Test from alchemy", uuid=opus_uuid_2)
    check_opus_document = f"\n{opus_2.level}" + r"{" + f"{opus_2.title}" + r"}"
    check_opus_document += f"\n{str(scripture)}{opus_2.separator}"
    check_opus_document += f"{str(formula)}{opus_2.separator}"
    check_opus_document += f"{str(image)}{opus_2.separator}"
    check_opus_document += f"{str(table)}{opus_2.separator}"
    assert opus_2.uuid == opus_uuid_2
    assert opus_2.document == check_opus_document

    # TODO: from_template to be implemented
    opus_from_template = Opus.from_template(template_filename="")
    assert isinstance(opus_from_template, Opus)

    # test Opera
    opera_title = "This is an Opera"
    opera_uuid = "opera_uuid"
    opus_a = scripture + formula
    opus_b = image + table
    assert isinstance(opus_a, Opus)
    assert isinstance(opus_b, Opus)
    opera = Opera(title=opera_title, opera=(opus_a, opus_b), uuid=opera_uuid)
    assert opera.title == opera_title
    assert opera.uuid == opera_uuid
    assert opera.to_markdown() == opera._repr_markdown_()

    # test Opera from opus
    opus.level = r"\section"
    opera_level = r"\chapter"
    opera_title = "This is an opera title"

    # Opera from a single Opus object
    opera = Opera.from_opus(opus=opus, title=opera_title)
    opera.level = opera_level
    check_opera_document = f"\n{opera_level}" + r"{" + f"{opera.title}" + r"}" + "\n"
    check_opera_document += str(opus) + opera.separator
    assert isinstance(opera, Opera)
    assert opera.title == opera_title
    assert opera.document == str(opera)
    assert opera.document == check_opera_document

    # Opera from a tuple of Opus
    opera = Opera.from_opus(opus=(opus, opus), title=opera_title)
    opera.level = opera_level
    check_opera_document = f"\n{opera_level}" + r"{" + f"{opera.title}" + r"}" + "\n"
    check_opera_document += str(opus) + opera.separator + str(opus) + opera.separator
    assert isinstance(opera, Opera)
    assert opera.title == opera_title
    assert opera.document == str(opera)
    assert opera.document == check_opera_document

    # Opera from an additon of Opus object
    opera = opus + opus
    opera.level = opera_level
    check_opera_document = f"\n{opera_level}" + r"{" + f"{opera.title}" + r"}" + "\n"
    check_opera_document += str(opus) + opera.separator + str(opus) + opera.separator
    assert isinstance(opera, Opera)
    assert opera.title == "New Opera"
    assert opera.document == str(opera)
    assert opera.document == check_opera_document

    # append an Opus
    opera.append(opus)
    check_opera_document += str(opus) + opera.separator
    assert opera.document == check_opera_document

    # set new variables and update the formula
    a = 13
    b = 144
    new_latex_formula = latex_formula.replace(r"VAR{a}", f"{a}").replace(r"VAR{b}", f"{b}")
    opera.set_variables(Ingredients(a=a, b=b))
    assert new_latex_formula in str(opera)

    opera_2 = opera + opera
    # join the two strings and remove the second header
    check_opera_document = str(opera) + str(opera).replace("\n\\chapter{New Opera}\n", "")
    assert opera_2.document == check_opera_document

    # TODO: from_template to be implemented
    opus_from_template = Opus.from_template(template_filename="")
    assert isinstance(opus_from_template, Opus)


def test_scriptores_errors():
    """Test Scriptores errors."""
    # Scriptores
    john_doe = ("John", "Nobody", "Doe", "john.doe@area51.gov", "Area51")

    # test __getitem__ and pop IndexError
    with pytest.raises(IndexError) as excinfo:
        Scriptores(authors=(john_doe,), uuids=("",))[0]

    with pytest.raises(IndexError) as excinfo:
        Scriptores(authors=(john_doe,), uuids=("",)).pop(0)
    assert excinfo.match("the index must be positive or negative, not null")

    # test TypeError summing a Scriptores to another non-Scriptores object
    with pytest.raises(TypeError) as excinfo:
        Scriptores(authors=(john_doe,), uuids=("",)) + []
    assert excinfo.match("concatenate")

    # ValidationError for wrong variables
    with pytest.raises(ValidationError) as excinfo:
        Scriptores(authors=(john_doe,), uuids=(1,))
    assert excinfo.match("str type expected")

    john_doe = ("John", "Nobody", 1, "john.doe@area51.gov", "Area51")
    with pytest.raises(ValidationError) as excinfo:
        Scriptores(authors=(john_doe,), uuids=(1,))
    assert excinfo.match("str type expected")

    john_doe = ("John", "Nobody", "Doe", None, "Area51")
    with pytest.raises(ValidationError) as excinfo:
        Scriptores(authors=(john_doe,), uuids=("",))
    assert excinfo.match("is not an allowed value")

    # test a TypeError with a wrong argument type in the authors arguments
    with pytest.raises(TypeError) as excinfo:
        Scriptores().append("John", "Nobody", "Doe", None, "Area51")
    assert excinfo.match("must be string")


def test_scripture_errors():
    """Test Scripture errors."""
    # test TypeError summing a Scripture to another non-Scripture object
    with pytest.raises(TypeError) as excinfo:
        Scripture(description=r"I told you that this VAR{var}", variables=Ingredients(var="is just a test")) + []
    assert excinfo.match("concatenate")


def test_formula_errors():
    """Test Formula errors."""
    # test TypeError summing a Scripture to another non-Scripture object
    with pytest.raises(TypeError) as excinfo:
        Formula(name="", formula=Scripture(description=""), function=division, variables=Ingredients(a=1, b=1)) + []
    assert excinfo.match("concatenate")

    with pytest.raises(TypeError) as excinfo:
        (
            Formula(
                name="", formula=Scripture(description=""), function=wrong_function, variables=Ingredients(a=1, b=1)
            )
            + []
        )

    assert excinfo.match(r"callable \'function\' does not return a \'Solution\' object")

    with pytest.raises(TypeError) as excinfo:
        test = Formula(name="", formula=Scripture(description=""), function=division, variables=Ingredients(a=1, b=1))
        test.set_variables(3)
    assert excinfo.match(r"argument \'variables\' must be an pydonau.alchemy.Elements object")

    with pytest.raises(TypeError) as excinfo:
        test = Formula(name="", formula=Scripture(description=""), function=division, variables=Ingredients(a=1, b=1))
        test.set_formula(3)
    assert excinfo.match(r"argument \'formula\' must be a 'Scripture' object")

    with pytest.raises(TypeError) as excinfo:
        test = Formula(name="", formula=Scripture(description=""), function=division, variables=Ingredients(a=1, b=1))
        test.set_function(3)
    assert excinfo.match(r"argument \'function\' must be a 'Callable' object")

    with pytest.raises(TypeError) as excinfo:
        test = Formula(name="", formula=Scripture(description=""), function=division, variables=Ingredients(a=1, b=1))
        test.reset_uuid(3)
    assert excinfo.match(r"argument \'uuid\' must be a string")


def test_imago_errors():
    """Test Imago errors."""

    image_filename = Path(__file__).parent / Path(imago_test_image)
    scripture = Scripture(description="", variables=Ingredients())
    image = Imago(name="test", filename=image_filename, description=scripture, caption=scripture)

    scripture = Scripture(description="", variables=Ingredients())
    with pytest.raises(OSError) as excinfo:
        # file not found
        Imago(name="test", filename="", description=scripture, caption=scripture, uuid="")
    assert excinfo.match("does not exist")

    with pytest.raises(TypeError) as excinfo:
        image + []
    assert excinfo.match("can concatenate only")


def test_tabula_errors():
    """Test Tabula errors."""
    df = pd.DataFrame.from_dict({"a": [1, 2, 3], "b": [4, 5, 6], "c": [7, 8, 9]})
    num_columns = len(df.columns)
    wrong_headers = ["alpha", "beta"]
    num_names = len(wrong_headers)
    scripture = Scripture(description="", variables=Ingredients())

    with pytest.raises(ValueError) as excinfo:
        # not matching number of columns for the attribute headers
        Tabula(name="test", caption=scripture, description=scripture, data_frame=df, headers=wrong_headers)
    assert excinfo.match(rf"\({num_names}\) does not match the data frame columns \({num_columns}\)")

    table = Tabula(name="test", caption=scripture, description=scripture, data_frame=df)
    with pytest.raises(TypeError) as excinfo:
        table.set_headers([1] * num_columns)
    assert excinfo.match(r"argument \'headers\' must be a list of string")

    with pytest.raises(TypeError) as excinfo:
        table + []
    assert excinfo.match("can concatenate only")


def test_opus_and_opera_errors():
    """Test Opus and Opera errors."""
    description = "This ia a description"
    scripture = Scripture(description=description, variables=Ingredients())

    alchemic = (scripture,)
    opus_uuid = "opus_id"
    opus_title = "This is an Opus"
    opus = Opus(title=opus_title, opus=alchemic, uuid=opus_uuid)
    opera = opus + opus
    with pytest.raises(TypeError) as excinfo:
        opus + []
    assert excinfo.match("can concatenate only")

    with pytest.raises(TypeError) as excinfo:
        opus.append([])
    assert excinfo.match("arguments must be Alchemic or Opus objects")

    with pytest.raises(TypeError) as excinfo:
        opus.set_variables([])
    assert excinfo.match("Ingredients")

    with pytest.raises(TypeError) as excinfo:
        opera + []
    assert excinfo.match("can concatenate only")

    with pytest.raises(TypeError) as excinfo:
        opera.append([])
    assert excinfo.match("arguments must be Opus or Opera objects")

    with pytest.raises(TypeError) as excinfo:
        opera.set_variables([])
    assert excinfo.match("Ingredients")


# if __name__ == "__main__":
#     test_scriptores()
#     test_scriptores_errors()
#     test_scripture()
#     test_scripture_errors()
#     test_formula()
#     test_formula_errors()
#     test_imago()
#     test_imago_errors()
#     test_tabula()
#     test_tabula_errors()
#     test_opus_and_opera()
#     test_opus_and_opera_errors()
#     test_carta()
#     test_carta_errors()
#     test_types()
