# -*- coding: utf-8 -*-
"""
Created on Mon Jul 10 11:52:16 2023

@author: gi11883
"""
from __future__ import annotations
from os import getcwd, PathLike
from pathlib import Path
from sys import settrace
from typing import Any, Union

import json
import jinja2
import latex2markdown
from pydantic import BaseModel, PrivateAttr, StrictStr


from .alchemy import Alchemic, Document, Ingredients
from .scripta import Scripture, Tabula, Imago, Formula
from .utils import _replace_eol, pandoc_latex2markdown
from .constants import EOL
from .errata import ParseError


ScriptaObj: dict[str, Any] = dict(
    zip(
        ("Ingredients", "Scripture", "Formula", "Tabula", "Imago"),
        (Ingredients, Scripture, Formula, Tabula, Imago),
    )
)


class Opus(Document):
    r"""
    Opus.

    This class is a collection of Alchemic objects (e.g. Scripture and Formula).
    The Opus class will render the text accordingly to the order in which the contents is provided.

    Args:
        title (str): title of the Opus, this is used as a paragraph title into the object.
        opus (tuple[Alchemic, ...]): a tuple of Alchemic objects to be used for render the document..
        separator (str): the separator used between each element contained into the Opus. By default is '\\'
        level: (str): latex document level. By default is '\section'. If left blank '' the title will be omitted in the
        document.
          uuid (str): Universally Unique Identifiers of the Formula object, default '' (to be implemented).
    """

    __opus: tuple[Alchemic, ...] = PrivateAttr()
    __title: str = PrivateAttr("")
    __separator: str = PrivateAttr("")
    __level: str = PrivateAttr("")
    __uuid: str = PrivateAttr("")
    __allow_flat_string: bool = PrivateAttr(False)

    class OpusValidator(BaseModel):
        """A pydantic validation class for the Opus Object."""

        opus: tuple[Alchemic, ...]
        uuid: StrictStr
        allow_flat_string: bool

        class Config:
            """Configure the Pydantic BaseModel."""

            # this is required for the Alchemic type recognition
            arbitrary_types_allowed = True

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type AlchemicFormula class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Opus class."""
        if not isinstance(value, Opus):
            raise TypeError("Opus required")
        return value

    @classmethod
    def from_alchemy(
        cls,
        *args,
        title: str,
        level: str = r"\section",
        separator: str = r"\\",
        uuid: str = "",
    ) -> Opus:
        """
        Create an Opus from Scripture and AlchemicFormula objects.

        Args:
            *args (TYPE): DESCRIPTION.

        Returns:
            Opus: DESCRIPTION.

        """
        if isinstance(args[0], Formula):
            # TODO: generate a warning if the first element is a AlchemicFormula
            pass
        return Opus(title=title, opus=tuple(args), level=level, separator=separator, uuid=uuid)

    @classmethod
    def from_json(
        cls,
        filename: PathLike[Any],
        encoding: str = "utf-8",
    ) -> Opus:
        """
        Create an Opus object from a json file.

        Args:
            filename (File): json file name.
            encoding (str): json file encoding format.

        Returns:
            opus: the Opus object.
        """
        if isinstance(filename, (str, PathLike)):
            with open(file=filename, mode="r", encoding=encoding) as file:
                data = json.load(fp=file)
        else:
            raise TypeError("the argument 'filename' must be a PathLike object")
        opus: Opus = cls.from_dict(dictionary=data, json_path=Path(filename))

        return opus

    @classmethod
    def from_dict(
        cls,
        dictionary: dict[str, Any],
        json_path: PathLike = Path(""),
    ) -> Opus:
        """
        Create an Opus object from a dictionary.

        Args:
            dictionary(dict[str, Any]): the dictionary containing the Opus structure.
            json_path(PathLike, Optional): if the dictionary was read from a json file, the path to the json file.

        Returns:
            opus: the Opus object generated from the dictionary.

        """
        if not isinstance(dictionary, dict):
            raise TypeError("argument 'dictionary' must be a dictionary")
        try:
            # root = dictionary["document:Opus"]
            for field_name in dictionary.keys():
                if ":" not in field_name:
                    raise ParseError(f"the dictionary field {field_name!r} is not in the format 'name:type'")
                # split the attribute_name:attribute_type into attribute_name and attribute_type
                try:
                    root: str = dictionary[field_name]
                except ValueError as oerr:
                    raise ParseError(f"the json field {field_name!r} is not in the format 'name:type'") from oerr
        except KeyError as exc:
            raise ParseError("wrong format, missing '<opus name>:Opus' key") from exc

        json_path = Path(json_path)
        # if a json_path is provided
        if json_path.is_file():
            # if is a file get the folder
            json_path = json_path.parent
            opus_attributes = Opus.__read_json_attributes(root, json_path)
        elif Path(json_path).is_dir():
            # if in a folder get the folder
            opus_attributes = Opus.__read_json_attributes(root, json_path)
        else:
            # skip the json_path
            opus_attributes = Opus.__read_json_attributes(root)

        opus: Opus = Opus.from_attributes(**opus_attributes)

        return opus

    @classmethod
    def from_attributes(
        cls,
        title: str,
        separator: str,
        level: str,
        opus: tuple[Alchemic, ...],
        uuid: str = "",
    ) -> Opus:
        """
        Create an Opus object from opus attributes.

        Args:
            title (str)
            separator (str)
            level (str)
            opus (Opus)
            uuid (str)

        Returns:
            Opus: the Opus object generated from the template.

        """
        opus = Opus(
            title=title,
            separator=separator,
            level=level,
            opus=opus,
            uuid=uuid,
        )
        setattr(opus, "_Opus__title", title)
        setattr(opus, "_Opus__separator", separator)
        setattr(opus, "_Opus__level", level)
        setattr(opus, "_Opus__uuid", uuid)

        return opus

    @classmethod
    def from_template(cls, template_filename: PathLike, encoding: str = "utf-8", uuid: str = "") -> Opus:
        """
        Create an Opus object from a jinja2 template.
        Note: not yet implemented! Returns an empty Opus object.
        Args:
            template_filename (PathLike): jinja2 template filename.
            encoding (str): template file encoding format.
        Returns:
            Opus: the Opus object generated from the template.
        """
        return Opus()

    @property
    def template_filename(self) -> str:
        """Return the template filename."""
        return str(getattr(self, "_Carta__template_filename"))

    @property
    def title(self) -> str:
        """
        Return the Opus title.

        Returns:
            str: the title of the Opus.
        """
        return str(getattr(self, "_Opus__title"))

    @property
    def separator(self) -> str:
        """
        Return the Opus separator.

        Returns:
            str: the separator of the Opus.
        """
        return str(getattr(self, "_Opus__separator"))

    @property
    def level(self) -> str:
        """
        Return the Opus level.

        Returns:
            str: the level of the Opus.
        """
        return str(getattr(self, "_Opus__level"))

    @property
    def uuid(self) -> str:
        """
        Return the object uuid.

        Returns:
            str: the uuid of the object.
        """
        return str(getattr(self, "_Opus__uuid"))

    @staticmethod
    def __read_json_attributes(branch: dict[str, Any], json_path=Path("")) -> dict[str, Any]:
        """
        Read the attribute from the a json dictionary branch.

        Args:
            branch (dict[str, Any]): a branch of the json dictionary.

        Raises:
            ParseError: is risen when the data in the json dictionary are not compliant with the Carta format.

        Returns:
            dict[str, Any]: a dictionary of attributes to be used to instantiate a scripta object.

        """
        results = {}
        for field_name, field_value in branch.items():
            if ":" not in field_name:
                raise ParseError(
                    f"the json field {field_name!r} is not in the format 'name:type[:method]" + " (method is optional)'"
                )
            class_method = None  # the default class method is None, i.e. no method
            # split the attribute_name:attribute_type into attribute_name and attribute_type
            try:
                # check format 2: name, type and method
                attribute_name, attribute_type, class_method = field_name.split(":")
            except ValueError:
                try:
                    # chek format 1: name and type
                    attribute_name, attribute_type = field_name.split(":")
                except ValueError as exc:
                    # the json format is wrong
                    raise ParseError(
                        f"the json field {field_name!r} is not in the format 'name:type[:method]"
                        + " (method is optional)'"
                    ) from exc
            if attribute_type in ["str", "float", "int"]:
                # if attribute_type is a standard object
                results[attribute_name] = field_value
            elif attribute_type == "bool":
                if field_value == "False":
                    results[attribute_name] = False
                elif field_value == "True":
                    results[attribute_name] = True
                else:
                    raise ParseError(
                        f"boolean field name {field_name}!r must be either 'True' or 'False' (in string format)"
                    )
            elif attribute_type in ["tuple", "list"]:
                # if attribute_type is a tuple
                if not isinstance(field_value, list):
                    # check if the the json field contains a list of attributes [ ... ]
                    raise ParseError(f"the json field {field_name!r} must be a list")

                # build a tuple of objects
                results[attribute_name] = ()
                for item in field_value:
                    # populate the tuple
                    results[attribute_name] += (*Opus.__read_json_attributes(item, json_path).values(),)
                if attribute_type == "list":
                    # cast to a list
                    results[attribute_name] = list(results[attribute_name])
            elif attribute_type in ScriptaObj:
                # if is a documentation object
                scripta_results: dict[str, Any] = Opus.__read_json_attributes(field_value, json_path)
                # check if there are paths within the attributes
                filename_attrs: list[str] = [result for result in scripta_results.keys() if "filename" in result]
                # try to locate the file
                for filename_attr in filename_attrs:
                    filename = scripta_results[filename_attr]
                    filename_1 = Path(filename)  # as an absolute path
                    filename_2 = Path(getcwd()) / filename_1  # as a relative path from the current folder
                    filename_3 = json_path / filename_1  # as a relative path from the json file
                    if filename_1.is_file():
                        scripta_results[filename_attr] = str(filename_1)
                    elif filename_2.is_file():
                        scripta_results[filename_attr] = str(filename_2)
                    elif filename_3.is_file():
                        scripta_results[filename_attr] = str(filename_3)
                if class_method:
                    # get the class method
                    scripta_method = getattr(ScriptaObj[attribute_type], class_method)
                    try:
                        # then try to instatiate the object using the class method
                        results[attribute_name] = scripta_method(**scripta_results)
                    except TypeError as exc:
                        raise ParseError(
                            f"the attributes for the json field {field_name!r}"
                            + f" are not matching the type {attribute_type!r}"
                        ) from exc
                else:
                    # if is not defined by a template, assume that all the attributes are availabe and try to
                    # intantiate the object directly
                    results[attribute_name] = ScriptaObj[attribute_type](**scripta_results)
        return results

    def __init__(
        self,
        title: str = "Unnamed",
        opus: tuple[Alchemic, ...] = (),
        level: str = r"\section",
        separator: str = r"\\",
        uuid: str = "",
        allow_flat_string: bool = False,
    ) -> None:
        """Construct the class."""
        super().__init__(title=title, level=level, separator=separator)
        # validate PrivateAttr()
        self.OpusValidator(opus=opus, uuid=uuid, allow_flat_string=allow_flat_string)
        setattr(self, "_Opus__opus", opus)
        setattr(self, "_Opus__uuid", uuid)
        setattr(self, "_Opus__allow_flat_string", allow_flat_string)

    def __add__(self, other: Union[Alchemic, Opus]) -> Union[Opus, Opera]:
        """
        Concatenate Opus objects.

        The sum of an Opus to an Alchemic objects to generate an Opera object. The sum of two opus object generate an
        Opera object.

        Args:
            other (Alchemic | Opus): the second term of the sum, i.e. object to be concatenated to the Opus object.

        Returns:
            Opus | Opera: Opus object resulting from the concatenation of an Opus to an Alchemic objects, or an Opera
            object resulting from  a concatenation of two Opus objects.
        """
        this_title = self.title
        separator = self.separator
        level = self.level
        if isinstance(other, Opus):
            new_title = "New Opera"
            new_object: Union[Opus, Opera] = Opera(title=new_title, opera=(self, other))  # type: ignore
        elif isinstance(other, Alchemic) and not isinstance(other, Opera):
            this_tuple = getattr(self, "_Opus__opus")
            new_tuple = this_tuple + (other,)
            new_title = str(this_title)
            new_object = Opus(title=new_title, opus=new_tuple, separator=separator, level=level)
        else:
            name = other.__class__.__name__
            raise TypeError(f"can concatenate only Alchemic or Opus objects, not {name!r}")
        return new_object

    def _repr_markdown_(self) -> str:
        """Render the markdown code in jupyter."""
        return self.to_markdown()

    def __str__(self) -> str:
        r"""
        Return a string with the description contained in each Opus element.

        Note:
            The order matters! Each piece of information is separated by the provided latex separator
            ('\\' by default).
        """
        if self.level:
            if self.title.strip() == "":
                title = "Unnamed"
            else:
                title = self.title
            document = EOL + self.level + "{" + title + r"}" + EOL
        else:
            document = ""
        document += self.content
        return document

    @property
    def content(self) -> str:
        """Generate a text document from the Opus objects content in latex format."""
        opus = getattr(self, "_Opus__opus")
        content = ""
        for element in opus:
            try:
                content += str(element) + self.separator
            except jinja2.exceptions.UndefinedError as exc:
                if self.__allow_flat_string:
                    content += str(element.template_source) + self.separator
                else:
                    raise exc
        return content

    @property
    def document(self) -> str:
        """Generate a text document from the object content in latex format."""
        return str(self)

    def append(self, *args: Union[Alchemic, Opus]) -> None:
        """
        Append objects to the Opus.

        Append isolated Alchemic object, or objects contained in another Opus object

        Args:
            args (Union[Alchemic, Opus]): Alchemic or Opus objects.

        Raises:
            TypeError: if the arguments are neither Alchemic nor Opus objects.

        Returns:
            None.
        """
        opus = getattr(self, "_Opus__opus")
        for arg in args:
            if isinstance(arg, Opus):
                self.title += " | " + arg.title
                opus += getattr(arg, "_Opus__opus")
            elif isinstance(arg, Alchemic) and not isinstance(arg, Opera):
                opus += (arg,)
            else:
                raise TypeError("arguments must be Alchemic or Opus objects")
        setattr(self, "_Opus__opus", opus)

    def set_variables(self, variables: Ingredients) -> None:
        """
        Set the variables to be passed to the jinja template.

        Args:
            ingredients (Ingredients): Ingredients object containing the variables to be rendered by jinja.

        Returns:
            None.

        """
        if not isinstance(variables, Ingredients):
            raise TypeError("argument 'ingredients' must be an pydonau.alchemy.Ingredients object")
        for element in getattr(self, "_Opus__opus"):
            element.set_variables(variables)

    def to_dict(self) -> dict[str, Any]:
        """Dump the Opus object content into a dictionary."""
        # TODO: to be implemented
        return {"": {}}

    def to_markdown(self) -> str:
        """Generate a markdown code out of the Formula object."""
        opus = getattr(self, "_Opus__opus")
        if self.level:
            if self.title.strip() == "":
                title = "Unnamed"
            else:
                title = self.title
            description = EOL + self.level + "{" + title + r"}" + EOL
        else:
            description = ""
        for element in opus:
            description += element.to_markdown() + self.separator
        l2m = latex2markdown.LaTeX2Markdown(_replace_eol(description))
        return l2m.to_markdown()

    def pandoc_markdown(self) -> str:
        """Generate a markdown using the pandoc functions"""
        pdc_mkd = pandoc_latex2markdown(self.content, "gfm")
        return pdc_mkd


class Opera(Document):
    r"""
    Opera.

    This class is a collection of Opus objects.
    The Opera class will render the text accordingly to the order in which the Opus objects are provided.

    Args:
        title (str): title of the Opus, this is used as a paragraph title into the object.
        opera (tuple[Opus, ...]): a tuple of Opus objects to be used for render the document..
        separator (str): the separator used between each element contained into the Opus. By default is '\\'
        level: (str): latex document level. By default is '\chapter'. If left blank '' the title will be omitted in the
        document.
        uuid (str): Universally Unique Identifiers of the Formula object, default '' (to be implemented).
    """

    __opera: tuple[Opus, ...] = PrivateAttr()

    class OperaValidator(BaseModel):
        """A pydantic validation class for the Opus Object."""

        opera: tuple[Opus, ...]
        uuid: StrictStr

        class Config:
            """Configure the Pydantic BaseModel."""

            # this is required for the PathLike type recognition
            arbitrary_types_allowed = True

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type AlchemicFormula class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Opera class."""
        if not isinstance(value, Opera):
            raise TypeError("Opera required")
        return value

    @classmethod
    def from_opus(
        cls,
        title: StrictStr,
        opus: Union[Opus, tuple[Opus]],
        separator: StrictStr = r"",
        level: StrictStr = r"\chapter",
        uuid: StrictStr = "",
    ) -> Opera:
        """
        Create an Opera object from an opus.

        Args:
            opus (Opus): an Opus object to create an Opera.

        Returns:
            Opera: an Opera object containing the provided Opus.

        """
        # is_err = False
        if isinstance(opus, Opus):
            opera = (opus,)
        else:
            opera = opus
        cls.OperaValidator(opera=opera, uuid=uuid)
        obj = Opera(title=title, separator=separator, level=level)
        setattr(obj, "_Opera__opera", opera)
        setattr(obj, "_Document__uuid", uuid)
        return obj

    @classmethod
    def from_dict(cls, dictionary: dict[str, Any]) -> Opus:
        """
        Create an Opus object from a dictionary.

        Note: not yet implemented! Returns an empty Opus object.

        Args:
            dictionary(dict[str, Any]): the dictionary containing the Opus structure.

        Returns:
            Opus: the Opus object generated from the dictionary.

        """
        return Opus()

    @classmethod
    def from_template(cls, title: str, template_filename: PathLike, encoding: str) -> Opera:
        """
        Create an OPera object from a jinja2 template.

        Note: not yet implemented! Returns an empty Opera object.

        Args:
            template_filename (PathLike): jinja2 template filename.
            encoding (str): template file encoding format.

        Returns:
            Opera: the Opera object generated from the template.

        """
        return Opera()

    def __init__(
        self,
        title: str = "Unnamed",
        opera: tuple[Opus, ...] = (),
        level: str = "",
        separator: str = r"",
        uuid: str = "",
    ) -> None:
        """Construct the class."""
        super().__init__(title=title, level=level, separator=separator)
        # validate PrivateAttr()
        self.OperaValidator(opera=opera, uuid=uuid)
        setattr(self, "_Opera__opera", opera)
        setattr(self, "_Document__uuid", uuid)

    def __add__(self, other: Union[Opus, Opera]) -> Opera:
        """
        Concatenate Opera objects.

        The sum of two Opera objects concatenate the two objects. The sum of an Opera to an Opus objects to generate an
        Opera object containing also the additional Opus object.

        Args:
            other (Opus | Opera): the second term of the sum, i.e. the object to be concatenated to the Opera object.

        Returns:
            Opera:  Opera object resulting from  a concatenation of two Opera objects, or an Opera to an Opus object.
        """
        opera = getattr(self, "_Opera__opera")
        if isinstance(other, Opus):
            opera += (other,)
        elif isinstance(other, Opera):
            opera += getattr(other, "_Opera__opera")
        else:
            name = other.__class__.__name__
            raise TypeError(f"can concatenate only Opus or Opera (not {name!r}) to Opera")
        # TODO: create a new uuid
        new_opera = Opera(title=self.title, level=self.level, separator=self.separator)
        setattr(new_opera, "_Opera__opera", opera)
        return new_opera

    def _repr_markdown_(self) -> str:
        """Render the markdown code in jupyter."""
        return self.to_markdown()

    def __str__(self) -> str:
        r"""
        Return a string with the description contained in each Opus element.

        Note:
            The order matters! Each piece of information is separated by the provided latex separator
            ('\\' by default).
        """
        if self.level:
            if self.title.strip() == "":
                title = "Unnamed"
            else:
                title = self.title
            document = EOL + self.level + "{" + title + r"}" + EOL
        else:
            document = ""
        document += self.content
        return document

    @property
    def content(self) -> str:
        """Generate a text document from the Opus objects content in latex format."""
        opera = getattr(self, "_Opera__opera")
        n_opus = len(opera)
        content = ""
        for idx, element in enumerate(opera):
            # generate the content
            # the saparator is skipped for the last element (n_opus - idx - 1) = 0 -> bool = False
            content += str(element) + self.separator * bool(n_opus - idx - 1)
        return content

    @property
    def document(self) -> str:
        """Generate a text document from the object content in latex format."""
        return str(self)

    @property
    def uuid(self) -> str:
        """
        Return the object uuid.

        Returns:
            str: the uuid of the object.
        """
        return str(getattr(self, "_Document__uuid"))

    def append(self, *args: Union[Opus, Opera]) -> None:
        """
        Append objects to the Opera.

        Append isolated Opus object, or opus objects contained in another Opera object

        Args:
            args (Union[Opus, Opera]): Opus or Opera objects.

        Raises:
            TypeError: if the arguments are neither Opus nor Opera objects.

        Returns:
            None.
        """
        opera = getattr(self, "_Opera__opera")
        for arg in args:
            if isinstance(arg, Opus):
                opera += (arg,)
            elif isinstance(arg, Opera):
                self.title += " | " + arg.title
                opera += getattr(arg, "_Opera__opera")
            else:
                raise TypeError("arguments must be Opus or Opera objects")
        setattr(self, "_Opera__opera", opera)

    def set_variables(self, variables: Ingredients) -> None:
        """
        Set the variables to be passed to the jinja template.

        Args:
            ingredients (Ingredients): Ingredients object containing the variables to be rendered by jinja.

        Returns:
            None.

        """
        if not isinstance(variables, Ingredients):
            raise TypeError("argument 'ingredients' must be an pydonau.alchemy.Ingredients object")
        for opus in getattr(self, "_Opera__opera"):
            opus.set_variables(variables)

    def to_dict(self) -> dict[str, Any]:
        """Dump the Opera object content into a dictionary."""
        # TODO: to be implemented
        return {"": {}}

    def to_markdown(self) -> str:
        """Generate a markdown code out of the Opera object."""
        if self.level:
            if self.title.strip() == "":
                title = "Unnamed"
            else:
                title = self.title
            description = EOL + self.level + "{" + title + r"}" + EOL
        else:
            description = ""
        for idx, element in enumerate(getattr(self, "_Opera__opera")):
            description += element.to_markdown() + self.separator
        l2m = latex2markdown.LaTeX2Markdown(_replace_eol(description))
        return l2m.to_markdown()
