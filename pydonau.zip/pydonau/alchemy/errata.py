#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 10 16:51:33 2023

@author: gi11883
"""


class ParseError(Exception):
    """Raise a ParseError."""
