# -*- coding: utf-8 -*-
"""
Created on Thu Jun 22 10:09:20 2023

@author: gi11883
"""
from __future__ import annotations
import re
from math import floor, ceil
from string import Formatter
from abc import ABCMeta, abstractmethod
from typing import Any, ItemsView, Union, Optional
from copy import deepcopy
from pydantic import BaseModel, PrivateAttr, StrictStr, validate_arguments
import pandas as pd


from ..isengard import Data

# TODO: change Union to | with python 3.10
# TODO: put in place a system for the creation of uuid to be assigned to the instances


class ElementsFormatter(Formatter):
    """Formatter for the attributes of the Elements object."""

    def format_field(self, value: Any, format_spec) -> str:
        """
        Override the string format method adding ':s' for strings and ':i' for truncation to integer.

        Args:
            value (Any): value to be rendered into the string.
            format_spec (str): strings containing a specification of how the value should be presented, see python
            string module.

        Returns:
            str: the value rendered as string in accordance with the format_spec.

        """
        if format_spec == "i":  # Render as int
            return str(int(value))
        elif re.match(r"^\.\d+tf$", format_spec) and isinstance(value, float):  # Truncate float instead of round
            n = int(re.search(r"\d+", format_spec).group())  # type: ignore
            if n == 0:
                return str(int(value))
            elif value >= 0:
                result = str(floor(value * 10**n) / (10**n))
            else:
                result = str(ceil(value * 10**n) / (10**n))
            return result
        return super(ElementsFormatter, self).format_field(value, format_spec)

    @staticmethod
    def caster(value: str) -> Union[int, float, str]:
        """
        Cast a string to a float or a int when it is possible.

        Args:
            value (str): value to be caste to a float or an int.

        Returns:
            Union[int, float, str]: if the string is an integer or a float return it accordingly, otherwise leave
            it as a string.

        """
        result: Union[int, float, str] = value
        if "." in value:
            try:
                result = float(value)
            except ValueError:
                pass
        else:
            try:
                result = int(value)
            except ValueError:
                pass
        return result


class Alchemic(BaseModel, metaclass=ABCMeta):
    """Alchemic, the meta class."""

    name: StrictStr
    __uuid: StrictStr = PrivateAttr("")

    @classmethod
    @abstractmethod
    def from_template(cls, *args, **kwargs) -> Alchemic:
        """Create an Alchemic object from a json file."""

    @property
    @abstractmethod
    def description(self) -> str:
        """Description."""

    @property
    def uuid(self) -> str:
        """uuid."""
        return self.__uuid

    @abstractmethod
    def __str__(self) -> str:
        """To string (latex)."""

    @abstractmethod
    def _repr_markdown_(self) -> str:
        """Render to markdown in jupyter."""

    @abstractmethod
    def to_markdown(self) -> str:
        """To markdown."""


class Document(BaseModel, metaclass=ABCMeta):
    """Document, the meta class."""

    title: StrictStr
    level: StrictStr
    separator: StrictStr
    __uuid: StrictStr = PrivateAttr("")

    @classmethod
    @abstractmethod
    def from_dict(cls, *args, **kwargs) -> Document:
        """Create an Documentum object from a dictionary."""

    @classmethod
    @abstractmethod
    def from_template(cls, *args, **kwargs) -> Document:
        """Create an Documentum object from a json file."""

    @property
    @abstractmethod
    def content(self) -> str:
        """Content of the document."""

    @property
    @abstractmethod
    def document(self) -> str:
        """The whole document."""

    @property
    @abstractmethod
    def uuid(self) -> str:
        """uuid."""

    @abstractmethod
    def __str__(self) -> str:
        """To string (latex)."""

    @abstractmethod
    def _repr_markdown_(self) -> str:
        """Render to markdown in jupyter."""

    @abstractmethod
    def to_dict(self) -> dict:
        """To dictionary."""

    @abstractmethod
    def to_markdown(self) -> str:
        """To markdown."""


class Elements(Data):
    """
    Elements class.

    This class defines methods and attributes for Ingredients and Solution classes, to be used for an inter-class
     inputs and outputs interface.

     Args:
         uuid (str): Universally Unique Identifier of the object, default '' (to be implemented).
    """

    __formats: dict[str, str] = PrivateAttr()

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Scripture class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Elements class."""
        if not isinstance(value, Elements):
            raise TypeError("Elements required")
        return value

    @validate_arguments
    def __init__(self, uuid: StrictStr = "", **kwargs: Any) -> None:
        """Construct the Elements object."""
        descriptor = getattr(self, "_Data__descriptor")
        descriptor.description = self.__class__.__name__ + " object"
        descriptor.uuid = uuid
        setattr(self, "_Elements__formats", {})

    def __add__(self, other: Elements) -> Elements:
        """
        Concatenate two Elements object.

        Note: this method returns a new Elements object. It works like the 'append' method, if the same attributes is
        defined in both the objects this method raise a TypeError.

        Args:
            other (Elements): the second term of the addition.

        Returns:
            Elements: a new Elements object containing the attributes of both the object.
        """
        if not isinstance(other, Elements):
            other_name = other.__class__.__name__
            raise TypeError(f"can concatenate Elements (Ingredients, Solution), not {other_name}")
        attributes_1 = self.get_attributes()
        attributes_2 = other.get_attributes()
        formats_1 = self.get_formats()
        formats_2 = other.get_formats()
        obj = self.__class__(**attributes_1, **attributes_2)
        obj.add_formats(**formats_1, **formats_2)
        return obj

    def __contains__(self, attribute_name: str) -> bool:
        """
        Check if the attribute is contained into the object.

        Args:
            attribute_name (str): attribute name.

        Returns:
            bool: True if the attribute exists, False otherwise.

        """
        return attribute_name in getattr(self, "_Data__attributes").names

    def __eq__(self, other) -> bool:
        """
        Compare two Elements object.

        Note: it is a strict equality, not only the attributes must be the same but also the type of objects (e.g.
        Elements != Ingredients and Ingredients != Solution by definition). If only the content is to be compared use
        the get_attributes() method on both side of the equality (e.g. A.get_attributes() == B.get_attributes()), which
        is a comparison between two dictionary.

        Args:
            other (Elements): the object to be compared with.

        Returns:
            bool: True if the two objects share the same attributes, False otherwise.

        """
        if isinstance(other, self.__class__):
            return self.get_attributes() == other.get_attributes()
        return False

    def __sub__(self, other: Elements) -> Elements:
        """
        Subtract two Elements object.

        Note: this method returns a new Elements object. The subtraction is done deleting the attributes of the first
        Elements object that are matched in the second (other) Elements object, i.e. only if the attributes share the
        same name AND the same value.

        Args:
            other (Elements): the second term of the subtraction.

        Returns:
            Elements: a new Elements object containing the attributes defined only in the first object.

        """
        if not isinstance(other, Elements):
            other_name = other.__class__.__name__
            raise TypeError(f"can subtract attributes from Elements (Ingredients, Solution), not {other_name}")
        attributes_1 = self.get_attributes()
        attributes_2 = other.get_attributes()
        for name, value_2 in attributes_2.items():
            try:
                value_1 = attributes_1[name]
            except KeyError:
                continue
            if value_1 == value_2:
                del attributes_1[name]
        return self.__class__(**attributes_1)

    def __getitem__(self, key: str) -> Any:
        """Get an input by key."""
        attributes = getattr(self, "_Data__attributes")
        return attributes[key].value

    def __setitem__(self, key: str, value: Any) -> None:
        """Set an input by key."""
        attributes = getattr(self, "_Data__attributes")
        try:
            attributes[key].value = value
        except KeyError:
            raise KeyError(f"attribute {key!r} does not exists")

    def __get_attributes_and_names(self) -> tuple[dict, set[Any]]:
        """Get the 'arguments' (dictionary) and its names (keys)."""
        attrs = getattr(self, "_Data__attributes")
        return (attrs, set(attrs.names))

    def __len__(self) -> int:
        """Return the number of the main attributes."""
        attributes = getattr(self, "_Data__attributes")
        return len(attributes.names)

    @property
    def names(self) -> set[Any]:
        """Get a set containing the attributes names."""
        names = getattr(self, "_Data__attributes").names
        return set(names)

    @property
    def uuid(self) -> str:
        """Get the object uuid."""
        return self.descriptor.uuid

    def add_formats(self, **kwargs) -> None:
        """
        Add formats to the Elements attributes.

        Args:
            **kwargs (str, Any): name=value, where name and value are the attribute name and value, respectively.

        Returns:
            None.

        """
        formats = getattr(self, "_Elements__formats")
        attribute_names = getattr(self, "_Data__attributes").names
        new_formats = {key: str(value) for key, value in kwargs.items() if key in attribute_names}
        formats.update(new_formats)
        setattr(self, "_Elements__formats", formats)

    def del_formats(self, *args: str) -> None:
        """
        Delete the formats of the Elements attributes.

        Args:
            **args (str, ...): names of the attributes for which the formats shall be deleted.

        Returns:
            None.

        """
        formats = getattr(self, "_Elements__formats")
        for name in args:
            if name in formats:
                del formats[name]
        setattr(self, "_Elements__formats", formats)

    def get_formats(self) -> dict[str, Any]:
        """
        Get a duplicate of the defined formats.

        Returns:
            dict[str, Any]: a dictionary containing the format of the attributes. If the an attribute is not enclosed,
            the format is free.

        """
        return dict(getattr(self, "_Elements__formats"))

    def append(self, **kwargs) -> None:
        """Append parameters to the Elements."""
        new_names = set(kwargs.keys())
        attrs, attr_names = self.__get_attributes_and_names()
        common_names = attr_names.intersection(new_names)
        if self.are_attributes(*new_names, partial=True):
            if len(common_names) > 1:
                plural = "s"
                verb = "are"
            else:
                plural = ""
                verb = "is"
            raise KeyError(
                rf"attribute{plural} {sorted(common_names)!r} {verb} already defined, use the overwrite method instead"
            )
        attrs = getattr(self, "_Data__attributes")
        attrs.append_main(**kwargs)

    def are_attributes(self, *args: str, partial: bool = False) -> bool:
        """Check if the provided names are valid attribute names."""
        names = set(args)
        attrs, attr_names = self.__get_attributes_and_names()
        common_names = attr_names.intersection(names)
        if common_names:
            if partial:
                # if only a partial match is required then True
                result = True
            else:
                # otherwise the provided keys must be all common_keys
                result = names == attr_names
        else:
            # if no keys match then False
            result = False
        return result

    def copy(self, **kwargs) -> Elements:
        """
        Return a duplicate of the object.

        Returns:
            Elements: a duplicate of the object.

        """
        formats = deepcopy(getattr(self, "_Elements__formats"))
        attributes = deepcopy(getattr(self, "_Data__attributes"))
        descriptor = deepcopy(getattr(self, "_Data__descriptor"))
        # TODO: a new uuid must be generated
        # Create a proper Ingredients or Solution object
        obj = self.__class__()
        # set the data
        setattr(obj, "_Data__attributes", attributes)
        setattr(obj, "_Data__descriptor", descriptor)
        setattr(obj, "_Elements__formats", formats)
        return obj

    def formatted(self, **kwargs) -> Union[Elements, Ingredients, Solution]:
        """
        Return a duplicate of the Elements object with the formatted attributes.

        If no formats as provided the method applies the formats added to the object with the add_formats method.
        If formats are provided the previously defined formats are updated.

        Note: apply the formatting only to numerical value (integers and float)! The attributes without formats are left
        unchanged, the others are converted to string using the python string formatting capabilities, then the
        formatted string are cast back to the original format if possible. If an attribute is an object a format will
        destroy the information contained in it, therefore do not provide any formats for attributes containing objects.

        Args:
            **kwargs (str): name=format, the format is the common f-string format specification mini-language. A
            truncated float 'tf' is also available instead of the standard rounded float 'f' (e.g. '{:.2tf}').

        Returns:
            Elements: An Elements containing the formatted attributes.

        """
        if kwargs:
            self.add_formats(**kwargs)
        formats = getattr(self, "_Elements__formats")
        attributes = getattr(self, "_Data__attributes")
        fmt = ElementsFormatter()
        new_attributes = {}
        for name in attributes.names:
            value = attributes[name].value
            if name in formats:
                # cast value to a formatted string if a format is specified
                new_attributes[name] = fmt.caster(fmt.format(formats.get(name), value))
            else:
                # otherwise keep it unchanged
                # TODO: value should be copied and not just assigned
                new_attributes[name] = value
        return self.__class__(**new_attributes)  # type: ignore

    def get(self, name: str, default=None, **kwargs) -> Any:
        """
        Get the attribute by name otherwise return None.

        Args:
            name (str): attribute name.
            default (Any, optional): value to return if the name does not exist. Defaults to None.

        Returns:
            Any: the attribute with the provided name, or default.

        """
        attributes = getattr(self, "_Data__attributes")
        attribute = attributes.get_main(name)
        if attribute is None:
            return default
        return attribute.value

    def set(self, **kwargs) -> None:
        """."""

    @validate_arguments
    def get_attributes(self, clone: bool = True) -> dict:
        """Return a dictionary containing a copy of the main attribute values."""
        attributes = getattr(self, "_Data__attributes")
        attributes_dict = {}
        for name in attributes.names:
            attributes_dict[name] = attributes[name].value
        if clone:
            return deepcopy(attributes_dict)
        return attributes_dict

    def is_empty(self) -> bool:
        """Return True if there are no attributes, otherwise False."""
        return getattr(self, "_Data__attributes").is_empty()

    def items(self) -> ItemsView:
        """Return a copy of the items conteined into the object."""
        attributes = self.get_attributes()
        return attributes.items()

    def overwrite(self, **kwargs) -> None:
        """
        Append parameters to the Elements overwriting already existing parameters.

        Args:
            **kwargs (TYPE): name = value, attribute name and value.

        Returns:
            None.

        """
        attrs = getattr(self, "_Data__attributes")
        attrs.set_main(**kwargs)

    def pop(self, *args: str) -> Any:
        """
        Pop the attributes from the Elements object by name.

        Args:
            *args (str): attribute names.

        Returns:
            Any: the value of each attribute.

        """
        result = []
        attrs, attr_names = self.__get_attributes_and_names()
        # find the existing attributes
        common_names = attr_names.intersection(args)
        # order the existing attribute names as the provided arguments
        ordered_common_names = [name for name in args if name in common_names]
        if not ordered_common_names:
            return None
        # pop the attribute from the Elements object into a list
        for common_name in ordered_common_names:
            result.append(attrs.pop(common_name).value)
        if len(result) == 1:
            return result[0]
        return result

    def remove(self, *args: str) -> None:
        """
        Remove the attributes from the Elements object by name.

        Args:
            *args (str): attribute names.

        Returns:
            Any: the value of each attribute.

        """
        attrs, attr_names = self.__get_attributes_and_names()
        common_names = attr_names.intersection(args)
        for common_name in common_names:
            attrs.pop(common_name)

    def reset_uuid(self, uuid: str) -> None:
        """Reset the object uuid."""
        # TODO: check if is a valid uuid not only a generic string
        # or better remove the uuid argument and use a standard uuid generator
        if isinstance(uuid, str):
            self.descriptor.uuid = uuid


class Ingredients(Elements):
    """
    Ingredients class.

    This class is used to provide inputs to other classes via the defined attributes.
    The attributes are accessible only with the square bracket operator (e.g. obj["attribute_name"]).

    Args:
        **kwargs (Any): the attributes to be defined by a keyword (e.g. a=2, b='something', and so on).

    Returns:
        Ingredients: an Ingredients with the provided arguments.

    """

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Scripture class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Ingredients class."""
        if not isinstance(value, Ingredients):
            raise TypeError("Ingredients required")
        return value

    @classmethod
    def from_dict(cls, dictionary: dict) -> Ingredients:
        """
        Create an Ingredients object from a dictionary.

        Args:
            dictionary (dict): dictionary containing the attributes to be copied.

        Returns:
            Ingredients: an Ingredients object containing a duplicate of each dictionary item (key -> value).

        """
        obj: Ingredients = Ingredients()
        obj.append(**dictionary)
        return obj

    @classmethod
    def from_solution(cls, solution: Solution) -> Ingredients:
        """
        Create an Ingredients object from a Solution object.

        Args:
            solution (Solution): a Solution object containing the attributes to be copied.

        Returns:
            Solution: an Solution object containing a duplicate of the Ingredients attributes.

        """
        obj: Ingredients = Ingredients.from_dict(solution.get_attributes())
        return obj


class Solution(Elements):
    """
    Solution class.

    This class is used to provide outputs to other classes via the defined attributes.
    The attributes are accessible only with the square bracket operator (e.g. obj["attribute_name"]).

    Args:
        **kwargs (Any): the attributes to be defined by a keyword (e.g. a=2, b='something', and so on).

    Returns:
        Solution: a Solution with the provided arguments.

    """

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Scripture class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Solution class."""
        if not isinstance(value, Solution):
            raise TypeError("Solution required")
        return value

    @classmethod
    def from_dict(cls, dictionary: dict) -> Solution:
        """
        Create a Solution object from a dictionary.

        Args:
            dictionary (dict): dictionary containing the attributes to be copied.

        Returns:
            Solution: a Solution object containing a duplicate of each dictionary item (key -> value).

        """
        obj: Solution = Solution()
        obj.append(**dictionary)
        return obj

    @classmethod
    def from_schema(cls, schema: Any) -> Solution:
        """
        Create a Solution object from a schema. To be implements.

        Args:
            schema (Any): to be defined.

        Returns:
            Solution: a Solution object in accordance with the provided schema.

        """
        obj: Solution = Solution()
        # TODO: To be implemented
        return obj

    def update(self, **kwargs) -> None:
        """Update the all the Solutions attributes."""
        names = set(kwargs.keys())
        if self.are_attributes(*names, partial=False):
            attrs = getattr(self, "_Data__attributes")
            attrs.set_main(**kwargs)
            # setattr(self, "_Elements__attributes", attrs)
        else:
            names = self.names
            provided_names = set(kwargs.keys())
            missing_names = names - provided_names
            wrong_attributes = provided_names - names
            error_string = "all the attributes must be updated concurrently"
            if missing_names:
                if len(missing_names) > 1:
                    verb = "are"
                else:
                    verb = "is"
                error_string += f", {missing_names!r} {verb} missing"
            if wrong_attributes:
                if len(wrong_attributes) > 1:
                    plural = "s"
                    verb = "aren't"
                else:
                    plural = ""
                    verb = "isn't an"
                error_string += f", {wrong_attributes!r} {verb} attribute{plural}"
            raise ValueError(error_string + ".")


class SolutionSet:
    """
    A class to manage a set of Solution objects.

    Attributes:
        solutions (List[Solution]): A list of Solution objects.
        _df_cache (Optional[pd.DataFrame]): A cache for the DataFrame representation of solutions.

    Methods:
        add_solution(solution): Adds a new Solution to the set.
        dataframe: Returns the DataFrame representation of solutions.
        min_value(attribute): Finds the Solution with the minimum value for a given attribute.
        max_value(attribute): Finds the Solution with the maximum value for a given attribute.
        get_less_than(attribute, value): Returns a new SolutionSet with Solutions having values less than the given
        value for a specified attribute.
    """

    def __init__(self, solutions=None):
        """Inits SolutionSet with an empty list of solutions."""
        if solutions:
            self.solutions: list = solutions
        else:
            self.solutions: list = []
        self._df_cache: Optional[pd.DataFrame] = None

    def add_solution(self, solution: Solution) -> None:
        """
        Adds a Solution to the SolutionSet and resets the DataFrame cache.

        Args:
            solution (Solution): The Solution to be added.
        """
        if isinstance(solution, Solution):
            self.solutions.append(solution)
            self._df_cache = None
        else:
            raise TypeError("Only Solution objects can be added")

    @property
    def dataframe(self) -> Optional[pd.DataFrame]:
        """DataFrame representation of the solutions. Generates the DataFrame on first access."""
        if self._df_cache is None and self.solutions:
            solutions_data = [solution.get_attributes() for solution in self.solutions]
            self._df_cache = pd.DataFrame(solutions_data)
        return self._df_cache

    def min_value(self, attribute: str) -> Optional[Solution]:
        """
        Finds the Solution with the minimum value for a given attribute.

        Args:
            attribute (str): The attribute to evaluate.

        Returns:
            Optional[Solution]: The Solution with the minimum value for the given attribute.
        """
        if self.dataframe is not None and attribute in self.dataframe.columns:
            return self.solutions[self.dataframe[attribute].idxmin()]
        return None

    def max_value(self, attribute: str) -> Optional[Solution]:
        """
        Finds the Solution with the maximum value for a given attribute.

        Args:
            attribute (str): The attribute to evaluate.

        Returns:
            Optional[Solution]: The Solution with the maximum value for the given attribute.
        """
        if self.dataframe is not None and attribute in self.dataframe.columns:
            return self.solutions[self.dataframe[attribute].idxmax()]
        return None

    def get_less_than(self, attribute: str, value) -> "SolutionSet":
        """
        Returns a new SolutionSet with Solutions having values less than the given value for a specified attribute.

        Args:
            attribute (str): The attribute to evaluate.
            value (numeric): The threshold value.

        Returns:
            SolutionSet: A new SolutionSet containing Solutions that meet the condition.
        """
        if self.dataframe is not None and attribute in self.dataframe.columns:
            filtered_solutions = [
                self.solutions[i] for i in self.dataframe.index if self.dataframe.at[i, attribute] < value
            ]
            new_set = SolutionSet()
            for sol in filtered_solutions:
                new_set.add_solution(sol)
            return new_set
        return SolutionSet()

    def __getitem__(self, index: int) -> Solution:
        """Returns the solution at the specified index."""
        return self.solutions[index]

    def __len__(self) -> int:
        """Returns the number of solutions in the set."""
        return len(self.solutions)

    def __iter__(self) -> iter:
        """Returns an iterator for the solutions."""
        return iter(self.solutions)
