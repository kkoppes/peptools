# -*- coding: utf-8 -*-
"""
Created on Mon Jul 10 16:47:12 2023

@author: gi11883
"""
from __future__ import annotations

import json
from os import getcwd, PathLike
from pathlib import Path
from datetime import date
from typing import Any, Union

import latex2markdown
from jinja2 import Template
from pydantic import BaseModel, PrivateAttr, StrictStr

from .constants import EOL
from .errata import ParseError
from .alchemy import Ingredients
from .scripta import Scripture, Formula, Tabula, Imago, Scriptores
from .opera import Opus, Opera
from .utils import latex_jinja_env, _replace_eol

ScriptaObj: dict[str, Any] = dict(
    zip(
        ("Ingredients", "Scripture", "Formula", "Tabula", "Imago", "Opus", "Opera"),
        (Ingredients, Scripture, Formula, Tabula, Imago, Opus, Opera),
    )
)
today = date.today()


class Carta(BaseModel):
    r"""
    Carta.

    This class render the entire document out of the provided Opera object, including title, date, authors and
    bibliography (not implemented yet).

    Args:
        title (str): title of the document.
        authors (Scriptores): a Scriptores object containing the authors information.
        opera (Opera): the Opera object containing all the Opus to render the full document.
        uuid (str): Universally Unique Identifiers of the Formula object, default '' (to be implemented).

    Raises:
        OSError:
        ParseError:
        TypeError:
    """

    title: StrictStr
    authors: Scriptores
    opera: Opera
    __uuid: str = PrivateAttr("")
    __content: str = PrivateAttr("")
    __document: str = PrivateAttr("")
    __inputs: Ingredients = PrivateAttr()
    __template: Template = PrivateAttr()
    __template_uuid: str = PrivateAttr("")
    __template_source: str = PrivateAttr("")
    __template_filename: str = PrivateAttr("")

    class CartaValidator(BaseModel):
        """A pydantic validation class for the Opus Object."""

        uuid: StrictStr
        document: StrictStr

        class Config:
            """Configure the Pydantic BaseModel."""

            # this is required for the PathLike type recognition
            arbitrary_types_allowed = True

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type AlchemicFormula class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Carta class."""
        if not isinstance(value, Carta):
            raise TypeError("Carta required")
        return value

    @classmethod
    def from_dict(cls, dictionary: dict[str, Any], json_path: PathLike = Path("")) -> Carta:
        """
        Create an Carta object from a dictionary.

        Args:
            dictionary(dict[str, Any]): the dictionary containing the Opus structure.
            json_path(PathLike, Optional): if the dictionary was read from a json file, the path to the json file.

        Returns:
            Carta: the Opus object generated from the dictionary.

        """
        if not isinstance(dictionary, dict):
            raise TypeError("argument 'dictionary' must be a dictionary")
        try:
            # TODO: make it mor general using directly __read_json_attributes
            root = dictionary["document:Carta:from_template"]
        except KeyError as exc:
            raise ParseError("wrong format, missing 'document:Carta' key") from exc
        json_path = Path(json_path)
        # if a json_path is provided
        if json_path.is_file():
            # if is a file get the forlder
            json_path = json_path.parent
            carta_attributes = Carta.__read_json_attributes(root, json_path)
        elif Path(json_path).is_dir():
            # if ia a folder get the folder
            carta_attributes = Carta.__read_json_attributes(root, json_path)
        else:
            # skip the json_path
            carta_attributes = Carta.__read_json_attributes(root)
        # try to get an absolute path for the Carta template file
        template_filename_1 = Path(carta_attributes["template_filename"])  # as an absolute path
        template_filename_2 = json_path / template_filename_1  # as a relative path from the json file
        if template_filename_1.is_file():
            carta_attributes["template_filename"] = str(template_filename_1.absolute())
        elif template_filename_2.is_file():
            carta_attributes["template_filename"] = str(template_filename_2.absolute())
        carta = Carta.from_template(**carta_attributes)
        return carta

    @classmethod
    def from_json(cls, filename: PathLike[Any], encoding: str = "utf-8") -> Carta:
        """
        Create a Carta object from a json file.

        Args:
            filename (File): json file name.
            encoding (str): json file encoding format.

        Returns:
            Carta: the Carta object.
        """
        if isinstance(filename, (str, PathLike)):
            with open(file=filename, mode="r", encoding=encoding) as file:
                data = json.load(fp=file)
        else:
            raise TypeError("the argument 'filename' must be a PathLike object")
        carta = cls.from_dict(dictionary=data, json_path=Path(filename))
        return carta

    @classmethod
    def from_template(
        cls,
        template_filename: PathLike,
        title: str,
        authors: Scriptores,
        opera: Opera,
        encoding: str = "utf-8",
        template_uuid: str = "",
        uuid: str = "",
    ) -> Carta:
        """
        Create a Carta object from a latex jinja template.

        Args:
            template_filename (PathLike): jinja2 template filename.
            title (str): title of the Carta object.
            authors (Scriptores): a Scriptores object containing the authors information.
            opera (Opera): the Opera object containing all the Opus to render the full document.
            encoding (str, optional): template file encoding format. Defaults to "utf-8".
            template_uuid (str, optional): template file uuid. Defaults to "".

        Raises:
            TypeError: DESCRIPTION.
            OSError: DESCRIPTION.

        Returns:
            Carta: the Carta object.

        """
        if isinstance(template_filename, str):
            file_path = Path(template_filename)
        elif isinstance(template_filename, Path):
            file_path = template_filename
        else:
            raise TypeError("argument 'filename' must be a PathLike object")
        if file_path.exists():
            with open(file_path, "rb") as file:
                document = file.read().decode(encoding=encoding)
        else:
            raise OSError(f"file {file_path.absolute()!r} does not exist!")
        obj = Carta(document=document, title=title, authors=authors, opera=opera)
        setattr(obj, "_Carta__template_filename", str(file_path.absolute()))
        setattr(obj, "_Carta__template_uuid", template_uuid)
        setattr(obj, "_Carta__template_source", document)
        setattr(obj, "_Carta__inputs", Ingredients())
        setattr(obj, "_Carta__uuid", uuid)
        return obj

    def __init__(
        self,
        document: str,
        title: str,
        authors: Scriptores,
        opera: Opera,
        uuid: str = "",
    ) -> None:
        """Construct the Carta object."""
        # TODO: generate an uuid for the Carta object
        super().__init__(title=title, authors=authors, opera=opera)
        self.CartaValidator(uuid=uuid, document=document)
        setattr(self, "_Carta__template", latex_jinja_env.from_string(document))
        setattr(self, "_Carta__template_source", document)
        setattr(self, "_Carta__content", str(opera))
        setattr(self, "_Carta__inputs", Ingredients())
        setattr(self, "_Carta__uuid", uuid)

    def _repr_markdown_(self) -> str:
        """Render the markdown code in jupyter."""
        return self.to_markdown()

    def __str__(self) -> str:
        r"""
        Return a string with the description contained in each Opus object.

        Note:
            The order matters! Each piece of information is separated by the provided latex separator
            ('\newline' by default).
        """
        content = getattr(self, "_Carta__content")
        template = getattr(self, "_Carta__template")
        n_authors = len(self.authors)
        authors = [""] * n_authors
        for idx, author in enumerate(self.authors):
            first_name = author[0]
            middle_name = author[1]
            last_name = author[2]
            department = author[3]
            email = author[4]
            # build the name
            if middle_name:
                authors[idx] = " ".join([first_name, middle_name, last_name, department])
            else:
                authors[idx] = " ".join([first_name, last_name, department])
            if email:
                # add the email
                authors[idx] += r"\\ \texttt{" + email + r"}"
            # if is not the last one add a \and statement
            authors[idx] += (idx < (n_authors - 1)) * r"\and"
        self.update()
        self.opera.set_variables(getattr(self, "_Carta__inputs"))
        return template.render(title=self.title, authors=authors, content=content)

    @property
    def content(self) -> str:
        """Generate the main body of the document (i.e. everything but title, date and authors)."""
        return str(getattr(self, "_Carta__content"))

    @property
    def document(self) -> str:
        """Generate a document from the Opera object including document title, date and authors."""
        # TODO: include bibliography a.k.a. references
        return str(self)

    @property
    def template_filename(self) -> str:
        """Return the template filename."""
        return str(getattr(self, "_Carta__template_filename"))

    @property
    def uuid(self) -> str:
        """
        Return the object uuid.

        Returns:
            str: the uuid of the object.
        """
        return str(getattr(self, "_Carta__uuid"))

    def get_variables(self) -> Ingredients:
        """
        Get the variables passed to the jinja template.

        Returns:
            Ingredients: Ingredients object containing the variables rendered by jinja.

        """
        inputs = getattr(self, "_Carta__inputs")
        return Ingredients(**inputs.get_attributes())

    def set_variables(self, variables: Ingredients) -> None:
        """
        Set the variables to be passed to the jinja template.

        Args:
            ingredients (Ingredients): Ingredients object containing the variables to be rendered by jinja.

        Returns:
            None.

        """
        if not isinstance(variables, Ingredients):
            raise TypeError("argument 'ingredients' must be an pydonau.alchemy.Ingredients object")
        # copy the variables into the Carta object
        setattr(self, "_Carta__inputs", variables.copy())
        # propagate the new variables to the documentation objects for rendering
        self.opera.set_variables(variables.copy())  # type: ignore
        # update the carta content
        setattr(self, "_Carta__content", str(self.opera))

    def to_dict(self) -> dict[str, Any]:
        """Dump the Carta object content into a dictionary."""
        # TODO: to be implemented
        return {"": {}}

    def to_markdown(self) -> str:
        """Render the markdown code in jupyter."""
        to_markdown = "# " + self.title + EOL  # title
        to_markdown += str(today) + "<br>" + EOL  # today data
        for author in self.authors:  # authors
            to_markdown += " ".join(author) + "<br>" + EOL
        # add the docuemnt content
        to_markdown += self.opera.to_markdown()
        return to_markdown

    def update(self) -> None:
        """Update the Carta content after an append."""
        setattr(self, "_Carta__content", str(self.opera))

    @staticmethod
    def __read_json_attributes(branch: dict[str, Any], json_path=Path("")) -> dict[str, Any]:
        """
        Read the attribute from the a json dictionary branch.

        Args:
            branch (dict[str, Any]): a branch of the json dictionary.

        Raises:
            ParseError: is risen when the data in the json dictionary are not compliant with the Carta format.

        Returns:
            dict[str, Any]: a dictionary of attributes to be used to instantiate a scripta object.

        """
        results = {}
        for field_name, field_value in branch.items():
            if ":" not in field_name:
                raise ParseError(
                    f"the json field {field_name!r} is not in the format 'name:type[:method]" + " (method is optional)'"
                )
            class_method = None  # the default class method is None, i.e. no method
            # split the attribute_name:attribute_type into attribute_name and attribute_type
            try:
                # check format 2: name, type and method
                attribute_name, attribute_type, class_method = field_name.split(":")
            except ValueError:
                try:
                    # chek format 1: name and type
                    attribute_name, attribute_type = field_name.split(":")
                except ValueError as exc:
                    # the json format is wrong
                    raise ParseError(
                        f"the json field {field_name!r} is not in the format 'name:type[:method]"
                        + " (method is optional)'"
                    ) from exc
            if attribute_type in ["str", "float", "int"]:
                # if attribute_type is a standard object
                results[attribute_name] = field_value
            elif attribute_type == "bool":
                if field_value == "False":
                    results[attribute_name] = False
                elif field_value == "True":
                    results[attribute_name] = True
                else:
                    raise ParseError(
                        f"boolean field name {field_name}!r must be either 'True' or 'False' (in string format)"
                    )
            elif attribute_type in ["tuple", "list"]:
                # if attribute_type is a tuple
                if not isinstance(field_value, list):
                    # check if the the json field contains a list of attributes [ ... ]
                    raise ParseError(f"the json field {field_name!r} must be a list")
                if attribute_name == "authors":
                    # if the attribute contains the authors data
                    # use the ____read_json_authors private method
                    # TODO: __read_json_authors to be removed making the format more general
                    # using only __read_json_attributes
                    results[attribute_name] = Carta.__read_json_authors(field_value)
                else:
                    # build a tuple of objects
                    results[attribute_name] = ()
                    for item in field_value:
                        # populate the tuple
                        results[attribute_name] += (*Carta.__read_json_attributes(item, json_path).values(),)
                    if attribute_type == "list":
                        # cast to a list
                        results[attribute_name] = list(results[attribute_name])
            elif attribute_type in ScriptaObj:
                # if is a documentation object
                scripta_results = Carta.__read_json_attributes(field_value, json_path)
                # check if there are paths within the attributes
                filename_attrs = [result for result in scripta_results.keys() if "filename" in result]
                # try to locate the file
                for filename_attr in filename_attrs:
                    filename = scripta_results[filename_attr]
                    filename_1 = Path(filename)  # as an absolute path
                    filename_2 = Path(getcwd()) / filename_1  # as a relative path from the current folder
                    filename_3 = json_path / filename_1  # as a relative path from the json file
                    if filename_1.is_file():
                        scripta_results[filename_attr] = str(filename_1)
                    elif filename_2.is_file():
                        scripta_results[filename_attr] = str(filename_2)
                    elif filename_3.is_file():
                        scripta_results[filename_attr] = str(filename_3)
                if class_method:
                    # get the class method
                    scripta_method = getattr(ScriptaObj[attribute_type], class_method)
                    try:
                        # then try to instatiate the object using the class method
                        results[attribute_name] = scripta_method(**scripta_results)
                    except TypeError as exc:
                        raise ParseError(
                            f"the attributes for the json field {field_name!r}"
                            + f" are not matching the type {attribute_type!r}"
                        ) from exc
                else:
                    # if is not defined by a template, assume that all the attributes are availabe and try to
                    # intantiate the object directly
                    results[attribute_name] = ScriptaObj[attribute_type](**scripta_results)
        return results

    @staticmethod
    def __read_json_authors(authors_data: Union[list, dict]) -> Scriptores:
        if isinstance(authors_data, dict):
            persons: list[dict] = [authors_data]
        elif isinstance(authors_data, list):
            if not all(isinstance(author_data, dict) for author_data in authors_data):
                raise ParseError("all the elements in the field 'authors:Scriptores' must be a dictionary")
            persons = authors_data
        else:
            raise ParseError("the field authors:Scriptores' mist be a dictionary or a list")
        authors = Scriptores()
        for person in persons:
            authors.append(**person)
        return authors
