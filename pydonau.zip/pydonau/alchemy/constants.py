#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 22 13:32:16 2023

@author: gi11883
"""

EOL = "\n"
MARKDOWN_NEWLINE = "<br>\n"
LATEX_NEWLINES = [r"\newline", r"\\"]
