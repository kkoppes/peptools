#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 22 13:38:03 2023

@author: gi11883
"""
from os import PathLike
from typing import Any, Optional

from jinja2 import Environment, BaseLoader
from charset_normalizer import from_path

import subprocess
import logging

from .constants import LATEX_NEWLINES, MARKDOWN_NEWLINE


latex_jinja_env = Environment(
    block_start_string="BLOCK{",
    block_end_string="}",
    variable_start_string="VAR{",
    variable_end_string="}",
    comment_start_string="#{",
    comment_end_string="}",
    line_statement_prefix="%-",
    line_comment_prefix="%#",
    trim_blocks=True,
    autoescape=False,
    loader=BaseLoader(),
)


def _replace_eol(string: str) -> str:
    """Change Latex End of Line to markdown."""
    for latex_newline in LATEX_NEWLINES:
        string = string.replace(latex_newline, MARKDOWN_NEWLINE)
    return string


def _read_text_file(filename: PathLike[Any]) -> str:
    """Code to read a text file into a string."""
    # use the charset-normalizer package
    results = from_path(filename)
    return str(results.best())


def pandoc_latex2markdown(
    latex_string: str, markdown_flavor: str = "markdown"
) -> Optional[str]:
    """
    Convert a LaTeX string to Markdown using Pandoc. Return None if conversion fails.

    Args:
    latex_string (str): A string containing LaTeX.
    markdown_flavor (str): The markdown flavor for Pandoc to output.

    Returns:
    Optional[str]: The converted Markdown string, or None if an error occurs.
    """
    try:
        # Set up the Pandoc command with specified markdown flavor
        process = subprocess.Popen(
            ["pandoc", "--from=latex", f"--to={markdown_flavor}"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        # Send the LaTeX string to Pandoc and get the Markdown output
        markdown_string, error = process.communicate(latex_string)

        # Check for errors or empty output
        if process.returncode != 0 or not markdown_string.strip():
            raise Exception(f"Pandoc error: {error}")

        return markdown_string
    except FileNotFoundError:
        logging.warning(
            "Pandoc is not installed or not found in the system path. "
            "To install Pandoc using Conda, run: 'conda install -c conda-forge pandoc'"
        )
        return None
    except Exception as e:
        logging.warning(f"An error occurred: {e}")
        return None
