# -*- coding: utf-8 -*-
"""
Created on Thu Jun 22 11:45:22 2023.

@author: gi11883
"""
from __future__ import annotations
from os import PathLike
from pathlib import Path
from copy import deepcopy
from typing import Any, Callable, Union

import latex2markdown
import pandas as pd
from jinja2 import Template
from pydantic import BaseModel, Field, PrivateAttr, StrictStr, validator


from .utils import latex_jinja_env, _replace_eol
from .alchemy import Alchemic, Document, Elements, Ingredients, Solution
from .constants import EOL

# TODO: put in place a system for the creation of uuid to be assigned to the instances
# TODO: the uuid should be recreated every time an object is modified so existing copies of the same object
# continue to have the original uuid, and every modified object has an unique id
# TODO: add a class for bibliography and nomenclature, and add the possibility to generate list of tables and pictures


FirstName = StrictStr
MiddleName = StrictStr
LastName = StrictStr
Email = StrictStr
Department = StrictStr
# TODO: Add the author function field to the Scriptores tuple


class Scriptores(BaseModel):
    """
    Scriptores, authors in Latin.

    This class contains the information of the authors of the documentation.

     Args:
         uuids (tuple[str]): Universally Unique Identifiers of the authors, default () (to be implemented).

    """

    __authors: tuple[
        tuple[FirstName, MiddleName, LastName, Email, Department], ...
    ] = PrivateAttr()
    __uuids: tuple[str, ...] = PrivateAttr()
    __current_index: int = PrivateAttr(0)

    class ScriptoresValidator(BaseModel):
        """A pydantic validation class for the Scripture Object."""

        authors: tuple[tuple[FirstName, MiddleName, LastName, Email, Department], ...]
        uuids: tuple[StrictStr, ...]

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type AlchemicFormula class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Authors class."""
        if not isinstance(value, Scriptores):
            raise TypeError("Scriptores required")
        return value

    def __init__(
        self,
        authors: tuple[
            tuple[FirstName, MiddleName, LastName, Email, Department], ...
        ] = (),
        uuids: tuple[StrictStr, ...] = (),
    ) -> None:
        """Construct the Scripture object."""
        # Validate the PrivateAttr()
        self.ScriptoresValidator(
            authors=authors,
            uuids=uuids,
        )
        # initialize the class
        super().__init__()
        # set the private attributes
        setattr(self, "_Scriptores__authors", authors)
        setattr(self, "_Scriptores__uuids", uuids)

    def __add__(self, other: Scriptores) -> Scriptores:
        """
        Concatenate two Authors objects removing duplicates.

        Args:
            other (Authors): the second term of the sum.

        Returns:
            Authors: a concatenation of the two Authors objects.

        """
        if not isinstance(other, Scriptores):
            name = other.__class__.__name__
            raise TypeError(
                f"can concatenate only 'Authors' with 'Authors' (not {name!r})"
            )
        authors_1 = getattr(self, "_Scriptores__authors")
        authors_2 = getattr(other, "_Scriptores__authors")
        new_authors = tuple(set(authors_1 + authors_2))
        # TODO: create a new uuid
        return Scriptores(authors=new_authors, uuids=())

    def __getitem__(self, ith: int) -> tuple[str, ...]:
        """Get the ith item starting from 1."""
        ith = int(ith)
        # check the index ith
        if ith == 0:
            raise IndexError("the index must be positive or negative, not null")
        if ith > 0:
            # because the index is considered starting from 1
            # the actual python index for the tuple must be ith - 1
            ith -= 1
        authors = getattr(self, "_Scriptores__authors")
        return authors[ith]

    def __len__(self) -> int:
        """Return the number of authors."""
        return len(getattr(self, "_Scriptores__authors"))

    def __iter__(self):
        """Iterate."""
        return self

    def __next__(self):
        """Next item."""
        current_index = int(getattr(self, "_Scriptores__current_index"))
        authors = getattr(self, "_Scriptores__authors")
        if current_index < len(authors):
            setattr(self, "_Scriptores__current_index", current_index + 1)
            return authors[current_index]
        if current_index == len(authors):
            setattr(self, "_Scriptores__current_index", 0)
        raise StopIteration

    def append(
        self,
        first_name: str,
        last_name: str,
        department: str,
        email: str,
        middle_name: str = "",
    ) -> None:
        """
        Append an author to the authors list.

        Args:
            first_name (str): author's first name.
            middle_name (str, Optional): author's middle name
            last_name (str): author's last name
            department (str): author's department
            email (str): author's email.

        Returns:
            None.

        """
        args = [first_name, middle_name, last_name, department, email]
        validate = [not isinstance(arg, str) for arg in args]
        if any(validate):
            argnames = ["first_name", "middle_name", "last_name", "department", "email"]
            invalid = [
                f"{argname!r}" for idx, argname in enumerate(argnames) if validate[idx]
            ]
            raise TypeError("arguments " + ", ".join(invalid) + " must be string")
        authors = getattr(self, "_Scriptores__authors")
        authors += ((first_name, middle_name, last_name, department, email),)
        setattr(self, "_Scriptores__authors", tuple(set(authors)))

    def pop(self, ith: int) -> tuple[str, ...]:
        """
        Pop the ith-author (index-ith start from 1, not from 0!).

        Args:
            index (int): index of the author data to pop.

        Returns:
            None.

        """
        # check the index ith
        if ith == 0:
            raise IndexError("the index must be positive or negative, not null")
        if ith > 0:
            # because the index is considered starting from 1
            # the actual python index for the tuple must be ith - 1
            ith -= 1

        authors = getattr(self, "_Scriptores__authors")
        # get the ith author
        author = authors[ith]
        # remove this author from the tuple
        authors = tuple(val for val in authors if val != author)
        # store the modified tuple
        setattr(self, "_Scriptores__authors", authors)
        # return the chosen author
        return author


class Scripture(Alchemic):
    """
    Scripture.

    This class contains a part of text to be included into a document.

     Args:
         uuid (str): Universally Unique Identifiers of the Scripture object, default '' (to be implemented).
    """

    __template: Template = PrivateAttr()
    __alchemies: Ingredients = PrivateAttr()
    __variables: Ingredients = PrivateAttr()
    __template_source: StrictStr = PrivateAttr("")
    __template_filename: StrictStr = PrivateAttr("")

    class ScriptureValidator(BaseModel):
        """A pydantic validation class for the Scripture Object."""

        name: StrictStr
        description: StrictStr
        variables: Elements
        alchemies: Elements
        template_filename: StrictStr
        uuid: StrictStr

        class Config:
            """Configure the Pydantic BaseModel."""

            # this is required for the PathLike type recognition
            arbitrary_types_allowed = True

        @validator("alchemies")
        def are_alchemies(cls, value: Ingredients) -> Ingredients:
            """Validate the content of alchemies."""
            wrong_attributes = []
            for name, attribute in value.items():
                # check if the attributes are valid types
                if not isinstance(attribute, (Scripture, Formula, Imago, Tabula)):
                    wrong_attributes.append(name)
            if wrong_attributes:
                n_err = len(wrong_attributes)
                plurale = "s" * bool(n_err > 1)
                raise TypeError(
                    f"wrong type for attribute{plurale}: {', '.join(wrong_attributes)!r}"
                )
            return value

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Scripture class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Scripture class."""
        if not isinstance(value, Scripture):
            raise TypeError("Scripture required")
        return value

    @classmethod
    def from_template(
        cls,
        template_filename: PathLike,
        encoding: str = "utf-8",
        uuid: str = "",
        name: str = "",
        variables: Ingredients = Ingredients(),
        alchemies: Ingredients = Ingredients(),
        description: str = "",
    ) -> Scripture:
        """
        Create a Scripture object from a jinja2 template file.

        Args:
            filename (File): Scripture template file name.

        Returns:
            Scripture: the Scripture object generated from the template.

        """
        if template_filename == "":
            template_source = description
        else:
            with open(template_filename, "rb") as file:
                template_source = file.read().decode(encoding=encoding)

        obj = Scripture(
            name=name,
            description=template_source,
            variables=variables,
            alchemies=alchemies,
            uuid=uuid,
        )

        setattr(obj, "_Scripture__template_source", template_source)
        if isinstance(template_filename, Path):
            template_filepath: str = str(template_filename.absolute())
        else:
            template_filepath = str(template_filename)
        setattr(obj, "_Scripture__template_filename", template_filepath)
        return obj

    def __init__(
        self,
        description: str,
        variables: Ingredients = Ingredients(),
        alchemies: Ingredients = Ingredients(),
        name: str = "",
        uuid: str = "",
    ) -> None:
        """Construct the Scripture object."""
        # Validate the variables
        self.ScriptureValidator(
            name=name,
            description=description,
            variables=variables,
            alchemies=alchemies,
            template_filename="",
            uuid=uuid,
        )
        # initialize the class
        super().__init__(name=name)
        # set the private attributes
        template = latex_jinja_env.from_string(description)
        setattr(self, "_Scripture__template", template)
        setattr(self, "_Scripture__template_source", description)
        setattr(self, "_Scripture__variables", variables.copy())
        setattr(self, "_Scripture__alchemies", alchemies.copy())
        setattr(self, "_Alchemic__uuid", uuid)

    def __add__(self, other: Alchemic) -> Document:
        """
        Concatenate two Alchemic objects to generate an Opus.

        Args:
            other (Alchemic): the second Alchemic object to be concatenated.

        Returns:
            Opus: Opus object resulting from the concatenation of two Alchemic objects.

        """
        from .opera import Opus

        if not isinstance(other, Alchemic):
            name = other.__class__.__name__
            raise TypeError(f"can concatenate only Alchemic objects not {name!r}")
        new_opus = Opus()
        setattr(new_opus, "_Opus__opus", (self, other))
        return new_opus

    def __repr__(self) -> str:
        """Return a clone of the description."""
        return self.description

    def _repr_markdown_(self) -> str:
        """Render the markdown code in jupyter."""
        return self.to_markdown()

    def __str__(self) -> str:
        """Return a clone of the description."""
        return self.description

    @property
    def description(self) -> str:
        """Return the description."""
        template = getattr(self, "_Scripture__template")
        variables = getattr(self, "_Scripture__variables")
        alchemies = getattr(self, "_Scripture__alchemies")
        additional_variables = {}
        for name, content in alchemies.items():
            additional_variables[name] = str(content)
        description = template.render(
            **variables.get_attributes(), **additional_variables
        )
        return description

    @property
    def variables(self) -> Ingredients:  #
        """
        Get a copy of the variables.

        Returns:
            None.

        """
        variables = getattr(self, "_Scripture__variables")
        return Ingredients(**variables.get_attributes())

    @property
    def template(self) -> Template:
        """
        Get a copy of the template.

        Returns:
            Template: a copy of the jinja2 Template.

        """
        # TODO: find a way to copy the template because deepcopy raise an error
        return getattr(self, "_Scripture__template")

    @property
    def template_source(self) -> str:
        """
        Get the template a in text format.

        Returns:
           str: the jinja2 template text source.

        """
        return getattr(self, "_Scripture__template_source")

    @property
    def template_filename(self) -> str:
        """
        Get the template file name.

        Returns:
           str: the jinja2 template file name.

        """
        return getattr(self, "_Scripture__template_filename")

    @property
    def uuid(self) -> str:
        """
        Get the uuid.

        Returns:
            str: the Scripture object uuid.

        """
        return str(getattr(self, "_Alchemic__uuid"))

    def copy(self, **kwargs) -> Scripture:
        """Create a copy of the object."""
        name = self.name
        variables = getattr(self, "_Scripture__variables")
        uuid = getattr(self, "_Alchemic__uuid")
        copy = Scripture(
            name=name, description=self.description, variables=variables, uuid=uuid
        )
        return copy

    def set_variables(self, variables: Elements) -> None:
        """
        Set the variables and regenerate the description.

        Args:
            variables (Ingredients): the variables to be rendered into the jinja2 template.

        Returns:
            None.

        """
        if not isinstance(variables, Elements):
            raise TypeError(
                "argument 'variables' must be an pydonau.alchemy.Elements object"
            )
        if not variables.is_empty():
            attr: Ingredients = getattr(self, "_Scripture__variables")
            attr.overwrite(**variables.get_attributes())
            attr.add_formats(**variables.get_formats())

    def to_markdown(self) -> str:
        """Generate a markdown code out of  the Scripture object."""
        template = getattr(self, "_Scripture__template")
        variables = getattr(self, "_Scripture__variables")
        alchemies = getattr(self, "_Scripture__alchemies")
        additional_variables = {}
        for name, content in alchemies.items():
            additional_variables[name] = content.to_markdown()
        description = template.render(
            **variables.get_attributes(), **additional_variables
        )
        l2m = latex2markdown.LaTeX2Markdown(_replace_eol(description))
        return l2m.to_markdown()


class Formula(Alchemic):
    """
    Formula.

    This class contains a mathematical formula to be included into a document.

     Args:
         name: (str): the name of the function, i.e. a label to be used as reference for the document.
         function (Callable): a Callable object that perform the required calculation.
         formula (Scripture): a Scripture object that contains the latex formula to be rendered.
         variables (Ingredients): an Ingredients object containing the variables used by the Callable function.
         uuid (str): Universally Unique Identifiers of the Formula object, default '' (to be implemented).
    """

    __formula: Scripture = PrivateAttr()
    __function: Callable = PrivateAttr()
    __variables: Ingredients = PrivateAttr()
    __outputs: Solution = PrivateAttr()

    class FormulaValidator(BaseModel):
        """A pydantic validation class for the Formula Object."""

        name: StrictStr
        formula: Scripture
        function: Callable
        variables: Ingredients
        uuid: StrictStr

        class Config:
            """Configure the Pydantic BaseModel."""

            # this is required for the PathLike type recognition
            arbitrary_types_allowed = True

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Formula class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Formula class."""
        if not isinstance(value, Formula):
            raise TypeError("Formula required")
        return value

    @classmethod
    def from_template(
        cls,
        template_filename: PathLike,
        name: str,
        function: Callable,
        variables: Ingredients = Ingredients(),
        encoding: str = "utf-8",
        uuid: str = "",
    ) -> Formula:  # type: ignore
        """
        Create a Formula object from a jinja2 template file.

        Args:
            filename (File): jinja2 template file name.

        Returns:
            Formula: Formula object created from the jinja2 template.

        """
        obj = Formula(
            name=name,
            function=function,
            formula=Scripture.from_template(
                name=name, template_filename=template_filename, encoding=encoding
            ),
            variables=variables,
            uuid=uuid,
        )
        return obj

    def __init__(
        self,
        name: str,
        formula: Scripture,
        function: Callable,
        variables: Ingredients,
        uuid: str = "",
    ) -> None:
        """Construct the Formula object."""
        # Validate the variables
        self.FormulaValidator(
            name=name,
            formula=formula,
            function=function,
            variables=variables,
            uuid=uuid,
        )
        # initialize the class
        super().__init__(name=name)
        # set the private attributes
        setattr(self, "_Alchemic__uuid", uuid)
        setattr(self, "_Formula__formula", formula)
        setattr(self, "_Formula__function", function)
        setattr(self, "_Formula__variables", variables)
        setattr(self, "_Formula__outputs", Solution())
        self.compute()

    def __add__(self, other) -> Document:
        """
        Concatenate two Alchemic objects to generate an Opus.

        Args:
            other (ALchemy): the second Alchemic object to be concatenated.

        Returns:
            Opus: Opus object resulting from the concatenation of two Alchemic objects.

        """
        from .opera import Opus

        if not isinstance(other, Alchemic):
            name = other.__class__.__name__
            raise TypeError(f"can concatenate only an Alchemic object not {name!r}")
        new_opus = Opus()
        setattr(new_opus, "_Opus__opus", (self, other))
        return new_opus

    def _repr_markdown_(self) -> str:
        """Render the markdown code in jupyter."""
        return self.to_markdown()

    def __str__(self) -> str:
        """Return the formula as a string."""
        outputs = getattr(self, "_Formula__outputs")
        if outputs.is_empty():
            self.compute()
        return str(getattr(self, "_Formula__formula"))

    @property
    def description(self) -> str:
        """Return the formula as a string."""
        return str(self)

    @property
    def formula(self) -> Scripture:
        """Get a duplicate of the formula."""
        formula = getattr(self, "_Formula__formula")
        return formula.copy()

    @property
    def function(self) -> Callable:
        """Get a duplicate of the function."""
        return deepcopy(getattr(self, "_Formula__function"))

    @property
    def variables(self) -> Ingredients:
        """Get a duplicate of the variables."""
        variables = getattr(self, "_Formula__variables")
        outputs = getattr(self, "_Formula__outputs")
        return variables - outputs

    @property
    def outputs(self) -> Solution:
        """Get a duplicate of the outputs."""
        return getattr(self, "_Formula__outputs").copy()

    @property
    def template(self) -> Template:
        """
        Get a copy of the template.

        Returns:
            Template: a copy of the jinja2 Template.

        """
        # TODO: find a way to copy the template because deepcopy raise an error
        formula: Scripture = getattr(self, "_Formula__formula")
        return formula.template

    @property
    def template_source(self) -> str:
        """
        Get the template a in text format.

        Returns:
           str: the jinja2 template text source.

        """
        formula: Scripture = getattr(self, "_Formula__formula")
        return formula.template_source

    @property
    def template_filename(self) -> str:
        """
        Get the template file name.

        Returns:
           str: the jinja2 template file name.

        """
        formula: Scripture = getattr(self, "_Formula__formula")
        return formula.template_filename

    @property
    def uuid(self) -> str:
        """Get a duplicate of the uuid."""
        uuid = getattr(self, "_Alchemic__uuid")
        return str(uuid)

    def compute(self) -> None:
        """Compute the formula, update the solution and the description."""
        variables = getattr(self, "_Formula__variables")
        function = getattr(self, "_Formula__function")
        # compute and store the outputs
        outputs = function(variables)
        if not isinstance(outputs, Solution):
            raise TypeError("callable 'function' does not return a 'Solution' object")
        setattr(self, "_Formula__outputs", outputs)
        # create an Ingredients containing both variables and outputs to render the formula
        formula_variables = Ingredients(**variables.get_attributes())
        # use overwrite in case the function copies the input arguments into the output
        formula_variables.overwrite(**outputs.get_attributes())
        # set the formula variables and automatically regenerate the description with the new variables
        setattr(self, "_Formula__variables", formula_variables)
        # update the formula text
        formula: Scripture = getattr(self, "_Formula__formula")
        formula.set_variables(formula_variables)

    def set_formula(self, formula: Scripture) -> None:
        """
        Set the formula in latex format.

        Args:
            formula (Scripture): Scripture object containing the latex description of the formula.

        Returns:
            None.

        """
        if not isinstance(formula, Scripture):
            raise TypeError("argument 'formula' must be a 'Scripture' object")
        setattr(self, "_Formula__formula", formula.copy())
        self.compute()

    def set_function(self, function: Callable[[Ingredients], Solution]) -> None:
        """
        Set the function to be called to perform the calculation.

        Note: the function shall get in Ingredients object as input and return a Solution object.

        Args:
            function (Callable): a callable to perform the calculation.

        Returns:
            None.

        """
        if not callable(function):
            raise TypeError("argument 'function' must be a 'Callable' object")
        setattr(self, "_Formula__function", deepcopy(function))
        self.compute()

    def set_variables(self, variables: Elements) -> None:
        """
        Set the variables.

        Args:
            variables (Ingredients): variables to evaluate the formula.

        Returns:
            None.

        """
        if not isinstance(variables, Elements):
            raise TypeError(
                "argument 'variables' must be an pydonau.alchemy.Elements object"
            )
        if not variables.is_empty():
            attr: Ingredients = getattr(self, "_Formula__variables")
            attr.overwrite(**variables.get_attributes())
            attr.add_formats(**variables.get_formats())
            self.compute()

    def reset_uuid(self, uuid: str) -> None:
        """
        Reset the uuid assigned to the Formula.

        Args:
            uuid (str): a uuid to associated with the Formula.

        Returns:
            None.

        """
        if not isinstance(uuid, str):
            raise TypeError("argument 'uuid' must be a string")
        setattr(self, "_Alchemic__uuid", uuid)

    def to_markdown(self) -> str:
        """Generate a markdown code out of the Formula object."""
        outputs = getattr(self, "_Formula__outputs")
        if outputs.is_empty():
            self.compute()
        l2m = latex2markdown.LaTeX2Markdown(_replace_eol(self.description))
        return l2m.to_markdown()


class Imago(Alchemic):
    """
    Imago, image in Latin.

    This class contains a picture to be included into a document.

     Args:
         name: (str): the name of the picture, i.e. a label to be used as reference for the document.
         filename (str): the picture filename.
         caption (Scripture): a Scripture object that contains the picture caption.
         template (jinja2.Template): a jinja2 Template object.
         custom_arguments (Ingredients): in pydonau.alchemy Ingredients object for additional attributes to be passed
         to the template.
         uuid (str): Universally Unique Identifiers of the Formula object, default '' (to be implemented).
    """

    __filename: StrictStr = PrivateAttr()
    __caption: Scripture = PrivateAttr()
    __template: Template = PrivateAttr()
    __template_source: StrictStr = PrivateAttr("")
    __template_filename: StrictStr = PrivateAttr("")
    __custom_arguments: Ingredients = PrivateAttr()

    class ImagoValidator(BaseModel):
        """A pydantic validation class for the Imago Object."""

        name: StrictStr
        filename: Union[StrictStr, PathLike]
        caption: Scripture
        description: Scripture
        custom_arguments: Ingredients
        uuid: StrictStr

        class Config:
            """Configure the Pydantic BaseModel."""

            # this is required for the PathLike type recognition
            arbitrary_types_allowed = True

        @validator("filename")
        def file_exists(
            cls, value: Union[StrictStr, PathLike]
        ) -> Union[StrictStr, PathLike]:
            """Check if the image file exists."""
            if not Path(value).is_file():
                filename = Path(value).absolute()
                raise OSError(f"file {str(filename)!r} does not exist")
            return value

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Formula class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Imago class."""
        if not isinstance(value, Imago):
            raise TypeError("Imago required")
        return value

    @classmethod
    def from_template(
        cls,
        template_filename: PathLike,
        image_filename: str,
        name: str,
        caption: Scripture,
        encoding: str = "utf-8",
        uuid: str = "",
        custom_arguments: Ingredients = Ingredients(),
    ) -> Imago:
        """Create an Imago object from a latex jinja template."""
        imago = Imago(
            name=name,
            filename=image_filename,
            caption=caption,
            description=Scripture.from_template(
                name=name, template_filename=template_filename, encoding=encoding
            ),
            uuid=uuid,
            custom_arguments=custom_arguments,
        )
        return imago

    def __init__(
        self,
        name: str,
        filename: str,
        caption: Scripture,
        description: Scripture,
        uuid: str = "",
        custom_arguments: Ingredients = Ingredients(),
    ) -> None:
        """Construct the Imago object."""
        # Validate the variables
        self.ImagoValidator(
            name=name,
            filename=filename,
            caption=caption,
            description=description,
            custom_arguments=custom_arguments,
            uuid=uuid,
        )
        # initialize the class
        super().__init__(name=name)
        # set the private attributes
        setattr(self, "_Alchemic__uuid", uuid)
        setattr(self, "_Imago__filename", Path(filename))
        setattr(self, "_Imago__caption", caption)
        setattr(self, "_Imago__template", description.template)
        setattr(self, "_Imago__custom_arguments", custom_arguments)
        setattr(self, "_Imago__template_source", description.template_source)
        setattr(self, "_Imago__template_filename", description.template_filename)
        setattr(self, "_Imago__custom_arguments", custom_arguments)

    def __add__(self, other: Alchemic) -> Document:
        """
        Concatenate two Alchemic objects to generate an Opus.

        Args:
            other (AlchemicType): the second Alchemic object to be concatenated.

        Returns:
            Opus: Opus object resulting from the concatenation of two Alchemic objects.

        """
        from .opera import Opus

        if not isinstance(other, Alchemic):
            name = other.__class__.__name__
            raise TypeError(f"can concatenate only an Alchemic object not {name!r}")
        new_opus = Opus()
        setattr(new_opus, "_Opus__opus", (self, other))
        return new_opus

    def _repr_markdown_(self) -> str:
        """Return a string with the markdown code."""
        return self.to_markdown()

    def __str__(self) -> str:
        """Return a string with the latex code."""
        name = self.name
        caption = str(getattr(self, "_Imago__caption"))
        filename = Path(getattr(self, "_Imago__filename")).absolute()
        # TODO: add order options and layouts
        options = r"width=\linewidth"
        custom_arguments = getattr(self, "_Imago__custom_arguments")
        additional_arguments = custom_arguments.get_attributes()
        template = getattr(self, "_Imago__template")
        return template.render(
            name=name,
            caption=caption,
            filename=filename,
            options=options,
            **additional_arguments,
        )

    @property
    def caption(self) -> Scripture:
        """Return the image caption."""
        caption: Scripture = getattr(self, "_Imago__caption")
        return caption.copy()

    @property
    def custom_arguments(self) -> Ingredients:
        """Return the image custom arguments."""
        ingredients: Ingredients = getattr(self, "_Imago__custom_arguments")
        return Ingredients(**ingredients.get_attributes())

    @property
    def description(self) -> str:
        """
        Description.

        Returns:
            str: Imago latex description.

        """
        return str(self)

    @property
    def filename(self) -> str:
        """Return the image filename."""
        return str(getattr(self, "_Imago__filename"))

    @property
    def template(self) -> Template:
        """Return the image jinja2 template."""
        # TODO: find a way to copy a jonja2 template
        return getattr(self, "_Imago__template")

    @property
    def template_source(self) -> str:
        """
        Get the template a in text format.

        Returns:
           str: the jinja2 template text source.

        """
        return getattr(self, "_Imago__template_source")

    @property
    def template_filename(self) -> str:
        """
        Get the template file name.

        Returns:
           str: the jinja2 template file name.

        """
        return getattr(self, "_Imago__template_filename")

    @property
    def uuid(self) -> str:
        """Return the image uuid."""
        return str(getattr(self, "_Alchemic__uuid"))

    def set_variables(self, variables: Elements) -> None:
        """Just a dummy method for consistency."""
        # TODO: put in the meta class

    def to_markdown(self) -> str:
        """Generate a markdown code out of the Formula object."""
        caption = str(self.caption)
        filename = str(Path(getattr(self, "_Imago__filename")))
        custom_args = getattr(self, "_Imago__custom_arguments")
        style = ""
        if "width" in custom_args:
            style += f"width:{custom_args['width']};"
        else:
            style += "width:100%;"
        if "height" in custom_args:
            style += f"height:{custom_args['height']};"
        # TODO: support different options and the caption

        markdown = f'<center><img src="{filename}" style="{style}"/></center>\n'
        markdown += f"<p><center>{caption}</center></p>\n"
        return markdown


class Tabula(Alchemic):
    """Tabula, table in Latin.

    This class contains data for a table to be included into a document.

     Args:
         name: (str): the name of the table, i.e. a label to be used as reference for the document.
         caption (Scripture): a Scripture object that contains the picture caption.
         template (jinja2.Template): a jinja2 Template object.
         data_frame (pandas.DataFrame): a pandas DataFrame object containing the table data.
         headers (list[str]): a list the contains the headers of the table, if provided overrides the data frame
         column names.
         custom_arguments (Ingredients): in pydonau.alchemy Ingredients object for additional attributes to be passed
         to the template.
         uuid (str): Universally Unique Identifiers of the Formula object, default '' (to be implemented).
    """

    __caption: Scripture = PrivateAttr()
    __data_frame: pd.DataFrame = PrivateAttr()
    __headers: list[str] = PrivateAttr([])
    __template: Template = PrivateAttr()
    __template_source: StrictStr = PrivateAttr("")
    __template_filename: StrictStr = PrivateAttr("")
    __custom_arguments: Ingredients = PrivateAttr()

    class TabulaValidator(BaseModel):
        """A pydantic validation class for the Tabula Object."""

        name: StrictStr
        data_frame: pd.DataFrame
        caption: Scripture
        headers: list[StrictStr]
        custom_arguments: Ingredients
        description: Scripture
        uuid: StrictStr

        class Config:
            """Configure the Pydantic BaseModel."""

            # this is required for the pd.DataFrame type recognition
            arbitrary_types_allowed = True

        @validator("headers")
        def check_number_of_columns(
            cls, field_value: list[str], values: dict[str, Any]
        ) -> list[str]:
            """Check if the number of column names match the number of columns in the data_frame."""
            if field_value:
                num_names = len(field_value)
                num_columns = len(values["data_frame"].columns)
                if num_names != num_columns:
                    raise ValueError(
                        f"the number of column names ({num_names}) does not match"
                        + f" the data frame columns ({num_columns})"
                    )
            return field_value

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Formula class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Tabula class."""
        if not isinstance(value, Tabula):
            raise TypeError("Tabula required")
        return value

    @classmethod
    def from_template(
        cls,
        template_filename: PathLike,
        name: str,
        caption: Scripture,
        data_frame: pd.DataFrame,
        encoding: str = "utf-8",
        headers: list[str] = [],
        uuid: str = "",
        custom_arguments: Ingredients = Ingredients(),
    ) -> Tabula:
        """Create a Tabula object from a latex jinja template."""
        tabula = Tabula(
            name=name,
            data_frame=data_frame,
            description=Scripture.from_template(
                name=name, template_filename=template_filename
            ),
            caption=caption,
            headers=headers,
            uuid=uuid,
            custom_arguments=custom_arguments,
        )
        return tabula

    @classmethod
    def from_template_and_csv(
        cls,
        template_filename: PathLike,
        csv_filename: pd.PathLike,
        name: str,
        caption: Scripture,
        encoding: str = "utf-8",
        headers: list[str] = [],
        uuid: str = "",
        custom_arguments: Ingredients = Ingredients(),
    ) -> Tabula:
        """Create a Tabula object from a latex jinja template and a csv table."""
        # TODO: optimize for number only or text only tables
        data_frame = pd.read_csv(csv_filename)
        data_frame = data_frame.fillna("")
        tabula = Tabula(
            name=name,
            data_frame=data_frame,
            description=Scripture.from_template(
                name=name, template_filename=template_filename
            ),
            caption=caption,
            headers=headers,
            uuid=uuid,
            custom_arguments=custom_arguments,
        )
        return tabula

    def __init__(
        self,
        name: str,
        caption: Scripture,
        data_frame: pd.DataFrame,
        description: Scripture,
        headers: list[str] = [],
        custom_arguments: Ingredients = Ingredients(),
        uuid: str = "",
    ):
        """Construct the Tabula object."""
        # Validate the variables
        self.TabulaValidator(
            name=name,
            caption=caption,
            description=description,
            data_frame=data_frame,
            headers=headers,
            custom_arguments=custom_arguments,
            uuid=uuid,
        )
        # initialize the class
        super().__init__(name=name)
        # set the private attributes
        setattr(self, "_Alchemic__uuid", uuid)
        setattr(self, "_Tabula__caption", caption)
        setattr(self, "_Tabula__data_frame", data_frame)
        setattr(self, "_Tabula__headers", headers)
        setattr(self, "_Tabula__template", description.template)
        setattr(self, "_Tabula__template_source", description.template_source)
        setattr(self, "_Tabula__template_filename", description.template_filename)
        setattr(self, "_Tabula__custom_arguments", custom_arguments)

    def __add__(self, other: Alchemic) -> Document:
        """
        Concatenate two Alchemic objects to generate an Opus.

        Args:
            other (AlchemicType): the second Alchemic object to be concatenated.

        Returns:
            Opus: Opus object resulting from the concatenation of two Alchemic objects.

        """
        from .opera import Opus

        if not isinstance(other, Alchemic):
            name = other.__class__.__name__
            raise TypeError(f"can concatenate only an Alchemic object not {name!r}")
        new_opus = Opus()
        setattr(new_opus, "_Opus__opus", (self, other))
        return new_opus

    def _repr_markdown_(self):
        """Render the markdown code in jupyter."""
        return self.to_markdown()

    def __str__(self) -> str:
        """Return a string with the provided data frame in latex format."""
        # get the custom arguments
        custom_arguments = getattr(self, "_Tabula__custom_arguments")

        name = self.name
        caption = getattr(self, "_Tabula__caption")
        data_frame = getattr(self, "_Tabula__data_frame")

        # check if the column names are imposed
        headers = getattr(self, "_Tabula__headers")
        if headers:
            n_columns: int = len(headers)
        else:
            columns = data_frame.columns
            n_columns = len(columns)
            headers = [str(name) for name in columns]

        hline_check = custom_arguments.get("hline", default=False)
        if isinstance(hline_check, bool):
            hline = r"\hline" * hline_check  # the horizontal line, no line by defualt
        else:
            raise ValueError("attribute 'hline' must be either None or a boolean")
        if "layout" in custom_arguments:
            layout = custom_arguments.pop("layout")
        else:
            layout = "| c " * n_columns + "|"
        # TODO: add complex table layout
        if any(headers):
            table = hline + EOL
            table += r" & ".join(headers) + r"\\" + hline + EOL
        else:
            # no header
            table = ""
        for index, row in data_frame.iterrows():
            values = [str(value) for value in row]
            table += r" & ".join(values) + r"\\" + hline + EOL

        # process additional custom arguments
        additional_arguments = custom_arguments.get_attributes()
        # get the template and render it
        template = getattr(self, "_Tabula__template")
        return template.render(
            name=name,
            layout=layout,
            table=table,
            caption=str(caption),
            **additional_arguments,
        )

    @property
    def description(self) -> str:
        """
        Description.

        Returns:
            str: Tabula latex description.

        """
        return str(self)

    @property
    def headers(self) -> Template:
        """Return the table headers."""
        return getattr(self, "_Tabula__headers")

    @property
    def template(self) -> Template:
        """Return the image jinja2 template."""
        # TODO: find a way to copy a jonja2 template
        return getattr(self, "_Tabula__template")

    @property
    def template_source(self) -> str:
        """
        Get the template a in text format.

        Returns:
           str: the jinja2 template text source.

        """
        return getattr(self, "_Tabula__template_source")

    @property
    def template_filename(self) -> str:
        """
        Get the template file name.

        Returns:
           str: the jinja2 template file name.

        """
        return getattr(self, "_Tabula__template_filename")

    @property
    def uuid(self) -> str:
        """Return the image uuid."""
        return str(getattr(self, "_Alchemic__uuid"))

    def set_variables(self, variables: Elements) -> None:
        """Just a dummy method for consistency."""
        # TODO: put in the meta class

    def set_headers(self, headers: list[str]) -> None:
        """
        Set the table headers.

        Args:
            headers (list[str]): name of the table columns.

        Returns:
            None.

        """
        if all(isinstance(header, str) for header in headers):
            setattr(self, "_Tabula__headers", list(headers))
        else:
            raise TypeError("argument 'headers' must be a list of string")

    def to_markdown(self) -> str:
        """Generate a markdown code out of the Formula object."""
        # TODO: provide templates for both latex and markdown
        headers = getattr(self, "_Tabula__headers")
        data_frame = getattr(self, "_Tabula__data_frame")
        if headers:
            n_columns = len(headers)
        else:
            columns = data_frame.columns
            n_columns = len(columns)
            headers = [str(name) for name in columns]
        # TODO: add other layout support
        if any(headers):
            table = r"| " + r" | ".join(headers) + r" |" + EOL
        else:
            # no headers
            no_headers = ["<!-- -->"] * n_columns
            table = r"| " + r" | ".join(no_headers) + r" |" + EOL
        table += r"| --- " * n_columns + r"|" + EOL
        for index, row in data_frame.iterrows():
            values = [str(value) for value in row]
            table += r"| " + r" | ".join(values) + r" |" + EOL
        table += EOL
        # add the capton if exists
        caption = getattr(self, "_Tabula__caption")
        caption_md = caption.to_markdown()
        if caption_md.strip():
            table += caption_md + EOL
        return table
