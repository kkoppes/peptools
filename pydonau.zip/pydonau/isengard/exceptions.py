# -*- coding: utf-8 -*-
"""
Created on Tue Sep  5 14:35:19 2023

@author: gi11883
"""


class AttributeNotUnique(Exception):
    """Raise an AttributeNotUnique error."""


class AttributeNotFound(Exception):
    """Raise an AttributeNotFound error."""


class UnsupportedType(Exception):
    """Raise an UnsupportedType error."""

    def __str__(self) -> str:
        """Return the error string."""
        return f" type {self.args[0]!r} not supported"

    def __repr__(self) -> str:
        """Return the error string."""
        return f" type {self.args[0]!r} not supported"


class WrongHDF5Format(Exception):
    """Exception for a wrong HDF5 format."""
