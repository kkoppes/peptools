#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 15:10:06 2023

@author: gi11883
"""
from typing import Union
from pathlib import Path
from pydantic import BaseModel, FilePath
from io import BufferedReader, TextIOWrapper

FileType = Union[FilePath, BufferedReader, TextIOWrapper]


class FileValidator(BaseModel):
    """Validate the attributes."""

    file: FileType

    class Config:
        """Pydantic validation Config."""

        arbitrary_types_allowed = True

    def get_file_content(self) -> Union[str, bytes]:
        """Return the file content as string or bytes."""
        if isinstance(self.file, Path):
            return self.file.read_bytes()
        return self.file.read()


class FilePathValidator(BaseModel):
    """Validate the attributes."""

    filepath: FilePath

    class Config:
        """Pydantic validation Config."""

        arbitrary_types_allowed = True

    def get_file_content(self) -> Union[str, bytes]:
        """Return the file content as string or bytes."""
        if isinstance(self.filepath, Path):
            return self.filepath.read_bytes()
        return self.filepath.read()
