#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  5 15:55:41 2023

@author: gi11883
"""
from __future__ import annotations
from typing import Any
from abc import ABCMeta, abstractmethod
from pydantic import PrivateAttr
from .data import Data

# TODO: reveise implementation


class Analysis(Data, metaclass=ABCMeta):
    """Class that contains analysis data."""

    @property
    def description(self) -> str:
        """Get the object description."""
        return getattr(self, "_Data__description")

    @property
    @abstractmethod
    def location(self) -> Any:
        """Get the model ID."""

    @property
    @abstractmethod
    def documentation(self) -> Any:
        """Get the model ID."""

    @property
    @abstractmethod
    def model(self, *args, **kwargs) -> Any:
        """Get model."""

    @property
    @abstractmethod
    def results(self, *args, **kwargs) -> Any:
        """Get results."""


class Model(Data, metaclass=ABCMeta):
    """Class that contains analysis model data."""

    @property
    def description(self) -> str:
        """Get the object description."""
        return self.descriptor.description

    @property
    @abstractmethod
    def location(self) -> Any:
        """Get the model location."""

    @property
    @abstractmethod
    def documentation(self) -> Any:
        """Get the model documentation."""

    def get(self, *args: Any, **kwargs: Any) -> Any:
        """."""
        return self.__get(*args, **kwargs)

    def set(self, *args: Any, **kwargs: Any) -> None:
        """."""
        self.__set(*args, **kwargs)

    @abstractmethod
    def __get(self, *args: Any, **kwargs: Any) -> Any:
        """."""

    @abstractmethod
    def __set(self, *args: Any, **kwargs: Any) -> None:
        """."""


class Results(Data, metaclass=ABCMeta):
    """Class that contains analysis results data."""

    @property
    def description(self) -> str:
        """Get the object description."""
        return getattr(self, "_Data__description")

    @property
    @abstractmethod
    def location(self) -> Any:
        """Get the results location."""

    @property
    @abstractmethod
    def documentation(self) -> Any:
        """Get the results documentation."""

    @property
    @abstractmethod
    def model(self) -> Any:
        """Get the model related to the results."""


class APO(Data):
    """Analysis Point class."""

    # TODO: to be implemented

    def get(self, *args, **kwargs) -> Any:
        """Getter."""

    def set(self, *args, **kwargs) -> Any:
        """Setter."""
