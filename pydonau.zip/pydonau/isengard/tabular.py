#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 22 15:27:18 2023

@author: gi11883
"""
import pyarrow as pa
from .data import Data


class Tabular(Data):
    """."""

    def get(self):
        """."""

    def set(self):
        """."""
