# -*- coding: utf-8 -*-
"""Graph class."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Union


import numpy as np
import pandas as pd

import plotly.io
from plotly.graph_objects import Figure
from scipy.interpolate import interp1d

from .utils import FileType, FileValidator
from .plugins import plot_factory, Plot
from .data import Attributes, Data, DataDescriptor, DataType, DataTypeDescriptor

# TODO: Change union with | with python > 3.10


# Error management
class PlotTypeNotUnique(Exception):
    """Raise a plot type is not unique error."""


class InterpolationError(Exception):
    """Raise a interpolation error."""


class GraphDataType(DataType):
    """Graph datatype."""

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type GraphDataType class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Graph class."""
        if not isinstance(value, GraphDataType):
            raise TypeError("GraphDataType required")
        return value

    @property
    def extension(self) -> str:
        """Get the __extension private attribute."""
        # TODO: To be implemented
        return ""

    @property
    def mime(self) -> str:
        """Get the __mime private attribute."""
        # TODO: To be implemented
        return ""

    @property
    def descriptor(self) -> DataTypeDescriptor:
        """Get the __descriptor private attribute."""
        # TODO: To be implemented
        return DataTypeDescriptor(
            name="", byte_header=b"", descriptor=DataDescriptor(description=""), uuid=""
        )

    def encode(self, data: Any) -> Any:
        """Encode the file type."""

    def decode(self) -> Any:
        """Encode the file type."""

    def get_data(self) -> Any:
        """Get the data."""

    def set_data(self) -> Any:
        """Set the data and check validity against the datatype."""


class Graph(Data):
    """
    Class to handle data in form of graphs.

    Examples:
        Graph().from_json("plotly.json")
    """

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Graph class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Graph class."""
        if not isinstance(value, Graph):
            raise TypeError("Graph required")
        return value

    @classmethod
    def from_json(cls, file: FileType) -> Graph:
        """
        Instantiate a new Graph class from a plotly json format.

        Args:
            file (str, Path, BufferReader): Path to the file or a BufferReader object.

        Returns:
            Graph: Graph object.
        """
        arguments = FileValidator(file=file)
        figure = plotly.io.from_json(value=arguments.get_file_content())
        # types of plots
        none_type = type(None)
        plots = {}
        for plot in figure.data:
            plot_type = type(plot)
            if plot_type not in plots:
                # instantiate a new Plot object from plugins
                plots[plot_type] = plot_factory.get(plot_type, plot_factory[none_type]).from_plot(plot)  # type: ignore
            else:
                # append the plot to an existing one
                plots[plot_type].append(plot)
        # check if the plot type is unique
        if len(plots) > 1:
            raise PlotTypeNotUnique(
                f"the plot type must be unique but {len(plots)} different types were found"
            )
        plugin_class_name = plots[plot_type].__class__.__name__
        # store the plotly figure in the Plot object
        setattr(plots[plot_type], "_" + plugin_class_name + "__figure", figure)
        # create the Data attributes
        attributes = Attributes.from_dict(
            main={"plot": plots[plot_type]}, meta={"file": file}
        )
        obj = super().__new__(
            cls,
            data_descriptor=DataDescriptor(
                description="Graph object", method="from_json", uuid=""
            ),
            data_attributes=attributes,
        )
        return obj  # type: ignore

    @classmethod
    def from_json_str(cls, figure_json: str) -> Graph:
        """
        Instantiate a new Graph class from a plotly json format.

        Args:
            file (str, Path, BufferReader): Path to the file or a BufferReader object.

        Returns:
            Graph: Graph object.
        """
        figure: Figure = plotly.io.from_json(figure_json)

        # types of plots
        none_type = type(None)
        plots = {}
        for plot in figure.data:
            plot_type = type(plot)
            if plot_type not in plots:
                # instantiate a new Plot object from plugins
                plots[plot_type] = plot_factory.get(plot_type, plot_factory[none_type]).from_plot(plot)  # type: ignore
            else:
                # append the plot to an existing one
                plots[plot_type].append(plot)
        # check if the plot type is unique
        if len(plots) > 1:
            raise PlotTypeNotUnique(
                f"the plot type must be unique but {len(plots)} different types were found"
            )
        plugin_class_name = plots[plot_type].__class__.__name__
        # store the plotly figure in the Plot object
        setattr(plots[plot_type], "_" + plugin_class_name + "__figure", figure)
        # create the Data attributes
        attributes = Attributes.from_dict(
            main={"plot": plots[plot_type]}, meta={"figure_json": figure_json}
        )
        obj = super().__new__(
            cls,
            data_descriptor=DataDescriptor(
                description="Graph object", method="from_json_str", uuid=""
            ),
            data_attributes=attributes,
        )
        return obj  # type: ignore

    @classmethod
    def from_dataframe(
        cls, data_frame: pd.DataFrame, plot_type: type, **kwargs
    ) -> Graph:
        """
        Instantiate a Graph object from a pandas DataFrame object.

        Args:
            data_frame (pd.DataFrame): pandas data frame containing the data to plot.
            plot_type (type): pylantir.pydonau.isengard Plot object type.
            x_name (Any, optional): name of the data frame columns containing the x axis data

        Raises:
            TypeError: the provided argument are not of the right type.
            ValueError: the value of the provided argument is outside the boundaries of validity.

        Returns:
            Graph: Graph object.

        """
        if not isinstance(data_frame, pd.DataFrame):
            raise TypeError(f"argument 'plot' must be a {type(pd.DataFrame)}")

        if not isinstance(plot_type, type):
            raise TypeError("argument 'plot_type' must be a type object")

        plot = plot_factory.get(plot_type, plot_factory[type(None)]).from_dataframe(
            data_frame=data_frame, **kwargs
        )
        # create the Data attributes
        # attributes = Attributes()
        # attributes.set_main(plot=plot)
        # attributes.set_meta(data_frame=data_frame)
        # obj = super().__new__(
        #     descriptor=DataDescriptor(description="Graph object"), method="from_dataframe", attributes=attributes
        # )
        attributes = Attributes.from_dict(
            main={"plot": plot}, meta={"data_frame": data_frame}
        )
        obj = super().__new__(
            cls,
            data_descriptor=DataDescriptor(
                description="Graph object", method="from_dataframe", uuid=""
            ),
            data_attributes=attributes,
        )
        return obj  # type: ignore

    @property
    def figure(self) -> Figure:
        """Return the plotly Figure object contained into the Plot object."""
        return self.get().figure

    @property
    def n_dim(self) -> int:
        """Return the number of dimensions."""
        plot = self.get()
        return plot.n_dim

    def add_annotations(self, x: float, y: float, text: str, **kwargs: Any) -> None:
        """
        Add an annotation on the Graph.

        Args:
            x (float): x value.
            y (float): y value.
            text (str): text of the annotation.
            **kwargs (Any): additional arguments (see plotly annotations).

        Returns:
            None: DESCRIPTION.

        """
        figure = self.figure
        if "showarrow" not in kwargs:
            kwargs["showarrow"] = True
        if "arrowhead" not in kwargs:
            kwargs["arrowhead"] = 1
        figure.add_annotation(x=x, y=y, text=text, **kwargs)

    def get(self) -> Plot:
        """
        Return the Plot object contained into the Graph.

        Returns:
            Plot: A Plot object containing the graph data.
        """
        return self["plot"]

    def set(self, *args, **kwargs: Any) -> None:
        """
        Store the Plot object into the Graph Data object.

        Args:
            plot (Plot): Plot object containing plot data.

        Returns:
            None.

        """
        if args:
            plot = args[0]
        elif "plot" in kwargs:
            plot = kwargs["plot"]
        else:
            raise TypeError("Graph.set() requires the keyword 'plot'")
        if isinstance(plot, Plot):
            attributes = getattr(self, "_Data__attributes")
            attributes["plot"].value = plot
        else:
            raise TypeError("argument 'plot' must be a Plot object")

    def render(self, renderer: str = "browser", **kwargs: Any) -> None:
        """
        Render the graph.

        Available renderers:
            ['plotly_mimetype', 'jupyterlab', 'nteract', 'vscode',
             'notebook', 'notebook_connected', 'kaggle', 'azure', 'colab',
             'cocalc', 'databricks', 'json', 'png', 'jpeg', 'jpg', 'svg',
             'pdf', 'browser', 'firefox', 'chrome', 'chromium', 'iframe',
             'iframe_connected', 'sphinx_gallery', 'sphinx_gallery_png']

        Args:
            renderer (str): Plotly render format. By default is "browser".
            kwargs (Any): Plotly arguments for the Figure.show() method
        Returns:
            None.

        """
        self.figure.show(renderer=renderer, **kwargs)

    def interpolate(
        self,
        x: float,
        name: Union[float, str, None] = None,
        parameter: Union[float, None] = None,
        kind: str = "linear",
    ) -> Union[float, np.ndarray[float]]:
        """
        Interpolate the plot data first along x and then, if a third parameter is available, interpolate on y.

        Args:
            x (float): abscissa query point.
            name (float, str or None, optional): name of the curve where extract the value at the provided x.
            Defaults to None.
            parameter (float, optional): third parameter for three-variables 2D plot. Defaults to None.
            kind (str, optional): type of interpolation. Defaults to "linear".

        Note:
            If the 2D plot has a third parameter and the argument 'parameter' is not specified, the interpolation method
            returns an array of values for each curve related to a parameter. Otherwise, the method returns a float.
            The available interpolation kinds are:
                'linear' (for both x and y)
                'slinear' (spline of 1st order for both x and y)
                'cubic' (spline of 3rd order for both x and y)
                'linear-slinear' (linear for x and slinear for y)
                'linear-cubic' (linear for x and cubic for y)
                'slinear-linear' (slinear for x and linear for y)
                'cubic-linear' (cubic for x and linear for y)

        Raises:
            InterpolationError: is raised when the parameter is categorical and the interpolation cannot be performed.
            ValueError: is raised when the argument do not match the required types

        Returns:
            float, np.ndarray[float]: the interpolated value (float) or values (np.ndarray[float], see the note).

        """
        x = float(x)
        kind = str(kind)
        plot = self.get()
        # TODO: this method requires a ScatterPlot, that should be available into a list of plugins
        # define a "list" of available plots plugins and then add a check for ScatterPlot
        # then create plot as: plot: ScatterPlot = self.get() for mypy
        # plot = getattr(self, "_Data__struct")
        if name and parameter:
            raise InterpolationError(
                "arguments 'name' and 'parameter' are mutually exclusive"
            )
        if parameter and not plot.is_quantitative():
            raise InterpolationError(
                "interpolation variables must be all quantitative to be interpolable"
            )
        # TODO change the following if statement to match-case
        if kind == "linear":
            int_x = "linear"
            int_y = "linear"
        elif kind == "slinear":
            int_x = "slinear"
            int_y = "slinear"
        elif kind == "cubic":
            int_x = "cubic"
            int_y = "cubic"
        elif kind == "linear-cubic":
            int_x = "linear"
            int_y = "cubic"
        elif kind == "cubic-linear":
            int_x = "cubic"
            int_y = "linear"
        elif kind == "slinear-linear":
            int_x = "slinear"
            int_y = "linear"
        elif kind == "linear-slinear":
            int_x = "linear"
            int_y = "slinear"
        else:
            raise ValueError(
                "argument 'kind' must be: 'linear', 'slinear', 'cubic', 'linear-cubic', 'linear-slinear', "
                + "'cubic-linear' or 'slinear-linear'"
            )
        n_dim = self.n_dim
        if self.n_dim == 1:
            # if the plot is a single x-y curve
            fun = interp1d(plot.x[0], plot.y[0], kind=int_x)
            interpolation: Union[float, np.ndarray[float]] = float(fun(x))
        elif name:
            # if the argument name is specified
            try:
                idx = plot.y_names.index(name)
            except ValueError as exc:
                raise ValueError(f"{name!r} is not a valid curve name") from exc
            fun = interp1d(plot.x[idx], plot.y[idx], kind=int_x)
            interpolation = float(fun(x))
        else:
            y_names = np.array(plot.y_names)
            y_values = np.zeros(self.n_dim)
            for idx, x_graph, y_graph in zip(range(n_dim), plot.x, plot.y):
                # evaluate each value of y when the abscissa is equal to the provided x value
                fun = interp1d(x_graph, y_graph, kind=int_x)
                y_values[idx] = fun(x)
            if parameter:
                # if the argument parameter is specified
                # evaluate the interpolated value when the ordinate is equal to the provided var value
                fun = interp1d(y_names, y_values, kind=int_y)
                interpolation = float(fun(parameter))
            else:
                # otherwise return all the curve values for the specified x
                interpolation = y_values
        return interpolation

    def save(self, filename: Union[str, Path], **kwargs) -> None:
        """
        Save the graph to a file.

        Args:
            filename (str): string containing the path to file to save.
            format (str, optional): format of the file to save. Defaults to "svg".


        Note:
            Supported formats are:

        Returns:
            None: DESCRIPTION.

        """
        if isinstance(filename, str):
            file_path = Path(filename)
        elif isinstance(filename, Path):
            file_path = filename
        else:
            raise TypeError(
                "argumnet 'filename' must be a either a str ar a Path object"
            )
        fig = self.figure
        plotly.io.full_figure_for_development(
            fig, warn=False
        )  # prevent warnings to be rendered in the figure
        if "format" in kwargs:
            format_ = str(kwargs["format"]).lower()
        else:
            # get the format from the file extension
            format_ = file_path.suffix.strip(".")
            kwargs["format"] = format_
        # TODO: change to match case statement
        file_format = "w"  # text format by default
        if format_ == "json":
            # format is not a valid argument for plotly.io.to_json
            kwargs.pop("format")
            file_content = plotly.io.to_json(fig, **kwargs)
        elif format_ == "html":
            # format is not a valid argument for plotly.io.to_html
            kwargs.pop("format")
            file_content = plotly.io.to_html(fig, **kwargs)
        else:
            file_format = "wb"  # byte format
            file_content = plotly.io.to_image(fig, **kwargs)
        # TODO: introduce other exceptions
        try:
            with open(filename, file_format) as file:
                file.write(file_content)
        except PermissionError as exc:
            raise PermissionError("lack of permission to write the file") from exc
        except OSError as exc:
            raise OSError("the file cannot be saved") from exc
