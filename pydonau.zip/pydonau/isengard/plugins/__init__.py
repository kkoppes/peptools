#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 24 09:01:00 2023

@author: gi11883
"""

from pathlib import Path

from .file import File
from .plot import Plot
from .factory import Factory

parent = Path(__file__).parent

files_config_file = parent / Path("files/files.cfg")
plots_config_file = parent / Path("graphs/graphs.cfg")

file_factory = Factory.read_config(files_config_file)
plot_factory = Factory.read_config(plots_config_file)
