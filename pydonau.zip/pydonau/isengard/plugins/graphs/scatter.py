#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 23 16:51:33 2023

@author: gi11883
"""
from __future__ import annotations
from typing import Any, Union
from copy import deepcopy

import pandas as pd

# import pydantic_numpy.dtype as pnd
# from pydantic_numpy import NDArray
import numpy as np
from pydantic import PrivateAttr

import plotly.express as px
from plotly.graph_objects import Figure, Scatter

from ..plot import Plot, Variable

# TODO: Change union with | with python > 3.10

ScatterPlotType = type(Scatter())


def _y_var_type(y_var_name: Union[str, float]) -> tuple[Variable, Union[float, str]]:
    """
    Determine the type of the y variable.

    Args:
        group (Union[str, float]): plotly group.

    Returns:
        Variable: Type of the variable, either CATEGORICAL or QUANTITATIVE.

    """
    try:
        value: Union[float, str] = float(y_var_name)
        var_type = Variable.QUANTITATIVE
    except ValueError:
        value = str(y_var_name)
        var_type = Variable.CATEGORICAL
    return var_type, value


class ScatterPlot(Plot):
    """
    Wrapper class for plotly Scatter plots.

    Arguments:
        x (tuple[float]): Values on the x axis
        y (list[tuple[float]]): Values on the y axis. Could be more the one.
        y_variables (list[str | float]): Type of variable (categorical or quantitative)

    Examples:
        Graph().from_json("plotly.json")
    """

    # x: list[Union[tuple[float, ...], NDArray[float, pnd.float64]]] = []
    # y: list[Union[tuple[float, ...], NDArray[float, pnd.float64]]] = []
    x: list[Union[tuple[float, ...], np.ndarray[float]]] = []
    y: list[Union[tuple[float, ...], np.ndarray[float]]] = []
    y_names: list[Union[float, str]] = []
    y_variables: list[Variable] = []
    __figure: Figure = PrivateAttr()

    class Config:
        """Vlaidate numpy arrays."""

        arbitrary_types_allowed = True

    @classmethod
    def from_plot(cls, plot: ScatterPlot) -> ScatterPlot:
        """
        Instantiate a ScatterPlot class from a plotly Scatter() object.

        Args:
            plot (plotly.Scatter): plotly Scatter() plot

        Returns;
            ScatterPlot object
        """
        if not isinstance(plot, ScatterPlotType):
            raise TypeError(f"argument 'plot' must be a {ScatterPlotType!r}")
        x_label = plot["xaxis"]
        x_axis = plot[x_label]

        y_label = plot["yaxis"]
        y_axis = plot[y_label]
        y_variables, y_names = _y_var_type(y_var_name=plot["name"])
        return ScatterPlot(x=[x_axis], y=[y_axis], y_names=[y_names], y_variables=[y_variables])

    @classmethod
    def from_figure(cls, figure: Figure) -> ScatterPlot:
        """
        Instantiate a ScatterPlot class from a plotly Scatter() object.

        Args:
            plot (plotly.Scatter): plotly Scatter() plot

        Returns;
            ScatterPlot object
        """
        if not isinstance(figure, Figure):
            raise TypeError(f"argument 'figure' must be a {type(Figure)!r}")

        obj = None
        # for each plot in figure
        for index, plot in enumerate(figure.data):
            # check if the plot type is a plotly Scatter()
            if not isinstance(plot, Scatter):
                raise ValueError(f"plot number {index+1} is not a {ScatterPlotType!r}")
            # if the ScatterPlot object is already instantiated
            if obj:
                # append the plot
                obj.append(plot)
            else:
                # instantiate the ScatterPlot object
                obj = ScatterPlot().from_plot(plot)
        # store also the plotly Figure
        setattr(obj, "_ScatterPlot__figure", figure)
        return obj  # type: ignore

    @classmethod
    def from_dataframe(
        cls,
        data_frame: pd.DataFrame,
        x_name: Any,
    ) -> ScatterPlot:
        """
        Instantiate a ScatterPlot class from a pandas DataFrame() object.

        Args:
            data_frame (pandas.DataFrame): pandas data frame containing the plot data
            x_name (Any): the name of the data frame column containing the x axis values
            parameter_name (str): the name of the group of y values

        Returns;
            ScatterPlot: ScatterPlot object
        """
        if not isinstance(data_frame, pd.DataFrame):
            raise TypeError(f"argument 'data_frame' must be a {type(pd.DataFrame)!r}")

        # get the column names associated to the y axes
        y_names = list(data_frame.columns)
        try:
            # remove the x axis name
            y_names.remove(x_name)
        except ValueError as exc:
            raise ValueError(f"x_name = {x_name} is not a valid column name of data_frame") from exc

        figure = px.scatter(data_frame=data_frame, x=x_name, y=y_names)
        return ScatterPlot().from_figure(figure=figure)

    def __str__(self):
        """Return a descriptive string of the plugin."""
        return "Plotly 2D scatter plot"

    @property
    def figure(self) -> Figure:
        """Return the plotly Figure object."""
        # TODO: this property method should be able eventually to build a plotly Figure object from the class attributes
        return getattr(self, "_ScatterPlot__figure")

    @property
    def n_dim(self) -> int:
        """
        Number of plot dimensions.

        Returns:
            int: number of dimensions (i.e. plots).

        """
        return len(self.y_variables)

    @property  # type: ignore
    @staticmethod
    def plotly_type():
        """Return the associated plotly plot type."""
        return ScatterPlotType

    def append(self, plot: ScatterPlot) -> None:
        """
        Append a plot into the ScatterPlot.

        Args:
            plot (plotly Scatter()): Plotly Scatter() object to add to the ScatterPlot object.

        Returns:
            None.

        """
        if not isinstance(plot, Scatter):
            raise TypeError("argument 'plot' must be a {ScatterPlotType!r}")
        x_label = plot["xaxis"]
        y_label = plot["yaxis"]
        y_var_name = plot["name"]
        self.x.append(plot[x_label])
        self.y.append(plot[y_label])
        y_variable, y_name = _y_var_type(y_var_name=y_var_name)
        self.y_names.append(y_name)
        self.y_variables.append(y_variable)

    def copy(self, **kwargs) -> ScatterPlot:
        """
        Duplicate the ScatterPlot object.

        Returns:
            ScatterPlot: A copy of the object.
        """
        obj = ScatterPlot(x=self.x, y=self.y, y_variables=self.y_variables)
        setattr(obj, "_ScatterPlot__figure", deepcopy(self.figure))
        return obj

    def is_quantitative(self) -> bool:
        """Return True if the plotted variables are quantitative, False if categorical."""
        return all(y_variable == Variable.QUANTITATIVE for y_variable in self.y_variables)
