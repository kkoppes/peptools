#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 23 16:51:41 2023

@author: gi11883
"""
from __future__ import annotations
from typing import Any


from plotly.graph_objects import Figure
from pandas import DataFrame

from ..plot import Plot

NonePlotType = type(None)


class NonePlot(Plot):
    """An unsupported plotly plot format."""

    @classmethod
    def from_data_frame(cls, data_frame: DataFrame, x_name: str) -> NonePlot:
        """
        Instantiate a NonePlot class from a pandas DataFrame() object.

        Args:
            data_frame (pandas DataFrame): a pandas DataFrame object

        Returns;
            NonePlot object
        """
        return NonePlot()

    @classmethod
    def from_plot(cls, plot: Any) -> NonePlot:
        """
        Instantiate a NonePlot class from a plotly Scatter() object.

        Args:
            plot (Any): a plotly .graph_objs

        Returns;
            NonePlot object
        """
        return NonePlot()

    @classmethod
    def from_figure(cls, figure: Figure) -> NonePlot:
        """
        Instantiate a NonePlot class from a plotly Figure() object.

        Args:
            figure (plotly Figure): a plotly Figure object

        Returns;
            NonePlot object
        """
        return NonePlot()

    def __str__(self):
        """Return a descriptive string of the plugin."""
        return "Unsupported plotly plot"

    @property
    def n_dim(self) -> int:
        """
        Number of plot dimensions.

        Returns:
            int: number of dimensions (i.e. plots).

        """
        return 0

    @property
    @staticmethod
    def plotly_type():
        """Return the associated plotly plot type."""
        return NonePlotType

    def copy(self):
        """
        Duplicate the NonePlot object.

        Returns:
            NonePlot: A copy of the object.
        """
        return NonePlot()

    def append(self, plot: Any) -> None:
        """Append another plot."""

    def is_quantitative(self) -> bool:
        """Return True if the plotted variables are quantitative, False if categorical."""
        return False
