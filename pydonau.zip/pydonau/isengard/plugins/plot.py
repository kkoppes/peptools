#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun  5 19:14:35 2023

@author: gi11883
"""
from __future__ import annotations

from enum import Enum
from typing import Any
from abc import ABCMeta, abstractmethod, abstractstaticmethod

from pydantic import BaseModel

from pandas import DataFrame
from plotly.graph_objects import Figure


class Variable(Enum):
    """Enumerator for the plot variable types."""

    CATEGORICAL = 0
    QUANTITATIVE = 1


class Plot(BaseModel, metaclass=ABCMeta):
    """Plot plugin meta class."""

    @classmethod
    @abstractmethod
    def from_dataframe(cls, data_frame: DataFrame, x_name: str) -> Plot:
        """Initialize the Plot class."""

    @classmethod
    @abstractmethod
    def from_figure(cls, figure: Figure) -> Plot:
        """Initialize the Plot class from a plotly Figure object."""

    @classmethod
    @abstractmethod
    def from_plot(cls, plot: Any) -> Plot:
        """Initialize the Plot class."""

    @property
    @abstractmethod
    def figure(self) -> Figure:
        """Return the plotly Figure object."""

    @property
    @abstractmethod
    def n_dim(self):
        """Return the number of the dimensions."""

    @property
    @abstractstaticmethod
    def plotly_type(self):
        """Return the associated plotly plot type."""

    @abstractmethod
    def append(self, plot: Any) -> None:
        """Append another plot."""

    @abstractmethod
    def copy(self, *args, **kwargs) -> Plot:
        """Duplicate the Plot class."""

    @abstractmethod
    def is_quantitative(self) -> bool:
        """Return True if the plotted variables are quantitative, False if categorical."""
