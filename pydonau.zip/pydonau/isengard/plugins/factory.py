#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 24 09:01:07 2023

@author: gi11883
"""
from __future__ import annotations
import json
import importlib

from pathlib import Path
from typing import Any, Union

from pydantic import BaseModel

# TODO: Change union with | with python > 3.10


class Factory(BaseModel):
    """
    Factory for the plugins.

    Examples:
        Factory().read_config("graphs/graphs.cfg")
    """

    plugins: dict[type, object] = {}
    plugin_types: dict[str, type] = {}

    @classmethod
    def read_config(cls, filename: Union[str, Path], encoding: str = "utf-8") -> Factory:
        """
        Read plugins config files.

        Args:
            filename (str, Path): Path to the plugins configuration file.

        Returns:
            A factory class with the correspondent plugin loaded.

        Examples:
            Factory().read_config(filename="graphs/graphs.cfg")
        """
        if isinstance(filename, str):
            file_path = Path(filename)
        elif not isinstance(filename, Path):
            raise ValueError("attribute 'filename' must be either a string or a pathlib.Path object")
        else:
            file_path = filename
        if not file_path.exists():
            raise IOError(f"filename {str(file_path)!r} does not exists")
        try:
            with open(file_path, "r", encoding=encoding) as file:
                config = json.load(file)
        except IOError as exc:
            raise IOError(f"file {str(file_path)!r} cannot be opened") from exc
        # TODO: could also raise a json.JSONDecodeError
        # TODO: validate json schema for configuration files or use yaml
        obj = Factory()
        # get the configuration file directory
        module_path = __name__.split(".", 1)[0]
        # check if the module path is not contained in the file path
        file_path_parts = file_path.parts
        if module_path not in file_path_parts:
            # the plugin must be stored inside the pylantir module directory tree
            raise ImportError(f"the plugin path {str(file_path)!r} lies outside the {module_path!r} module!")
        # get the pylantir main module index
        module_index = file_path_parts.index(module_path)
        # build an import_path string from the main pylantir module to the plugin directory location
        import_path = ".".join(file_path_parts[module_index:-1])
        # for each entry in the config file
        for key, value in config.items():
            # get the python source, the name of the plugin class and the class type
            plugin_file, class_name, class_type = value.split(":")
            # add the name of the import file (without .py extension)
            import_name = import_path + "." + Path(plugin_file).stem
            # import the plug in type from the source
            plugin_type = getattr(importlib.import_module(str(import_name)), class_type)
            # import the plug in class from the source
            plugin = getattr(importlib.import_module(str(import_name)), class_name)
            # store the plugin into the Factory object
            obj.plugins[plugin_type] = plugin
            obj.plugin_types[key] = plugin_type
        return obj

    def __getitem__(self, key: Union[str, type]) -> Any:
        """
        Get a plugin by name or by type.

        Args:
            key (str, type): either a plugin name, as a string, or a type

        Returns:
            Any: A plugin object.
        """
        return self.get(key)

    def get(self, key: Union[str, type], *args) -> Any:
        """
        Get a plugin by type.

        Args:
            key (type): The plotly plot data type.
            default (Any): If the key is not valid return default.

        Returns:
            Any: Plugin object.

        """
        if isinstance(key, str):
            plugin_type = self.plugin_types[key]
        elif isinstance(key, type):
            plugin_type = key
        else:
            raise ValueError(f"key {key!r} is must be either a plugin name (str) or type")
        try:
            value = self.plugins[plugin_type]
        except KeyError as exc:
            if args:
                value = args[0]
            else:
                raise KeyError(f"{plugin_type}") from exc
        return value

    def get_plugin_names(self) -> list[str]:
        """Return a list of string containing the plugin names."""
        return list(self.plugin_types.keys())

    def get_plugin_types(self) -> list[type]:
        """Return a list of string containing the plugin types."""
        return list(self.plugin_types.values())
