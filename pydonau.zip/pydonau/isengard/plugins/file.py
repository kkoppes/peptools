#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep  4 16:29:42 2023

@author: gi11883
"""

from __future__ import annotations
from abc import ABCMeta, abstractmethod
from pydantic import FilePath
from ..data import Data

# TODO: define alla the operations (methods) allowed on a file object


class File(Data, metaclass=ABCMeta):
    """File plugin meta class."""

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type File class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type File class."""
        if not isinstance(value, File):
            raise TypeError("File required")
        return value

    @property
    def filename(self) -> FilePath:
        """Return the file name."""
        return self["filename"]

    @abstractmethod
    def get(self) -> FilePath:
        """Getter."""

    @abstractmethod
    def set(self, filename: FilePath):
        """Setter."""
