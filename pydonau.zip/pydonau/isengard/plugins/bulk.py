from __future__ import annotations
from abc import ABCMeta, abstractmethod
from pydantic import BaseModel, FilePath
from typing import List
from ..data import Data, MainAttribute
from ...alchemy import Ingredients


class Bulk(Data, metaclass=ABCMeta):
    """File plugin meta class."""

    @classmethod
    def Validator(cls, card: List) -> BaseModel:
        """Validate attributes."""

        class Validator(BaseModel):
            """Pydantic validator."""

            card: List

        # return the Validator if theargument 'card' is a List, otherwise rise a ValidationError
        return Validator(card=List)

    def __new__(cls, card: List) -> Bulk:
        """Create a new File object."""
        arguments = cls.Validator(card=List)
        description = "Bulk object"
        main = Ingredients(card=MainAttribute(name="card", value=arguments.card))  # type: ignore
        obj = super().__new__(cls, description=description, main=main)
        return obj  # type: ignore

    @property
    def card(self) -> List:
        """Return the file name."""
        return self["card"]

    @abstractmethod
    def get(self) -> List:
        """Getter."""

    @abstractmethod
    def set(self, card: List):
        """Setter."""
