from __future__ import annotations

import json
from typing import Any
from pathlib import Path
import pandas as pd

# from tables import open_file
from pydantic import FilePath, PrivateAttr, StrictStr, validate_arguments
from ..file import File

# from warnings import WarningMessage

from makerspace_mbe_pylantir.scrolls import get_logger  # type:ignore
import logging

logger: logging.Logger = get_logger(__name__, level=logging.DEBUG)  # type: ignore

DATA_FOLDER_BDS_SHEAR_PLATE_STRENGTH: Path = Path(__file__).parents[5] / Path(
    "pyelbe/ithil/data/shear_plate_strength"
)
CONFIG_FILE_BDS_SHEAR_PLATE_STRENGTH: str = "bds_shear_plate_input_config.json"


class BDS_ShearPlate_input_reader(File):
    """
    Class to read analysis input files.

    Args:
        filename  (FilePath):   path to the input file
        uuid      (str):        unique identifier (UUID)

    Returns:
        None.
    """

    __analysis_setup_data: dict[str, str] = PrivateAttr()

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type AnalysisSetup class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value) -> "BDS_ShearPlate_input_reader":
        """Validate the type AnalysisConfigProcessor class."""
        if not isinstance(value, BDS_ShearPlate_input_reader):
            raise TypeError("AnalysisConfigProcessor required")
        return value

    @validate_arguments(config={"arbitrary_types_allowed": True})
    def __init__(self, filename: FilePath, uuid: StrictStr = "") -> None:
        """Create a new File object."""
        # arguments = FilePathValidator(filepath=filename)
        attributes = getattr(self, "_Data__attributes")
        attributes.set_main(filename=Path(filename))
        # set data descriptor
        descriptor = getattr(self, "_Data__descriptor")
        descriptor.description = "BDS Shear Plate analysis input reader object"
        # TODO: put the open_file into a try except statement to catch hdf5 errors
        # table = open_file(filename, "r")
        # setattr(self, "_AnalysisConfigProcessor__analysis_setup_data", table)

    @property
    def data_lines(self):
        """Returns the contents of the input file in list format."""
        attributes = getattr(self, "_Data__attributes")
        return attributes.get_hidden("data_lines").value

    @property
    def data_rows(self):
        """Returns the contents of the input file in list format."""
        attributes = getattr(self, "_Data__attributes")
        return attributes.get_hidden("data_rows").value

    @property
    def data_dict(self):
        """Returns the contents of the input file in dictionary format."""
        attributes = getattr(self, "_Data__attributes")
        return attributes.get_hidden("data_dict").value

    def parse_data(
        self,
        input_type: str,
        config_filepath: Path,
        delimiter: str = ",",
    ) -> None:
        """
        Class to parse analysis setup files and set up analysis input.

        Args:
            input_type (str):  type of analysis input file
                                e.g. plate_geometry, materials, joint_detail, etc.
            delimiter   (str):    delimiter to be used to split data in input file,
                                    e.g. ';', ',', '|', etc.
            config_filepath (Optional[str]): path to the input file configuration
                                  template. If not provided then default is used.

        Returns:
            None.
        """

        attributes = getattr(self, "_Data__attributes")
        attributes.set_hidden(delimiter=delimiter)
        attributes.set_hidden(input_type=input_type)  # e.g. "pax_door_corner"
        attributes.set_hidden(data_lines=[])
        attributes.set_hidden(data_rows=[])
        attributes.set_hidden(data_dict={})
        if config_filepath:
            attributes.set_hidden(configuration_filepath=Path(config_filepath))
        else:
            attributes.set_hidden(
                configuration_filepath=DATA_FOLDER_BDS_SHEAR_PLATE_STRENGTH
                / Path(CONFIG_FILE_BDS_SHEAR_PLATE_STRENGTH),
            )

        self._read_file(input_type)

    def _read_plate_details(self) -> None:
        pass

    def _read_hole_details(self) -> None:
        pass

    def _read_materials(self) -> None:
        pass

    def _read_joint_details(self) -> None:
        pass

    def _read_file(self, input_type: str) -> None:
        """Reads the contents of the input file."""
        attributes = getattr(self, "_Data__attributes")
        filename = attributes.get_main("filename").value
        delimiter = attributes.get_hidden("delimiter").value
        data_dict: dict[str, Any] = {}

        df: pd.DataFrame = pd.read_csv(
            filename,
            sep=delimiter,
        )

        headers: list[str] = df.columns.tolist()
        self._check_headers(headers, input_type)
        if input_type == "materials":
            data_dict = df.set_index("Material specification").T.to_dict()
        elif input_type == "joint_details":
            data_dict = df.set_index("Joint ID").T.to_dict()
        elif input_type == "fastener_systems":
            data_dict = df.set_index("Fastener system ID").T.to_dict()
        else:
            data_dict = df.set_index("Part name").T.to_dict()

        attributes.set_hidden(data_dict=data_dict)

    def _check_headers(self, headers: list[str], input_type: str) -> None:
        """Checks that the input file headers are according to the config template."""

        attributes = getattr(self, "_Data__attributes")

        configuration_filepath = attributes.get_hidden("configuration_filepath").value

        with open(configuration_filepath) as file:
            try:
                json_config = json.load(file)

                expected_headers = json_config[input_type]

                for header in headers:
                    if header not in expected_headers:
                        e_msg: str = str(
                            f"Unknown header: '{header}'\n"
                            + f"{input_type} input file requires the following headers:\n"
                            + f"{expected_headers}"
                        )
                        raise Warning(e_msg)

            except json.JSONDecodeError:
                assert False, "File is not a valid JSON file"

    @property
    def export_to_dict(self) -> dict[str, Any]:
        """Return the input file contents in dictionary format."""
        return getattr(self, "_Data__attributes").get_hidden("data_dict").value

    @property
    def export_to_json(self) -> None:
        """Exports the contents of the input file to a json file."""
        json_filepath: Path = (
            getattr(self, "_Data__attributes")
            .get_hidden("input_filename")
            .value.with_suffix("." + "json")
        )
        with open(json_filepath, "w") as file:
            json.dump(
                getattr(self, "_Data__attributes").get_hidden("data_dict").value,
                file,
                indent=4,
            )

    def get(self):
        """Getter."""
        # TODO: implementation

    def set(self, filename: FilePath, **kwargs):
        """Setter."""
        # TODO: implementation
