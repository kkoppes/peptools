from __future__ import annotations

import csv
import json
import re
from typing import Any
from pathlib import Path
import pandas as pd

# from tables import open_file
from pydantic import FilePath, PrivateAttr, StrictStr, validate_arguments
from ..file import File

from makerspace_mbe_pylantir.scrolls import get_logger  # type:ignore
import logging

logger: logging.Logger = get_logger(__name__, level=logging.DEBUG)  # type: ignore

DATA_FOLDER_CORNER_MAT_STRENGTH: Path = Path(__file__).parents[5] / Path(
    "pyelbe/ithil/data/material_strength"
)
DATA_FOLDER_BDS_SHEAR_PLATE_STRENGTH: Path = Path(__file__).parents[5] / Path(
    "pyelbe/ithil/data/shear_plate_strength"
)
CONFIG_FILE_CORNER_MAT_STRENGTH: str = "pax_door_corner_input_config.json"
CONFIG_FILE_BDS_SHEAR_PLATE_STRENGTH: str = "bds_shear_plate_input_config.json"


class AnalysisConfigProcessor(File):
    """
    Class to read analysis setup files and set up analysis input.

    Args:
        input_type  (str):   name of the analysis the input file is for (tbc),
                                e.g. pax_door_corner, etc.
        uuid    (str):       unique identifier (UUID)

    Returns:
        None.
    """

    __analysis_setup_data: dict[str, str] = PrivateAttr()

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type AnalysisSetup class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type AnalysisConfigProcessor class."""
        if not isinstance(value, AnalysisConfigProcessor):
            raise TypeError("AnalysisConfigProcessor required")
        return value

    @validate_arguments(config={"arbitrary_types_allowed": True})
    def __init__(self, filename: FilePath, uuid: StrictStr = "") -> None:
        """Create a new File object."""
        # arguments = FilePathValidator(filepath=filename)
        attributes = getattr(self, "_Data__attributes")
        attributes.set_main(filename=Path(filename))
        # set data descriptor
        descriptor = getattr(self, "_Data__descriptor")
        descriptor.description = "Analysis setup File object"
        # TODO: put the open_file into a try except statement to catch hdf5 errors
        # table = open_file(filename, "r")
        # setattr(self, "_AnalysisConfigProcessor__analysis_setup_data", table)

    @property
    def number_of_parts(self) -> int:
        """Returns the number of parts or components identified in the input file."""
        attributes = getattr(self, "_Data__attributes")
        return attributes.get_hidden("number_of_parts").value

    @property
    def data_lines(self):
        """Returns the contents of the input file in list format."""
        attributes = getattr(self, "_Data__attributes")
        return attributes.get_hidden("data_lines").value

    @property
    def data_rows(self):
        """Returns the contents of the input file in list format."""
        attributes = getattr(self, "_Data__attributes")
        return attributes.get_hidden("data_rows").value

    @property
    def data_dict(self):
        """Returns the contents of the input file in dictionary format."""
        attributes = getattr(self, "_Data__attributes")
        return attributes.get_hidden("data_dict").value

    def parse_data(
        self,
        analysis_type: str,
        config_filepath: Path,
        delimiter: str = ",",
    ) -> None:
        """
        Class to parse analysis setup files and set up analysis input.

        Args:
            analysis_type (str):  name of the analysis the input file is for (tbc),
                                    e.g. pax_door_corner, etc.
            delimiter   (str):    delimiter to be used to split data in input file,
                                    e.g. ';', ',', '|', etc.
            config_filepath (Optional[str]): path to the input file configuration
                                  template. If not provided then default is used.

        Returns:
            None.
        """

        attributes = getattr(self, "_Data__attributes")
        attributes.set_hidden(delimiter=delimiter)
        attributes.set_hidden(analysis_type=analysis_type)  # e.g. "pax_door_corner"
        attributes.set_hidden(number_of_parts=0)
        attributes.set_hidden(data_lines=[])
        attributes.set_hidden(data_rows=[])
        attributes.set_hidden(data_dict={})
        attributes.set_hidden(common_information_headers=[])
        attributes.set_hidden(part_information_headers=[])
        attributes.set_hidden(part_header_pattern=[])
        attributes.set_hidden(part_header_prefix_pattern=[])

        if analysis_type == "pax_door_corner":
            if config_filepath:
                attributes.set_hidden(configuration_filepath=Path(config_filepath))
            else:
                attributes.set_hidden(
                    configuration_filepath=DATA_FOLDER_CORNER_MAT_STRENGTH
                    / Path(CONFIG_FILE_CORNER_MAT_STRENGTH),
                )
            self._read_csv_pax_door_corner()

        if analysis_type == "bds_shear_plate":
            if config_filepath:
                attributes.set_hidden(configuration_filepath=Path(config_filepath))
            else:
                attributes.set_hidden(
                    configuration_filepath=DATA_FOLDER_BDS_SHEAR_PLATE_STRENGTH
                    / Path(CONFIG_FILE_BDS_SHEAR_PLATE_STRENGTH),
                )
            self._read_csv_bds_shear_plate()

    def _read_csv_pax_door_corner(self) -> None:
        """Reads the contents of the input file."""
        attributes = getattr(self, "_Data__attributes")
        filename = attributes.get_main("filename").value
        delimiter = attributes.get_hidden("delimiter").value
        rows: list[Any] = []
        data_dict: dict[str, Any] = {}

        with open(filename, "r") as csvfile:
            csv_reader = csv.DictReader(csvfile, delimiter=delimiter)
            headers: list[str] = list(csv_reader.fieldnames)
            self._check_headers(headers)
            for row in csv_reader:
                rows.append(row)

            for entry in rows:
                part_data: dict[str, Any] = self._extract_part_data(entry)
                data_dict.update({part_data["meta"]["position"]: part_data})

        with open(filename, "r") as csvfile:
            lines: list[str] = csvfile.readlines()

        attributes.set_hidden(data_lines=lines)
        attributes.set_hidden(data_rows=rows)
        attributes.set_hidden(data_dict=data_dict)

    def _read_csv_bds_shear_plate(self) -> None:
        """Reads the contents of the BDS shear plate input file."""
        attributes = getattr(self, "_Data__attributes")
        filename = attributes.get_main("filename").value
        delimiter = attributes.get_hidden("delimiter").value
        rows: list[Any] = []
        data_dict: dict[str, Any] = {}

        df: pd.DataFrame = pd.read_csv(
            filename,
            sep=delimiter,
            index_col=0,
            header=None,
        )
        df_transposed = df.T
        # logger.debug(f"\n\n\n\ndf_transposed = {df_transposed}")
        headers: list[str] = df_transposed.columns.tolist()
        # logger.debug(f"\n\n\n\nheaders = {headers}")
        self._check_headers(headers)
        rows = df_transposed.values.tolist()
        part_data: dict[str, Any] = {}
        for index, row in df_transposed.iterrows():
            part_data = self._extract_part_data(row)
            data_dict.update({part_data["meta"]["position"]: part_data})

        # with open(filename, "r") as csvfile:
        # csv_reader = csv.DictReader(csvfile, delimiter=delimiter)
        # headers: list[str] = list(csv_reader.fieldnames)
        # self._check_headers(headers)
        # for row in csv_reader:
        #     rows.append(row)

        # for entry in rows:
        #     part_data: dict[str, Any] = self._extract_part_data(entry)
        #     data_dict.update({part_data["meta"]["position"]: part_data})

        with open(filename, "r") as csvfile:
            lines: list[str] = csvfile.readlines()

        attributes.set_hidden(data_lines=lines)
        attributes.set_hidden(data_rows=rows)
        attributes.set_hidden(data_dict=data_dict)

    def _extract_part_data(self, row: dict[str, Any]) -> dict[str, Any]:
        """
            Extracts the data in the input file and organises it in a dictionary format.

        Returns:
            dict[str, Any]: a dictionary containing general information ('meta' key) and
                            specific information about each component ('part_info' key).
        """

        attributes = getattr(self, "_Data__attributes")
        common_information_headers: list[str] = attributes.get_hidden(
            "common_information_headers"
        ).value
        part_header_prefix_pattern: str = attributes.get_hidden(
            "part_header_prefix_pattern"
        ).value

        part_data: dict[str, Any] = {}

        meta_info: dict[str, Any] = {}
        part_info: dict[str, Any] = {}

        counter = 1

        # pdb.set_trace()
        for key, value in row.items():
            if key in common_information_headers:
                # extract meta information:
                meta_info[key] = value
            else:
                if str(counter) not in key:
                    counter += 1
                key = self._remove_pattern_from_string(
                    pattern=part_header_prefix_pattern,
                    string=key,
                )
                # logger.debug(f"{counter=}, {key=}")
                # extract parts information:
                if "Part_" + str(counter) in part_info:
                    part_info["Part_" + str(counter)].update({key: value})
                else:
                    part_info["Part_" + str(counter)] = {key: value}
            meta_info.update({"number_of_parts": counter})
        part_data["meta"] = meta_info.copy()
        part_data["part_info"] = part_info.copy()

        return part_data

    def _check_headers(self, headers: list[str]) -> None:
        """Checks that the input file headers are according to the config template."""

        attributes = getattr(self, "_Data__attributes")

        configuration_filepath = attributes.get_hidden("configuration_filepath").value
        number_of_parts: int = attributes.get_hidden("number_of_parts").value

        with open(configuration_filepath) as file:
            try:
                json_config = json.load(file)

                common_information_headers = json_config["common_information_headers"]
                part_information_headers = json_config["part_information_headers"]
                for fix_header in common_information_headers:
                    if fix_header not in headers:
                        raise ValueError(f"Missing header in input file {fix_header=}")

                part_header_pattern = json_config["part_header_pattern"]
                part_header_prefix_pattern = json_config["part_header_prefix_pattern"]
                for header in headers:
                    if "_part_description" in header:
                        # logger.debug(f"_part_description found in {header=}")
                        number_of_parts += 1

                    if header not in common_information_headers:
                        # check that the part header has the right pattern:
                        if not bool(re.match(part_header_pattern, header)):
                            raise ValueError(
                                f"Invalid header in input file's \n\t{header=}, \n\t{part_header_pattern=}"
                            )

                        # check that all required part information is provided:
                        clean_header: str = self._remove_pattern_from_string(
                            part_header_prefix_pattern, header
                        )
                        if clean_header not in part_information_headers:
                            e_msg: str = str(
                                f"Missing part information in input file {clean_header=}, "
                                + f"required are {part_information_headers}"
                            )
                            raise ValueError(e_msg)

                attributes.set_hidden(
                    common_information_headers=common_information_headers
                )
                attributes.set_hidden(part_information_headers=part_information_headers)
                attributes.set_hidden(
                    part_header_prefix_pattern=part_header_prefix_pattern
                )
                attributes.set_hidden(part_header_pattern=part_header_pattern)
                attributes.set_hidden(number_of_parts=number_of_parts)

            except json.JSONDecodeError:
                assert False, "File is not a valid JSON file"

    def _remove_pattern_from_string(self, pattern: str, string: str) -> str:
        """Removes a given character pattern from the string provided."""
        return re.sub(pattern, "", string)

    def _matches_header_pattern(self, string: str) -> bool:
        """Checks whether the string provided matches the header pattern."""
        # pattern = r"^part_\d+_.*$"
        attributes = getattr(self, "_Data__attributes")
        part_header_pattern = attributes.get_hidden("part_header_pattern").value
        return bool(re.match(part_header_pattern, string))

    def _organise_data_by_key(self, key: str) -> dict[str, list[Any]]:
        """Arranges the file input data contents according the selected header name (key)."""
        attributes = getattr(self, "_Data__attributes")
        data_rows = attributes.get_hidden("data_rows").value
        common_information_headers = attributes.get_hidden(
            "common_information_headers"
        ).value
        part_information_headers = attributes.get_hidden(
            "part_information_headers"
        ).value

        # check key:
        # common_information_headers: list[str]
        # part_information_headers: list[str]
        valid_keys: list[str] = common_information_headers + part_information_headers
        if key not in valid_keys:
            raise ValueError(
                f"Wrong key for organising data selected: {key=}\nValid keys are: {valid_keys}"
            )
        organised_bykey_data: dict[str, list[Any]] = {}
        # pdb.set_trace()
        for row in data_rows:
            organised_bykey_data[row[key]] = row

        return organised_bykey_data

    def _organise_by_position(self) -> dict[str, list[Any]]:
        """Arranges the file input data contents according the position header."""
        attributes = getattr(self, "_Data__attributes")
        data_rows = attributes.get_hidden("data_rows").value
        organised_by_posit_data: dict[str, list[Any]] = {}
        # pdb.set_trace()
        for row in data_rows:
            organised_by_posit_data[row["position"]] = row
        return organised_by_posit_data

    def _create_data_dictionary(self) -> None:
        """Creates the data dictionary based on the input file."""
        attributes = getattr(self, "_Data__attributes")
        data_dict = attributes.get_hidden("data_dict").value
        organised_data_by_posit: dict[str, list[Any]] = self._organise_by_position()

        for k, v in organised_data_by_posit.items():
            data_dict.update({k: v})

    @property
    def export_to_dict(self) -> dict[str, Any]:
        """Return the input file contents in dictionary format."""
        return getattr(self, "_Data__attributes").get_hidden("data_dict").value

    @property
    def export_to_json(self) -> None:
        """Exports the contents of the input file to a json file."""
        json_filepath: Path = (
            getattr(self, "_Data__attributes")
            .get_hidden("input_filename")
            .value.with_suffix("." + "json")
        )
        with open(json_filepath, "w") as file:
            json.dump(
                getattr(self, "_Data__attributes").get_hidden("data_dict").value,
                file,
                indent=4,
            )

    def get(self):
        """Getter."""
        # TODO: implementation

    def set(self, filename: FilePath, **kwargs):
        """Setter."""
        # TODO: implementation
