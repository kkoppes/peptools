#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep  4 16:26:49 2023

@author: gi11883
"""
from __future__ import annotations
from pathlib import Path
from tables import open_file
from tables.file import File as Tables_File
from tables.group import Group as Tables_Group
from pydantic import FilePath, PrivateAttr, StrictStr, validate_arguments
from ..file import File


class HDF5(File):
    """Class to read HDF5 files."""

    __hdf5: Tables_File = PrivateAttr()

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type HDF5 class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type HDF5 class."""
        if not isinstance(value, HDF5):
            raise TypeError("HDF5 required")
        return value

    @validate_arguments(config={"arbitrary_types_allowed": True})
    def __init__(self, filename: FilePath, uuid: StrictStr = "") -> None:
        """Create a new File object."""
        # arguments = FilePathValidator(filepath=filename)
        attributes = getattr(self, "_Data__attributes")
        attributes.set_main(filename=Path(filename))
        # set data descriptor
        descriptor = getattr(self, "_Data__descriptor")
        descriptor.description = "HDF5 File object"
        # TODO: put the open_file into a try except statement to catch hdf5 errors
        table = open_file(filename, "r")
        setattr(self, "_HDF5__hdf5", table)

    def __del__(self) -> None:
        """Close the hdf5 file if opened when the object is destroyed."""
        self.close()

    @property
    def isopen(self) -> bool:
        """Check if the hdf5 file is open."""
        h5f: Tables_File = getattr(self, "_HDF5__hdf5")
        return h5f.isopen

    # @property
    # def root(self):
    #     """Return the hdf5 file root."""
    #     h5f: Tables_File = getattr(self, "_HDF5__hdf5")
    #     return h5f.root

    def close(self) -> None:
        """Close the hdf5 file."""
        h5f: Tables_File = getattr(self, "_HDF5__hdf5")
        if h5f.isopen:
            h5f.close()

    def get_table(self, *names) -> Tables_Group:
        """Get a hdf5 table."""
        h5f: Tables_File = getattr(self, "_HDF5__hdf5")
        table = h5f.root
        for name in names:
            table = getattr(table, name)
        return table

    def get(self):
        """Getter."""
        # TODO: implementation

    def set(self, filename: FilePath, **kwargs):
        """Setter."""
        # TODO: implementation
