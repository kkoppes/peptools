#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: fofl100
"""

from __future__ import annotations
from typing import Union, Optional
from pathlib import Path
from tables import open_file
from tables.file import File as Tables_File
from tables.group import Group as Tables_Group
from pydantic import FilePath, PrivateAttr, StrictStr, validate_arguments
from ..file import File
import sqlite3


class DatabaseNotFound(Exception):
    """Exception when the requested ISAMI database cannot be found"""


class SQLConnectionError(Exception):
    """Exception when the connection to ISAMI database fails"""


class SQLdatabase(File):
    """_summary_"""

    # class Config:
    #     """_summary_"""

    #     arbitrary_types_allowed = True

    # db_con: Optional[Union[sqlite3.Connection, None]] = None
    # db_path: Optional[Union[Path, None]] = None

    def __init__(
        self,
        filename: FilePath,
        db_con: Optional[Union[sqlite3.Connection, None]] = None,
    ) -> None:
        """_summary_

        Args:
            database (FilePath): _description_

        Returns:
            _type_: _description_
        """
        attributes = getattr(self, "_Data__attributes")
        attributes.set_main(filename=Path(filename), db_con=db_con)
        db_file_path = attributes.get_main("filename").value
        db_con = attributes.get_main("db_con").value
        if db_file_path.exists():
            # self.db_path = db_file_path
            self.connect()
        else:
            raise DatabaseNotFound(f"ISAMI database {db_file_path!r} not found")

    @property
    def filename(self) -> Path:
        """
        return filename
        """
        return self["filename"]

    @property
    def db_con(self) -> sqlite3.Connection:
        """
        return the connection of the database
        """
        return self["db_con"]

    def connect(self) -> bool:
        """.. __IsamiDB_Connect
        Connect to the provided ISAMI material database.

        :return: False if the connection fails, True otherwise.
        :rtype: bool
        """
        # db_path = self.db_path
        db_con = self.db_con
        db_path = self.filename
        if db_path:
            if db_con is None:
                try:
                    db_con = sqlite3.connect(db_path)
                    self["db_con"] = db_con
                except sqlite3.OperationalError as exc:
                    raise SQLConnectionError(
                        f"connection to the database {db_path!r} failed"
                    ) from exc
            return True
        return False

    def get(self):
        """Getter."""
        # TODO: implementation

    def set(self, filename: FilePath, **kwargs):
        """Setter."""
        # TODO: implementation

    def get_schema(self) -> Union[list[str], None]:
        """
        get the schema of the sql database as list of sql queries
        """
        db_con = self.db_con
        print("Database connection is: ", db_con)
        if db_con:
            cursor = db_con.cursor()
            sql_query = """SELECT sql FROM sqlite_master
            WHERE type IN ('table', 'view')
            AND name NOT LIKE 'sqlite_%' ORDER BY type DESC, name;"""
            cursor.execute(sql_query)
            schema = cursor.fetchall()
            schema_dict = [item[0] for item in schema]
            return schema_dict
        return None

    def recreate_database_from_schema(self, new_database: str):
        """
        it creates a new empty database, at the location specifed by
        the new_db_path, based on the sql queries contained in the schema.

        Args:
            new_database (str): str that specify the location of the
                                new database
        """
        new_db_path = Path(new_database)
        conn = sqlite3.connect(new_db_path)
        cursor = conn.cursor()
        schema = self.get_schema()
        for statement in schema:
            cursor.execute(statement)
            conn.commit()
        conn.close()

    @classmethod
    def insert_data_to_db(cls, filepath: str, data: dict[str, str]):
        """
        class method to insert data into a given sql database

        Args:
            db_path (str): str that contains the path to the sql database
            where the data is to be inserted;
            data (Dict[str, str]): dict with data to be inserted
                {'TableName': [{'column1':'value1', 'column2':'value2'},
                {'column1':'value12', 'column2':'value22'}]}
        """

        db_path = Path(filepath)
        if db_path.exists():
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            sql_exist_tables = "SELECT name FROM sqlite_master WHERE type='table';"
            cursor.execute(sql_exist_tables)
            existing_tables = set(table[0] for table in cursor.fetchall())
            for table_name, rows in data.items():
                if table_name in existing_tables:
                    for row in rows:
                        columns = ",".join(row.keys())
                        placeholders = ",".join("?" for _ in row)
                        sql = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
                        cursor.execute(sql, tuple(row.values()))
            conn.commit()
            conn.close()
        else:
            raise DatabaseNotFound
