#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 28 11:52:46 2024

@author: gi11883
"""
from typing import Any, Annotated, Callable, Optional, Literal
from pydantic import confloat, conint
from pydantic import StrictBool, StrictFloat, StrictInt, StrictStr, StrictBytes
from pydantic import BaseModel, validate_arguments
from pydantic.error_wrappers import ErrorWrapper, ValidationError
from .exceptions import UnsupportedType

# This is called by exec to validate the DataModel arguments
# TODO: with pydantic >= 2 validate_arguments becomes validate_call
# code to be executed to validate all the attributes
validate_attributes = (
    "@validate_arguments(config={{'arbitrary_types_allowed': True}})\ndef validator({}):\n\tpass\nvalidator(**kwargs)"
)

# code to be executed to validate a single attribute
validate_value = "@validate_arguments(config={{'arbitrary_types_allowed': True}})\n"
validate_value += "def validator({}):\n\tpass\nvalidator(value)"

# a dictionary of Callable to be used for casting
caster: dict[str, Callable] = {"bool": bool, "float": float, "int": int, "str": str}


class PylantirDataModel(BaseModel):
    """This class is needed just to rise a pydantic ValidationError."""


def __get_attr_type_name__(attribute_type) -> str:
    """Get the attribute type name."""
    try:
        attribute_type_name = attribute_type.__name__
    except AttributeError:
        # TODO: to be removed with python >= 3.10
        # all types have names in newwer python versions
        try:
            attribute_type_name = attribute_type.__origin__._name
        except AttributeError:
            RuntimeError(f" type {str(attribute_type)!r} for attribute {attribute_type_name!r} not supported")
    return attribute_type_name


def union_type(value, attribute_name, union_type) -> tuple[Any, tuple[str, str]]:
    """Validate the value against a list of types provided by a Union."""
    checks: list[bool] = []
    union_list: list[str] = []
    union_true_list: list[str] = []
    optional = False
    for attribute_type in union_type.__args__:
        # check if the value is at least one of the types of Union
        try:
            value, (attribute_name, single_type) = validate_type(value, attribute_name, attribute_type)
        except ValidationError:
            # this is because one of the types is a generic object and the check in validate_type fails
            # set the type to Any for the validate_attrs inside isengard.data.DataModel
            single_type = "Any"
            # the provided value is not the required generic object
            checks.append(False)
            # add Any to the list of types for validate_attrs
            union_list.append(single_type)
            # add the actual type for the error message in case all the checks do not pass
            union_true_list.append(__get_attr_type_name__(attribute_type))
            # skip to the next type
            continue

        if attribute_type is type(None):
            # Transform the Union[..., NonteType] to Optional[Union]
            optional = True
            checks.append(value is None)
            # and do not add NoneType to the list
            continue

        # try to validate value angainst the single type of Union
        try:
            exec(validate_value.format(attribute_name + ": " + single_type))
            checks.append(True)
        except ValidationError:
            checks.append(False)

        union_list.append(single_type)
        union_true_list.append(__get_attr_type_name__(attribute_type))

    union = ", ".join(union_list)
    if optional:
        # if NoneType is one of the types Union -> Optional[Any]
        attribute_type = "Optional[Any] = None"
    else:
        attribute_type = f"Union[{union}]"
    if not any(checks):
        # if none of the types is matched raise a ValidationError
        negation = "not" * (not optional) + "neither" * optional
        attribute_type = f"Union[{', '.join(union_true_list)}]" + " nor NoneType" * optional
        exc = TypeError(f"{value} is {negation} a valid type of {attribute_type}")
        raise ValidationError([ErrorWrapper(exc, loc=attribute_name)], PylantirDataModel)

    return value, (attribute_name, attribute_type)


def constrained_value(value, type_name) -> str:
    """Return a constrained int or float."""
    type_str = (
        f"strict={value.strict}, gt={value.gt}, ge={value.ge}, lt={value.lt}, "
        + f"le={value.le}, multiple_of={value.multiple_of}"
    )
    if type_name == "ConstrainedIntValue":
        type_str = "conint(" + type_str + ")"
    elif type_name == "ConstrainedFloatValue":
        type_str = "confloat(" + type_str + f", allow_inf_nan={value.allow_inf_nan})"
    else:
        raise UnsupportedType(type_name)
    return type_str


def validate_type(value, attribute_name, attribute_type) -> tuple[Any, tuple[str, str]]:
    """Validate the provided attribute."""
    attribute_type_name = __get_attr_type_name__(attribute_type)
    if attribute_type_name in ["bool", "float", "int", "str"]:
        # try a cast
        try:
            # validate the value agains builin types
            exec(validate_value.format(attribute_name + ": " + attribute_type_name))
            # if success cast the value to the correct type (e.g. float('1.0') -> 1.0, bool(1) -> True)
            # this mimic the pydantic behaviour
            value = caster[attribute_type_name](value)
        except ValidationError:
            # the error will be captured iside the DataModel executing validate_attrs
            pass
        return value, (attribute_name, attribute_type_name)
    elif attribute_type_name in ["StrictBool", "StrictFloat", "StrictInt", "StrictStr"]:
        # strict types are not casted as the builin types
        return value, (attribute_name, attribute_type_name)
    elif "Constrained" in attribute_type_name and "Value" in attribute_type_name:
        # this manage conint and confloat
        return value, (attribute_name, constrained_value(attribute_type, attribute_type_name))
    elif attribute_type_name in ["Annotated", "Literal"]:
        # get the argoments for the Annotated or Literal type (bewtween square brackets)
        annotated_args = str(attribute_type).split(attribute_type_name)[1]
        # add the Annotated or Literal type to the attributes list
        return value, (attribute_name, attribute_type_name + annotated_args)
    elif "Optional" in str(attribute_type):
        # get the actual type inside the optional type
        optional_attribute = attribute_type.__args__[0]
        # the type check is performed by the isinstance below
        if not isinstance(value, (optional_attribute, type(None))):
            optional_attr_name = optional_attribute.__name__
            exc = TypeError(f"{value} is not a valid {optional_attr_name} object")
            raise ValidationError([ErrorWrapper(exc, loc=attribute_name)], PylantirDataModel)
        # if the check pass, to pydantic is passed a fake Optional[Any] = None argument to make it work
        return value, (attribute_name, "Optional[Any] = None")
    elif "Union" in str(attribute_type):
        return union_type(value, attribute_name, attribute_type)

    # if none of the above options is passed then do a type check value against the requested attribute_type
    # this cannot be done executing validate_attrs because pydantic needs to know the type to do the check, i.e.
    # the class should be imported inside validate_attrs. This approach is much more simple and does not reauire to find
    # out where the class is defined to be iimported
    if not isinstance(value, attribute_type):
        exc = TypeError(f"{value} is not a valid {attribute_type_name} object")
        raise ValidationError([ErrorWrapper(exc, loc=attribute_name)], PylantirDataModel)
    # if the check pass, to pydantic is passed a fake Any type to make it work
    return value, (attribute_name, "Any")
