# -*- coding: utf-8 -*-
"""Data management module."""

from __future__ import annotations
import json
from pathlib import Path
from copy import deepcopy
from dataclasses import dataclass
from abc import ABCMeta, abstractmethod
from typing import Any, Optional, Literal, Union

from jinja2 import Template
from pydantic import BaseModel, PrivateAttr, validate_arguments

# from pydantic.error_wrappers import ValidationError, ErrorWrapper

# import types for DataModel validation with the exec() buil-in method
from .types import conint, confloat
from .types import StrictBool, StrictFloat, StrictInt, StrictStr

from .types import validate_type, validate_attributes, validate_value
from .utils import FileType
from .exceptions import AttributeNotUnique, AttributeNotFound

# TODO: Change union with | with python > 3.10

# initialize ATTR_TYPE for the validate_arguments decorator in DataModel
ATTR_TYPE: type = type(None)


class Attribute(BaseModel):
    """Attribute class."""

    name: StrictStr
    value: Any
    tag: Literal["main", "meta", "hidden"] = "main"

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Attribute class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Attribute class."""
        if not isinstance(value, Attribute):
            raise TypeError("Attribute required")
        return value

    @property
    def class_name(self) -> str:
        """Return the name of the attribute 'value' class."""
        return self.value.__class__.__name__

    @property
    def type(self) -> type:
        """Return the type of the attribute 'value'."""
        return type(self.value)

    def to_json(self) -> str:
        """Return the attribute in a json format."""
        method = ""
        if isinstance(self.value, (int, float, str, bool)):
            value = '"' + str(self.value) + '"'
        elif isinstance(self.value, (list, tuple)):
            # TODO: a check for jsonification for each element of the list/tuple
            # must be performed, and add the support fo dictionaries
            elements = [""] * len(self.value)
            for idx, element in enumerate(self.value):
                if isinstance(element, Data):
                    data_method = element.method
                    if data_method is not None and data_method != "__init__":
                        data_method = ":" + data_method
                    else:
                        data_method = ""
                    elements[idx] += '":' + element.class_name + data_method + '": ' + element.to_json()
                else:
                    elements[idx] += '":' + element.__class___.__name__ + '": {' + json.dumps(element) + "}"
            value = "{" + ",".join(elements) + "}"
        elif isinstance(self.value, Data):
            value = self.value.to_json()
            data_method = self.value.method
            if data_method is not None and data_method != "__init__":
                method = ":" + data_method
        elif isinstance(self.value, Path):
            value = str(self.value.absolute())
        elif self.value is None:
            value = str(None)
        else:
            raise TypeError(
                f"object {self.class_name!r} in attribute {self.name!r}"
                + " cannot be represented in pylantir data json format"
            )
        return '"' + self.name + ":" + self.class_name + method + '"' + f": {value}"


class DataAttributes(dict):
    """Collector of attributes for DataModel."""

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type DataAttributes class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type DataAttributes class."""
        if not isinstance(value, DataAttributes):
            raise TypeError("DataAttributes required")
        return value

    @classmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def from_dict(
        self,
        main: Optional[dict[str, Any]] = None,
        meta: Optional[dict[str, Any]] = None,
        hidden: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Initialize the object with dicttionaries."""
        obj = Attributes()
        if main:
            obj.set_main(**main)
        if meta:
            obj.set_meta(**meta)
        if hidden:
            obj.set_hidden(**hidden)
        return obj

    @validate_arguments(config={"arbitrary_types_allowed": True})
    def __init__(self, /, *args: Attribute, mapping=None, **kwargs: Any) -> None:
        """Initialize the object."""
        self.__hidden = {}
        self.__meta = {}
        mapping = {}

        for arg in args:
            if arg.tag == "main":  # isinstance(arg, MainAttribute):
                mapping[arg.name] = arg
            elif arg.tag == "meta":  # isinstance(arg, MetaAttribute):
                self.__meta[arg.name] = arg
            elif arg.tag == "hidden":  # isinstance(arg, HiddenAttribute):
                self.__hidden[arg.name] = arg
            else:
                raise TypeError(f"attribute named {arg.name!r} is not a meta, main or hidden attribute")
        # add the kwargs to the main attributes
        for name, value in kwargs.items():
            mapping[name] = Attribute(name=name, value=value)

        super().__init__(mapping)

    def __getitem__(self, name) -> Any:
        """Get a main Attribute value."""
        try:
            return super().__getitem__(name).value
        except KeyError:
            raise KeyError(f"name {name!r} is not a main attribute")

    def __setitem__(self, name, value) -> None:
        """Set a main Attribute value."""
        try:
            attribute = super().__getitem__(name)
            attribute.value = value
        except KeyError:
            super().__setitem__(name, Attribute(name=name, value=value))

    @property
    def names(self) -> list[str]:
        """Return a list containing the main attributes names."""
        return list(self.keys())

    @property
    def meta_names(self) -> list[str]:
        """Return a list containing the meta attributes names."""
        return list(self.__meta.keys())

    def append_hidden(self, **kwargs: Any) -> None:
        """Append hidden attributes."""
        hidden = getattr(self, "_DataAttributes__hidden")
        new_hidden: dict[str, Union[None, Attribute]] = {name: None for name in kwargs}

        common_keys = set(hidden.keys()).intersection(set(new_hidden.keys()))
        if common_keys:
            # If there are duplicated attribute names raise an error
            raise AttributeNotUnique(f"attributes {', '.join(common_keys)} are not unique")

        for name, value in kwargs.items():
            new_hidden[name] = Attribute(name=name, value=value, tag="hidden")
        # add the new Attributes to the private attribute __hidden
        hidden.update(new_hidden)

    def append_main(self, **kwargs: Any) -> None:
        """Kept for legacy reasons."""
        self.append_public(**kwargs)

    def append_public(self, **kwargs: Any) -> None:
        """Append public attributes."""
        new_public: dict[str, Union[None, Attribute]] = {name: None for name in kwargs}

        common_keys = set(self.keys()).intersection(set(new_public.keys()))
        if common_keys:
            # If there are duplicated attribute names raise an error
            raise AttributeNotUnique(f"attributes {', '.join(common_keys)} are not unique")

        for name, value in kwargs.items():
            new_public[name] = Attribute(name=name, value=value)
        # add the new Attributes to the private attribute __main
        self.update(new_public)

    def append_meta(self, **kwargs: Any) -> None:
        """Append meta attributes."""
        meta = getattr(self, "_DataAttributes__meta")
        new_meta: dict[str, Union[None, Attribute]] = {name: None for name in kwargs}

        common_keys = set(meta.keys()).intersection(set(new_meta.keys()))
        if common_keys:
            # If there are duplicated attribute names raise an error
            raise AttributeNotUnique(f"attributes {', '.join(common_keys)} are not unique")

        for name, value in kwargs.items():
            new_meta[name] = Attribute(name=name, value=value, tag="meta")
        # add the new Attributes to the private attribute __meta
        meta.update(new_meta)

    def copy(self) -> DataAttributes:
        """Create a copy of Attributes."""
        copy_of_attributes = DataAttributes()
        for name, attribute in self.items():
            copy_of_attributes[name] = deepcopy(attribute.value)
        copy_of_attributes.set_meta(**deepcopy(self.__meta))
        copy_of_attributes.set_hidden(**deepcopy(self.__hidden))
        return copy_of_attributes

    def is_empty(self) -> bool:
        """Return true if there are no public attributes."""
        if self:
            return False
        return True

    @validate_arguments
    def get_hidden(self, *names: StrictStr, default: Any = None) -> Any:
        """Get a hidden attributes."""
        attr_list = []
        for name in names:
            attr_list.append(self.__hidden.get(name, default))
        if len(attr_list) == 1:
            return attr_list[0]
        return tuple(attr_list)

    def get_main(self, *names: StrictStr, default: Any = None) -> Any:
        """Kept for legacy reasons."""
        return self.get_public(*names, default=default)

    @validate_arguments
    def get_public(self, *names: StrictStr, default: Any = None) -> Any:
        """Get a public attributes."""
        attr_list = []
        for name in names:
            attr_list.append(self.get(name, default))
        if len(attr_list) == 1:
            return attr_list[0]
        return tuple(attr_list)

    @validate_arguments
    def get_meta(self, *names: StrictStr, default: Any = None) -> Any:
        """Get a meta attribute."""
        attr_list = []
        for name in names:
            attr_list.append(self.__meta.get(name, default))
        if len(attr_list) == 1:
            return attr_list[0]
        return tuple(attr_list)

    def set_hidden(self, **kwargs: Any) -> None:
        """Set hidden attributes overwriting them if they alrerady exist."""
        for name, value in kwargs.items():
            if isinstance(value, Attribute):
                self.__hidden[name] = value
                self.__hidden[name].tag = "hidden"
            else:
                self.__hidden[name] = Attribute(name=name, value=value, tag="hidden")

    def set_main(self, **kwargs: Any) -> None:
        """Kept for legacy reasons."""
        self.set_public(**kwargs)

    def set_public(self, **kwargs: Any) -> None:
        """Set public attributes overwriting them if they alrerady exist."""
        for name, attribute in kwargs.items():
            if isinstance(attribute, Attribute):
                self[name] = attribute.value
            else:
                self[name] = attribute

    def set_meta(self, **kwargs: Any) -> None:
        """Set meta attributes overwriting them if they alrerady exist."""
        for name, value in kwargs.items():
            if isinstance(value, Attribute):
                self.__meta[name] = value
                self.__meta[name].tag = "meta"
            else:
                self.__meta[name] = Attribute(name=name, value=value, tag="meta")

    def reset_main(self, **kwargs: Any) -> None:
        """Kept for legacy reasons."""
        self.reset_public(**kwargs)

    def reset_public(self, **kwargs: Any) -> None:
        """Reset public attributes."""
        self.clear()
        for name, value in kwargs.items():
            self[name] = value

    def reset_meta(self, **kwargs: Any) -> None:
        """Reset meta attributes."""
        meta: dict[str, Union[None, Attribute]] = {name: None for name in kwargs}
        for name, value in kwargs.items():
            meta[name] = Attribute(name=name, value=value, tag="meta")
        setattr(self, "_DataAttributes__meta", meta)

    def reset_hidden(self, **kwargs: Any) -> None:
        """Reset hidden attributes."""
        hidden: dict[str, Union[None, Attribute]] = {name: None for name in kwargs}
        for name, value in kwargs.items():
            hidden[name] = Attribute(name=name, value=value, tag="hidden")
        setattr(self, "_DataAttributes__hidden", hidden)

    @validate_arguments
    def pop(self, name: str, default: Any = None) -> Optional[Attribute]:
        """Pop the atrribute if exists."""
        if name in self:
            return self.pop(name)
        elif name in self.__meta:
            return self.__meta.pop(name)
        return default


class Attributes(BaseModel):
    """Collector of attributes."""

    __fields_set__: set = set()  # workaround for AttributeError __fields_set__
    __hidden: dict[str, Attribute] = PrivateAttr()
    __main: dict[str, Attribute] = PrivateAttr()
    __meta: dict[str, Attribute] = PrivateAttr()

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Attributes class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Attributes class."""
        if not isinstance(value, Attributes):
            raise TypeError("Attributes required")
        return value

    @classmethod
    @validate_arguments()
    def from_dict(
        self,
        main: Optional[dict[str, Any]] = None,
        meta: Optional[dict[str, Any]] = None,
        hidden: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Initialize the object with dicttionaries."""
        obj = Attributes()
        if main:
            obj.set_main(**main)
        if meta:
            obj.set_meta(**meta)
        if hidden:
            obj.set_hidden(**hidden)
        return obj

    @validate_arguments(config={"arbitrary_types_allowed": True})
    def __init__(self, *args: Attribute) -> None:
        """Initialize the object."""
        self.__hidden = {}
        self.__meta = {}
        self.__main = {}
        for arg in args:
            if arg.tag == "main":  # isinstance(arg, MainAttribute):
                self.__main[arg.name] = arg
            elif arg.tag == "meta":  # isinstance(arg, MetaAttribute):
                self.__meta[arg.name] = arg
            elif arg.tag == "hidden":  # isinstance(arg, HiddenAttribute):
                self.__hidden[arg.name] = arg
            else:
                raise TypeError(f"attribute named {arg.name!r} is not a meta, main or hidden attribute")

    def __deepcopy__(self, *args) -> Attributes:
        """Override deepcopy."""
        return self.copy()

    def __getitem__(self, name) -> Attribute:
        """Get an attribute by name."""
        main = getattr(self, "_Attributes__main")
        try:
            return main[name]
        except KeyError:
            raise KeyError(f"name {name!r} is not a main attribute")

    @property
    def names(self) -> list[str]:
        """Return a list containing the main attributes names."""
        return list(self.__main.keys())

    @property
    def meta_names(self) -> list[str]:
        """Return a list containing the meta attributes names."""
        return list(self.__meta.keys())

    def append_hidden(self, **kwargs: Any) -> None:
        """Append hidden attributes."""
        hidden = getattr(self, "_Attributes__hidden")
        new_hidden: dict[str, Union[None, Attribute]] = {name: None for name in kwargs}

        common_keys = set(hidden.keys()).intersection(set(new_hidden.keys()))
        if common_keys:
            # If there are duplicated attribute names raise an error
            raise AttributeNotUnique(f"attributes {', '.join(common_keys)} are not unique")

        for name, value in kwargs.items():
            new_hidden[name] = Attribute(name=name, value=value, tag="hidden")
        # add the new Attributes to the private attribute __hidden
        hidden.update(new_hidden)

    def append_main(self, **kwargs: Any) -> None:
        """Append main attributes."""
        main = getattr(self, "_Attributes__main")
        new_main: dict[str, Union[None, Attribute]] = {name: None for name in kwargs}

        common_keys = set(main.keys()).intersection(set(new_main.keys()))
        if common_keys:
            # If there are duplicated attribute names raise an error
            raise AttributeNotUnique(f"attributes {', '.join(common_keys)} are not unique")

        for name, value in kwargs.items():
            new_main[name] = Attribute(name=name, value=value)
        # add the new Attributes to the private attribute __main
        main.update(new_main)

    def append_meta(self, **kwargs: Any) -> None:
        """Append meta attributes."""
        meta = getattr(self, "_Attributes__meta")
        new_meta: dict[str, Union[None, Attribute]] = {name: None for name in kwargs}

        common_keys = set(meta.keys()).intersection(set(new_meta.keys()))
        if common_keys:
            # If there are duplicated attribute names raise an error
            raise AttributeNotUnique(f"attributes {', '.join(common_keys)} are not unique")

        for name, value in kwargs.items():
            new_meta[name] = Attribute(name=name, value=value, tag="meta")
        # add the new Attributes to the private attribute __meta
        meta.update(new_meta)

    def copy(self, *args, **kwargs) -> Attributes:
        """Copy the this object and its content."""
        data: dict[str, dict[str, Any]] = {"meta": {}, "main": {}, "hidden": {}}
        for name in self.__meta:
            value = self.__meta[name].value
            if isinstance(value, Template):
                data["meta"][name] = value
            else:
                data["meta"][name] = deepcopy(value)
        for name in self.__main:
            value = self.__main[name].value
            if isinstance(value, Template):
                data["main"][name] = value
            else:
                data["main"][name] = deepcopy(value)
        for name in self.__hidden:
            value = self.__hidden[name].value
            if isinstance(value, Template):
                data["hidden"][name] = value
            else:
                data["hidden"][name] = deepcopy(value)
        copy_of_attributes = Attributes.from_dict(main=data["main"], meta=data["meta"], hidden=data["hidden"])
        return copy_of_attributes

    def is_empty(self) -> bool:
        """Return true if there are no main attributes."""
        if self.__main:
            return False
        return True

    @validate_arguments
    def get_hidden(self, *names: StrictStr, default: Any = None) -> Any:
        """Get a hidden attributes."""
        attr_list = []
        for name in names:
            attr_list.append(self.__hidden.get(name, default))
        if len(attr_list) == 1:
            return attr_list[0]
        return tuple(attr_list)

    @validate_arguments
    def get_main(self, *names: StrictStr, default: Any = None) -> Any:
        """Get a main attributes."""
        attr_list = []
        for name in names:
            attr_list.append(self.__main.get(name, default))
        if len(attr_list) == 1:
            return attr_list[0]
        return tuple(attr_list)

    @validate_arguments
    def get_meta(self, *names: StrictStr, default: Any = None) -> Any:
        """Get a meta attribute."""
        attr_list = []
        for name in names:
            attr_list.append(self.__meta.get(name, default))
        if len(attr_list) == 1:
            return attr_list[0]
        return tuple(attr_list)

    def set_hidden(self, **kwargs: Any) -> None:
        """Set hidden attributes overwriting them if they alrerady exist."""
        for name, value in kwargs.items():
            if isinstance(value, Attribute):
                self.__hidden[name] = value
                self.__hidden[name].tag = "hidden"
            else:
                self.__hidden[name] = Attribute(name=name, value=value, tag="hidden")

    def set_main(self, **kwargs: Any) -> None:
        """Set main attributes overwriting them if they alrerady exist."""
        for name, value in kwargs.items():
            if isinstance(value, Attribute):
                self.__main[name] = value
                self.__main[name].tag = "main"
            else:
                self.__main[name] = Attribute(name=name, value=value)

    def set_meta(self, **kwargs: Any) -> None:
        """Set meta attributes overwriting them if they alrerady exist."""
        for name, value in kwargs.items():
            if isinstance(value, Attribute):
                self.__meta[name] = value
                self.__meta[name].tag = "meta"
            else:
                self.__meta[name] = Attribute(name=name, value=value, tag="meta")

    # def swap(self) -> None:
    #     """Swap meta attributes with main attributes."""
    #     new_meta: dict[str, MetaAttribute] = {}
    #     for name, main_attribute in self.__main.items():
    #         new_meta[name] = main_attribute.to_meta_attribute()
    #     new_main: dict[str, MainAttribute] = {}
    #     for name, meta_attribute in self.__meta.items():
    #         new_main[name] = meta_attribute.to_main_attribute()
    #     self.__main, self.__meta = (new_main, new_meta)

    def reset_main(self, **kwargs: Any) -> None:
        """Reset main attributes."""
        main: dict[str, Union[None, Attribute]] = {name: None for name in kwargs}
        for name, value in kwargs.items():
            main[name] = Attribute(name=name, value=value)
        setattr(self, "_Attributes__main", main)

    def reset_meta(self, **kwargs: Any) -> None:
        """Reset meta attributes."""
        meta: dict[str, Union[None, Attribute]] = {name: None for name in kwargs}
        for name, value in kwargs.items():
            meta[name] = Attribute(name=name, value=value, tag="meta")
        setattr(self, "_Attributes__meta", meta)

    @validate_arguments
    def pop(self, name: str) -> Optional[Attribute]:
        """Pop the atrribute if exists."""
        if name in self.__main:
            return self.__main.pop(name)
        elif name in self.__meta:
            return self.__meta.pop(name)
        return None


class DataDescriptor(BaseModel):
    """Data descriptor."""

    name: StrictStr = ""
    method: Optional[StrictStr] = None
    description: StrictStr = ""
    uuid: StrictStr = ""  # TODO: implement uuid system


class DataTypeDescriptor(BaseModel):
    """DataType descriptor."""

    name: StrictStr
    descriptor: DataDescriptor
    byte_header: bytes
    uuid: StrictStr = ""  # TODO: implement uuid system

    class Config:
        """Configure BaseModel."""

        arbitrary_types_allowed = True


class DataType(BaseModel, metaclass=ABCMeta):
    """DataType meta class."""

    __data: Data = PrivateAttr()
    __filetype: Any = PrivateAttr()
    __descriptor: DataTypeDescriptor = PrivateAttr()

    @property
    @abstractmethod
    def extension(self) -> str:
        """Get the __extension private attribute."""

    @property
    @abstractmethod
    def mime(self) -> str:
        """Get the __mime private attribute."""

    @property
    @abstractmethod
    def descriptor(self) -> DataTypeDescriptor:
        """Get the __descriptor private attribute."""

    @abstractmethod
    def encode(self, data: Any) -> Any:
        """Encode the file type."""

    @abstractmethod
    def decode(self) -> Any:
        """Encode the file type."""

    @abstractmethod
    def get_data(self) -> Any:
        """Get the data."""

    @abstractmethod
    def set_data(self) -> Any:
        """Set the data and check validity against the datatype."""


@dataclass
class DataModel(metaclass=ABCMeta):
    """Pylantir Data class."""

    # TODO: with python >= 3.10 __slots__can be moved in the decorator @dataclass(slots=True, kw_only=True)
    __slots__ = ["__descriptor", "__attributes"]

    __descriptor: DataDescriptor
    __attributes: DataAttributes

    def __new__(cls, *args, **kwargs):
        """Is a New World Order."""
        try:
            default_values = getattr(cls, "__default_values")
        except AttributeError:
            default_values = {}
            setattr(cls, "__default_values", default_values)

        obj = object().__new__(cls)
        attributes = DataAttributes()
        setattr(obj, "__dict__", attributes)
        setattr(obj, "_DataModel__attributes", attributes)

        hidden_args: dict[str, Any] = {}
        for attr_name, attr_type in cls.__annotations__.items():
            if attr_name in default_values:
                default_value = default_values[attr_name]
            else:
                try:
                    default_value = getattr(cls, attr_name)
                except AttributeError:
                    default_value = None

                if isinstance(default_value, property):
                    default_value = None
            if attr_name[0] != "_":
                # public (main) attributes
                if default_value is not None:
                    default_values[attr_name] = default_value

                    if attr_name not in kwargs:
                        kwargs[attr_name] = default_value

                def _get(obj, key=attr_name):
                    return obj.__dict__[key]

                # unfortunately @validate_arguments cannot get attr_type as a valid type
                # this can be however be done with validate_call
                # TODO: improve using pydantic v2
                def _set(obj, value: Any, key=attr_name):
                    attribute_type = obj.__annotations__[key]
                    value, attribute = validate_type(value, key, attribute_type)
                    validation_string = attribute[0] + ": " + attribute[1]
                    exec(validate_value.format(validation_string))
                    obj.__dict__[key] = value

                setattr(cls, attr_name, property(fget=_get, fset=_set))
            else:
                hidden_attr_name = attr_name.replace("_" + cls.__name__, "")
                hidden_args[hidden_attr_name] = default_value

        try:
            data_descriptor = kwargs.pop("descriptor")
        except KeyError:
            raise TypeError(f" Can't instantiate class {obj.__class__.__name__} without 'descriptor'")

        if not isinstance(data_descriptor, DataDescriptor):
            raise ValueError(
                " 'descriptor' shall be a pylantir 'DataDescriptor' object,"
                + f" and not {data_descriptor.__class__.__name__!r} "
            )

        setattr(obj, "_DataModel__descriptor", data_descriptor)
        # validate the types

        exec(validate_attributes.format(obj.__main_attrs_validity(kwargs)))
        # set the attributes
        attributes.set_public(**kwargs)
        attributes.set_hidden(**hidden_args)
        return obj

    def __init__(self, *args, **kwargs) -> None:
        """Initialize the Data object."""
        # nothing to do
        pass

    def __repr__(self) -> str:
        """Representation of the Data."""
        return self.__class__.__name__ + "({})".format(
            ", ".join([f"{name}={value.value}" for name, value in self.__dict__.items()])
        )

    def __main_attrs_validity(self, kwargs) -> str:
        """
        Check if all the main attribures are provided and, in case, return a type validation string.

        Args:
            kwargs (dict[str, Any]): main attributes.

        Raises:
            TypeError: for missing or unexpeted attributes.

        Returns:
            str: a comma separated list of attributes and respective types (e.g. 'a: int, b: float, c: str, ...')

        """
        # get a list of tuples (attribute name, attribute type)
        main_attrs = []
        for attribute_name, attribute_type in self.__annotations__.items():
            value = kwargs.get(attribute_name)
            if attribute_name == "descriptor" or attribute_name.startswith("_"):
                # skip the DataDescriptor for later and hidden/private varaibles
                continue
            value, main_attr = validate_type(value, attribute_name, attribute_type)
            main_attrs.append(main_attr)
            if "Optional" in main_attrs[-1][1] and value is None:
                # add the optional argument set to None
                kwargs[attribute_name] = None
            elif attribute_name in kwargs:
                kwargs[attribute_name] = value

        # unzip the list of tuples into two tuples of strings
        main_attrs_names, main_attrs_types = list(zip(*main_attrs))
        # make a set from the main attribute names
        main_attrs_set = set(main_attrs_names)
        # make a set from the provided attribute names
        attrs_set = set([attr for attr in kwargs.keys() if not attr.startswith("_")])
        # check if the provided set of required names does not match with the main attributes
        if main_attrs_set != attrs_set:
            missing_attrs = sorted(list(main_attrs_set - attrs_set))
            unexpected_attrs = sorted(list(attrs_set - main_attrs_set))

            missing_attrs_str = ""
            m_sfx = "s" * (len(missing_attrs) - 1)  # plural "s" if  len > 1
            if missing_attrs:
                missing_attrs_str = (
                    ", ".join(missing_attrs[:-1]) + " and " * len(missing_attrs[:-1]) + missing_attrs[-1]
                )

            unexpected_attrs_str = ""
            u_sfx = "s" * (len(unexpected_attrs) - 1)  # plural "s" if  len > 1
            if unexpected_attrs:
                unexpected_attrs_str = (
                    ", ".join(unexpected_attrs[:-1]) + " and " * len(unexpected_attrs[:-1]) + unexpected_attrs[-1]
                )

            raise TypeError(
                f"\n\nMissing {len(missing_attrs)} positional argument{m_sfx}: {missing_attrs_str}"
                * bool(len(missing_attrs))
                + f"\n\nGot {len(unexpected_attrs)} unexpeted argument{u_sfx}: {unexpected_attrs_str}"
                * bool(len(unexpected_attrs))
            )
        type_validation_string = ", ".join(
            [f"{attr_name}: {attr_type}" for attr_name, attr_type in zip(main_attrs_names, main_attrs_types)]
        )
        return type_validation_string


class Data(BaseModel, metaclass=ABCMeta):
    """Data hybrid meta class."""

    __fields_set__: set = set()  # workaround for AttributeError __fields_set__
    __descriptor: DataDescriptor = PrivateAttr()  # a description of the content
    __attributes: Attributes = PrivateAttr()  # data attributes

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type Data class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type Data class."""
        if not isinstance(value, Data):
            raise TypeError("Data required")
        return value

    @classmethod
    def __new__(
        cls: Any,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """
        Create a new empty Data object.

        Returns:
            Data.

        """
        # istantiate a new Data object
        obj = object().__new__(cls)
        try:
            descriptor = kwargs.pop("data_descriptor")
        except KeyError:
            descriptor = DataDescriptor(description="Data object", method=None, uuid="")

        try:
            attributes = kwargs.pop("data_attributes")
        except KeyError:
            attributes = Attributes.from_dict(main=kwargs)

        @validate_arguments(config={"arbitrary_types_allowed": True})
        def __validate_inputs__(descriptor: DataDescriptor, attributes: Attributes):
            """Validate descriptor and attributes types."""

        __validate_inputs__(descriptor=descriptor, attributes=attributes)
        # store data attributes and descriptor
        setattr(obj, "_Data__attributes", attributes)
        setattr(obj, "_Data__descriptor", descriptor)
        return obj

    def __deepcopy__(self, memo) -> Data:
        """Override the BaseModel __deepcopy__ method."""
        return self.copy()

    def __getitem__(self, name: str) -> Any:
        """Get a content item."""
        attr = getattr(self, "_Data__attributes")
        return attr[name].value

    def __setitem__(self, name: str, value: Any) -> None:
        """Get a content item."""
        attr = getattr(self, "_Data__attributes")
        attr[name].value = value

    def __str__(self) -> str:
        """Get a string reperesentation of the object."""
        return self.__repr__()

    def __repr__(self) -> str:
        """Get representation string."""
        class_name = self.__class__.__name__
        attributes = getattr(self, "_Data__attributes")
        names = attributes.names
        arguments = [""] * len(names)
        for idx, name in enumerate(names):
            value = attributes[name].value
            if isinstance(value, str):
                # add single quote mark
                value_str = f"{value!r}"
            else:
                # cast the value to a string
                value_str = str(value)
            arguments[idx] = name + "=" + value_str
        return class_name + f"({', '.join(arguments)})"

    @property
    def class_name(self) -> str:
        """Return the name of the Data class."""
        return self.__class__.__name__

    @property
    def descriptor(self) -> DataDescriptor:
        """Get the DataDescriptor object."""
        return getattr(self, "_Data__descriptor")

    @property
    def method(self) -> Optional[str]:
        """Return the method used to instantiate the Data object."""
        return self.descriptor.method

    @property
    def main_names(self) -> set[str]:
        """Return the name of the main attributes."""
        attr = getattr(self, "_Data__attributes")
        return attr.names

    @property
    def meta_names(self) -> set[str]:
        """Return the name of the meta attributes."""
        attr = getattr(self, "_Data__attributes")
        return attr.meta_names

    @property
    def uuid(self) -> str:
        """Return the name of the meta attributes."""
        return self.descriptor.uuid

    def copy(self, *args, **kwargs) -> Data:
        """Create a copy of the object."""
        obj = self.__class__.__new__(self.__class__)
        attributes = getattr(self, "_Data__attributes")
        descriptor = getattr(self, "_Data__descriptor")
        setattr(obj, "_Data__attributes", deepcopy(attributes))
        setattr(obj, "_Data__descriptor", deepcopy(descriptor))
        return obj

    @abstractmethod
    def get(self, *args: Any, **kwargs: Any) -> Any:
        """Get the data."""

    @abstractmethod
    def set(self, *args: Any, **kwargs: Any) -> None:
        """Set the data."""

    def to_json(self) -> str:
        """Return a json format of the class."""
        # TODO: to be tested!
        attributes = getattr(self, "_Data__attributes")
        json_string = []
        if self.method:
            # if a class method has been used pass only the meta attributes
            attribute_names = attributes.meta_names
            get_method = "get_meta"
        else:
            # otherwise pass the main attributes
            attribute_names = attributes.names
            get_method = "get_main"
        for attribute_name in attribute_names:
            attribute = getattr(attributes, get_method)(attribute_name)
            if attribute is None:
                raise AttributeNotFound(f"to_json() error, attribute {attribute_name!r} not found!")
            json_string.append(attribute.to_json())
        return "{" + ", ".join(json_string) + "}"


class EmptyData(Data):
    """Empty Data."""

    @classmethod
    def __get_validators__(cls):
        """Get validators of the type EmptyData class."""
        # one or more validators may be yielded which will be called in the
        # order to validate the input, each validator will receive as an input
        # the value returned from the previous validator
        yield cls.validate

    @classmethod
    def validate(cls, value):
        """Validate the type EmptyData class."""
        if not isinstance(value, EmptyData):
            raise TypeError("EmptyData required")
        return value

    def __init__(self) -> None:
        """Instantiate a new EmptyData class."""
        super().__init__(descriptor=DataDescriptor(description="Empty data"))

    def __repr__(self) -> str:
        """Return the string representation of the object."""
        return self.__class__.__name__ + "()"

    def get(self) -> None:
        """Return None."""

    def set(self, **kwargs: Any) -> None:
        """Do nothing."""


class EmptyDataType(DataType):
    """Empty DataType."""

    def __new__(cls) -> EmptyDataType:
        """Instantiate a new EmptyDatatype."""
        obj = super().__new__(cls)
        setattr(obj, "_DataType__data", EmptyData())
        setattr(obj, "_DataType__filetype", None)
        setattr(
            obj,
            "_DataType__descriptor",
            DataTypeDescriptor(
                name="Empty Datatype", byte_header=b"", descriptor=DataDescriptor(description="Empty data")
            ),
        )
        return obj

    @property
    def extension(self) -> str:
        """Get the __extension private attribute."""
        return ""

    @property
    def mime(self) -> str:
        """Get the __mime private attribute."""
        return ""

    @property
    def descriptor(self) -> DataTypeDescriptor:
        """Get the __descriptor private attribute."""
        return getattr(self, "_DataType__descriptor")

    def encode(self, data: Any) -> Any:
        """Encode the file type."""
        return None

    def decode(self) -> None:
        """Encode the file type."""
        return None

    def get_data(self) -> Any:
        """Get the data."""

    def set_data(self) -> Any:
        """Set the data and check validity against the datatype."""


class DataLoader(BaseModel):
    """Data loader."""

    datatype: DataType

    @classmethod
    def load(cls, file: FileType) -> DataLoader:
        """Instantiate a new DataLoader."""
        return DataLoader(datatype=EmptyDataType())
